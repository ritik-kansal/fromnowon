<?php
function emember_custom_field_settings(){
	global $emember_config;
	if(isset($_POST['info_update'])){
		unset($_POST['info_update']);
		$fields = $_POST;
		update_option('emember_custom_field_type', $_POST);
	}
	else{
		$fields = get_option('emember_custom_field_type');
		
	}
	$fields['emember_field_name'] = array_values($fields['emember_field_name']);
	$fields['emember_field_type'] = array_values($fields['emember_field_type']);
	
	$fields['emember_field_requred'] = array_values($fields['emember_field_requred']);
	$fields['emember_field_extra'] = array_values($fields['emember_field_extra']);	
	?>
    <form id="emember-dyn-form" method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">   
	    <div class="wrap"><h3>WP eMembers - Custom Fields Settings</h3>
			<div id="poststuff">
				<div id="post-body">    
				    <p>For detailed documentation, information and updates, please visit the    <a href="http://tipsandtricks-hq.com/wordpress-membership">WP eMember HomePage</a></p>     
				    <p>For Dropdown field types, write down key=>value pairs as a comma separated list in the "extra field info" field. (i.e 1=>option1,2=>option2)</p>
			              <fieldset class="inlineLabels" id="cfU-204BD901-09C4-BEF8-6008F40594EA946F">
								<div id="add-name-container" class="add-field-container">
									<span class="add-field-trigger">
										<img src="<?php echo WP_EMEMBER_URL;?>/images/add.gif" alt="" title="Add New Item" />
										Add Custom Field
									</span>
								</div>			              
							<div class="ctrlHolder">
							    <?php
							    $i =0; 
							    do{
							    	echo $fields['emember_field_name'][$i] .'<br/>';
							    ?>
								<div id="removable-name-container-<?php echo ($i+1);?>" class="postbox">
								<table width="100%" border="0" cellspacing="0" cellpadding="6">
									<tr>
										<td>
											<label for="emember_field_name_<?php echo ($i+1);?>">Field Name</label>
										</td>
										<td>
											<input type="text" name="emember_field_name[<?php echo $i?>]" id="name_<?php echo ($i+1);?>" value="<?php echo $fields['emember_field_name'][$i];?>" class="textInput removable" />
											<input <?php echo isset($fields['emember_field_requred'][$i])?"checked='checked'":"";?> type="checkbox" name="emember_field_requred[<?php echo $i?>]" id="required_<?php echo ($i+1);?>" value="checked" class="textInput" /> required.
										</td>
										<td></td>
									</tr>																
									<tr>
										<td>
											<label for="emember_field_type_<?php echo ($i+1);?>">Field Type</label>
										</td>
										<td>
											<select  name="emember_field_type[<?php echo $i?>]" id="emember_field_type_<?php echo ($i+1);?>" class="textInput removable" >
												<option <?php echo (isset($fields['emember_field_type'][$i]) &&($fields['emember_field_type'][$i]=='text'))?"selected='selected'":"";?> value="text">Text</option>
												<option <?php echo (isset($fields['emember_field_type'][$i]) &&($fields['emember_field_type'][$i]=='dropdown'))?"selected='selected'":"";?> value="dropdown">Dropdown List</option>
												<option <?php echo (isset($fields['emember_field_type'][$i]) &&($fields['emember_field_type'][$i]=='checkbox'))?"selected='selected'":"";?> value="checkbox">Checkbox</option>
												<option <?php echo (isset($fields['emember_field_type'][$i]) &&($fields['emember_field_type'][$i]=='textarea'))?"selected='selected'":"";?> value="textarea">Text Area</option>
											</select>
										</td>
										<td></td>
									</tr>
									<tr>
										<td>
											<label for="name_<?php echo ($i+1);?>">Extra Field Info</label>
										</td>
										<td>
											<textarea name="emember_field_extra[<?php echo $i?>]" id="extra_<?php echo ($i+1);?>"  rows="1" cols="70"  class="textInput removable" ><?php echo $fields['emember_field_extra'][$i];?></textarea>
										</td>
										<td></td>									
									</tr>
								</table>	
									<img class="emember_remove_segment" src="<?php echo WP_EMEMBER_URL;?>/images/spacer.gif" width="16" height="16" alt="" title="Remove This Item" class="" />
								</div>
								<?php
								 $i++;
                                }while($i<count($fields['emember_field_name']));

								?>
							</div>
						   </fieldset>
						 <div class="submit">
						 <input type="submit"  name="info_update" value="<?php _e('Update options'); ?> &raquo;" />
						 </div>    						
					</div>
				</div>
		</div>			
		</form> 
<script type="text/javascript">
   ;(function($){
		$(document).ready(function(){
			$('form').submit(function(){
				var $ok = true;
				$('input[type=text]').each(function(){
					if($(this).val()==""){
						$ok = false;
						return false;
					}
				});
				return $ok;
			});
			$("button[name='cancel']").click(function() {
				var input = $(':input');
				input.each(function(i) {
					$(this).rules('remove');
				});				
				$(':input').removeClass('required').addClass('ignore');
				$('#emember-dyn-form').validate({ignore: '.ignore'});
			});
			
			$("#emember-dyn-form #removable-name-container-1").dynamicField({
				removeImgSrc:'<?php echo WP_EMEMBER_URL;?>/images/cross.png',
				spacerImgSrc:'<?php echo WP_EMEMBER_URL;?>/images/spacer.gif'
			});	
	    });		   
    })(jQuery);
</script>
    	
	<?php 	
}