<?php
include_once('../../../../wp-load.php');

function eMember_handle_subsc_signup_stand_alone($ipn_data,$subsc_ref,$unique_ref,$eMember_id='')
{
    global $wpdb;
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    	
    $email = $ipn_data['payer_email'];
    $query_db = $wpdb->get_row("SELECT * FROM $members_table_name WHERE email = '$email'", OBJECT);
	//if (!empty($eMember_id))
	if ($query_db)
	{
		$eMember_id = $query_db->member_id;
		// upgrade the member account
		$account_state = 'active';
		$membership_level = $subsc_ref;
		$subscription_starts = (date ("Y-m-d"));
		$subscr_id = $unique_ref;
		$updatedb = "UPDATE $members_table_name SET account_state='$account_state',membership_level='$membership_level',subscription_starts='$subscription_starts',subscr_id='$subscr_id' WHERE member_id='$eMember_id'";    	
    	$results = $wpdb->query($updatedb);
    	
    	$email = $ipn_data['payer_email'];
		$subject = "Member Account Upgraded";//get_option('eMember_email_subject');
		$body = "Your account has been upgraded successfully";//get_option('eMember_email_body');
		$from_address = get_option('senders_email_address');
		$email_body = $body;
	    $headers = 'From: '.$from_address . "\r\n";   
	     
    	//If using the WP user integration then update the role on WordPress too
    	$membership_level_table = $wpdb->prefix . "wp_eMember_membership_tbl";
    	if($config->getValue('eMember_create_wp_user'))
    	{
			eMember_debug_log_subsc("Updating WordPress user role...",true);
			$resultset = $wpdb->get_row("SELECT * FROM $members_table_name where member_id='$eMember_id'", OBJECT);
    		$membership_level = $resultset->membership_level;
    		$username = $resultset->user_name;
    		eMember_debug_log_subsc("Current users username:".$username." and membership level is:".$membership_level,true);
	        $membership_level_resultset = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$membership_level'", OBJECT);
	                                                                         
			$wp_user_id = $username;
	        $wp_user_info  = array();
	        $wp_user_info['user_nicename'] = $username;
	        $wp_user_info['display_name']  = $username;
	        $wp_user_info['nickname']      = $username;
	        $wp_user_info['user_email']    = $resultset->email;
	        //$wp_user_info['user_pass']     = "We dont know the password";//we don't want to update the password anyway.                       
	        $wp_user_info['ID']            = $wp_user_id;
	        $wp_user_info['role']            = $membership_level_resultset->role;
	        $wp_user_info['user_registered'] = date('Y-m-d H:i:s');                                        
	        wp_update_user($wp_user_info);
	        update_wp_user_Role($wp_user_id, $membership_level_resultset->role);  
	        eMember_debug_log_subsc("Current users role updated.",true);
    	} 	    	
	}
	else
	{
		// create new member account
		$user_name ='';
		$password = '';
	
		$first_name = $ipn_data['first_name'];
		$last_name = $ipn_data['last_name'];
		$email = $ipn_data['payer_email'];
		$membership_level = $subsc_ref;
		$subscr_id = $unique_ref;
		
		eMember_debug_log_subsc("Membership level ID: ".$membership_level,true);
		
	    $address_street = $ipn_data['address_street'];
	    $address_city = $ipn_data['address_city'];
	    $address_state = $ipn_data['address_state'];
	    $address_zipcode = $ipn_data['address_zip'];
	    $country = $ipn_data['address_country'];
	
		$date = (date ("Y-m-d"));
		$account_state = 'active';
		$reg_code = uniqid();//rand(10, 1000);
		$md5_code = md5($reg_code);
	
	    $updatedb = "INSERT INTO $members_table_name (user_name,first_name,last_name,password,member_since,membership_level,account_state,last_accessed,last_accessed_from_ip,email,address_street,address_city,address_state,address_zipcode,country,gender,referrer,extra_info,reg_code,subscription_starts,txn_id,subscr_id) VALUES ('$user_name','$first_name','$last_name','$password', '$date','$membership_level','$account_state','$date','IP','','$address_street','$address_city','$address_state','$address_zipcode','$country','','','','$reg_code','$date','','$subscr_id')";
	    $results = $wpdb->query($updatedb);
	
		$results = $wpdb->get_row("SELECT * FROM $members_table_name where subscr_id='$subscr_id' and reg_code='$reg_code'", OBJECT);
	
		$id = $results->member_id;
		
	    $separator='?';
		$url=get_option('eMember_registration_page');
		if(strpos($url,'?')!==false)
		{
			$separator='&';
		}
		$reg_url = $url.$separator.'member_id='.$id.'&code='.$md5_code;
		eMember_debug_log_subsc("Member signup URL :".$reg_url,true);
	
		$subject = get_option('eMember_email_subject');
		$body = get_option('eMember_email_body');
		$from_address = get_option('senders_email_address');
	
	    $tags = array("{first_name}","{last_name}","{reg_link}");
	    $vals = array($first_name,$last_name,$reg_url);
		$email_body    = str_replace($tags,$vals,$body);
	    $headers = 'From: '.$from_address . "\r\n";
	}

        wp_mail($email,$subject,$email_body,$headers);
        eMember_debug_log_subsc("Member signup/upgrade completion email successfully sent",true);

}

function eMember_handle_subsc_cancel_stand_alone($ipn_data)
{
    $subscr_id = $ipn_data['subscr_id'];    

    global $wpdb;
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    $membership_level_table   = $wpdb->prefix . "wp_eMember_membership_tbl";
    
    eMember_debug_log_subsc("Retrieving member account from the database...",true);
    $resultset = $wpdb->get_row("SELECT * FROM $members_table_name where subscr_id='$subscr_id'", OBJECT);
    if($resultset)
    {
    	$membership_level = $resultset->membership_level;
    	$level_query = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$membership_level'", OBJECT);
    	if ($level_query->subscription_period == 0)
    	{
    		//subscription duration is set to no expiry or until canceled so deactivate the account now
    		$account_state = 'inactive';
		    $updatedb = "UPDATE $members_table_name SET account_state='$account_state' WHERE subscr_id='$subscr_id'";
		    $results = $wpdb->query($updatedb);    		
		    eMember_debug_log_subsc("Subscription cancellation received! Member account deactivated.",true);
    	}
    	else
    	{
    		//Set the account to unsubscribed and it will be set to inactive when the "Subscription duration" is over	
    		$account_state = 'unsubscribed';    
		    $updatedb = "UPDATE $members_table_name SET account_state='$account_state' WHERE subscr_id='$subscr_id'";
		    $results = $wpdb->query($updatedb);    		
		    eMember_debug_log_subsc("Subscription cancellation received! Member account set to unsubscribed.",true);
    	}
    }
    else
    {
    	eMember_debug_log_subsc("No member found for the given subscriber ID:".$subscr_id,false);
    	return;
    }      	
}

function eMember_debug_log_subsc($message,$success,$end=false)
{
    // Timestamp
    $text = '['.date('m/d/Y g:i A').'] - '.(($success)?'SUCCESS :':'FAILURE :').$message. "\n";
    if ($end) {
    	$text .= "\n------------------------------------------------------------------\n\n";
    }
    // Write to log
    $fp=fopen("subscription_handle_debug.log",'a');
    fwrite($fp, $text );
    fclose($fp);  // close file
}
?>