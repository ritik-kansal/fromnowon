<?php
/*
Plugin Name: WP eMember
Version: v6.0.9
Plugin URI: http://www.tipsandtricks-hq.com/?p=1059
Author: Ruhul Amin & Nur Hasan
Author URI: http://www.tipsandtricks-hq.com/
Description: Simple WordPress Membership plugin to add Membership functionality to your wordpress blog.
*/

define('WP_EMEMBER_VERSION', "6.0.9");

include_once('wp_eMember1.php');

//Installer
function wp_eMember_install ()
{
	require_once(dirname(__FILE__).'/eMember_installer.php');
}
register_activation_hook(__FILE__,'wp_eMember_install');

?>