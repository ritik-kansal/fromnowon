<?php
function free_rego_with_email_confirmation_handler()
{
	$error_message = "";
	if(isset($_POST['eMember_Register_with_confirmation']))
	{
		if(!empty($_POST['aemail']) && !empty($_POST['afirstname']) && !empty($_POST['alastname']))
		{
			// create new member account and send the registration completion email
			global $emember_config,$wpdb;
			
			if(emember_email_exists($_POST['aemail']))
			{
				$error_message = "<p style='color:red;'><strong>".EMEMBER_EMAIL_TAKEN."</strong></p>";
			}
	    	else
	    	{
				$fields = array();
				$fields['user_name'] = '';
				$fields['password'] = '';
				$fields['first_name'] = $_POST['afirstname'];
				$fields['last_name'] = $_POST['alastname'];
				$fields['email'] = $_POST['aemail'];
				
				$fields['member_since'] = (date ("Y-m-d"));
				$fields['subscription_starts'] = date("Y-m-d");
				
				$fields['membership_level'] = $emember_config->getValue('eMember_free_membership_level_id');
				
				$fields['account_state'] = 'active';
				
				$reg_code = uniqid(); //rand(10, 1000);
				$md5_code = md5($reg_code);
				$fields['reg_code'] = $reg_code;
				
				$ret = dbAccess::insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
				
				$resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME,' reg_code=\''.$reg_code.'\'');
				$id = $resultset->member_id;
					
			    $separator='?';
				$url = $emember_config->getValue('eMember_registration_page');
				if(strpos($url,'?')!==false)
				{
					$separator='&';
				}
				$reg_url = $url.$separator.'member_id='.$id.'&code='.$md5_code;
			
				$subject = $emember_config->getValue('eMember_email_subject');
				$body = $emember_config->getValue('eMember_email_body');
				$from_address = $emember_config->getValue('senders_email_address');
			
			    $tags = array("{first_name}","{last_name}","{reg_link}");
			    $vals = array($_POST['afirstname'],$_POST['alastname'],$reg_url);
				$email_body = str_replace($tags,$vals,$body);
			    $headers = 'From: '.$from_address . "\r\n";
				
		        wp_mail($_POST['aemail'],$subject,$email_body,$headers);
		        $output = "<br /><strong>".EMEMBER_PLEASE_CHECK_YOUR_INBOX."</strong><br /><br />";
		        return $output;
	    	}
		}
		else
		{
			$error_message = "<p style='color:red;'><strong>".EMEMBER_YOU_MUST_FILL_IN_ALL_THE_FIELDS."</strong></p>";
		}
    }
    	
	ob_start();
	echo $error_message;
    ?>
    <form action="" method="post" name="regoFormWithConfirmation" id="regoFormWithConfirmation" >	
    <table width="95%" border="0" cellpadding="3" cellspacing="3" class="forms">
    <tr>
       <td><label for="afirstname" class="eMember_label"><?php echo EMEMBER_FIRST_NAME;?>: </label></td>
       <td>
         <input type="text" id="afirstname" name="afirstname" size="20" value="<?php echo $_POST['afirstname'];?>" class="eMember_text_input" />
       </td>
    </tr>
    <tr>
       <td><label for="alastname" class="eMember_label"><?php echo EMEMBER_LAST_NAME ?>: </label></td>
       <td><input type="text" id="alastname" name="alastname" size="20" value="<?php echo $_POST['alastname'];?>" class="eMember_text_input" /></td>
    </tr>
    <tr>
       <td><label for="aemail" class="eMember_label"><?php echo EMEMBER_EMAIL;?>*: </label></td>
       <td><input type="text" id="aemail" name="aemail" size="20" value="<?php echo $_POST['aemail'];?>" class="eMember_text_input" /></td>
    </tr>
    <tr>
    	<td></td>
    	<td><input class="eMember_button" name="eMember_Register_with_confirmation" type="submit" id="eMember_Register_with_confirmation" value="<?php echo EMEMBER_REGISTRATION;?>" /></td>
    </tr>                
    </table>
    </form>
    <?php
    $output = ob_get_contents();
    ob_end_clean();    
    return $output;    
}

function show_login_form()
{  
   global $emember_config;	 
   global $emember_auth;
   $msg = ($emember_auth->getCode()!=1)?  $emember_auth->getMsg(): '';
   $join_url = $emember_config->getValue('eMember_payments_page');   
   ob_start();
   ?>
    <form action="" method="post" class="loginForm" name="loginForm" id="loginForm" >
	<table width="95%" border="0" cellpadding="3" cellspacing="5" class="forms">
	    <tr>
	    	<td colspan="2"><label for="login_user_name" class="eMember_label"> <?php echo EMEMBER_USER_NAME;  ?></label></td>
	    </tr>
	    <tr>
	        <td colspan="2"><input class="eMember_text_input" type="text" id="login_user_name" name="login_user_name" size="15" value="<?php echo $_POST['login_user_name'];?>" /></td>
	    </tr>
	    <tr>
	    	<td colspan="2"><label for="login_pwd" class="eMember_label"> <?php echo EMEMBER_PASSWORD;?></label></td></tr>
	    <tr>
	        <td colspan="2"><input class="eMember_text_input" type="password" id="login_pwd" name="login_pwd" size="15" value="<?php echo $_POST['login_pwd'];?>" /></td>
	    </tr>
	    <tr>
	        <td><label><input type="checkbox" tabindex="90" value="forever" id="rememberme" name="rememberme" /> <?php echo EMEMBER_REMEMBER_ME;?></label></td>
	    </tr>
	    <tr>
	        <td colspan="2">
	        <input type="hidden" value="1" name="testcookie" />
	        <input name="doLogin" type="submit" id="doLogin" class="eMember_button" value="<?php echo EMEMBER_LOGIN;?>" />
	        </td>	       
	    </tr>
	    <tr> 
	        <td colspan="2">&raquo; <a id="forgot_pass" rel="#prompt" class="forgot_pass_link" href="javascript:void(0);"> <?php echo EMEMBER_FORGOT_PASS;?></a></td>
	    </tr>
	    <tr> 
	        <td colspan="2">&raquo; <a id="register" class="register_link" href="<?php echo $join_url; ?>"><?php echo EMEMBER_JOIN_US;?></a></td>
	    </tr>
	    <tr>
	    	<td colspan="2"><span style="color:red"> <?php echo $msg;?> </span></td>
	    </tr>
	</table>
	</form>   
   <?php 
    $output = ob_get_contents();
    ob_end_clean();
	return $output;
}

function print_eMember_bookmark_list()
{
    global $emember_auth;
    global $emember_config;
    $enable_bookmark = $emember_config->getValue('eMember_enable_bookmark');
    if(!$enable_bookmark) return EMEMBER_BOOKMARK_DISABLED;
    if($emember_auth->isLoggedIn())
    {
        $bookmarks = $emember_auth->getUserInfo('extra_info');
        if(empty($bookmarks))
        {
            return EMEMBER_NO_BOOKMARK;
        }
        else
        {
            $return = '<form method="post"><table>';
            $bookmarks = unserialize($bookmarks);
            $counter = 1;
            foreach($bookmarks['bookmarks'] as $key)
            {    
                $c = ($counter%2)? 'style="background:#E8E8E8;"' : '';
                $return .= '<tr '. $c .' ><td>'.$counter.'</td><td width=350px><a target= "_blank" href="' . get_permalink($key) . '">' . get_the_title($key) . '</a> </td>';
                $return .= '<td><input type="checkbox" name=del_bookmark[] value="'.$key.'" ></td><tr>';
                $counter++;
            }
            $return .= '<tr ><td colspan="3" align="left"><input type="submit" name="remove_bookmark" value="Remove" /></td></tr>';
            $return .= '</table>';            
            $return .= '</form>';
            return $return;
        }    
    }
    else
    {
        return EMEMBER_BOOKMARK_NOT_LOGGED_IN;        
    }
    
}
function show_registration_form($level=0)
{
	global $emember_config;
	
	$blacklisted_ips    = $emember_config->getValue('blacklisted_ips');
	$blacklisted_ips = empty($blacklisted_ips)? array(): explode(';',$blacklisted_ips);
	
	$current_ip = get_real_ip_addr();
	if(in_array($current_ip, $blacklisted_ips))
		return '<span style="color:red">' .EMEMBER_IP_BLACKLISTED. ' </span>'; 
    if(!function_exists('recaptcha_check_answer'))
        require_once(WP_PLUGIN_DIR.'/'.WP_EMEMBER_FOLDER.'/recaptchalib.php');         

    $output     = '';
    $eMember_id = $_GET["member_id"];
    $code       = $_GET["code"];
    $recaptcha_error = null;
    $resp = null;    
    global $wpdb;
    $is_reg_successfull = false;
    if(isset($_POST['eMember_Register']))    
    {
    	$dc = $_POST['aemail'].$_POST['user_name'].$_POST['pwd'];
    	if(isset($_SESSION['emember_dc'])){
    		if($_SESSION['emember_dc']==$dc&&((time()-$_SESSION['time'])<100)){
    		    if(isset($_SESSION['msg'])&&$_SESSION['msg'])
    		        $output .= '<br/>'.EMEMBER_REG_COMPLETE;
    		    else {
	                $output .= eMember_reg_form();
	                $output .= '<span style="color:red">Something went wrong. </span>';    		    	
    		    } 
    		    return $output;
    		}
    		else{
    		   $_SESSION['time'] = time();
    		   $_SESSION['emember_dc'] = $dc;
    		}
    	}
    	else {
    		$_SESSION['time'] = time();
    	    $_SESSION['emember_dc'] = $dc;
    	}
		$blacklisted_emails = $emember_config->getValue('blacklisted_emails');	  
        $blacklisted_emails = empty($blacklisted_emails)? array(): explode(';',$blacklisted_emails);
        foreach($blacklisted_emails as $email)
        {
        	if((!empty($email))&&stristr($_POST['aemail'],$email))
        	{
        		return '<span style="color:red"> '. EMEMBER_EMAIL_BLACKLISTED.' </span>';
        	}
        }
        
        $enable_recaptcha = $emember_config->getValue('emember_enable_recaptcha');
        if($enable_recaptcha)
        {
            if(isset($_POST["recaptcha_response_field"]))
            {
                $recaptcha_private_key = $emember_config->getValue('emember_recaptcha_private');            
                $resp = recaptcha_check_answer ($recaptcha_private_key,
                                                $_SERVER["REMOTE_ADDR"],
                                                $_POST["recaptcha_challenge_field"],
                                                $_POST["recaptcha_response_field"]);
                if(!$resp->is_valid)
                {
                    $recaptcha_error = $resp->error;
                    $output .= eMember_reg_form($recaptcha_error);                
                }            
            }
            else
            {
                $output .= '<span style="color:red">reCAPTCHA&trade; service encountered error. please Contact Admin. </span>';                
            }
            
        }
        if(!$enable_recaptcha||($resp && $resp->is_valid))
        {
            include_once(ABSPATH . WPINC . '/class-phpass.php'); 
            require_once( ABSPATH . WPINC . '/registration.php' );
            $wp_hasher = new PasswordHash(8, TRUE);
            $password = $wp_hasher->HashPassword($_POST['pwd']);                      
            if (username_exists($_POST['user_name'])||emember_username_exists($_POST['user_name']))
            {
                $output .= eMember_reg_form();
                $output .= '<span style="color:red">'.EMEMBER_USER_NAME_TAKEN.' </span>';
            }
            else if(email_exists($_POST['aemail'])||emember_registered_email_exists($_POST['aemail']))
            {
                $output .= eMember_reg_form();
                $output .= '<span style="color:red">'.EMEMBER_EMAIL_TAKEN.'</span>';
            }
            else
            {  
            	if (!empty($_SESSION['eMember_id']) && !empty($_SESSION['reg_code']))
            	{
                     /*************************/
                    $fields = array();
                    $fields['user_name'] = $_POST['user_name'];
                    $fields['password']  = $password;
                    $fields['email']     = $_POST['aemail'];
                    $fields['reg_code']  = '';
                    $fields['last_accessed_from_ip']= get_real_ip_addr();
                    $wp_user_id = username_exists($fields['user_name']);
                    if($wp_user_id) 
                    {
	                	$role_names = array(1=>'Administrator',2=>'Editor',3=>'Author',4=>'Contributor',5=>'Subscriber');                	
						$membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" .$fields['membership_level'] . "'" );						                	
                    	
                        $wp_user_info  = array();
                        $wp_user_info['user_nicename'] = $_POST['user_name'];
                        $wp_user_info['display_name']  = $_POST['user_name'];
                        $wp_user_info['nickname']      = $_POST['user_name'];
                        $wp_user_info['user_email']    = $_POST['aemail'];
                        $wp_user_info['user_pass']     = $_POST['pwd'];                        
                        $wp_user_info['ID']            = $wp_user_id;
	        			$wp_user_info['role']            = $membership_level_resultset->role;
    	    			$wp_user_info['user_registered'] = date('Y-m-d H:i:s');                	
                        
                        wp_update_user( $wp_user_info );
                        update_wp_user_Role($wp_user_id, $membership_level_resultset->role);
                    }
                    
                    $ret = dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id='. $wpdb->escape($eMember_id), $fields);
                    /*************************/
                    if($ret === false)
                    {
                        $output .= '<br /> ' . 'Failed';
                        $is_reg_successfull = false;
                    }
                    else
                    {
			            if(isset($_POST['emember_custom']))
			                $wpdb->query('UPDATE ' . WP_EMEMBER_MEMBERS_META_TABLE . 
			                ' SET meta_value ='. '\''.serialize($_POST['emember_custom']). 
			                '\' WHERE meta_key = \'custom_field\' AND  user_id=' . $eMember_id);
		                
                        unset($_SESSION['eMember_id']);
                        unset($_SESSION['reg_code']);
                        unset($_SESSION['eMember_resultset']);
                        // We can maybe log this person in at this stage and redirect to the $redirect_page automatically here
                        $output .= '<br /> ' . EMEMBER_REG_COMPLETE;
                        $_SESSION['msg'] = true;
                        $is_reg_successfull = true;
                    }
            	}
            	else
            	{
            		//Create a new account for a free member or the level specified in the shortcode    	    
                    $fields = array();
                    $fields['user_name']           = $_POST['user_name'];
                    $fields['password']            = $password;
                    if(isset($_POST['afirstname']))$fields['first_name'] 		  = $_POST['afirstname'];
                    if(isset($_POST['alastname']))$fields['last_name']   		  = $_POST['alastname'];
		            if(isset($_POST['phone']))$fields['phone']                    = $_POST['phone'];
		            if(isset($_POST['emember_street']))$fields['address_street']  = $_POST['emember_street'];
		            if(isset($_POST['emember_city']))$fields['address_city']      = $_POST['emember_city'];
		            if(isset($_POST['emember_state']))$fields['address_state']    = $_POST['emember_state'];
		            if(isset($_POST['emember_zipcode']))$fields['address_zipcode']= $_POST['emember_zipcode'];
		            if(isset($_POST['emember_country']))$fields['country']        = $_POST['emember_country'];
		            if(isset($_POST['emember_gender']))$fields['gender']          = $_POST['emember_gender'];  
		            if(isset($_POST['company_name']))$fields['company_name']      = $_POST['company_name'];          
                    
                    $fields['member_since']        = (date ("Y-m-d"));
                    $fields['subscription_starts'] = date("Y-m-d");

                    if(isset($_POST['custom_member_level_shortcode']))
                    {
                    	$fields['membership_level']    = $_POST['custom_member_level_shortcode'];
                    }
                    else
                    {
                    	$fields['membership_level']    = $emember_config->getValue('eMember_free_membership_level_id');
                    }
                    
                    $fields['account_state']       = 'active';
                    $fields['email']               = $_POST['aemail'];
                    $fields['last_accessed_from_ip']= get_real_ip_addr();
                    $ret = dbAccess::insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
                    $lastid = $wpdb->insert_id;
                    if(isset($_POST['emember_custom']))
                    $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . 
                    '( user_id, meta_key, meta_value ) VALUES(' . $lastid .',\'custom_field\',' . '\''.serialize($_POST['emember_custom']).'\')');
                    
                    if($ret === false)
                    {
	                    $output .= '<br />' .'Failed.';
	                    $is_reg_successfull = false;                    	
                    }
                    else
                    {   $_SESSION['msg'] = true;                                     
	                    $output .= '<br />' .EMEMBER_REG_COMPLETE;
	                    $is_reg_successfull = true;
                    }
                }
                if($is_reg_successfull)
                { 
                	
                	// Create the corresponding wordpress user
                    $should_create_wp_user = $emember_config->getValue('eMember_create_wp_user');
                    if($should_create_wp_user) 
                    {
	                	$role_names = array(1=>'Administrator',2=>'Editor',3=>'Author',4=>'Contributor',5=>'Subscriber');                	
						$membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" .$fields['membership_level'] . "'" );						                	                    
                        $wp_user_info  = array();
                        $wp_user_info['user_nicename'] = $_POST['user_name'];
                        $wp_user_info['display_name']  = $_POST['user_name'];
                        $wp_user_info['nickname']      = $_POST['user_name'];
                        $wp_user_info['first_name']    = $_POST['afirstname'];
                        $wp_user_info['last_name']     = $_POST['alastname'];
	        			$wp_user_info['role']            = $membership_level_resultset->role;
    	    			$wp_user_info['user_registered'] = date('Y-m-d H:i:s');                	
                        
                        $wp_user_id = wp_create_user($_POST['user_name'], $_POST['pwd'], $_POST['aemail']);                        
                        $wp_user_info['ID'] = $wp_user_id;
                        wp_update_user( $wp_user_info );
                        update_wp_user_Role($wp_user_id, $membership_level_resultset->role);
                    }
                    //-----------------            	
                    $subject_rego_complete = $emember_config->getValue('eMember_email_subject_rego_complete');			
                    $body_rego_complete    = $emember_config->getValue('eMember_email_body_rego_complete');			
                    $from_address          = $emember_config->getValue('senders_email_address');			
                    $login_link            = $emember_config->getValue('login_page_url');			
                    $tags1                 = array("{first_name}","{last_name}","{user_name}","{password}","{login_link}");			
                    $vals1                 = array($_POST['afirstname'],$_POST['alastname'],$_POST['user_name'],$_POST['pwd'],$login_link);			
                    $email_body1           = str_replace($tags1,$vals1,$body_rego_complete);			
                    $headers               = 'From: '.$from_address . "\r\n";			
                    wp_mail($_POST['aemail'],$subject_rego_complete,$email_body1,$headers); 
                    if ($emember_config->getValue('eMember_admin_notification_after_registration'))
                    {
                    	$admin_email = get_option('admin_email');
                    	$admin_notification_subject = EMEMBER_NEW_ACCOUNT_MAIL_HEAD;
                    	$admin_email_body = EMEMBER_NEW_ACCOUNT_MAIL_BODY.
                    						"\n\n-------Member Email----------\n".
                    						$email_body1.
                    						"\n\n------End------\n";
                    	wp_mail($admin_email,$admin_notification_subject,$admin_email_body,$headers);
                    }
                    //Create the corresponding affliate account
                    if($emember_config->getValue('eMember_auto_affiliate_account'))
                    {
                        eMember_handle_affiliate_signup($_POST['user_name'],$_POST['pwd'],$_POST['afirstname'],$_POST['alastname'],$_POST['aemail'],eMember_get_aff_referrer());
                    }
                    
                    /*** Signup the member to Autoresponder List (Autoresponder integration) ***/
                    eMember_global_autoresponder_signup($_POST['afirstname'],$_POST['alastname'],$_POST['aemail']);  
				    /*** end of autoresponder integration ***/                

                    $redirect_page = $emember_config->getValue('login_page_url');
                    if (!empty($redirect_page)) $output .= EMEMBER_PLEASE.' <a href="'.$redirect_page.'">'.EMEMBER_LOGIN.'</a>';    	                                                                    
                }
                else
                {
                    $output .= "<b><br/>Something went wrong. Please Contact <a href='mailto:".get_bloginfo('admin_email')."'>Admin.</a></b>";
                }                    
            }
        }
    }
	else
	{
		if (!empty($eMember_id) && !empty($code))
		{
            $resultset = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME,' member_id='. $wpdb->escape($eMember_id));
		    $md5code = md5($resultset->reg_code);
		    if ($code == $md5code)
		    {
                $free_member_level = $resultset->membership_level;
                $level_resultset   = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE,' id='.$wpdb->escape($free_member_level));
                $_POST['member_level']         = $level_resultset->alias;
		    	$_POST['afirstname']           = $resultset->first_name;
		    	$_POST['alastname']            = $resultset->last_name;
		    	$_POST['aemail']               = $resultset->email;
				$_SESSION['eMember_id']        = $eMember_id;
				$_SESSION['reg_code']          = $code;
		    	$_SESSION['eMember_resultset'] = $resultset;
		    	$output .= "<br />" . EMEMBER_USER_PASS_MSG;
		    	$output .= eMember_reg_form($recaptcha_error);
		    }
		}
		else if($emember_config->getValue('eMember_enable_free_membership'))
		{
			if(isset($_POST['custom_member_level_shortcode'])){
				$level = $_POST['custom_member_level_shortcode'];
			}			
			if($level != 0)
			{
				$level_resultset   = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE,' id='.$wpdb->escape($level));
			}
			else
			{
	            $free_member_level = $emember_config->getValue('eMember_free_membership_level_id');
	            if(empty($free_member_level)) return "<b>Free Membership Level ID is not set. Please Contact Admin.</b>";
	            if(!is_numeric($free_member_level)) return "<b>Free Membership Level Should be Numeric.Please Contact Admin.</b>";
	            $level_resultset   = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE,' id='.$wpdb->escape($free_member_level));
			}
            $_POST['member_level'] = $level_resultset->alias;
			$output .= eMember_reg_form($recaptcha_error,$level);					
		}
		else
		{
			//Free membership is disabled
			$output .= EMEMBER_FREE_MEMBER_DISABLED;
			$payment_page = $emember_config->getValue('eMember_payments_page');
			if (!empty($payment_page))
			{
				$output .= '<br />'.EMEMBER_VISIT_PAYMENT_PAGE.'.'.EMEMBER_CLICK.' <a href="'.$payment_page.'">'.EMEMBER_HERE.'</a>';
			}
		}
	}
	return $output;
}
function update_wp_user_Role($wp_user_id, $role)
{
    	update_usermeta($wp_user_id,'wp_capabilities', array($role=>true));
         $roles = new WP_Roles();
         $level = $roles->roles[$role]['capabilities'];
         if(isset($level['level_10']) &&$level['level_10'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 10);
         	return;
         }
         if(isset($level['level_9']) &&$level['level_9'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 9);
         	return;
         }
         if(isset($level['level_8']) &&$level['level_8'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 8);
         	return;
         }
         if(isset($level['level_7']) &&$level['level_7'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 7);
         	return;
         }
         if(isset($level['level_6']) &&$level['level_6'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 6);
         	return;
         }
         if(isset($level['level_5']) &&$level['level_5'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 5);
         	return;
         }
         if(isset($level['level_4']) &&$level['level_4'])
         {         
         	update_usermeta($wp_user_id,'wp_user_level', 4);
         	return;
         }
         if(isset($level['level_3']) &&$level['level_3'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 3);
         	return;
         }                                                
         if(isset($level['level_2']) &&$level['level_2'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 2);
         	return;
         }
         if(isset($level['level_1']) &&$level['level_1'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 1);
         	return;
         }
         if(isset($level['level_0']) &&$level['level_0'])
         {
         	update_usermeta($wp_user_id,'wp_user_level', 0);
         	return;
         }                                          
//		 if(isset()&&$roles->roles['administrator']['capabilities']['level_10'])    	
    /*switch($role)
    {
      	case 1:
  			update_usermeta($wp_user_id,'wp_capabilities', array("administrator"=>true));
   			update_usermeta($wp_user_id,'wp_user_level', 10);                        		
       		break;
       	case 2:
  			update_usermeta($wp_user_id,'wp_capabilities', array("editor"=>true));
   			update_usermeta($wp_user_id,'wp_user_level', 7);                       		                        		
       		break;
       	case 3:
  			update_usermeta($wp_user_id,'wp_capabilities', array("author"=>true));
   			update_usermeta($wp_user_id,'wp_user_level', 2);                        		                        		
       		break;
       	case 4:
  			update_usermeta($wp_user_id,'wp_capabilities', array("contributor"=>true));
   			update_usermeta($wp_user_id,'wp_user_level', 1);                        		                        		
       		break;
       	case 5:
   			update_usermeta($wp_user_id,'wp_capabilities', array("subscriber"=>true));
   			update_usermeta($wp_user_id,'wp_user_level', 0);                        		                        		
       		break;
    }*/
}
function eMember_reg_form($error = null,$level=0)
{	
	global $emember_config;
    $publickey = $emember_config->getValue('emember_recaptcha_public');
    $emember_enable_recaptcha = $emember_config->getValue('emember_enable_recaptcha');
    if(!function_exists('recaptcha_get_html'))
        require_once(WP_PLUGIN_DIR.'/'.WP_EMEMBER_FOLDER.'/recaptchalib.php');         
    ob_start();
    ?>
    <form action="" method="post" name="regoForm" id="regoForm" >    
    <?php if($level!=0){ ?>
    	<input type="hidden" name="custom_member_level_shortcode" value="<?php echo $level; ?>" />
    <?php } ?>
    <table width="95%" border="0" cellpadding="3" cellspacing="3" class="forms">
    <tr>
       <td><label for="user_name"  class="eMember_label"><?php echo EMEMBER_USERNAME;?>*: </label></td>
       <td><input type="text" id="user_name" name="user_name" size="20" value="<?php echo $_POST['user_name'];?>" class="eMember_text_input eMember_required" /></td>
    </tr>
    <tr>
       <td><label for="pwd" class="eMember_label"><?php echo EMEMBER_PASSWORD;?>*: </label></td>
       <td><input type="password" id="pwd" name="pwd" size="20" value="<?php echo $_POST['pwd'];?>" class="eMember_text_input" /></td>
    </tr>    
    <tr>
       <td><label for="aemail" class="eMember_label"><?php echo EMEMBER_EMAIL;?>*: </label></td>
       <td><input type="text" id="aemail" name="aemail" size="20" value="<?php echo $_POST['aemail'];?>" class="eMember_text_input eMember_required" /></td>
    </tr>
    <tr>
       <td><label for="member_level" class="eMember_label"> <?php echo EMEMBER_MEMBERSHIP_LEVEL;?>*: </label></td>
       <td><input type="text" id="member_level" name="member_level" size="20" value="<?php echo $_POST['member_level'];?>" class="eMember_text_input eMember_required" readonly /></td>
    </tr>    
    <?php if($emember_config->getValue('eMember_reg_title')):?>
    <tr>
       <td width="30%"><label for="atitle" class="eMember_label"><?php echo EMEMBER_TITLE;?>: </label></td>
       <td>
       	   <select name="atitle">
               <option value="Mr">Mr</option>
               <option value="Mrs">Mrs</option>
               <option value="Miss">Miss</option>
               <option value="Ms">Ms</option>
               <option value="Dr">Dr</option>
           </select>
       </td>
     </tr>
     <?php endif;?>
     <?php if($emember_config->getValue('eMember_reg_firstname')):?>
    <tr>
       <td><label for="afirstname" class="eMember_label"><?php echo EMEMBER_FIRST_NAME;?>: </label></td>
       <td>
         <input type="text" id="afirstname" name="afirstname" size="20" value="<?php echo $_POST['afirstname'];?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_reg_firstname_required')? 'eMember_required': "";?>" />
       </td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_lastname')):?>
    <tr>
       <td><label for="alastname" class="eMember_label"><?php echo EMEMBER_LAST_NAME ?>: </label></td>
       <td><input type="text" id="alastname" name="alastname" size="20" value="<?php echo $_POST['alastname'];?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_reg_lastname_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_phone')):?>
    <tr>
       <td><label for="aemail" class="eMember_label"><?php echo EMEMBER_PHONE?>: </label></td>
       <td><input type="text" name="phone" size="20" value="<?php echo $_POST['phone']; ?>" class="eMember_text_input  <?php echo $emember_config->getValue('eMember_reg_phone_required')? 'eMember_required': "";?>" /></td>
    </tr>    
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_company')):?>
    <tr>
       <td><label for="company_name" class="eMember_label"><?php echo EMEMBER_COMPANY ?>: </label></td>
       <td><input type="text" name="company_name" size="20" value="<?php echo $_POST['company_name']; ?>" class="eMember_text_input  <?php echo $emember_config->getValue('eMember_reg_company_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_street')):?>    
    <tr>
       <td><label for="emember_street" class="eMember_label"><?php echo EMEMBER_ADDRESS_STREET?>: </label></td>
       <td><input type="text" name="emember_street" size="20" value="<?php echo $_POST['emember_street']; ?>" class="eMember_text_input  <?php echo $emember_config->getValue('eMember_reg_street_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_city')):?>    
    <tr>    
       <td><label for="emember_city" class="eMember_label"><?php echo EMEMBER_ADDRESS_CITY ?>: </label></td>
       <td><input type="text" name="emember_city" size="20" value="<?php echo $_POST['emember_city'];?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_reg_city_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_state')):?>    
    <tr>
       <td><label for="emember_state" class="eMember_label"><?php echo EMEMBER_ADDRESS_STATE ?>: </label></td>
       <td><input type="text" name="emember_state" size="20" value="<?php echo $_POST['emember_state']; ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_reg_state_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_zipcode')):?>    
    <tr>
       <td><label for="emember_zipcode" class="eMember_label"><?php echo EMEMBER_ADDRESS_ZIP ?>: </label></td>
       <td><input type="text" name="emember_zipcode" size="20" value="<?php echo $_POST['emember_zipcode']; ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_reg_zipcode_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_country')):?>
    
    <tr>
       <td><label for="emember_country" class="eMember_label"><?php echo EMEMBER_ADDRESS_COUNTRY ?>: </label></td>
       <td><input type="text" name="emember_country" size="20" value="<?php echo $_POST['emember_country']; ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_reg_country_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_reg_gender')):?>    
	<tr >
		<td > <label for="emember_gender" class="eMember_label"><?php echo EMEMBER_GENDER ?>: </label></td>
		<td>
	   <select name="emember_gender" id="emember_gender">
	      <option  <?php echo (($_POST['emember_gender'] ==='male') ? 'selected=\'selected\'' : '' ) ?> value="male"><?php echo EMEMBER_GENDER_MALE ?></option>
	      <option  <?php echo (($_POST['emember_gender'] ==='female') ? 'selected=\'selected\'' : '' ) ?> value="female"><?php echo EMEMBER_GENDER_FEMALE ?></option>      
	      <option  <?php echo (($_POST['emember_gender'] ==='not specified') ? 'selected=\'selected\'' : '' ) ?> value="not specified"><?php echo EMEMBER_GENDER_UNSPECIFIED ?></option>      
	   </select>
		</td>
	</tr>        
	<?php endif;?>   
	<!--  custom field<?php
	if($emember_config->getValue('eMember_custom_field')):
	$custom_fields = get_option('emember_custom_field_type');
	
	for($i=0; isset($custom_fields['emember_field_name'][$i]); $i++){		
	?> 
	    <tr>
	       <td><label for="<?php echo $custom_fields['emember_field_name'][$i]?>" class="eMember_label"><?php echo  $custom_fields['emember_field_name'][$i]?>: </label></td>
	       <td>
	       <?php
	         switch($custom_fields['emember_field_type'][$i]){
	         	case 'text': 
	       ?>
	       <input type="text" name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" size="20" value="<?php echo $_POST['emember_country']; ?>" class="eMember_text_input<?php echo isset($custom_fields['emember_field_requred'][$i])? ' eMember_required': "";?>" />
	       <?php
	            break;
	            case 'dropdown':
	       ?>	
	       <select name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="eMember_text_input">
	       <?php
				$options = explode(',',$custom_fields['emember_field_extra'][$i]);
				foreach($options as $option){
					$option = explode("=>", $option);       	    
	       	   ?>   
	       	   <option value="<?php echo $option[0];?>"><?php echo $option[1];?></option>
	       	   <?php
				} 
	       
	       ?>
	       
	       </select>
	       <?php	            	
	            break; 
	            case 'checkbox':
	       ?>
	       <input type="checkbox" name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="" />
	       <?php	            	
	            break; 
	            case 'textarea':
	       ?>
	       <textarea name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="<?php echo isset($custom_fields['emember_field_requred'][$i])? 'eMember_required': "";?>" ></textarea>
	       <?php	            	
	            break; 	            	            
	       ?>
	       <?php 	            
	            
	         } 
	       ?>
	       </td>
	    </tr>
		
	<?php
	}
	endif; 
	?>-->
    <tr><td colspan="2" align="center"> <?php echo (($emember_enable_recaptcha)? recaptcha_get_html($publickey , $error): '' );?>  </td></tr>
    <tr>
    	<td></td>
    	<td><input class="eMember_button" name="eMember_Register" type="submit" id="eMember_Register" value="<?php echo EMEMBER_REGISTRATION;?>" /></td>
    </tr>
    </table>    
    </form><br />
    <script type="text/javascript">
    /*<![CDATA[*/
    jQuery(document).ready(function(){        
        var available = true;
        jQuery("#user_name").keypress(function(){var msg_obj = jQuery("#user_name_msg");if(msg_obj.html(""));}).
        keyup(function(){
          var $_this = this;
          var user_name = jQuery(this).val();
          if((user_name!="")&&(user_name.length>4))
          {available = false;
          jQuery.get('<?php echo admin_url('admin-ajax.php');?>',{"event":"check_name","user_name":jQuery(this).val()},
                function(data)
                {
                   var msg_obj = jQuery("#user_name_msg");
                   if(!msg_obj.length)
                   {
                      msg_obj = jQuery('<span id= "user_name_msg"/>');
                      jQuery($_this).after(msg_obj).after(jQuery("<br />"));
                   }
                   available = data.status_code;
                   if(data.status_code)
                   {
                      msg_obj.css("color", "green").html(data.msg);
                   }
                   else
                   {
                       msg_obj.css("color", "red").html(data.msg);
                   }
                },
          "json");
          }
        });
        jQuery('#regoForm').submit(function(){
            var $empty = false;            
            jQuery('.eMember_required').each(function(){
                jQuery(this).removeClass('eMember_required_warn');
                if(jQuery(this).val()==''){
                	jQuery(this).addClass('eMember_required_warn');                    
                    $empty  = true;
                }
            });
          if($empty){
              alert('Please Fill in the required fields');
          	  return !$empty;
          }
          var ok = true;
          ok = checkError("user_name", {"required":"This field is required","5_chars":"User name is too short."})&& ok;
          ok = checkError("pwd", {"required":"This field is required"})&& ok;
          ok = checkError("aemail", {"required":"This field is required","email": "This is not a valid email address"})&& ok;
       return ok&&available;
        });
       });
    /*]]>*/
    </script>    
    <?php 
    $output = ob_get_contents();
    ob_end_clean();    
    return $output;
}
function show_edit_profile_form()
{
    global $wpdb;
    global $emember_config;
	if(isset($_POST['eMember_update_profile']))
	{
        include_once(ABSPATH . WPINC . '/class-phpass.php');
        require_once ( ABSPATH . WPINC . '/registration.php' );
        	    
        $resultset  = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . 
                      $wpdb->escape($_POST['member_id'])); 
        $wp_user_id = username_exists($resultset->user_name);  
        $updatable = true;     
        if(isset($_POST['aemail'])){
        	$emmber_email_owner = emember_email_exists($_POST['aemail']);
        	$wp_email_owner = email_exists($_POST['aemail']);
	        if(!is_email($_POST['aemail']))
	        {
	            $msg = EMEMBER_EMAIL_INVALID;
	            $updatable = false;
	        }
	        else if(($wp_email_owner&&($wp_email_owner!=$wp_user_id))||($emmber_email_owner &&($emmber_email_owner!=$_POST['member_id'])))
	        {
	            $output .= '<br /><span style="color:red">'.EMEMBER_EMAIL_UNAVAIL.' </span>';
	            $updatable = false;
	        }
	    } 
        if($updatable)
        {   	    
            $wp_hasher = new PasswordHash(8, TRUE);	    
            $fields = array();
            if(isset($_POST['afirstname']))$fields['first_name']          = $_POST['afirstname'];
            if(isset($_POST['alastname']))$fields['last_name']            = $_POST['alastname'];
            if(isset($_POST['aemail']))$fields['email']                   = $_POST['aemail'];
            if(isset($_POST['phone']))$fields['phone']                    = $_POST['phone'];
            if(isset($_POST['emember_street']))$fields['address_street']  = $_POST['emember_street'];
            if(isset($_POST['emember_city']))$fields['address_city']      = $_POST['emember_city'];
            if(isset($_POST['emember_state']))$fields['address_state']    = $_POST['emember_state'];
            if(isset($_POST['emember_zipcode']))$fields['address_zipcode']= $_POST['emember_zipcode'];
            if(isset($_POST['emember_country']))$fields['country']        = $_POST['emember_country'];
            if(isset($_POST['emember_gender']))$fields['gender']          = $_POST['emember_gender'];  
            if(isset($_POST['company_name']))$fields['company_name']      = $_POST['company_name'];          
            if(!empty($_POST['pwd'])){
                $password = $wp_hasher->HashPassword($_POST['pwd']);
                $fields['password'] = $password;            
            }

            if($wp_user_id) {
                $wp_user_info  = array();
                $wp_user_info['first_name']    = $_POST['afirstname'];
                $wp_user_info['last_name']     = $_POST['alastname'];
                $wp_user_info['user_email']    = $_POST['aemail'];
                $wp_user_info['ID']            = $wp_user_id;
                
                if(!empty($_POST['pwd'])) $wp_user_info['user_pass'] = $_POST['pwd'];                                            
                wp_update_user( $wp_user_info );
            }

            if(count($fields)>0){
	            $ret = dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id ='. $wpdb->escape($_POST['member_id']), $fields);
	            if(isset($_POST['emember_custom'])){
	            	$custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . $_POST['member_id'] . ' AND meta_key=\'custom_field\'');
	            	if($custom_fields)
		                $wpdb->query('UPDATE ' . WP_EMEMBER_MEMBERS_META_TABLE . 
		                ' SET meta_value ='. '\''.serialize($_POST['emember_custom']). '\' WHERE meta_key = \'custom_field\' AND  user_id=' . $_POST['member_id']);
	                else 
		                $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . 
		                '( user_id, meta_key, meta_value ) VALUES(' . $_POST['member_id'] .',"custom_field",' . '\''.serialize($_POST['emember_custom']).'\')');
	                
	            }
	            if($ret === false) $output .= 'Failed';
	            else $output .= EMEMBER_PROFILE_UPDATED;
            }
        	return $output;
    	}
	}
	
	
    global $emember_auth;
    $member_id  = $emember_auth->getUserInfo('member_id');
    $resultset  = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $wpdb->escape($member_id));
    $edit_custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . $wpdb->escape($member_id) . ' AND meta_key=\'custom_field\'');
    $edit_custom_fields = unserialize($edit_custom_fields->meta_value);
    $username   = $resultset->user_name;
    $first_name = $resultset->first_name;
    $last_name  = $resultset->last_name;
    $phone      = $resultset->phone;
    $email      = $resultset->email;
    $password   = $resultset->password;
    $address_street  = $resultset->address_street;
    $address_city    = $resultset->address_city;
    $address_state   = $resultset->address_state;
    $address_zipcode = $resultset->address_zipcode;
    $country         = $resultset->country;
    $gender          = $resultset->gender;
    $company         = $resultset->company_name;    
    $image_url       = null;
    $image_path  = null;
	$upload_dir  = wp_upload_dir();
    $upload_url  = $upload_dir['baseurl'];
    $upload_path = $upload_dir['basedir'];
    $upload_url  .= '/emember/';
    $upload_path .= '/emember/';
    $upload_url  .= $emember_auth->getUserInfo('member_id');
    $upload_path .= $emember_auth->getUserInfo('member_id');
    if(file_exists($upload_path . '.jpg'))
    {
    	$image_url = $upload_url . '.jpg';
    	$image_path = $upload_path . '.jpg';
    }
    else if(file_exists($upload_path . '.jpeg'))
    {
    	$image_url = $upload_url . '.jpeg';
    	$image_path = $upload_path . '.jpeg';
    }
    else if(file_exists($upload_path . '.gif'))
    {
    	$image_url = $upload_url . '.gif';
    	$image_path = $upload_path . '.gif';
    }
    else if(file_exists($upload_path . '.png'))
    {
    	$image_url = $upload_url . '.png';
    	$image_path = $upload_path . '.png';
    }
    else
    {
    	$use_gravatar = $emember_config->getValue('eMember_use_gravatar');
    	if($use_gravatar)
	    	$image_url = "http://www.gravatar.com/avatar/" . md5(strtolower($email)) . "?d=" . urlencode(404) . "&s=" . 96;
    	else
    		$image_url = WP_EMEMBER_URL . '/images/default_image.gif';
    }
    
    $f = $emember_config->getValue('eMember_allow_account_removal');
    $delete_button = empty($f)? '': '<a id="delete_account_btn" href="'.get_bloginfo('wpurl').
                     '?event=delete_account" >Delete Account</a> ';
    ob_start();
    echo isset($msg)?'<span  style="color:red;">'.$msg . '</span>': '';
	?>
    <form action="" method="post" name="profileUpdateForm" id="profileUpdateForm" >
    <input type="hidden" name="member_id" id="member_id" value ="<?php echo $member_id;?>" />
    <table width="95%" border="0" cellpadding="3" cellspacing="3" class="forms">	
	<tr>
		<td><label class="eMember_label"> <?php echo EMEMBER_USERNAME;?>: </label></td>
		<td><label class="eMember_highlight"><?php echo $username;?></label></td>
	</tr>
	<tr>
		<td><label class="eMember_label"><?php echo EMEMBER_PROFILE_IMAGE;?>: </label></td>
		<td>
			<img id="emem_profile_image" src="<?php echo $image_url;?> "  width="100px" height="100px"/>
			<a id="remove_button" href="<?php echo $image_path; ?>">Remove</a>
			<div id="upload_button" class="emember_upload_div">Upload</div><br/><span id="error_msg"></span>
		</td>
    </tr>
    <?php if($emember_config->getValue('eMember_edit_firstname')):?>
    <tr>
       <td><label for="afirstname" class="eMember_label"><?php echo EMEMBER_FIRST_NAME;?>: </label></td>
       <td><input type="text" name="afirstname" size="20" value="<?php echo $first_name;?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_firstname_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_lastname')):?>
    <tr>
       <td><label for="alastname" class="eMember_label"><?php echo EMEMBER_LAST_NAME;?>: </label></td>
       <td><input type="text" name="alastname" size="20" value="<?php echo $last_name;?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_lastname_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_company')):?>
    <tr>
       <td><label for="company_name" class="eMember_label"><?php echo EMEMBER_COMPANY ?>: </label></td>
       <td><input type="text" name="company_name" size="20" value="<?php echo $company ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_company_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>    
    <?php if($emember_config->getValue('eMember_edit_email')):?>
    <tr>
       <td><label for="aemail" class="eMember_label"><?php echo EMEMBER_EMAIL;?>: </label></td>
       <td><input type="text" name="aemail" size="20" value="<?php echo $email;?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_email_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_phone')):?>
    <tr>
       <td><label for="aemail" class="eMember_label"><?php echo EMEMBER_PHONE?>: </label></td>
       <td><input type="text" name="phone" size="20" value="<?php echo $phone ?>" class="eMember_text_input  <?php echo $emember_config->getValue('eMember_edit_phone_required')? 'eMember_required': "";?>" /></td>
    </tr>    
    <?php endif;?>
    <tr>
       <td><label for="pwd" class="eMember_label"><?php echo EMEMBER_PASSWORD ?>: </label></td>
       <td><input type="password" name="pwd" size="20" value="" class="eMember_text_input" /><br/><?php echo EMEMBER_KEEP_CURRENT_PASS_MSG?></td>
    </tr>
    <?php if($emember_config->getValue('eMember_edit_street')):?>    
    <tr>
       <td><label for="emember_street" class="eMember_label"><?php echo EMEMBER_ADDRESS_STREET?>: </label></td>
       <td><input type="text" name="emember_street" size="20" value="<?php echo $address_street ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_street_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_city')):?>    
    <tr>    
       <td><label for="emember_city" class="eMember_label"><?php echo EMEMBER_ADDRESS_CITY ?>: </label></td>
       <td><input type="text" name="emember_city" size="20" value="<?php echo $address_city?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_city_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_state')):?>    
    <tr>
       <td><label for="emember_state" class="eMember_label"><?php echo EMEMBER_ADDRESS_STATE ?>: </label></td>
       <td><input type="text" name="emember_state" size="20" value="<?php echo $address_state ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_state_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_zipcode')):?>    
    <tr>
       <td><label for="emember_zipcode" class="eMember_label"><?php echo EMEMBER_ADDRESS_ZIP ?>: </label></td>
       <td><input type="text" name="emember_zipcode" size="20" value="<?php echo $address_zipcode ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_zipcode_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_country')):?>
    
    <tr>
       <td><label for="emember_country" class="eMember_label"><?php echo EMEMBER_ADDRESS_COUNTRY ?>: </label></td>
       <td><input type="text" name="emember_country" size="20" value="<?php echo $country ?>" class="eMember_text_input <?php echo $emember_config->getValue('eMember_edit_country_required')? 'eMember_required': "";?>" /></td>
    </tr>
    <?php endif;?>
    <?php if($emember_config->getValue('eMember_edit_gender')):?>    
	<tr >
		<td > <label for="emember_gender" class="eMember_label"><?php echo EMEMBER_GENDER ?>: </label></td>
		<td>
	   <select name="emember_gender" id="emember_gender">
	      <option  <?php echo (($gender ==='male') ? 'selected=\'selected\'' : '' ) ?> value="male"><?php echo EMEMBER_GENDER_MALE ?></option>
	      <option  <?php echo (($gender ==='female') ? 'selected=\'selected\'' : '' ) ?> value="female"><?php echo EMEMBER_GENDER_FEMALE ?></option>      
	      <option  <?php echo (($gender ==='not specified') ? 'selected=\'selected\'' : '' ) ?> value="not specified"><?php echo EMEMBER_GENDER_UNSPECIFIED ?></option>      
	   </select>
		</td>
	</tr>        
	<?php endif;?>
<!--  custom field	<?php
	if($emember_config->getValue('eMember_custom_field')):
	$custom_fields = get_option('emember_custom_field_type');
	
	for($i=0; isset($custom_fields['emember_field_name'][$i]); $i++){		
	?> 
	    <tr>
	       <td><label for="<?php echo $custom_fields['emember_field_name'][$i]?>" class="eMember_label"><?php echo  $custom_fields['emember_field_name'][$i]?>: </label></td>
	       <td>
	       <?php
	         $field_value = isset($edit_custom_fields[$custom_fields['emember_field_name'][$i]])?$edit_custom_fields[$custom_fields['emember_field_name'][$i]]:"";
	         switch($custom_fields['emember_field_type'][$i]){
	         	case 'text': 
	       ?>
	       <input type="text"  name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" size="20" value="<?php echo  $field_value; ?>" class="eMember_text_input<?php echo isset($custom_fields['emember_field_requred'][$i])? ' eMember_required': "";?>" />
	       <?php
	            break;
	            case 'dropdown':
	       ?>	
	       <select name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="eMember_text_input">
	       <?php
				$options = explode(',',$custom_fields['emember_field_extra'][$i]);
				foreach($options as $option){
					$option = explode("=>", $option);       	    
	       	   ?>   
	       	   <option <?php echo ($field_value ===$option[0])? "selected='selected'": "";?> value="<?php echo $option[0];?>"><?php echo $option[1];?></option>
	       	   <?php
				} 
	       
	       ?>
	       </select>
	       <?php	            	
	            break; 
	            case 'checkbox':
	       ?>
	       <input <?php echo $field_value? "checked='checked'": "";?> type="checkbox" name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="" />
	       <?php	            	
	            break; 
	            case 'textarea':
	       ?>
	       <textarea name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="<?php echo isset($custom_fields['emember_field_requred'][$i])? 'eMember_required': "";?>" > <?php echo $field_value; ?></textarea>
	       <?php	            	
	            break; 	            	            
	       ?>
	       <?php 	            
	            
	         } 
	       ?>
	       </td>
	    </tr>
		
	<?php
	}
	endif; 
	?>
	-->
    <tr>
    <td >
      <?php echo $delete_button ?>
    </td>
    <td>
       <input class="eMember_button" name="eMember_update_profile" type="submit" id="eMember_update_profile" class="button" value="<?php echo EMEMBER_UPDATE ?>" />
    </td>
    </tr>
    </table>
    </form><br />
    <script type="text/javascript">    
    jQuery(document).ready(function(){
        jQuery('#profileUpdateForm').submit(function(){
            var $empty = false;            
            jQuery('.eMember_required').each(function(i){
            	jQuery(this).removeClass('eMember_required_warn');
                if(jQuery(this).val()==''){
                	jQuery(this).addClass('eMember_required_warn');
                    $empty = true;                   
                }
                    
            });
            if($empty)alert('Please Fill in the required fields');
            return !$empty;
        });
        jQuery("#delete_account_btn").click(function(){
            top.document.location = jQuery(this).attr("href");
        }).confirm({timeout:5000});
	    var upload_button = jQuery("#upload_button");
	    var target_url = "<?php echo  get_bloginfo('wpurl'); ?>";
	    interval = "";
	    jQuery('#remove_button').click(function(e){
	        var imagepath = jQuery(this).attr('href');
	        if(imagepath){
	        jQuery.get( '<?php echo admin_url('admin-ajax.php');?>',{"action":"delete_profile_picture","path":imagepath},
	                function(data){
	     	              jQuery("#emem_profile_image").attr("src",   "<?php echo WP_EMEMBER_URL; ?>/images/default_image.gif?" + (new Date()).getTime());  
	      	             jQuery('#remove_button').attr('href','');         
	                },
	          "json");
	        }
	        e.preventDefault();
	    }); 	    
	    new AjaxUpload(upload_button, 
	    {
	        action:  "<?php echo admin_url('admin-ajax.php');?>?event=emember_upload_ajax",
	        name: "profile_image",
	        data :{image_id: <?php echo $emember_auth->getUserInfo('member_id');?>} ,
	        onSubmit : function(file , ext){    
	            if (ext && /^(jpg|png|jpeg|gif)$/.test(ext)){
	                upload_button.text("Uploading");
	                this.disable();
	                interval = window.setInterval(function(){
	                    var text = upload_button.text();
	                    if (text.length < 13){
	                        upload_button.text(text + ".");         
	                    } else {
	                        upload_button.text("Uploading");        
	                    }
	                }, 200);
	                jQuery("#error_msg").css("color","").text("Uploading ");  
	            } else {          
	                jQuery("#error_msg").css("color","red").text("Error: only images are allowed");
	                return false;       
	            }   
	        },    
	        onComplete: function(file, response){
	            upload_button.text("Upload");           
	            window.clearInterval(interval);
	            this.enable();      
	            response = eval( "("+response+")");   
	            if(response.status==1){         
	                jQuery("#emem_profile_image").attr("src", " <?php echo $upload_dir['baseurl'] ;?>/emember/" +response.file +"?" + (new Date()).getTime());
	    			jQuery("#error_msg").css("color","").text("Uploaded");
	    		}	
	    		else{
	    			jQuery("#error_msg").css("color","").text("Error Occurred.Check file size.");
	    		}						
	        }
	    }); 	    
	});
		</script>	
	<?php 
    $output = ob_get_contents();
    ob_end_clean();	
    return $output;
}

function emember_registered_email_exists($email)
{
    global $wpdb;
    $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
    $resultset = dbAccess::find($member_table,' email=\''. $wpdb->escape($email) . '\' AND user_name != ""');
    if(empty($resultset)) return false;
    return $resultset->member_id;        
}
function emember_email_exists($email)
{
    global $wpdb;
    $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
    $resultset = dbAccess::find($member_table,' email=\''. $wpdb->escape($email) . '\'');
    if(empty($resultset)) return false;
    return $resultset->member_id;        
}
function emember_username_exists($user_name)
{
    global $wpdb;
    $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
    $resultset = dbAccess::find($member_table,' user_name=\''. $wpdb->escape($user_name) . '\'');
    if(empty($resultset)) return false;
    return $resultset->member_id;    
}

if (!function_exists('json_decode')) 
{
    function json_decode($content, $assoc=false) 
    {
        require_once WP_PLUGIN_DIR. '/' . WP_EMEMBER_FOLDER.'/JSON.php';
        if ($assoc) $json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
        else $json = new Services_JSON;
        return $json->decode($content);
    }
}

if (!function_exists('json_encode')) 
{
    function json_encode($content) 
    {
        require_once WP_PLUGIN_DIR. '/' . WP_EMEMBER_FOLDER.'/JSON.php';
        $json = new Services_JSON;
        return $json->encode($content);
    }
}

function eMember_send_aweber_mail($list_name,$from_address,$cust_name,$cust_email)
{
    $subject = "Aweber Automatic Sign up email";
    $body    = "\n\nThis is an automatic email that is sent to AWeber for member signup purpose\n".
               "\nEmail: ".$cust_email.
               "\nName: ".$cust_name;

	$headers = 'From: '.$from_address . "\r\n";
    wp_mail($list_name, $subject, $body, $headers);
}
function get_real_ip_addr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   
        $ip=$_SERVER['HTTP_CLIENT_IP'];
    else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    else
        $ip=$_SERVER['REMOTE_ADDR'];
        
    return $ip;
}
function eMember_get_string_between($string, $start, $end)
{
	$string = " ". $string;
	$ini = strpos($string,$start);
	if ($ini == 0) return "";
	$ini += strlen($start);
	$len = strpos($string, $end, $ini) - $ini;
	return substr($string, $ini, $len);
}
?>