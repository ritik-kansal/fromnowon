<?php
function eMember_my_more_link( $more_link, $more_link_text = "More" ){   
    global $emember_config;
    global $emember_auth;
    global $post;
    $id = $post->ID;
    $emember_auth->hasmore = true;
    if($emember_auth->is_protected_category($id)){    	
        if($emember_auth->isLoggedIn()){
        	$expires = $emember_auth->getUserInfo('account_state');
        	if($expires == 'expired')
        		return get_renewal_link();
        		
            if(!$emember_auth->is_subscription_expired()){
                if($emember_auth->is_permitted_category($id))
                    return str_replace( $more_link_text,  EMEMBER_MORE_LINK . ' &raquo;', $more_link );                	
                else
                    return '<br/><b>'.EMEMBER_CONTENT_RESTRICTED .'</b>';             
            }
           else 
               return str_replace( $more_link_text, EMEMBER_MORE_LINK . ' &raquo;', get_renewal_link() );                                       
        }
        else{
             $join_url = $emember_config->getValue ('eMember_payments_page');
             if(empty($join_url)) 
                 return '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:'.get_option('admin_email').'">Admin</a>.';
             else 
                 $join_url = ' href ="'.$join_url.'" ';
             return str_replace( $more_link_text, EMEMBER_MORE_LINK . ' &raquo;', '<a '. $join_url .'>' . EMEMBER_MORE_LINK . ' &raquo;'. '</a>' );            
        }
    }
    else if($emember_auth->is_protected_post($id)){
        if($emember_auth->isLoggedIn()){
        	$expires = $emember_auth->getUserInfo('account_state');
        	if($expires == 'expired')
        		return get_renewal_link();
        	
            if(!$emember_auth->is_subscription_expired()){
                if($emember_auth->is_permitted_post($id))
                    return str_replace( $more_link_text,  EMEMBER_MORE_LINK . ' &raquo;', $more_link );
                else
                    return '<br/><b>'.EMEMBER_LEVEL_NOT_ALLOWED .'</b>';
            }
           else
               return str_replace( $more_link_text, EMEMBER_MORE_LINK . ' &raquo;', get_renewal_link() );                                       
        }
        else{
             $join_url = $emember_config->getValue('eMember_payments_page');    
             if(empty($join_url)) 
                 return '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:'.get_option('admin_email').'">Admin</a>.';
             else 
                 $join_url = ' href ="'.$join_url.'" ';
             return str_replace( $more_link_text, EMEMBER_MORE_LINK . ' &raquo;', '<a '. $join_url .'>' . EMEMBER_MORE_LINK . ' &raquo;'. '</a>' );            
        }   	
    }
    else
        return str_replace( $more_link_text, EMEMBER_MORE_LINK . ' &raquo;', $more_link );
}

function auth_check_category($content){
    global $emember_auth;
    global $post;
    $id = $post->ID;
    if($emember_auth->hasmore){
        $emember_auth->hasmore = false;
        return $content;
    }
    else{
        if($emember_auth->is_protected_category($id))
        {
            if($emember_auth->isLoggedIn()){
	        	$expires = $emember_auth->getUserInfo('account_state');
	        	if($expires == 'expired')
	        		return get_renewal_link();
            	
                if(!$emember_auth->is_subscription_expired()){
                    if($emember_auth->is_permitted_category($id))
                        return $content;
                    else
                         return '<br/><b>' . EMEMBER_LEVEL_NOT_ALLOWED .'</b>';
                }
                else
                   return get_renewal_link();                                   
            }
            else{   
                if(isset($_GET['event'])&&($_GET['event']=='login'))
                    return get_login_link();
                else
                    return get_login_link();                 
            }
        }
        else{
            if($emember_auth->is_protected_post($id)){
                if($emember_auth->isLoggedIn()){
		        	$expires = $emember_auth->getUserInfo('account_state');
		        	if($expires == 'expired')
		        		return get_renewal_link();
                	
                    if(!$emember_auth->is_subscription_expired()){
                        if($emember_auth->is_permitted_post($id))
                            return $content;
                        else
                             return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED . '</b>';
                    }
                   else
                       return get_renewal_link();         
                }
                else
                    return get_login_link();                      
            }
            else
                return $content;
            
            return $content;
        }
    }
}
function auth_check_post($content){
    global $post;
    $id = $post->ID;
    return check_post_content($id, $content);
}
function auth_check_page($content){
    global $emember_auth;
    global $post;
    $id = $post->ID;
    if($emember_auth->is_protected_page($id)){
        if($emember_auth->isLoggedIn()){
        	$expires = $emember_auth->getUserInfo('account_state');
        	if($expires == 'expired')
        		return get_renewal_link();
        	
            if(!$emember_auth->is_subscription_expired()){
                if($emember_auth->is_permitted_page($id))
                    return $content;
                else
                     return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED .'</b>';
            }
            else
               return get_renewal_link();                    
        }
        else{
            if(isset($_GET['event'])&&($_GET['event']=='login'))                   
                return print_eMember_login_form();
            else{
                if($emember_auth->hasmore){$emember_auth->hasmore = false;return $content;}
                return get_login_link();                        
            }                    
        }
    }
    else{
        if($emember_auth->hasmore){ $emember_auth->hasmore = false;}
        return $content;
    }   
}
function auth_check_comment($content){
    global $comment;
    global $emember_auth;
    global $emember_config;
    
    if($emember_config->getValue('eMember_protect_comments_separately')){
	    $id = $comment->comment_ID;
	    if($emember_auth->is_protected_category($id)){
	       if($emember_auth->isLoggedIn()){
	        	$expires = $emember_auth->getUserInfo('account_state');
	        	if($expires == 'expired')
	        		return get_renewal_link();
	       	
	           if(!$emember_auth->is_subscription_expired()){
	               if($emember_auth->is_permitted_category($id))
	                   return $content;                               
	               else
	                   return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED . '</b>';
	           }
	           else
	               return get_renewal_link();                    
	       }
	       else{
	           if(isset($_GET['event'])&&($_GET['event']=='login'))    
	               return get_login_link();
	           else{
	               if($emember_auth->hasmore){$emember_auth->hasmore = false;return $content;}
	               return get_login_link();                        
	           }           
	       }
	    }
	    else if($emember_auth->is_protected_comment($id)){
	       if($emember_auth->isLoggedIn()){
	        	$expires = $emember_auth->getUserInfo('account_state');
	        	if($expires == 'expired')
	        		return get_renewal_link();
	       	
	           if(!$emember_auth->is_subscription_expired()){
	               if($emember_auth->is_permitted_comment($id))
	                   return $content;
	               else
	                   return '<br/><b>' . EMEMBER_CONTENT_RESTRICTED .'</b>';
	           }
	           else
	               return get_renewal_link();                    
	       }
	       else{
	           if(isset($_GET['event'])&&($_GET['event']=='login'))                   
	               return get_login_link();
	           else
	               if($emember_auth->hasmore){$emember_auth->hasmore = false;return $content;}
	               return get_login_link();                                
	       }    	
	    }
	    else{
	       if($emember_auth->hasmore){ $emember_auth->hasmore = false;}        
	       return $content;
	    }
    }  //
    else{
    	return check_post_content($comment->comment_post_ID, $content);
    }        
}
function check_post_content($id, $content){
    global $emember_auth;
    if($emember_auth->hasmore){
        $emember_auth->hasmore = false;
        return $content;
    }    
    else{        	
        if($emember_auth->is_protected_category($id)){
            if($emember_auth->isLoggedIn()){
	        	$expires = $emember_auth->getUserInfo('account_state');
	        	if($expires == 'expired')
	        		return get_renewal_link();
            	
                if(!$emember_auth->is_subscription_expired()){
                    if($emember_auth->is_permitted_category($id))
                        return $content;
                    else
                        return '<br/><b>'. EMEMBER_LEVEL_NOT_ALLOWED .'</b>';                 	
                }
               else
                   return get_renewal_link();      
            }
            else{
                if(isset($_GET['event'])&&($_GET['event']=='login')){                    
                    if(is_single())
                        return print_eMember_login_form();
                    else
                        return get_login_link();
                }
                else                
                    return get_login_link();                                       
            }
        }
        else if($emember_auth->is_protected_post($id)){
            if($emember_auth->isLoggedIn()){
	        	$expires = $emember_auth->getUserInfo('account_state');
	        	if($expires == 'expired')
	        		return get_renewal_link();
            	
                if(!$emember_auth->is_subscription_expired()){        	
		            if($emember_auth->is_permitted_post($id))
		                return $content;
		            else
		                return  '<br/><b>' . EMEMBER_CONTENT_RESTRICTED . '</b>';
                }
                else
		            return get_renewal_link();                	
            }
            else{
                if(isset($_GET['event'])&&($_GET['event']=='login')){                    
                    if(is_single())
                        return print_eMember_login_form();
                    else
                        return get_login_link();
                }
                else                               
                    return get_login_link();                                   
            }            
        }
        else
            return $content;
    }        	
}
?>