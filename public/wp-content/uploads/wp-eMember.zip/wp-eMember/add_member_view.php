<style type="text/css">
        .emember_upload { padding: 0 20px; float: left; width: 230px; }
		.emember_upload_wrapper { width: 133px;  }		
		.emember_upload_div {
			height: 24px;	
			width: 133px;
			background: #FFF 0 0;			
			font-size: 14px; color: #000; text-align: center; padding-top: 0px;
		}
		/* 
		We can't use ":hover" preudo-class because we have
		invisible file input above, so we have to simulate
		hover effect with JavaScript. 
		 */
		.emember_upload_div.hover {
			background: #6D6D6D 0 56px;
			color: #FFF;	
		}
		.emember_upload_div a.hover{
			color:#fff;
        }
}
</style>
<form method="post" action="admin.php?page=wp_eMember_manage&members_action=add_edit">
<!--<form method="post" action="javascript:void(0);">-->
<table class="form-table">
<?php if ($_GET['editrecord']!='') { echo '<input name="editedrecord" id="editedrecord"  type="hidden" value="'.$_GET['editrecord'].'" />'; } ?>
<tr valign="top">
<th scope="row"><?php _e('User Name', 'wp_eMember'); ?></th>
<td><input name="user_name" <?php echo empty($editingrecord['user_name'])? '': 'readonly'; ?> type="text" id="user_name" value="<?php echo $editingrecord['user_name']; ?>" size="30" /><br/><?php _e('User Name of the Member', 'wp_eMember'); ?></td>
</tr>
<?php
if($_GET['editrecord']!='') 
{
?>
<tr>
	<td><label class="eMember_label"> <?php  echo EMEMBER_PROFILE_IMAGE;?>: </label></td>
	<td>
		<img id="emem_profile_image" src="<?php echo $image_url; ?>"  width="100px" height="100px"/>
		<a id="remove_button" href="<?php echo $image_path; ?>">Remove</a><span id="error_msg"></span>
		<div id="upload_button" class="emember_upload_div">Upload</div>
	</td>
</tr>
<?php
} 
?>
<tr valign="top">
<th scope="row"><?php _e('First Name', 'wp_eMember'); ?></th>
<td><input name="first_name" type="text" id="first_name" value="<?php echo $editingrecord['first_name']; ?>" size="30" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Last Name', 'wp_eMember'); ?></th>
<td><input name="last_name" type="text" id="last_name" value="<?php echo $editingrecord['last_name']; ?>" size="30" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Password', 'wp_eMember'); ?></th>
<td><input name="password" type="password" id="password" value="" size="30" /><?php if ($_GET['editrecord']!=''){?>Leave empty to keep current password.<?php }?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Retype Password', 'wp_eMember'); ?></th>
<td><input name="retype_password" type="password" id="retype_password" value="" size="30" /></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Company', 'wp_eMember'); ?></th>
<td><input name="company_name" type="text" id="company_name" value="<?php echo $editingrecord['company_name']; ?>" size="30" /></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Member Since', 'wp_eMember'); ?></th>
<td><input name="member_since" type="text" id="member_since" value="<?php echo empty($editingrecord['member_since']) ? date('Y-m-d') : $editingrecord['member_since']; ?>" size="20" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Membership Level', 'wp_eMember'); ?></th>
<td>
      <select name="membership_level"  id="membership_level">
         <?php foreach($all_levels as $level){?>
         <option <?php echo ($editingrecord['membership_level'] ===$level->id)? "selected='selected'" : null;?> value="<?php echo $level->id?>"><?php echo $level->alias;?></option>
         <?php }?>
      </select>
</td>
</tr>
<?php if($emember_config->getValue('eMember_enable_secondary_membership')):?>
<tr valign="top">
<th scope="row"><?php _e('Additional Membership Levels', 'wp_eMember'); ?></th>
<td>
      <table id="eMembership_level_container">
         <?php foreach($all_levels as $level){?>
         <tr>
         	<td><input type="checkbox" class="eMembership_level" id="membership_level_<?php echo $level->id;?>" name=more_membership_levels[] value="<?php echo $level->id;?>" <?php echo in_array($level->id ,(array)$editingrecord['more_membership_levels'])? "checked='checked'" : ""?>  ></input></td>
         	<td><?php echo $level->alias;?></td>
         </tr>
         <?php }?>
      </table>
</td>
</tr>
<?php endif;?>
<tr valign="top">
<th scope="row"><?php _e('Account State', 'wp_eMember'); ?></th>
<td>   <select name="account_state"  id="account_state">
      <option <?php echo ($editingrecord['account_state'] ==='active')? "selected='selected'" : null;?> value="active">Active</option>
      <option <?php echo ($editingrecord['account_state'] ==='inactive')? "selected='selected'" : null;?> value="inactive">Inactive</option>
      <option <?php echo ($editingrecord['account_state'] ==='expired')? "selected='selected'" : null;?> value="expired">expired</option>
      <!--<option <?php echo ($editingrecord['account_state'] ==='pending')? "selected='selected'" : null;?> value="pending">Pending</option>-->
   </select></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Email Address', 'wp_eMember'); ?></th>
<td><input name="email" type="text" id="email" value="<?php echo $editingrecord['email']; ?>" size="30" /></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Phone No.', 'wp_eMember'); ?></th>
<td><input name="phone" type="text" id="email" value="<?php echo $editingrecord['phone']; ?>" size="30" /></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Address Street', 'wp_eMember'); ?></th>
<td><input name="address_street" type="text" id="address_street" value="<?php echo $editingrecord['address_street']; ?>" size="30" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Address City', 'wp_eMember'); ?></th>
<td><input name="address_city" type="text" id="address_city" value="<?php echo $editingrecord['address_city']; ?>" size="30" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Address State', 'wp_eMember'); ?></th>
<td>
   <input name="address_state" type="text" id="address_state" value="<?php echo $editingrecord['address_state']; ?>" size="30" />
   </td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Address Zipcode', 'wp_eMember'); ?></th>
<td><input name="address_zipcode" type="text" id="address_zipcode" value="<?php echo $editingrecord['address_zipcode']; ?>" size="30" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Country', 'wp_eMember'); ?></th>
<td><input name="country" type="text" id="country" value="<?php echo $editingrecord['country']; ?>" size="30" /></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Gender', 'wp_eMember'); ?></th>
<td>   
   <select name="gender" id="gender">
      <option <?php echo ($editingrecord['gender'] ==='male')? "selected='selected'" : null;?> value="male">Male</option>
      <option <?php echo ($editingrecord['gender'] ==='female')? "selected='selected'" : null;?> value="female">Female</option>
      <option <?php echo ($editingrecord['gender'] ==='not specified')? "selected='selected'" : null;?> value="not specified">Not Specified</option>
   </select>
</td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Referrer', 'wp_eMember'); ?></th>
<td><input name="referrer" type="text" id="referrer" value="<?php echo $editingrecord['referrer']; ?>" size="30" /></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Subscription Starts', 'wp_eMember'); ?></th>
<td><input name="subscription_starts" type="text" id="subscription_starts" value="<?php echo empty($editingrecord['subscription_starts'])? date('Y-m-d'):$editingrecord['subscription_starts']; ?>" size="20" /></td>
</tr>
<!--  custom field	<?php
	if($emember_config->getValue('eMember_custom_field')):
	
	$custom_fields = get_option('emember_custom_field_type');
	for($i=0; isset($custom_fields['emember_field_name'][$i]); $i++){		
	?> 
	    <tr>
	       <th><label for="<?php echo $custom_fields['emember_field_name'][$i]?>" class=""><?php echo  $custom_fields['emember_field_name'][$i]?>: </label></td>
	       <td>
	       <?php
	         $field_value = isset($edit_custom_fields[$custom_fields['emember_field_name'][$i]])?$edit_custom_fields[$custom_fields['emember_field_name'][$i]]:"";
	         switch($custom_fields['emember_field_type'][$i]){
	         	case 'text':	         		 
	       ?>
	       <input type="text" size="30" value="<?php echo $field_value; ?>" name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" size="20"  class="<?php echo isset($custom_fields['emember_field_requred'][$i])? ' eMember_required': "";?>" />
	       <?php
	            break;
	            case 'dropdown':	            	
	       ?>	
	       <select name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" >
	       	   <?php
				$options = explode(',',$custom_fields['emember_field_extra'][$i]);
				foreach($options as $option){
					$option = explode("=>", $option);       	    
	       	   ?>   
	       	   <option <?php echo ($field_value ===$option[0])? "selected='selected'": "";?> value="<?php echo $option[0];?>"><?php echo $option[1];?></option>
	       	   <?php
				} 
	       	   ?>  
	       </select>
	       <?php	            	
	            break; 
	            case 'checkbox':
	       ?>
	       <input <?php echo $field_value? "checked='checked'": "";?> type="checkbox" value="checked" name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="" />
	       <?php	            	
	            break; 
	            case 'textarea':
	       ?>
	       <textarea name="emember_custom[<?php echo $custom_fields['emember_field_name'][$i];?>]" class="<?php echo isset($custom_fields['emember_field_requred'][$i])? 'eMember_required': "";?>" ><?php echo $field_value; ?></textarea>
	       <?php	            	
	            break; 	            	            
	       ?>
	       <?php 	            
	            
	         } 
	       ?>
	       </td>
	    </tr>
		
	<?php
	} 
	endif;
	?>-->
<!--  <tr valign="top">
<th scope="row"><?php _e('Extra Info', 'wp_eMember'); ?></th>
<td><input name="extra_info" type="text" id="extra_info" value="<?php echo $editingrecord['extra_info']; ?>" size="60" /></td>
</tr>-->
</table>
<p class="submit">
   <input type="submit" name="Submit" value="<?php _e('Save Member Info', 'wp_eMember'); ?>" /> &nbsp; <?php if ($_GET['editrecord']!='') { ?>
   <input type="button" secret="<?php echo $_GET['editrecord']; ?>" name="deleterecord" id="deleterecord" value="<?php _e('Delete Member', 'wp_eMember'); ?>" /><?php } ?>
</p>
</form>
<script type="text/javascript">
function checkPassMatch(pass,retype)
{
   var pwd = pass.val();   
   var msg = 'Password doesn\'t match.';
   var repwd = retype.val();
   var msgObj = jQuery('#mismatch_msg');   
   if((pwd=='')&&(repwd==''))
   {
	   if(msgObj.length>0)msgObj.html('');
	   pass.css('border','');
	   retype.css('border',''); 
	   return true;
   }   
   if(msgObj.length>0) msgObj.html('');
   else msgObj = jQuery('<span id= "mismatch_msg"/>');   
   if (pwd.length<5) msg = ' Password too short.';   
   else if(pwd===repwd)
   {
      pass.css('border', '1px solid green').
         after(jQuery(msgObj).css('color', 'green').html('Password match.' ));
      retype.css('border', '1px solid green');
      return true;

   }
   
   pass.css('border', '1px solid red').
      after(msgObj.css('color', 'red').html(msg));
   retype.css('border', '1px solid red');
   return false;
   
}
function checkError(at, rules)
{
   var testable = jQuery('#'+at);
   var ok       = true;

   for(var rule in rules)
   {
      switch(rule)
      {
         case 'required':
            if(jQuery.trim(testable.val())=='') ok = false;
            break;
         case 'email':
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(!filter.test(jQuery.trim(testable.val()))) ok = false;
            break;
         case '1_chars':
            var testcase = jQuery.trim(testable.val());
            if(testcase.length<1) ok = false;
            break;

         default:
            alert('undefined rule: ' +rule);
            return false;
            break;
      }

      if(!ok)
      {  
          if(!jQuery('#'+at+'_msg').length)
          {
             testable.css('border', '1px solid red').
             after(jQuery('<span id= "'+at+'_msg"/>').
                   css('color', 'red').html(rules[rule]));
          }
          return false;
      }
   }
   return true;
}
function clearErrorMsg(at)
{
    jQuery('#'+at).css('border', '');
    jQuery('#'+at+'_msg').remove();
}
jQuery(document).ready(function(){
    var upload_button = jQuery("#upload_button");
    interval = ""; 
    jQuery('#membership_level').change(function(){
        jQuery('.eMembership_level').removeAttr('disabled');
        jQuery('#membership_level_'+jQuery(this).val()).attr('disabled', 'disabled').attr('checked','checked');
    }).change();
    <?php if($_GET['editrecord']!='') 
    {
    ?>
    jQuery('#remove_button').click(function(e){
        var imagepath = jQuery(this).attr('href');
        if(imagepath){
        jQuery.get( '<?php echo admin_url('admin-ajax.php');?>',{"action":"delete_profile_picture","path":imagepath},
                function(data){
     	              jQuery("#emem_profile_image").attr("src",   "<?php echo WP_EMEMBER_URL; ?>/images/default_image.gif?" + (new Date()).getTime());  
      	             jQuery('#remove_button').attr('href','');         
                },
          "json");
        }
        e.preventDefault();
    }); 
    if(upload_button.length){          	    
    new AjaxUpload(upload_button, 
    	    {
	    		action:  "<?php echo admin_url('admin-ajax.php');?>?event=emember_upload_ajax",
				name: "profile_image",
    data :{image_id: '<?php echo $_GET['editrecord'];?>'},
	onSubmit : function(file , ext){		
		if (ext && /^(jpg|png|jpeg|gif)$/.test(ext)){
			upload_button.text("Uploading");
			this.disable();
			interval = window.setInterval(function(){
				var text = upload_button.text();
				if (text.length < 13){
					upload_button.text(text + ".");					
				} else {
					upload_button.text("Uploading");				
				}
			}, 200);
			jQuery("#error_msg").css("color","").text("Uploading ");	
		} else {					
			jQuery("#error_msg").css("color","red").text("Error: only images are allowed");
			return false;				
		}		
	},		
	onComplete: function(file, response){
		upload_button.text("Upload");						
		window.clearInterval(interval);
		this.enable();			
		response = eval( "("+response+")");		
		if(response.status==1)
		{	jQuery('#remove_button').attr('href','<?php echo addslashes($upload_dir['basedir']) . '/emember/';?>'+response.file);		    
			jQuery("#emem_profile_image").attr("src",   "<?php echo $upload_dir['baseurl']; ?>"+ "/emember/" +response.file +"?" + (new Date()).getTime());
			jQuery("#error_msg").css("color","").text("Uploaded");
		}	
		else{
			jQuery("#error_msg").css("color","").text("Error Occurred.Check file size.");
		}						
	}
	}); 
    }  	
    <?php }?>
        var available = true;
        jQuery("#user_name").keyup(function(){
          var $_this = this;
          var user_name = jQuery(this).val();
          if(user_name!="" &&(user_name.length>4)){
          jQuery.get( '<?php echo admin_url('admin-ajax.php');?>',{"event":"check_name","user_name":jQuery(this).val()},
                function(data)
                {
                   var msg_obj = jQuery("#user_name_msg");
                   if(!msg_obj.length)
                   {
                      msg_obj = jQuery('<span id= "user_name_msg"/>');
                      jQuery($_this).after(msg_obj);
                   }
                   available = data.status_code;
                   if(data.status_code)
                   {
                      msg_obj.css("color", "green").html(data.msg);
                   }
                   else
                   {
                       msg_obj.css("color", "red").html(data.msg);
                   }
                },
          "json");
          }
        });

   jQuery('#retype_password').keyup(function(){
         checkPassMatch(jQuery('#password'), jQuery(this));
   });
   jQuery('#password').keyup(function(){
         checkPassMatch(jQuery(this), jQuery('#retype_password'));
   });

   jQuery('#deleterecord').click(function(){
      var u = 'admin.php?page=wp_eMember_manage&members_action=delete&deleterecord='+
              jQuery(this).attr('secret')+'&confirm=1';
      top.document.location = u;
      return false;
   });
   jQuery('#deleterecord').confirm({timeout:5000});

    var imgPath = '<?php echo get_option('siteurl').'/wp-content/plugins/'.
                   dirname(plugin_basename(__FILE__)) . '/images/' ;?>';
    jQuery('#member_since').datepicker({dateFormat: 'yy-mm-dd' ,showOn: 'button', buttonImage: imgPath+'calendar.gif', buttonImageOnly: true})
    .dateEntry({dateFormat: 'ymd-',spinnerImage: '', useMouseWheel:false});

    jQuery('#subscription_starts').datepicker({dateFormat: 'yy-mm-dd' ,showOn: 'button', buttonImage: imgPath+'calendar.gif', buttonImageOnly: true})
    .dateEntry({dateFormat: 'ymd-',spinnerImage: '', useMouseWheel:false});
    jQuery('#user_name').focus(function(e){
       clearErrorMsg('user_name');
    });
    jQuery('#password').focus(function(e){
       clearErrorMsg('password');
    });
    jQuery('#email').focus(function(e){
       clearErrorMsg('email');
    });
    jQuery('#membership_level').focus(function(e){
       clearErrorMsg('membership_level');
    });
    jQuery('form').submit(function(e){
       var ok = true;
       ok = checkPassMatch(jQuery('#password'), jQuery('#retype_password'));
       ok = checkError('user_name', {'required':'This field is required',"1_chars":"User name is too short."})&& ok;
       var isEdit = jQuery('#editedrecord');
       if(isEdit.length<1)  {ok = checkError('password', {'required':'This field is required'})&& ok};
       ok = checkError('email', {'required':'This field is required','email': 'This is not a valid email address'})&& ok;
       ok = checkError('membership_level', {'required':'This field is required'})&& ok;       
       return ok&&available;
    });
});
</script>