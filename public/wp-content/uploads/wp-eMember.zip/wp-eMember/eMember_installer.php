<?php
//***** Installer *****
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
//require_once(ABSPATH . 'wp-admin/upgrade.php');
//***Installer variables***
$wp_eMember_db_version = "3.0.1";
global $wpdb;
$members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
$membership_table   = $wpdb->prefix . "wp_eMember_membership_tbl";
$auth_session_table = $wpdb->prefix . "wp_auth_session_tbl";
$members_meta_table = $wpdb->prefix . "wp_members_meta_tbl";
//***Installer***
if($wpdb->get_var("SHOW TABLES LIKE '$members_table_name'") != $members_table_name)
{
   $sql = "CREATE TABLE " . $members_table_name . " (
          `member_id` int(12) NOT NULL PRIMARY KEY AUTO_INCREMENT,
          `user_name` varchar(32) NOT NULL,
          `first_name` varchar(32) DEFAULT '',
          `last_name` varchar(32) DEFAULT '',
          `password` varchar(64) NOT NULL,
          `member_since` date NOT NULL DEFAULT '0000-00-00',
          `membership_level` smallint(6) NOT NULL,
          `more_membership_levels` VARCHAR(100) DEFAULT NULL,
          `account_state` enum('active','inactive','expired','pending','unsubscribed') DEFAULT 'pending',
          `last_accessed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
          `last_accessed_from_ip` varchar(15) NOT NULL,
          `email` varchar(64) DEFAULT NULL,
          `phone` varchar(64) DEFAULT NULL,
          `address_street` varchar(255) DEFAULT NULL,
          `address_city` varchar(255) DEFAULT NULL,
          `address_state` varchar(255) DEFAULT NULL,
          `address_zipcode` varchar(255) DEFAULT NULL,
          `country` varchar(255) DEFAULT NULL,
          `gender` enum('male','female','not specified') DEFAULT 'not specified',
          `referrer` varchar(255) DEFAULT NULL,
          `extra_info` text,
          `reg_code` varchar(255) DEFAULT NULL,
          `subscription_starts` date DEFAULT NULL,
          `txn_id` varchar(64) DEFAULT '',
          `subscr_id` varchar(32) DEFAULT '',
          `company_name` varchar(100) DEFAULT '',
          `flags` int(11) DEFAULT '0'
      );";
   dbDelta($sql);

   // Add default options

   add_option("wp_eMember_db_version", $wp_eMember_db_version);
   include_once('emember_config.php');
   $emember_config = Emember_Config::getInstance();
   //$emember_config->loadConfig();
   $emember_config->setValue('eMember_reg_firstname' ,"checked='checked'");
   $emember_config->setValue('eMember_reg_lastname'  ,"checked='checked'");
   $emember_config->setValue('eMember_edit_firstname',"checked='checked'"); 
   $emember_config->setValue('eMember_edit_lastname' ,"checked='checked'");
   $emember_config->setValue('eMember_edit_company'  ,"checked='checked'");
   $emember_config->setValue('eMember_edit_email'    ,"checked='checked'");
   $emember_config->setValue('eMember_edit_phone'    ,"checked='checked'");
   $emember_config->setValue('eMember_edit_street'   ,"checked='checked'");
   $emember_config->setValue('eMember_edit_city'     ,"checked='checked'");
   $emember_config->setValue('eMember_edit_state'    ,"checked='checked'");
   $emember_config->setValue('eMember_edit_zipcode'  ,"checked='checked'");
   $emember_config->setValue('eMember_edit_country'  ,"checked='checked'");
   $emember_config->saveConfig();
}
if($wpdb->get_var("SHOW TABLES LIKE '$members_meta_table'") != $members_meta_table)
{
   $sql = "CREATE TABLE IF NOT EXISTS " .$members_meta_table. " (
          umeta_id bigint(20) unsigned NOT NULL PRIMARY KEY AUTO_INCREMENT,
  		  user_id bigint(20) unsigned NOT NULL DEFAULT '0',
          meta_key varchar(255) DEFAULT NULL,
          meta_value longtext,
          PRIMARY KEY (umeta_id),
          KEY user_id (user_id)
      ) ;";
   dbDelta($sql);

   // Add default options

   add_option("wp_eMember_db_version", $wp_eMember_db_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$auth_session_table'") != $auth_session_table)
{
   $sql = "CREATE TABLE $auth_session_table (
         id INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
         session_id VARCHAR( 100 ) NOT NULL ,
         user_id INT NOT NULL ,
         last_impression TIMESTAMP NOT NULL ,
         logged_in_from_ip varchar(15) NOT NULL,
         UNIQUE (session_id)
      ) ENGINE = MYISAM ";
   dbDelta($sql);

   // Add default options

   add_option("wp_eMember_db_version", $wp_eMember_db_version);
}
if($wpdb->get_var("SHOW TABLES LIKE '$membership_table'") != $membership_table)
{
   $sql = "CREATE TABLE ".$membership_table." (
         id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
         alias varchar(127) NOT NULL,
         role varchar(255) NOT NULL DEFAULT 'subscriber',
         permissions tinyint(4) NOT NULL DEFAULT '0',
         subscription_period int(11) NOT NULL DEFAULT '-1',
         subscription_unit   VARCHAR(15)        NULL,
         loginredirect_page  text NULL,
         category_list longtext,
         page_list longtext,
         post_list longtext,
         comment_list longtext,
         disable_bookmark_list longtext,
         options longtext          
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
   dbDelta($sql);
   //file_put_contents(WP_PLUGIN_DIR .'/' . WP_EMEMBER_FOLDER .  '/temp1.txt', serialize($wpdb));   
   $sql = "SELECT * FROM " . $membership_table . " WHERE id = 1";
   $results = $wpdb->get_row($sql);
   if(is_null($results))
   {
      $sql = "INSERT INTO  ".$membership_table."  (
            id ,
            alias ,
            role ,
            permissions ,
            subscription_period ,
            subscription_unit,
            loginredirect_page,
            category_list ,
            page_list ,
            post_list ,
            comment_list,
            disable_bookmark_list,
            options
         )VALUES (NULL , 'Content Protection', 'administrator', '15', '0',NULL,NULL, NULL , NULL , NULL , NULL,NULL,NULL
         );";
      $wpdb->query($sql);
   }
   // Add default options

   add_option("wp_eMember_db_version", $wp_eMember_db_version);
}
//***Upgrader***
$installed_ver = get_option( "wp_eMember_db_version" );

if( $installed_ver != $wp_eMember_db_version )
{
   $sql = "CREATE TABLE " . $members_table_name . " (
          `member_id` int(12) NOT NULL PRIMARY KEY AUTO_INCREMENT,
          `user_name` varchar(32) NOT NULL,
          `first_name` varchar(32) DEFAULT '',
          `last_name` varchar(32) DEFAULT '',
          `password` varchar(64) NOT NULL,
          `member_since` date NOT NULL DEFAULT '0000-00-00',
          `membership_level` smallint(6) NOT NULL,
          `more_membership_levels` VARCHAR(100) DEFAULT NULL,
          `account_state` enum('active','inactive','expired','pending','unsubscribed') DEFAULT 'pending',
          `last_accessed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
          `last_accessed_from_ip` varchar(15) NOT NULL,
          `email` varchar(64) DEFAULT NULL,
          `phone` varchar(64) DEFAULT NULL,
          `address_street` varchar(255) DEFAULT NULL,
          `address_city` varchar(255) DEFAULT NULL,
          `address_state` varchar(255) DEFAULT NULL,
          `address_zipcode` varchar(255) DEFAULT NULL,
          `country` varchar(255) DEFAULT NULL,
          `gender` enum('male','female','not specified') DEFAULT 'not specified',
          `referrer` varchar(255) DEFAULT NULL,
          `extra_info` text,
          `reg_code` varchar(255) DEFAULT NULL,
          `subscription_starts` date DEFAULT NULL,
          `txn_id` varchar(64) DEFAULT '',
          `subscr_id` varchar(32) DEFAULT '',
          `company_name` varchar(100) DEFAULT '',
          `flags` int(11) DEFAULT '0'
      );";
      dbDelta($sql);
    $sql = "CREATE TABLE $auth_session_table (
         id INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
         session_id VARCHAR( 100 ) NOT NULL ,
         user_id INT NOT NULL ,
         logged_in_from_ip varchar(15) NOT NULL,
         last_impression TIMESTAMP NOT NULL ,
         UNIQUE (session_id)
      ) ENGINE = MYISAM ";
      dbDelta($sql);
   $sql = "CREATE TABLE IF NOT EXISTS " .$members_meta_table. " (
         umeta_id  bigint(20) unsigned NOT NULL  PRIMARY KEY AUTO_INCREMENT,
  		 user_id  bigint(20) unsigned NOT NULL DEFAULT '0',
         meta_key  varchar(255) DEFAULT NULL,
         meta_value longtext,
         KEY user_id (user_id),
         KEY meta_key (meta_key)
      ) ;";
      dbDelta($sql);
   $sql = "CREATE TABLE ".$membership_table." (
         id int(11) NOT NULL  PRIMARY KEY AUTO_INCREMENT,
         alias varchar(127) NOT NULL,
         role varchar(255) NOT NULL DEFAULT 'subscriber',
         permissions tinyint(4) NOT NULL DEFAULT '0',
         subscription_period int(11) NOT NULL DEFAULT '-1',
         subscription_unit   VARCHAR(15)        NULL,
         loginredirect_page  text NULL,
         category_list longtext,
         page_list longtext,
         post_list longtext,
         comment_list longtext,
         disable_bookmark_list longtext,
         options longtext
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
   dbDelta($sql);
   //file_put_contents(WP_PLUGIN_DIR .'/' . WP_EMEMBER_FOLDER .  '/temp.txt', serialize($wpdb));
   
   $sql = "SELECT * FROM " . $membership_table . " WHERE id = 1";
   $results = $wpdb->get_row($sql);
   if(is_null($results))
   {
      $sql = "INSERT INTO  ".$membership_table."  (
            id ,
            alias ,
            role ,
            permissions ,
            subscription_period ,
            subscription_unit,
            category_list ,
            page_list ,
            post_list ,
            comment_list,
            disable_bookmark_list,
            options
         )VALUES (NULL , 'Content Protection', '1', '0', '0', NULL,NULL , NULL , NULL , NULL,NULL,NULL
         );";
      $wpdb->query($sql);
   }
      // Add default options
      add_option("wp_eMember_db_version", $wp_eMember_db_version);
}

/******************************************************************/
/*** === Other upgrade/default value setting realated tasks === ***/
/******************************************************************/

$wp_eMember_rego_field_default_settings_ver = 1;
$currently_installed_ver = get_option( "wp_eMember_rego_field_default_settings_ver" );
if($currently_installed_ver < $wp_eMember_rego_field_default_settings_ver)
{
   include_once('emember_config.php');
   $emember_config = Emember_Config::getInstance();
   //$emember_config->loadConfig();
   $emember_config->setValue('eMember_reg_firstname' ,"checked='checked'");
   $emember_config->setValue('eMember_reg_lastname'  ,"checked='checked'");
   $emember_config->setValue('eMember_edit_firstname',"checked='checked'"); 
   $emember_config->setValue('eMember_edit_lastname' ,"checked='checked'");
   $emember_config->setValue('eMember_edit_company'  ,"checked='checked'");
   $emember_config->setValue('eMember_edit_email'    ,"checked='checked'");
   $emember_config->setValue('eMember_edit_phone'    ,"checked='checked'");
   $emember_config->setValue('eMember_edit_street'   ,"checked='checked'");
   $emember_config->setValue('eMember_edit_city'     ,"checked='checked'");
   $emember_config->setValue('eMember_edit_state'    ,"checked='checked'");
   $emember_config->setValue('eMember_edit_zipcode'  ,"checked='checked'");
   $emember_config->setValue('eMember_edit_country'  ,"checked='checked'");
   $emember_config->saveConfig();	
   add_option("wp_eMember_rego_field_default_settings_ver", $wp_eMember_rego_field_default_settings_ver);
}

/*** Settings default values at activation time ***/
$senders_email_address = get_bloginfo('name')." <".get_bloginfo('admin_email').">";
$eMember_email_subject = "Complete your registration";
$eMember_email_body = "Dear {first_name} {last_name}".
			  "\n\nThank you for joining us!".
			  "\n\nPlease complete your registration by visiting the following link:".
			  "\n\n{reg_link}".
			  "\n\nThank You";        

add_option('senders_email_address', stripslashes($senders_email_address));
add_option('eMember_email_subject', stripslashes($eMember_email_subject));
add_option('eMember_email_body', stripslashes($eMember_email_body));

//***** End Installer *****
?>