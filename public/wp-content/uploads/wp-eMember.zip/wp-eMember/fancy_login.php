<fieldset id="signin_menu">
    <span id="emem_ui_close" class="ui_close">X</span>
    <form action="<?php echo $login_url?>" id="loginForm" name="loginForm" method="post">
        <p class="textbox">
            <label for="login_user_name"><?php echo EMEMBER_USER_NAME;?></label>
            <input type="text" tabindex="4" title="username" value="" name="login_user_name" id="login_user_name">
        </p>
        <p class="textbox">
            <label for="login_pwd"><?php echo EMEMBER_PASSWORD;?></label>
            <input type="password" tabindex="5" title="password" value="" name="login_pwd" id="login_pwd">
        </p>
        
        <p class="rememberme">
            <input type="submit" tabindex="7" value="Sign in" class="emember_button" name="doLogin" id="doLogin">
            <input type="checkbox" tabindex="6" value="forever" name="rememberme" id="rememberme">
            <input type="hidden" value="1" name="testcookie" />
            <label for="remember"><?php echo EMEMBER_REMEMBER_ME;?></label>
        </p>
        <p class="forgot">
            <a id="forgot_pass" rel="#prompt" class="forgot_pass_link" href="javascript:void(0);"><?php echo EMEMBER_FORGOT_PASS;?></a>
        </p>        
        <p class="forgot-username">
            <a title="Join us" id="join_us" href="<?php echo $join_url; ?>"><?php echo EMEMBER_JOIN_US;?></a>
        </p>
    </form>
    <div id="marker" style="display: none;"></div>
</fieldset>
<script type="text/javascript">
/*<![CDATA[*/
jQuery(document).ready(function(){
	jQuery('#emem_ui_close').click(function(e){
		jQuery(this).parent().hide('slow');
		jQuery('#marker').html("");
	});
	jQuery('.emember_fancy_login_link').click(
			function(e){
				var targetId = jQuery(e.target).addClass('activeLink').attr('id');
				var alreadyOpened = jQuery('#marker');
				var menu = jQuery('#signin_menu'); 
                                var offset = jQuery(e.target).offset();
				if(!alreadyOpened.html()){
					alreadyOpened.html(targetId);
					menu.css({'left':offset.left +'px','top':(offset.top+20) +'px'}).show('slow');
				}
				else if (targetId !=alreadyOpened.html()){
					alreadyOpened.html(targetId);
					menu.hide().css({'left':offset.left +'px','top':(offset.top+20) +'px'}).show('slow');
				}else if(targetId ==alreadyOpened.html()){
                                        jQuery(e.target).removeClass('activeLink');
					alreadyOpened.html("");
					menu.hide('slow');
				}				
		    }
		);
});
/*]]>*/
</script>
