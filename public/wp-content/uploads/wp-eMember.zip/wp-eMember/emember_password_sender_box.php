<div class="modal" id="prompt">
<h2><?php echo EMEMBER_PASS_RESET;?></h2>
        <div id="mailMsg"></div>
        <div id="mailForm">        
            <?php echo EMEMBER_PASS_RESET_MSG; ?>
            <form action="javascript:void(0);" method="post" name="mailSendForm" id="mailSendForm" >
                <p class="textbox">
	                <label for="email" class="eMember_label"><?php echo EMEMBER_EMAIL;?>: </label>
	                <input class="eMember_text_input" type="text" id="email" name="email" size="20" value="" />
	                <input class="eMember_text_input" type="hidden" id="event" name="event" size="20" value="send_mail" />                
                </p>
                <p>
                     <input name="doSend" type="submit" id="doSend" class="emember_button"  value="<?php echo EMEMBER_RESET;?>" />
                     <input type="button" class="close emember_button" value="<?php echo EMEMBER_CLOSE;?>" />                
                </p>
                <!--  <table >
                <tr>
                   <td width="30%"><label for="email" class="eMember_label"><?php echo EMEMBER_EMAIL;?>: </label></td>
                   <td>
                       <input class="eMember_text_input" type="text" id="email" name="email" size="20" value="" />
                       <input class="eMember_text_input" type="hidden" id="event" name="event" size="20" value="send_mail" />
                     </td>
                </tr>
                <tr>
                   <td colspan="2">
                     <input name="doSend" type="submit" id="doSend" class="emember_button"  value="<?php echo EMEMBER_RESET;?>" />
                     <input type="button" class="close emember_button" value="<?php echo EMEMBER_CLOSE;?>" />
                   </td>
                </tr>
               </table>-->
           </form>
       </div>
</div>
   <script type="text/javascript">
   /*<![CDATA[*/
    jQuery(document).ready(function(){
    trigger = '';    
    
    $forgot_pass_overlay = jQuery(".forgot_pass_link").click(function(e){
        jQuery("#mailMsg").html("").hide();
        jQuery("#mailForm").show();   
        jQuery('.eMember_text_input').val("");     
        }).overlay({
        // some mask tweaks suitable for modal dialogs
        mask: {
            color: '#ebecff'/*'darkred'*//*'#E7E7E7'*/,
            loadSpeed: 200,
            top: '30%',
            opacity: 0.9
        },
        api:true,
        onBeforeLoad:function(){
            trigger = this.getTrigger();
        },    
        closeOnClick: false
    });
        	
  	jQuery("#mailSendForm").submit(function(e){
       var $this = this;
       var divs = jQuery($this).parent().parent().find("div");
       var emailId = jQuery($this).find("input").eq(0).val();
       if(emailId=="")
          return;
       divs.eq(1).hide();
       divs.eq(0).html("").append(jQuery('<h3>Please Wait...</h3>')).show();
       jQuery.get( WPURL+"/wp-admin/admin-ajax.php",{"event":"send_mail","email":emailId},    	       
             function(data){
                 divs.eq(0).html("").append(jQuery('<h3>'+data.msg+'</h3>'));                 
                 setTimeout("trigger.overlay().close()", 1000);                                  
             },
       "json");
       e.preventDefault();
    });
    
    jQuery('.loginForm').submit(function(){
		return true;
    });
        
	jQuery(".ememberbookmarkbutton").find("a").each(function(i){
		jQuery(this).click(function(e){
			e.preventDefault();
	    		  var id = jQuery(this).attr("href");			  
	    		  if(!id) return;
	    		  var $this = this;
	    	      jQuery.get(WPURL+"/wp-admin/admin-ajax.php",
	    	         { event: "bookmark_ajax",id: id},
	    	            function(data){
	    	        	 jQuery($this).parent().html(data.msg);
	    	         	},
	    	         "json"
	    	     );			
			});
		});  
	});
	function checkError(at, rules)
	{ 
	   var testable = jQuery('#'+at);
	   var ok       = true;
	
	   for(var rule in rules)
	   {
	      switch(rule)
	      {
	         case 'required':
	            if(jQuery.trim(testable.val())=='') ok = false;
	            break;
	         case 'email':
	            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	            if(!filter.test(jQuery.trim(testable.val()))) ok = false;
	            break;
	         case '5_chars':
	            var testcase = jQuery.trim(testable.val());
	            if(testcase.length<5) ok = false;
	            break;
	         default:
	            alert('undefined rule: ' +rule);
	            return false;
	            break;
	      }
	
	      if(!ok)
	      {
	          if(!jQuery("#"+at+"_msg").length)
	          { 
	             testable.css("border", "1px solid red").
	             focus(function(){jQuery(this).css("border","");jQuery("#"+at+"_msg").html("");}).
	             after(jQuery('<span id= "'+at+'_msg" >'+rules[rule]+'</span>').	    	             
	                   css("color", "red")).after(jQuery("<br />"));
	          }
	          else
	          {
	            testable.css("color", "1px solid red").
	            focus(function(){jQuery(this).css("border","");jQuery("#"+at+"_msg").html("");});
	            jQuery("#"+at+"_msg").html(rules[rule]);
	          }
	          return false;
	      }
	   }
	   return true;
	}     
    /*]]>*/	   
    </script>                