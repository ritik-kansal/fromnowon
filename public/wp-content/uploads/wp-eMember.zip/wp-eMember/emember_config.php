<?php
class Emember_Config
{
	var $configs;
	static $_this;
	function loadConfig(){		
		$this->configs = unserialize(get_option('eMember_configs')) ;
	}
	
    function getValue($key){
    	return isset($this->configs[$key])?$this->configs[$key] : '';    	
    }
    
    function setValue($key, $value){
    	$this->configs[$key] = $value;
    }
    function saveConfig(){
    	update_option('eMember_configs', serialize($this->configs) );
    }
    
    static function getInstance(){
    	if(empty(self::$_this)){
    		self::$_this = new Emember_Config();
    		self::$_this->loadConfig();
    		return self::$_this;
    	}
    	return self::$_this;
    } 
}
?>