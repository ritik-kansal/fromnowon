<?php
session_start();
include_once('eMember_db_access.php');
include_once('eMember_misc_functions.php');
include_once('auth.php');

function build_menu($current)
{
   ?>
   <ul class="eMemberSubMenu">
      <li <?php echo ($current==1) ? 'class="current"' : ''; ?> ><a href="admin.php?page=wp_eMember_manage">Manage Members</a></li>
      <li <?php echo ($current==2) ? 'class="current"' : ''; ?> ><a href="admin.php?page=wp_eMember_manage&members_action=add_edit">Add/Edit Member</a></li>
      <li <?php echo ($current==3) ? 'class="current"' : ''; ?> ><a href="admin.php?page=wp_eMember_manage&members_action=manage_list">Member Lists</a></li>
      <li <?php echo ($current==4) ? 'class="current"' : ''; ?> ><a href="admin.php?page=wp_eMember_manage&members_action=add_wp_members">Import WP Users</a></li>
      <li <?php echo ($current==5) ? 'class="current"' : ''; ?> ><a href="admin.php?page=wp_eMember_manage&members_action=manage_blacklist">Manage Blacklist</a></li>
      <li <?php echo ($current==6) ? 'class="current"' : ''; ?> ><a href="admin.php?page=wp_eMember_manage&members_action=manage_upgrade">Auto Upgrade</a></li>
   </ul>
   <?php
}

function wp_eMember_members()
{
    echo '<div class="wrap"><h2>WP eMembers - Members v'.WP_EMEMBER_VERSION.'</h2>';
    echo '<div id="poststuff"><div id="post-body">';
    echo check_php_version();
    echo eMember_admin_submenu_css();
   switch ($_GET['members_action'])
   {
       case 'add_edit':
              build_menu(2);
           wp_eMember_add_memebers();
           break;
       case 'manage_list':
              build_menu(3);
           wp_eMember_manage_memebers_lists();
           break;
       case 'delete':
           wp_eMember_delete_member();
           break;
       case 'edit_ip_lock':
              build_menu(1);
              wp_eMember_edit_ip_lock();
              break;
       case 'add_wp_members':
              build_menu(4);
           wp_eMember_add_wp_members();
           break;
       case 'manage_blacklist':
              build_menu(5);
           wp_eMember_manage_blackList();
           break;
       case 'manage_upgrade':
              build_menu(6);
           wp_eMember_manage_upgrade();
           break;           
       case 'manage':
       default:
              build_menu(1);
           wp_eMember_manage_members();
           break;
   }
    echo '</div></div>';
    echo '</div>';
}
function wp_eMember_manage_upgrade()
{
	if(isset($_POST['submit']))
	{
		foreach($_POST['data'] as $key=>$data)
		{
			if($key==1) continue;
			$fields = array();
			$fields['options'] = serialize($data);
			dbAccess::update(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE,'id = ' . $key, $fields);
		}
		echo wp_eMember_message('Updated!');
	}
    global $emember_config;
   $levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
   ob_start(); 
    ?>
     <form method="post">
	    <div id="Pagination" class="pagination"></div>
	    <table id="membership_level_list" class="widefat"><thead><tr>
	    <th scope="col"><?php echo __('Membership Level', 'wp_eMember');?></th>
	    <th scope="col"><?php echo __('Promote to', 'wp_eMember');?></th>
	    <th scope="col"><?php echo __('After #of Days From the Subscription Start Date', 'wp_eMember');?></th>
	    </tr></thead>
	    <tbody>    
	     <?php
	    $count = 0;
	    foreach($levels as $level)
	    {   $em_options = unserialize($level->options);  	
	    	?>
	    	<tr <?php echo ($count%2)? 'class="alternate"': '';?>>
	    		<td>
	    			<?php echo $level->alias;?>
	    		</td>
	    		<td>
	    			<select name="data[<?php echo $level->id;?>][promoted_level_id]">
	    			    <option value="-1">No Auto Promote</option>	    			
	    			    <?php	    			     
	    			     foreach($levels as $l)
	    			     {
	    		       	    ?>	    			    
	    				<option <?php echo ($l->id===$em_options['promoted_level_id'])? 'selected="selected"':'';?> value="<?php echo $l->id;?>">
	    					<?php echo $l->alias;?>
	    				</option>
	    				<?php
	    			     } 
	    				?>
	    			</select>
	    		</td>
	    		<td>
	    			<input name="data[<?php echo $level->id;?>][days_after]" type="text" size="6" value="<?php echo $em_options['days_after'];?>" ></input> Day(s) After the Subscription Start Date
	    		</td>
	    	</tr>
	    	<?php     	
	    	$count++;
	    }
	    ?>    
	    </tbody>
	    </table>
	    <p class="submit">
	    <input type="submit" name="submit" value="Update" class="button-secondary"/>
	    </p>
    </form>
    <?php 	
    $content = ob_get_contents();
    ob_end_clean();
    echo $content;
}
function wp_eMember_edit_ip_lock()
{
    echo '<h2>Manage IP Lock</h2>';
    if(isset($_GET['editrecord']))
    {
        global $wpdb;
        $query = "SELECT meta_value FROM " . WP_EMEMBER_MEMBERS_META_TABLE .
                 " WHERE user_id = " . $_GET['editrecord'] . " AND meta_key = 'login_count'";
        $login_count = $wpdb->get_row($query);        
        $login_count = unserialize($login_count->meta_value);

        $used_ips = '';
        if(isset($login_count[date('y-m-d')]))
        {
            $used_ips = implode(';',$login_count[date('y-m-d')]);
        }

        if(isset($_POST['submit']))
        {

            $used_ips = $_POST['locked_ips'];
            if(empty($used_ips))
                $ips = array();
            else
                $ips = explode(';',$_POST['locked_ips']);

            $ips = array(date('y-m-d')=>array_unique($ips));
            if($login_count === false)
                   $query =  "INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . "(user_id,meta_key,meta_value)".
                             "VALUES(".$_GET['editrecord'].", 'login_count', '".serialize($ips)."')";
            else
                $query =  "UPDATE " . WP_EMEMBER_MEMBERS_META_TABLE . " SET meta_value = '" . serialize($ips) . "'".
                          " WHERE user_id= " . $_GET['editrecord'] . " AND meta_key = 'login_count'";
            $wpdb->query($query);
            echo wp_eMember_message('Updated!');
        }

    ?>
    <form method="post">
        <table class="widefat">
          <tr>
            <th>IP Addresses</th>
          </tr>
          <tr>
            <td><p>Following list provides all the IP addresses used by this user to log into this site.you can modify it but make sure that IP addresses are semi-colon separated.</p></td>
          </tr>
          <tr>
            <td><br/><textarea name="locked_ips" rows="15" cols="35"><?php echo $used_ips; ?></textarea> </td>
          </tr>
          <tr >
              <td colspan="2" ><p class="submit"><input type="submit" name="submit" value="Update" /> </p></td>
          </tr>
        </table>
    </form>

    <?php
    }
    else
    {
        die('<span style="color:red;">Oops!</span>');
    }
}
function wp_eMember_manage_blackList()
{
    global $emember_config;
    ?>
    <h2>Registration BlackList</h2>
    <?php
    if(isset($_POST['submit']))
    {
        $options = array('blacklisted_ips'=>$_POST['blacklisted_ips'],
                         'blacklisted_emails'=>$_POST['blacklisted_emails']
                        );
        $emember_config->setValue('blacklisted_ips', $_POST['blacklisted_ips']);
        $emember_config->setValue('blacklisted_emails',$_POST['blacklisted_emails']);
        $emember_config->saveConfig();
    }

     $blacklisted_ips    = $emember_config->getValue('blacklisted_ips');
     $blacklisted_emails = $emember_config->getValue('blacklisted_emails');
    ?>
    <form method="post">
        <table class="widefat">
          <tr>
            <th>IP Black List</th>
            <th>Email Black List</th>
          </tr>
          <tr>
            <td><p>Following list provides a list (semi-colon separated) of blacklisted IP addresses. You may modify the list as needed.</p></td>
            <td><p>Following list provides a list (semi-colon separated) of blacklisted email addresses. You may modify the list as needed.</p></td>
          </tr>
          <tr>
            <td><br/><textarea name="blacklisted_ips" rows="15" cols="35"><?php echo $blacklisted_ips; ?></textarea> </td>
            <td><br/><textarea name="blacklisted_emails" rows="15" cols="35"><?php echo $blacklisted_emails; ?></textarea> </td>
          </tr>
          <tr >
              <td colspan="2" ><p class="submit"><input type="submit" name="submit" value="Update" /> </p></td>
          </tr>
        </table>
    </form>
    <?php
}
function wp_eMember_add_wp_members()
{
    global $emember_config;
    if(isset($_POST['submit']))
    {
        $updated = false;
        foreach($_POST['selected_wp_users'] as $row)
        {
            if(isset($row['ID']))
            {
                $user_info = get_userdata($row['ID']);
                $user_cap = array_keys($user_info->wp_capabilities);
                $fields = array();
                $fields['user_name'] = $user_info->user_login;
                $fields['first_name'] = $user_info->user_firstname;
                $fields['last_name'] = $user_info->user_lastname;
                $fields['password'] = $user_info->user_pass;
                $fields['member_since'] = date('Y-m-d H:i:s');                
                $fields['membership_level'] = $row['membership_level'];
                $fields['account_state'] = $row['account_state'];
                $fields['email'] = $user_info->user_email;
                $fields['address_street'] = '';
                $fields['address_city'] = '';
                $fields['address_state'] = '';
                $fields['address_zipcode'] ='';
                $fields['country'] = '';
                $fields['gender'] = '';
                $fields['referrer'] = '';
                $fields['subscription_starts'] = $row['subscription_starts'];
                $fields['extra_info'] = '';
                if(isset($row['preserve_wp_role']))
                {

                    $fields['flags'] = 1;
                }
                else
                {
                    $fields['flags'] = 0;
                    if(!in_array('administrator',$user_cap))
                    	update_wp_user_Role($row['ID'], $row['membership_level']);
                }
                $user_exists = emember_username_exists($fields['user_name']);
                if($user_exists)
                {
                    $updated = dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $user_exists, $fields);
                }
                else
                {
                    $updated = dbAccess::insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
                }

            }
        }
        if($updated === false)
        {
            $_SESSION['flash_message'] = '<div id="message" style= "color:red;" class="updated fade"><p>'.__('Failed to update ', 'wp_eMember').__('Member Info.', 'wp_eMember').'</p></div>';
        }
        else
        {
            $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>'.__('Member Info ', 'wp_eMember').__('updated.', 'wp_eMember').'</p></div>';
            echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
            return ;
        }
    }

    global $wpdb;
    $wp_member_count = $wpdb->get_row("SELECT count(*) as count FROM $wpdb->users ORDER BY ID");

    $all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
    ?>
<div class="wrap"><h2>WP eMembers - Manage Wordpress Members</h2>
    <div id="Pagination" class="pagination"></div>
    <form method="post">
    <table class="widefat" id="wp_member_list">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">User Name</th>
                <th scope="col">Email</th>
                <th scope="col">Membership Level</th>
                <th scope="col">Subscription Starts From</th>
                <th scope="col">Account State</th>
                <th scope="col">Preserve Role</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
    <p class="submit">
        <input name="submit" type="submit" value="Submit" />
    </p>
    </form>
    <script type="text/javascript">
    jQuery(document).ready(function(){
/*********************/
      var counter = 0;
      var itms_per_pg = parseInt(<?php $items_per_page = $emember_config->getValue('eMember_rows_per_page');
      $items_per_page = trim($items_per_page);
      echo (!empty($items_per_page)&& is_numeric($items_per_page))? $items_per_page:30;?>);
      var count = <?php echo $wp_member_count->count; ?>;
      var $tbody = jQuery('#wp_member_list tbody');
      jQuery("#Pagination").pagination(count, {
         callback: function(i,container){
            $tbody.html('Loading...........');
           var levelSelect = jQuery('<select />');
           <?php
           foreach($all_levels as $l)
           {
           ?>
           jQuery('<option />').
           val('<?php echo $l->id; ?>').
           html('<?php echo $l->alias; ?>').
           appendTo(levelSelect);
           <?php
            }
           ?>
           var statusSelect = jQuery('<select />').
           append(jQuery('<option value="active" />').html('Active')).
           append(jQuery('<option value="inactive" />').html('Inactive')).
           append(jQuery('<option value="blocked" />').html('Blocked'));

           var maxIndex = Math.min((i+1)*itms_per_pg, count);
           var target_url = '<?php bloginfo('wpurl'); ?>';
           jQuery.get(target_url + "/wp-admin/admin-ajax.php",
               { event: "wp_user_list_ajax",start:i*itms_per_pg,limit:itms_per_pg},
                 function(data){
                      $tbody.html('');
                      if(data.length<1) {$tbody.html('No member found.');return;}
                      for( var k in data){
                          if(jQuery.isFunction(data[k])) continue;
                       var cls = (counter%2)? 'class="alternate"' : '';
                       var $tr2    = jQuery('<tr valign="top" '+cls+' />').appendTo($tbody);
                       for (l in data[k]){
                          if(l=='ID'){
                             jQuery('<td scope="row" class="check-column" />').
                                append(jQuery('<input type="checkbox"  name="selected_wp_users['+counter+'][ID]" value="'+data[k][l]+'" />').removeAttr('checked')).
                                appendTo($tr2);
                          }
                          else{
                             jQuery('<td />').
                                html(data[k][l]).
                                appendTo($tr2);
                          }
                       }

                       jQuery('<td />').
                       append(levelSelect.clone().attr('name', 'selected_wp_users['+counter+'][membership_level]')).
                       appendTo($tr2);
                       var inp = jQuery('<input type="text" value="<?php echo date('Y-m-d');?>">').
                                 attr('name', 'selected_wp_users['+counter+'][subscription_starts]');
                       jQuery('<td />').
                       append(inp).
                       appendTo($tr2);
                       jQuery('<td />').
                       append(statusSelect.clone().attr('name', 'selected_wp_users['+counter+'][account_state]')).
                       appendTo($tr2);
                       jQuery('<td />').
                       append(jQuery('<input type="checkbox"  name="selected_wp_users['+counter+'][preserve_wp_role]" value="1" />').attr('checked','checked')).
                       appendTo($tr2);
                       counter++;
                    }
                    bindDate();
                 },
                 'json'
             );
         },
         num_edge_entries: 2,
         num_display_entries: 10,
         items_per_page: itms_per_pg
      });


 /*****************/
          });
   function bindDate()
   {
        imgPath = '<?php echo get_option('siteurl').'/wp-content/plugins/'.
      dirname(plugin_basename(__FILE__)) . '/images/' ;?>';

       jQuery('#wp_member_list').find('input[type^="text"]').each(function(e){
           jQuery(this).datepicker({dateFormat: 'yy-mm-dd' ,showOn: 'button', buttonImage: imgPath+'calendar.gif', buttonImageOnly: true})
           .dateEntry({dateFormat: 'ymd-',spinnerImage: '', useMouseWheel:false});
        });

   }
    </script>
</div>
<?php
}
function wp_eMember_manage_memebers_lists()
{      	
    ?>
    <div class="postbox">
       <h3><label for="title">Member Email Options</label></h3>
       <div class="inside">
          <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
             <input type="hidden" name="wp_eMember_display_email_list_for_id" id="wp_eMember_display_email_list_for_id" value="true" />
             <table width="100%" border="0" cellspacing="0" cellpadding="6">
                <tr valign="top">
                   <td width="25%" align="left">
                      <strong>1)</strong> Display Member Email List for a Particular Membership Level:
                   </td>
                   <td align="left">
                      <input name="wp_eMember_mem_level_id" type="text" size="10" value="<?php echo $wp_eMember_mem_level_id; ?>" />
                      <input type="submit" name="wp_eMember_display_email_list_for_id" value="<?php _e('Display List'); ?> &raquo;" />
                      <br /><i>Enter the ID of the membership level that you want to display the member email list for (comma separated) and hit Display List.</i><br />
                    </td>
                </tr>
             </table>
          </form>

          <br />
          <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
             <input type="hidden" name="wp_eMember_display_all_member_email" id="wp_eMember_display_all_member_email" value="true" />
             <table width="100%" border="0" cellspacing="0" cellpadding="6">
                <tr valign="top">
                    <td width="25%" align="left">
                        <strong>2)</strong> Display Email List of All Members:
                    </td>
                    <td align="left">
                        <input type="submit" name="wp_eMember_display_all_member_email" value="<?php _e('Display All Members Email List'); ?> &raquo;" />
                        <br /><i>Use this to display a list of emails (comma separated) of all the members for bulk emailing purpuse.</i><br />
                    </td>
                </tr>
             </table>
          </form>
          <br/>
          <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
             <table width="100%" border="0" cellspacing="0" cellpadding="6">
                <tr valign="top">
                    <td width="25%" align="left">
                        <strong>3)</strong> Export All Member info:
                    </td>
                    <td align="left">
                        <input type="submit" name="wp_emember_export" value="<?php _e('Export'); ?> &raquo;" />
                        <br /><i>Use this to export all member info in CSV format.</i><br />
                    </td>
                </tr>
             </table>
          </form>          
       </div>
    </div>
    <?php
    global $wpdb;	
    if ($_POST['wp_eMember_display_email_list_for_id']){
        $selected_level_id = (string)$_POST["wp_eMember_mem_level_id"];
        $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
        $ret_member_db = $wpdb->get_results("SELECT * FROM $member_table WHERE membership_level = '$selected_level_id'", OBJECT);
        echo wp_eMember_display_member_email_list($ret_member_db);
    }
    if ($_POST['wp_eMember_display_all_member_email']){
        $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
        $ret_member_db = $wpdb->get_results("SELECT * FROM $member_table ORDER BY member_id DESC", OBJECT);
        echo wp_eMember_display_member_email_list($ret_member_db);
    }
}
function wp_eMember_display_member_email_list($ret_member_db)
{
    if ($ret_member_db)
    {
        foreach ($ret_member_db as $ret_member_db)
        {
            $output .= $ret_member_db->email;
            $output .= ', ';
        }
    }
    else
    {
        $output .= 'No Members found.';
    }
    return $output;
}

function wp_eMember_delete_member()
{
    wp_eMember_sub_header('<div class="wrap"><h2>WP eMembers - Manage Members</h2>');
    if ($_GET['deleterecord']!='')
    {
        $therecord=$_GET['deleterecord'];
        $profile = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=\'' . $therecord . '\'');
        $wp_user_id = username_exists($profile->user_name);

        $ud = get_userdata($wp_user_id);
        $delete_user = false;
        if(isset($ud->wp_capabilities['administrator'])||$ud->wp_user_level == 10){
            if(isset($_GET['confirm'])&&($_GET['confirm']==2))
               $delete_user = true;
            else{
                $u = "admin.php";
                $_GET['confirm'] = 2;
                $u .= '?' . http_build_query($_GET);
                $warning = "<div id='message' style=\"color:red;\" ><p>You are about to delete an account that has admin privilege.
                If you are using WordPress user integration then this will delete the corresponding user
                account from WordPress and you may not be able to log in as admin with this account.
                Continue? <a href='". $u. "'>yes</a>/<a href='javascript:void(0);' onclick='jQuery(\"#message\").remove();top.document.location=\"admin.php?page=wp_eMember_manage\";' >no</a></p></div>";
                echo $warning;
            }
        }
        else if(isset($_GET['confirm'])&&($_GET['confirm']=='1')){
            $delete_user = true;
        }
        if($delete_user){
            if($wp_user_id) wp_delete_user( $wp_user_id, 1 ); //assigns all related to this user to admin.
            $ret = dbAccess::delete(WP_EMEMBER_MEMBERS_TABLE_NAME, " member_id='$therecord' ");
            if($ret === false) wp_eMember_message('Member Delete Failed.');
            else wp_eMember_message('Member Deleted.');
            wp_eMember_list();
        }
    }
}
function wp_eMember_sub_header($sub_header)
{
   echo $sub_header;
}
function wp_eMember_message($msg)
{
   echo '<div id="message" class="updated fade"><p>'.__($msg, 'wp_eMember').'</p></div>';
}
function wp_eMember_list()
{
    global $emember_config;
    echo '<div id="Pagination" class="pagination"></div>';
    echo '<table id="member_list" class="widefat"><thead><tr>
    <th scope="col">'.__('Member ID', 'wp_eMember').'</th>
    <th scope="col">'.__('User Name', 'wp_eMember').'</th>
    <th scope="col">'.__('First Name', 'wp_eMember').'</th>
    <th scope="col">'.__('Last Name', 'wp_eMember').'</th>
    <th scope="col">'.__('Email', 'wp_eMember').'</th>
    <th scope="col">'.__('Membership Level', 'wp_eMember').'</th>
   <th scope="col">'.__('Subscription Starts From', 'wp_eMember').'</th>
    <th scope="col">'.__('Account State', 'wp_eMember').'</th>
    <th scope="col" colspan="3">'.__('Actions', 'wp_eMember').'</th>
    </tr></thead>
    <tbody>';

   global $wpdb;
   $emember_user_count = $wpdb->get_row("SELECT COUNT(*) as count FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME . ' ORDER BY member_id');

    echo '</tbody>
    </table>';
   ?>
   <script type="text/javascript">
   function drawContent(count, params){
       var counter = 0;
       var itms_per_pg = parseInt(<?php $items_per_page = $emember_config->getValue ('eMember_rows_per_page');
       $items_per_page = trim($items_per_page);
       echo (!empty($items_per_page)&& is_numeric($items_per_page))? $items_per_page:30;?>);
       var $tbody = jQuery('#member_list tbody');
       jQuery("#Pagination").pagination(count, {
          callback: function(i,container){
             $tbody.html('Loading...........');
            if(params)
                paramss = { event: "emember_user_list_ajax",start:i*itms_per_pg,limit:itms_per_pg,u:params.u, e:params.e,o:params.o};
            else
                paramss = { event: "emember_user_list_ajax",start:i*itms_per_pg,limit:itms_per_pg};
            var maxIndex = Math.min((i+1)*itms_per_pg, count);
            var target_url = '<?php bloginfo('wpurl'); ?>';
            jQuery.get(target_url + "/wp-admin/admin-ajax.php",
                paramss,
                  function(data){
                       $tbody.html('');
                       if(data.length<1) {$tbody.html('No member found.');return;}
                       for( var k in data){
                           if(jQuery.isFunction(data[k])) continue;
                        var cls = (counter%2)? 'class="alternate"' : '';
                        var $tr2    = jQuery('<tr valign="top" '+cls+' />').appendTo($tbody);
                        var $break = false;                        
                        for (l in data[k]){ 
                        	  if(data[k][l] == 'array'){
                            	  $break = true; 
                            	  continue;                            	  
                        	  }
                              jQuery('<td />').
                                 html(data[k][l]).
                                 appendTo($tr2);
                        }
                        if(!$break){
	                        jQuery('<td />').
	                        append(jQuery('<a class = "edit_ip_lock" href="admin.php?page=wp_eMember_manage&members_action=edit_ip_lock&editrecord='+data[k]['member_id']+'">Unlock</a>')).
	                        appendTo($tr2);
	
	                        jQuery('<td />').
	                        append(jQuery('<a class = "edit" href="admin.php?page=wp_eMember_manage&members_action=add_edit&editrecord='+data[k]['member_id']+'">Edit</a>')).
	                        appendTo($tr2);
	
	                        jQuery('<td />').
	                        append(jQuery('<a class = "del" href="'+data[k]['member_id']+'">Delete</a>')).
	                        appendTo($tr2);
	                        counter++;
                        }
                        else
                            $break = false;
                     }
                       bindEvnt();
                  },
                  'json'
              );
          },
          num_edge_entries: 2,
          num_display_entries: 10,
          items_per_page: itms_per_pg
       });
   }

      jQuery(document).ready(function(){
          jQuery('input[title!=""]').hint();
          var count = <?php echo $emember_user_count->count; ?>;
          drawContent(count);
          jQuery('#emember_user_search').submit(function(e){
                e.prevenDefault;
                var user  = jQuery('#post-search-user').val();
                var email = jQuery('#post-search-email').val();
                var op    = jQuery('#post_search_operator').val();
                var q     = "u="+ user+ "&e="+email + "&o="+op;
                if(user !="" ||email !="")
                {
                    var target_url = '<?php bloginfo('wpurl'); ?>';
                    jQuery.get(target_url + "/wp-admin/admin-ajax.php",
                        {  event: "emember_user_count_ajax",u:user, e:email,o:op},
                           function(data){
                              drawContent(data.count, {u:user, e:email,o:op});
                           },
                           'json'
                        );
                }
                  return false;
          });
      });
   function bindEvnt()
   {
       jQuery('#member_list').find('a.del').each(function(e){
           jQuery(this).click(function(){
              var u = 'admin.php?page=wp_eMember_manage&members_action=delete&deleterecord='+jQuery(this).attr('href')+'&confirm=1';
              top.document.location = u;
              return false;
           });
           jQuery(this).confirm({msg:"",timeout:5000});
        });
   }
   </script>
   <?php
}
function wp_eMember_manage_members()
{
    wp_eMember_sub_header('<div class="wrap"><h2>WP eMembers - Manage Members</h2>');
    echo '<form action="javascript:void(0);" id="emember_user_search"><p class="search-box">
    <label for="post-search-input" class="screen-reader-text">Search Users:</label>
    <input type="text" value="" name="e" title="Email" id="post-search-email"/>
    <select id="post_search_operator">
    <option value="and"> And </option>
    <option value="or"> Or </option>
    </select>
    <input type="text" value="" name="u" title="User Name" id="post-search-user"/>
    <input type="submit" class="button" value="Search Users"/>
    </p></form>';
    if(isset($_SESSION['flash_message'])){echo $_SESSION['flash_message']; unset($_SESSION['flash_message']);}
    wp_eMember_list();
}

function wp_eMember_add_memebers()
{
    global $emember_config;
    global $wpdb;
    wp_eMember_sub_header('<div class="wrap"><h2>WP eMember - Add/Edit Members</h2>');
    //If being edited, grab current info
    if ($_GET['editrecord']!='')
    {
        $theid = $_GET['editrecord'];
        $editingrecord = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $theid);
        $edit_custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . $theid . ' AND meta_key="custom_field"');
        $edit_custom_fields = unserialize($edit_custom_fields->meta_value);
        $editingrecord->more_membership_levels = explode(',', $editingrecord->more_membership_levels);
        $editingrecord = (array)$editingrecord;        
	    $image_url       = null;
	    $image_path  = null;
		$upload_dir  = wp_upload_dir();
	    $upload_url  = $upload_dir['baseurl'];
	    $upload_path = $upload_dir['basedir'];
	    $upload_url  .= '/emember/';
	    $upload_path .= '/emember/';
	    $upload_url  .= $theid;
	    $upload_path .= $theid;
	    if(file_exists($upload_path . '.jpg'))
	    {
	    	$image_url = $upload_url . '.jpg';
	    	$image_path = $upload_path . '.jpg';
	    }
	    else if(file_exists($upload_path . '.jpeg'))
	    {
	    	$image_url = $upload_url . '.jpeg';
	    	$image_path = $upload_path . '.jpeg';
	    }
	    else if(file_exists($upload_path . '.gif'))
	    {
	    	$image_url = $upload_url . '.gif';
	    	$image_path = $upload_path . '.gif';
	    }
	    else if(file_exists($upload_path . '.png'))
	    {
	    	$image_url = $upload_url . '.png';
	    	$image_path = $upload_path . '.png';
	    }
	    else
	    {
// 			$grav_url = "http://www.gravatar.com/avatar/" . 
//         	md5(strtolower($email)) . "?d=" . urlencode($default) . "&s=" . $size;
	    	$use_gravatar = $emember_config->getValue('eMember_use_gravatar');
	    	if($use_gravatar)	    	
		    	$image_url = "http://www.gravatar.com/avatar/" . md5(strtolower($editingrecord['email'])) . "?d=" . urlencode(404) . "&s=" . 96;
	         else
		   		$image_url = WP_EMEMBER_URL . '/images/default_image.gif';
	    }        
    }
    if ($_POST['Submit'])
    {
        global $wpdb;
        include_once(ABSPATH . WPINC . '/class-phpass.php');
        $wp_hasher = new PasswordHash(8, TRUE);
        $post_editedrecord = $wpdb->escape($_POST['editedrecord']);
        $fields = array();
        $fields['flags'] = 0;
        if($emember_config->getValue('eMember_enable_secondary_membership'))
        $fields['more_membership_levels'] = implode(',',$_POST['more_membership_levels']);
		$fields["user_name"] =          $_POST["user_name"];         
		$fields["first_name"]=          $_POST["first_name"];        
		$fields["last_name"]=           $_POST["last_name"];                     
		$fields["company_name"]=        $_POST["company_name"];      
		$fields["member_since"]=        $_POST["member_since"];      
		$fields["membership_level"]=    $_POST["membership_level"];  
		$fields["account_state"]=       $_POST["account_state"];     
		$fields["email"]=               $_POST["email"];  
		$fields["phone"]=               $_POST["phone"];           
		$fields["address_street"]=      $_POST["address_street"];    
		$fields["address_city"]=        $_POST["address_city"];      
		$fields["address_state"]=       $_POST["address_state"];     
		$fields["address_zipcode"]=     $_POST["address_zipcode"];   
		$fields["country"]=             $_POST["country"];           
		$fields["gender"]=              $_POST["gender"];            
		$fields["referrer"]=            $_POST["referrer"];          
		$fields["subscription_starts"]= $_POST["subscription_starts"];  
		$fields['last_accessed_from_ip']= get_real_ip_addr();     
        $editingrecord = $_POST;
        $wp_user_info  = array();
        $wp_user_info['user_nicename'] = $_POST['user_name'];
        $wp_user_info['display_name']  = $_POST['user_name'];
        $wp_user_info['user_email']    = $_POST['email'];
        $wp_user_info['nickname']      = $_POST['user_name'];
        $wp_user_info['first_name']    = $_POST['first_name'];
        $wp_user_info['last_name']     = $_POST['last_name'];
        
        if ($post_editedrecord=='')
        {
            $fields['user_name']        = $wpdb->escape($_POST['user_name']);
            $wp_user_info['user_login'] = $_POST['user_name'];
            // Add the record to the DB
            if(empty($_POST['password'])||($_POST['password']!=$_POST['retype_password']))
            {
                echo '<div id="message" class="updated fade"><p>Password does\'t match!</p></div>';
            }
            else if (username_exists($fields['user_name'])||emember_username_exists($fields['user_name']))
            {
                echo '<div id="message" class="updated fade"><p>User name &quot;'.
                $fields['user_name'].'&quot; is unavailable!</p></div>';
            }
            else if (email_exists($fields['email'])||emember_registered_email_exists($fields['email']))
            {
                echo '<div id="message" class="updated fade"><p>Email ID &quot;'.
                $fields['email'].'&quot; is already registered to a user!</p></div>';
            }
            else
            {
                $password           = $wp_hasher->HashPassword($_POST['password']);
                $fields['password'] = $wpdb->escape($password);
                $should_create_wp_user = $emember_config->getValue('eMember_create_wp_user');
                if($should_create_wp_user)
                {
                    $role_names = array(1=>'Administrator',2=>'Editor',3=>'Author',4=>'Contributor',5=>'Subscriber');
                    $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" .$fields['membership_level'] . "'" );
                    $wp_user_info['role']            = $membership_level_resultset->role;
                    $wp_user_info['user_registered'] = date('Y-m-d H:i:s');
                    $wp_user_id = wp_create_user($_POST['user_name'], $_POST['password'], $_POST['email']);
                    $wp_user_info['ID'] = $wp_user_id;
                    wp_update_user( $wp_user_info );
                    update_wp_user_Role($wp_user_id, $membership_level_resultset->role);
                }

                $ret = dbAccess::insert(WP_EMEMBER_MEMBERS_TABLE_NAME, $fields);
                $lastid = $wpdb->insert_id;
                ///custom field insert
                if(isset($_POST['emember_custom']))
                $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . 
                '( user_id, meta_key, meta_value ) VALUES(' . $lastid .',"custom_field",' . '\''.serialize($_POST['emember_custom']).'\')');
                if($ret === false)
                    $_SESSION['flash_message'] = '<div id="message" style = "color:red;" class="updated fade"><p>Couldn\'t create new member.</p></div>';
                else
                {
                    if(isset($_POST['uploaded_profile_img']))
                    {
                        $upload_dir  = wp_upload_dir();
                        $upload_path = $upload_dir['basedir'];
                        $upload_path .= '/emember/';

                        $ext = explode('.',$_POST['uploaded_profile_img']);
                        rename($upload_path . $_POST['uploaded_profile_img'], $upload_path . $lastid . '.' . $ext[1]);
                    }
                    $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>Member &quot;'.
                    $fields['user_name'].'&quot; created.</p></div>';

                     //Notify the newly created member if specified in the settings
                    if ($emember_config->getValue('eMember_email_notification_for_manual_member_add'))
                    {
                        $login_link            = $emember_config->getValue('login_page_url');
                        $member_email_address  = $_POST['email'];

                        $subject_rego_complete = $emember_config->getValue('eMember_email_subject_rego_complete');

                        $body_rego_complete    = $emember_config->getValue('eMember_email_body_rego_complete');
                        $tags1                 = array("{first_name}","{last_name}","{user_name}","{password}","{login_link}");
                        $vals1                 = array($_POST['first_name'],$_POST['last_name'],$_POST['user_name'],$_POST['password'],$login_link);
                        $email_body1           = str_replace($tags1,$vals1,$body_rego_complete);

                        $from_address          = $emember_config->getValue('senders_email_address');
                        $headers               = 'From: '.$from_address . "\r\n";

                        wp_mail($member_email_address,$subject_rego_complete,$email_body1,$headers);
                    }
                    
                    //Create the corresponding affliate account if specified in the settings
                    if($emember_config->getValue('eMember_auto_affiliate_account'))
                    {
                        eMember_handle_affiliate_signup($_POST['user_name'],$_POST['password'],$_POST['first_name'],$_POST['last_name'],$_POST['email'],'');
                    }                    

                    echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage/";</script>';
                }
            }
        }
        else
        {
            if(isset($_POST['emember_custom'])){
            	$custom_fields = dbAccess::find(WP_EMEMBER_MEMBERS_META_TABLE, ' user_id=' . $post_editedrecord . ' AND meta_key=\'custom_field\'');
            	if($custom_fields)
	                $wpdb->query('UPDATE ' . WP_EMEMBER_MEMBERS_META_TABLE . 
	                ' SET meta_value ='. '\''.serialize($_POST['emember_custom']). '\' WHERE meta_key = \'custom_field\' AND  user_id=' . $post_editedrecord);
                else 
	                $wpdb->query("INSERT INTO " . WP_EMEMBER_MEMBERS_META_TABLE . 
	                '( user_id, meta_key, meta_value ) VALUES(' . $post_editedrecord .',"custom_field",' . '\''.serialize($_POST['emember_custom']).'\')');            	
            }
                             
            $editingrecord = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $post_editedrecord);
            // Update the member info
            $member_id = $wpdb->escape($_POST['editedrecord']);
            $wp_user_id = username_exists($fields['user_name']);
            $wp_email_owner = email_exists($fields['email']);
            $emember_email_owner = emember_email_exists($fields['email']);
            if(($wp_email_owner&&($wp_user_id!=$wp_email_owner))||($emember_email_owner&&($member_id!=$emember_email_owner)))
            {
                echo '<div id="message" class="updated fade"><p>Email ID &quot;'.
                $fields['email'].'&quot; is already registered to a user!</p></div>';
            }
            else
            {
                $user_info = get_userdata($wp_user_id);
                $user_cap = array_keys($user_info->wp_capabilities);
                                	
                if(!empty($_POST['password']))
                {
                    if($_POST['password']===$_POST['retype_password'])
                    {
                        $password           = $wp_hasher->HashPassword($_POST['password']);
                        $fields['password'] = $wpdb->escape($password);
                        $wp_user_info['user_pass']=$_POST['password'];
                        if($wp_user_id)
                        {
                            $wp_user_info['ID'] = $wp_user_id;
                            wp_update_user( $wp_user_info );
                            if(($editingrecord->flags&1)!=1)
                            {
                                $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" .$fields['membership_level'] . "'" );
                                if(!in_array('administrator',$user_cap))                                
                                	update_wp_user_Role($wp_user_id, $membership_level_resultset->role);
                            }
                        }
                        $ret = dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $member_id, $fields);
                        if($ret === false)
                        {
                            $_SESSION['flash_message'] = '<div id="message" style="color:red;" class="updated fade"><p>'.__('Member', 'wp_eMember').' &quot;'.
                            $fields['user_name'].'&quot; '.__('Update Failed.', 'wp_eMember').'</p></div>';
                        }
                        else
                        {                        	
                            $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>'.__('Member', 'wp_eMember').' &quot;'.
                            $fields['user_name'].'&quot; '.__('updated.', 'wp_eMember').'</p></div>';
                            echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
                        }
                    }
                    else
                    {
                        echo '<div id="message" class="updated fade"><p>Password does\'t match!</p></div>';
                    }
                }
                else
                {
                    if($wp_user_id)
                    {
                        $wp_user_info['ID'] = $wp_user_id;
                        wp_update_user( $wp_user_info );
                        if(($editingrecord->flags&1)!=1)
                        {
                            $membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='" .$fields['membership_level'] . "'" );
                			if(!in_array('administrator',$user_cap))                            
                            	update_wp_user_Role($wp_user_id, $membership_level_resultset->role);
                        }
                    }
                    $ret = dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $member_id, $fields);                    
                     if($ret === false)
                     {
                        $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>'.__('Member', 'wp_eMember').' &quot;'.
                        $fields['user_name'].'&quot; '.__('Update Failed.', 'wp_eMember').'</p></div>';
                     }
                     else
                     {                     	
                        $_SESSION['flash_message'] = '<div id="message" class="updated fade"><p>'.__('Member', 'wp_eMember').' &quot;'.
                        $fields['user_name'].'&quot; '.__('updated.', 'wp_eMember').'</p></div>';
                        echo '<script type="text/javascript">window.location = "admin.php?page=wp_eMember_manage";</script>';
                     }
                }
            }
            $editingrecord = (array)$editingrecord;
        }
    }

   $all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
   include_once ('add_member_view.php');
}
?>