<?php
function emember_create_custom_feed()
{
	load_template(WP_PLUGIN_DIR . '/' . WP_EMEMBER_FOLDER . '/emember_feed_template.php');
}