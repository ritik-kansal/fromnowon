<?php
function emember_rss_text_limit($string, $length, $replacer = '...') { 
  $string = strip_tags($string);
  if(strlen($string) > $length) 
    return (preg_match('/^(.*)\W.*$/', substr($string, 0, $length+1), $matches) ? $matches[1] : substr($string, 0, $length)) . $replacer;   
  return $string; 
}
if(isset($_GET['key']))
{
	$result = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, 'md5(member_id)=\'' . $_GET['key'] . '\'');
	if(empty($result))
	{
		die(EMEMBER_NO_USER_KEY);
	}
}
else
{
	die(EMEMBER_WRONG_RSS_URL);
}
//////////////code starts here///////////////
$numposts = get_option('posts_per_rss');
$posts = query_posts('showposts='.$numposts);

header("Content-Type: application/rss+xml; charset=UTF-8");
echo '<?xml version="1.0"?>';
?>
<rss version="2.0">
<channel>
  <title><?php bloginfo_rss('name'); wp_title_rss(); ?></title>
  <link><?php bloginfo_rss('url') ?></link>
  <description><?php bloginfo_rss("description") ?></description>
  <language><?php echo get_option('rss_language'); ?></language>
<lastBuildDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_lastpostmodified('GMT'), false); ?></lastBuildDate>
<?php
    global $emember_auth;    
    $emember_auth->setPermissions($result->membership_level);
	foreach ($posts as $post) { 	
        if($emember_auth->is_protected_category($post->ID))
        {

                if(!$emember_auth->is_subscription_expired($result->subscription_starts))
                {
                    if($emember_auth->is_permitted_category($post->ID))
                    {
                    	?>
					  <item>
					    <title><?php echo get_the_title($post->ID); ?></title>
					    <link><?php echo get_permalink($post->ID); ?></link>
					    <description><?php echo '<![CDATA['.emember_rss_text_limit($post->post_content, 100).'<br/><br/>Keep on reading: <a href="'.get_permalink($post->ID).'">'.get_the_title($post->ID).'</a>'.']]>';  ?></description>
						<pubDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_post_time('Y-m-d H:i:s', true), false); ?></pubDate>
					    <guid><?php echo get_permalink($post->ID); ?></guid>
					  </item>                    	
					  <?php
                    }    
                }
        }
        else if($emember_auth->is_protected_post($post->ID))
        {
                if(!$emember_auth->is_subscription_expired($result->subscription_starts))
                {        	
		            if($emember_auth->is_permitted_post($post->ID))
                    {
                    	?>
					  <item>
					    <title><?php echo get_the_title($post->ID); ?></title>
					    <link><?php echo get_permalink($post->ID); ?></link>
					    <description><?php echo '<![CDATA['.emember_rss_text_limit($post->post_content, 100).'<br/><br/>Keep on reading: <a href="'.get_permalink($post->ID).'">'.get_the_title($post->ID).'</a>'.']]>';  ?></description>
						<pubDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_post_time('Y-m-d H:i:s', true), false); ?></pubDate>
					    <guid><?php echo get_permalink($post->ID); ?></guid>
					  </item>                    	
					  <?php
                    }    		                           
                }
        }
        else
		{
        	?>
				  <item>
				    <title><?php echo get_the_title($post->ID); ?></title>
				    <link><?php echo get_permalink($post->ID); ?></link>
				    <description><?php echo '<![CDATA['.emember_rss_text_limit($post->post_content, 100).'<br/><br/>Keep on reading: <a href="'.get_permalink($post->ID).'">'.get_the_title($post->ID).'</a>'.']]>';  ?></description>
					<pubDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_post_time('Y-m-d H:i:s', true), false); ?></pubDate>
				    <guid><?php echo get_permalink($post->ID); ?></guid>
				  </item>                    	
			<?php
        }    
        
	?>  
<?php }
unset($emember_auth);
 ?>
</channel>
</rss>