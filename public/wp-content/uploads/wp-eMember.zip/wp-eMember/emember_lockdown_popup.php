<body>
<script type="text/javascript">
<!--
jQuery(document).ready(function() {
	   // select the overlay element - and "make it an overlay"
   $lockdown_overlay = jQuery("#lockdownbox").overlay({	   
	       // custom top position
	       top: '30%',
	       oneInstance: false,
	       api:true,
	       // some mask tweaks suitable for facebox-looking dialogs
	       mask: {
	    
	           // you might also consider a "transparent" color for the mask
	           color: '#ebecff',
	    
	           // load mask a little faster
	           loadSpeed: 200,
	    
	           // very transparent
	           opacity: 0.9
	       },
	    
	       // disable this for modal dialog-type of overlays
	       closeOnClick: false,
	       closeOnEsc:false,
	       // load it immediately after the construction
	       load: true	    
	   }); 
        $forgot_pass_overlay.onClose(function(){
            $lockdown_overlay.load();
        });
	});
//-->
</script>
<div id="lockdownbox" class="modal"> 
 
    <div> 
        <h2>
            Authentication Required <br/>
            <span>Protected by <a target="_blank" href="http://www.tipsandtricks-hq.com/wordpress-emember-easy-to-use-wordpress-membership-plugin-1706">WP eMember &copy;</a></span>
        </h2>  
	    <form action="<?php echo $login_url?>" id="loginForm" name="loginForm" method="post">
	        <p class="textbox">
	            <label for="login_user_name"><?php echo EMEMBER_USER_NAME;?></label>
	            <input type="text" tabindex="4" title="username" value="" name="login_user_name" id="login_user_name">
	        </p>
	        <p class="textbox">
	            <label for="login_pwd"><?php echo EMEMBER_PASSWORD;?></label>
	            <input type="password" tabindex="5" title="password" value="" name="login_pwd" id="login_pwd">
	        </p>
	        
	        <p class="rememberme">
	            <input type="submit" tabindex="7" value="Sign in" name="doLogin" class="emember_button" id="doLogin">
	            <input type="checkbox" tabindex="6" value="forever" name="remember_me" id="rememberme">
	            <input type="hidden" value="1" name="testcookie" />
	            <label for="remember"><?php echo EMEMBER_REMEMBER_ME;?></label>
	        </p>
                <p style="color:red;"><?php echo ($emember_auth->getCode()!=1)?  $emember_auth->getMsg(): '';?></p>
	        <p class="forgot">
	            <a id="forgot_pass" rel="#prompt" class="forgot_pass_link" href="javascript:void(0);"><?php echo EMEMBER_FORGOT_PASS;?></a>
	        </p>        
	        <p class="forgot-username">
	            <a title="Join us" id="join_us" href="<?php echo $join_url; ?>"><?php echo EMEMBER_JOIN_US;?></a>
	        </p>
	    </form>  
    </div>  
</div> 
 
</body>
</html>