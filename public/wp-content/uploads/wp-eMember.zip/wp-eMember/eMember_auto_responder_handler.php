<?php
//global $emember_config;
//if($emember_config->getValue('eMember_use_mailchimp'))
{
	$eMember_mailchimp_lib_file = "lib/auto-responder/MCAPI.class.php";
	if(!class_exists(MCAPI))
	{
		include_once($eMember_mailchimp_lib_file);
	}	
}
//if($emember_config->getValue('eMember_use_getresponse'))
{
	$eMember_get_response_lib_file = "lib/auto-responder/jsonRPCClient.php";
	if(!class_exists(jsonRPCClient))
	{
		include_once($eMember_get_response_lib_file);
	}	
}

function eMember_get_chimp_api()
{
	global $emember_config;
    $api = new MCAPI($emember_config->getValue('eMember_chimp_user_name'), $emember_config->getValue('eMember_chimp_pass'));
    return $api;
}

function eMember_mailchimp_subscribe($api,$target_list_name,$fname,$lname,$email_to_subscribe)
{
    $lists = $api->lists();
    foreach ($lists AS $list) 
    {
        if ($list['name'] == $target_list_name)
        {
            $list_id = $list['id'];
        }
    }   
    $merge_vars = array('FNAME'=>$fname, 'LNAME'=>$lname,
                        'INTERESTS'=>'');

    $retval = $api->listSubscribe( $list_id, $email_to_subscribe, $merge_vars );
    return $retval;
}

function eMember_getResponse_subscribe($campaign_name,$fname,$lname,$email_to_subscribe)
{
	// your API key
	// available at http://www.getresponse.com/my_api_key.html
	$api_key = get_option('eMember_getResponse_api_key');
	
	// API 2.x URL
	$api_url = 'http://api2.getresponse.com';
	
	$customer_name = $fname." ".$lname;
	
	// initialize JSON-RPC client
	$client = new jsonRPCClient($api_url);
	
	$result = NULL;

    $result = $client->get_campaigns(
        $api_key,
        array (
            # find by name literally
            'name' => array ( 'EQUALS' => $campaign_name )
        )
    );

	# uncomment this line to preview data structure
	# print_r($result);
	
	# since there can be only one campaign of this name
	# first key is the CAMPAIGN_ID you need
	$CAMPAIGN_ID = array_pop(array_keys($result));	
	
	if(empty($CAMPAIGN_ID))
	{
		eStore_payment_debug("Could not retrieve campaign ID. Please double check your GetResponse Campaign Name:".$campaign_name,false);
	}
	else
	{
	# add contact to 'sample_marketing' campaign
	    $result = $client->add_contact(
	        $api_key,
	        array (
	            'campaign'  => $CAMPAIGN_ID,
	            'name'      => $customer_name,
	            'email'     => $email_to_subscribe
	        )
	    );
	}
	# uncomment this line to preview data structure
	# print_r($result);	
	return true;
}

function eMember_global_autoresponder_signup($firstname,$lastname,$emailaddress)
{
	global $emember_config;
    if($emember_config->getValue('eMember_enable_aweber_int') == 1)
    {
	    $list_name = $emember_config->getValue('eMember_aweber_list_name');
	    $from_address = $emember_config->getValue('senders_email_address');
    	$senders_email = eMember_get_string_between($from_address, "<", ">");
        if(empty($senders_email))
        {
        	$senders_email = $from_address;
        }	    
	    $cust_name = $firstname .' '. $lastname;
	    eMember_send_aweber_mail($list_name,$senders_email,$cust_name,$emailaddress);
    }	
    if ($emember_config->getValue('eMember_use_mailchimp') == 1)
    {
        $api = eMember_get_chimp_api();
        $target_list_name = $emember_config->getValue('eMember_chimp_list_name');
        $retval = eMember_mailchimp_subscribe($api,$target_list_name,$firstname,$lastname,$emailaddress);
    }	
    if(get_option('eMember_use_getresponse') == 1)
    {
	    $campaign_name = get_option('eMember_getResponse_campaign_name');
	    $retval = eMember_getResponse_subscribe($campaign_name,$firstname,$lastname,$emailaddress);    	
    }    
}
?>