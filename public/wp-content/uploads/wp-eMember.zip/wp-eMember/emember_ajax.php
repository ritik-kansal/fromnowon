<?php
function is_ajax()
{
    return (isset($_SERVER['HTTP_X_REQUESTED_WITH'])&&(strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])=='xmlhttprequest'));
}
function wp_emem_delete_image(){
	
	@unlink($_GET['path']);
	echo json_encode(array('status'=>"done",'payload'=>'deleted.'));
	exit(0);
}
function wp_emem_get_post_preview(){
    $post_content = get_post($_POST['id'],OBJECT);
    echo '<h2>' . $post_content->post_title . '</h2>';
    echo $post_content->post_content;
	exit(0);
}
function wp_emem_upload_file()
{
     if(($_FILES["profile_image"]["size"] / 1024)>2048){
		echo json_encode(array('status'=>0));
		exit(0);
    }
    $upload_dir  = wp_upload_dir();
    $upload_path = $upload_dir['basedir'];
    $upload_url  = $upload_dir['baseurl'];
    $upload_path .= '/emember/';
    $upload_url  .= '/emember/';
    global $emember_auth;
    $upload_name  = $_POST['image_id']; 
    switch($_FILES['profile_image']['type'])
    {
		case ("image/gif" ):
			$upload_name .= '.gif';
			break;
		case ("image/jpg" ):
			$upload_name .= '.jpg';
			break;
		case ("image/jpeg"):
			$upload_name .= '.jpeg';
			break;
		case ("image/pjpeg"):
			$upload_name .= '.jpeg';
			break;			
		case ("image/png" ):
			$upload_name .= '.png';
			break;
    }
    if(!file_exists($upload_path) || !is_dir($upload_path)) mkdir($upload_path);       
    if(move_uploaded_file($_FILES["profile_image"]["tmp_name"],$upload_path . $upload_name))
    	echo json_encode(array('file'=>$upload_name, 'status'=>1));
    else
        echo json_encode(array('status'=>0));
    exit(0);	
}
function wp_emem_user_count_ajax()
{
   global $wpdb;
   $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
   $condition = "";
   if(!empty($_GET['u'])&&!empty($_GET['e']))
      $condition = 'user_name LIKE \'' . $_GET['u'] . '%\' ' . $_GET['o'] . ' email=\'' . $_GET['e'] . '%\'';
   else if(!empty($_GET['u']))
   	  $condition = 'user_name LIKE \'' . $_GET['u'] . '%\'';
   else if(!empty($_GET['e']))
      $condition = 'email LIKE \'' . $_GET['e'] . '%\'';
   if(empty($condition))
      $q = "SELECT COUNT(*) as count FROM " . $member_table . ' ORDER BY member_id';
   else
      $q = "SELECT COUNT(*) as count FROM " . $member_table . " WHERE $condition ORDER BY member_id";

   $emember_user_count = $wpdb->get_row($q);
   echo json_encode($emember_user_count);
   exit(0);
}
function wp_emem_user_list_ajax()
{
   $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
   $membership_table = WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE;
   $table_name = " $member_table LEFT JOIN $membership_table ON ".
                 " ($member_table.membership_level = $membership_table.id)";
    
    global $wpdb;
   $condition = "";
   if(!empty($_GET['u'])&&!empty($_GET['e']))
      $condition = 'user_name LIKE \'' . $_GET['u'] . '%\' ' . $_GET['o'] . ' email=\'' . $_GET['e'] . '%\'';
   else if(!empty($_GET['u']))
   	  $condition = 'user_name LIKE \'' . $_GET['u'] . '%\'';
   else if(!empty($_GET['e']))
      $condition = 'email LIKE \'' . $_GET['e'] . '%\'';
    if(empty($condition))
      $q = "SELECT member_id, user_name, first_name,last_name,email,alias,subscription_starts,account_state FROM $table_name ORDER BY member_id LIMIT ";
    else 
      $q = "SELECT member_id, user_name, first_name,last_name,email,alias,subscription_starts,account_state FROM $table_name WHERE $condition ORDER BY member_id LIMIT ";
    $wp_users = $wpdb->get_results( $q. $_GET['start'] . ',' . $_GET['limit']);
    echo json_encode($wp_users);
    exit(0);        
}
function wp_emem_public_user_list_ajax()
{
   $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
   $membership_table = WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE;
   $table_name = " $member_table LEFT JOIN $membership_table ON ".
                 " ($member_table.membership_level = $membership_table.id)";
    
    global $wpdb;
   $condition = "";
   if(!empty($_GET['u'])&&!empty($_GET['e']))
      $condition = 'user_name LIKE \'' . $_GET['u'] . '%\' ' . $_GET['o'] . ' email=\'' . $_GET['e'] . '%\'';
   else if(!empty($_GET['u']))
   	  $condition = 'user_name LIKE \'' . $_GET['u'] . '%\'';
   else if(!empty($_GET['e']))
      $condition = 'email LIKE \'' . $_GET['e'] . '%\'';
    if(empty($condition))
      $q = "SELECT member_id, user_name, first_name,last_name,email FROM $table_name ORDER BY member_id LIMIT ";
    else 
      $q = "SELECT member_id, user_name, first_name,last_name,email FROM $table_name WHERE $condition ORDER BY member_id LIMIT ";
    $wp_users = $wpdb->get_results( $q. $_GET['start'] . ',' . $_GET['limit']);
    echo json_encode($wp_users);
    exit(0);        
}
function wp_emem_wp_user_list_ajax()
{
    global $wpdb;
    $wp_users = $wpdb->get_results("SELECT ID, user_login, user_email FROM $wpdb->users ORDER BY ID LIMIT " . $_GET['start'] . ',' . $_GET['limit']);
    echo json_encode($wp_users);
    exit(0);    
}
function wp_emem_public_user_profile_ajax()
{
	global $emember_config;
	$p  = $emember_config->getValue('eMember_enable_public_profile');
	if(!$p) 
	{
		echo json_encode(array('content'=>'Public profile Listing is disabled', 'status'=>0));
		exit(0);
	}
	
	global $wpdb;
    $resultset  = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' member_id=' . $wpdb->escape($_GET['id']));
	$upload_dir  = wp_upload_dir();
    $upload_url  = $upload_dir['baseurl'];
    $upload_path = $upload_dir['basedir'];
    $upload_url  .= '/emember/';
    $upload_path .= '/emember/';
    $upload_url  .= $resultset->member_id;
    $upload_path .= $resultset->member_id;
    if(file_exists($upload_path . '.jpg'))
    {
    	$image_url = $upload_url . '.jpg';
    }
    else if(file_exists($upload_path . '.jpeg'))
    {
    	$image_url = $upload_url . '.jpeg';
    }
    else if(file_exists($upload_path . '.gif'))
    {
    	$image_url = $upload_url . '.gif';
    }
    else if(file_exists($upload_path . '.png'))
    {
    	$image_url = $upload_url . '.png';
    }
    else
    {
    	$image_url = WP_EMEMBER_URL . '/images/default_image.gif';
    }
    
    ob_start();
    ?>
    <h2 class="emember_profile_head">User Profile</h2>
    <table align="center" class="emember_profile">
    	<tbody align="center">
    		<tr>
    			<td colspan="2" align="center">
    				<img alt="" width="100px" height="100px" src="<?php echo $image_url;?>"/>    			
    			</td>
    		</tr>
    		<tr class="emember_profile_cell">
    			<td colspan="2" align="center" class="emember_profile_user_name">
    			  <?php echo $resultset->user_name; ?>
    			</td>    		
    		</tr>
    		<tr class="emember_profile_cell alternate">
    			<td>
    				<label>First Name:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->first_name; ?>
    			</td>
    		</tr>
    		<tr class="emember_profile_cell">
    			<td>
    				<label>Last Name:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->last_name; ?>
    			</td>
    		</tr>
    		<tr class="emember_profile_cell alternate">
    			<td>
    				<label>Email Address:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->email; ?>
    			</td>
    		</tr>
    		<tr class="emember_profile_cell">
    			<td>
    				<label>Company:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->company; ?>
    			</td>
    		</tr>
    		<tr class="emember_profile_cell alternate">
    			<td>
    				<label>Street:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->address_street; ?>
    			</td>
    		</tr>
    		<tr class="emember_profile_cell">
    			<td>
    				<label>City:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->address_city; ?>
    			</td>
    		</tr>    		
    		<tr class="emember_profile_cell alternate">
    			<td>
    				<label>State:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->address_state; ?>
    			</td>
    		</tr>    		
    		<tr class="emember_profile_cell">
    			<td>
    				<label>Zipcode:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->address_zipcode; ?>
    			</td>
    		</tr>    	
    		<tr class="emember_profile_cell alternate">
    			<td>
    				<label>Country:</label>    			
    			</td>
    			<td>
    			  <?php echo $resultset->country; ?>
    			</td>
    		</tr>    			
    	</tbody>
    </table>    
    <?php
    $content = ob_get_contents();
    ob_end_clean();
    echo json_encode(array('content'=>$content, 'status'=>1)); 
    exit(0);	
}
function wp_emem_add_bookmark()
{
    if(is_ajax())
    {
        global $emember_auth;
        global $wpdb;
        $extr = $emember_auth->getUserInfo('extra_info');
        $member_id = $emember_auth->getUserInfo('member_id');
        $extr = unserialize($extr);
        $bookmarks = isset($extr['bookmarks'])?$extr['bookmarks'] : array();
        array_push($bookmarks, $_GET['id']);
        $bookmarks = array_unique($bookmarks);
        $extr['bookmarks'] = $bookmarks;
        $fields['extra_info'] = serialize($extr); 
        dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $member_id, $fields);
            $a1 = '<span title="Bookmarked"  class="count">
    					<span class="c"><b>&radic;</b></span><br/>
    					<span class="t">'.EMEMBER_FAVORITE.'</span>
    				</span>
    				<span title="Bookmarked"class="emember">'.EMEMBER_ADDED.'</span>';        
        echo json_encode(array('status'=>1,'msg'=>$a1));
        exit(0);
    }
}
function item_list_ajax()
{
    global $wpdb;
    if(is_ajax())
    {
        switch($_GET['type'])
        {
            case 'pages':    
                $args = array(
                    'child_of' => 0,
                    'sort_order' => 'ASC',
                    'sort_column' => 'post_title',
                    'hierarchical' => 0,
                    'parent' => -1,
                    'number' => $_GET['limit'],
                    'offset' => $_GET['start'] );                   
                $all_pages      = get_pages($args);                     
//                $all_pages      =  $wpdb->last_result;               
                $filtered_pages = array();
                foreach($all_pages as $page)
                {
                      $page_summary = array();
                      $user_info    = get_userdata($page->post_author);
             
                      $page_summary['ID']     = $page->ID;
                      $page_summary['date']   = $page->post_date;
                      $page_summary['title']  = $page->post_title;
                      $page_summary['author'] = $user_info->user_nicename;
                      $page_summary['status'] = $page->post_status;
                      $filtered_pages[]       = $page_summary;
                }
               echo json_encode($filtered_pages);
                
                break;
            case 'posts':
            	$sql  = "SELECT ID,post_date,post_title,post_author, post_type, post_status FROM $wpdb->posts ";
            	$sql .= " WHERE post_type != 'page' AND post_status = 'publish' LIMIT " . $_GET['start'] . " , " . $_GET['limit'];
				$all_posts = $wpdb->get_results($sql);
				            	
//                $all_posts      = get_posts(array('numberposts'=>$_GET['limit'],
//                                                  'offset'=>$_GET['start'],
//                                                  'post_type'=>'any'));
                $filtered_posts = array();
                foreach($all_posts as $post)
                {
                	//if($post->post_type=='page')continue;
                    $post_summary = array();
                    $user_info    = get_userdata($post->post_author);
                    $categories   = get_the_category($post->ID);
                    $cat          = array();
                    foreach($categories  as $category)
                       $cat[] = $category->category_nicename;
             
                    $post_summary['ID']         = $post->ID;
                    $post_summary['date']       = $post->post_date;
                    $post_summary['title']      = $post->post_title;
                    $post_summary['author']     = $user_info->user_nicename;
                    $post_summary['categories'] = implode(' ', $cat);
                    $post_summary['type']       = $post->post_type;                    
                    $post_summary['status']     = $post->post_status;
                    $filtered_posts[]           = $post_summary;
                }
                echo json_encode($filtered_posts);                       
                break;
            case 'comments':
                $all_comments      = get_comments(array('number'=>$_GET['limit'],'offset'=>$_GET['start'],'status'=>'approve'));
                $filtered_comments = array();
                foreach($all_comments as $comment)
                {
                      $comment_summary            = array();
                      $comment_summary['ID']      = $comment->comment_ID;
                      $comment_summary['date']    = $comment->comment_date;
                      $comment_summary['author']  = $comment->comment_author;
                      $comment_summary['content'] = $comment->comment_content;
                      $filtered_comments[]        = $comment_summary;
                }               
                echo json_encode($filtered_comments);
                break;
            case 'categories':
                $all_categories = array();
                $all_cat_ids    = get_all_category_ids();
                for($i=$_GET['start'];$i<($_GET['start']+$_GET['limit'])&&!empty($all_cat_ids[$i]);$i++)
                {
                    $all_categories[] = get_category($all_cat_ids[$i]);
                }
                foreach($all_categories as $category)
                {
                      $category_summary                = array();
                      $category_summary['ID']          = $category->term_id;
                      $category_summary['name']        = $category->name;
                      $category_summary['description'] = $category->description;
                      $category_summary['count']       = $category->count;
                      $filtered_categories[]           = $category_summary;
                }
                echo json_encode($filtered_categories);               
                break;    
        }
    }
    exit(0);
}
function wp_emem_send_mail()
{
    if(is_ajax())
    {
       global $wpdb;
       global $emember_config;
       $emailId= $wpdb->escape(trim($_GET['email']));       
       $user = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, 'email=\'' . $emailId.'\'');
       if($user)
       {
           require_once('rand_pass.php');
           include_once(ABSPATH . WPINC . '/class-phpass.php');
           $wp_hasher = new PasswordHash(8, TRUE);        
           
           $reset_pass = utility::generate_password();
           //send mail from here with user name & password
           $wp_user_id = username_exists($user->user_name);
           if ($wp_user_id)
           {
               $wp_user_info              = array();
               $wp_user_info['user_pass'] = $reset_pass;
               $wp_user_info['ID']        = $wp_user_id;
               wp_update_user( $wp_user_info );               
           }      
           $fields   = array();     
           $password = $wp_hasher->HashPassword($reset_pass);
           $fields['password'] = $wpdb->escape($password);
           dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $user->member_id, $fields);
           $email_body = $emember_config->getValue('eMember_fogot_pass_email_body');
           $email_subject = $emember_config->getValue('eMember_fogot_pass_email_subject');
           //wp_mail($emailId,$email_subject,$email_body);
           $tags1                 = array("{first_name}","{last_name}","{user_name}","{password}");			
           $vals1                 = array($user->first_name,$user->last_name,$user->user_name,$reset_pass);			
           $email_body           = str_replace($tags1,$vals1,$email_body);
		   $from_address = $emember_config->getValue('eMember_fogot_pass_senders_email_address');
		   $headers = 'From: '.$from_address . "\r\n";
		   wp_mail($emailId,$email_subject,$email_body,$headers);           
           echo json_encode(array('status_code'=>true,'msg'=>EMEMBER_PASS_EMAILED_MSG));
       }
       else
           echo json_encode(array('status_code'=>false,'msg'=>EMEMBER_EMAIL_NOT_EXIST));
    }
    exit(0);
}
function wp_emem_check_level_name()
{
    if(is_ajax())
    {        
        global $wpdb;
        $alias = $wpdb->escape(trim($_GET['alias']));
        $user = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' alias=\'' .$wpdb->escape($alias) .'\'');
        if($user) echo json_encode(array('status_code'=>false,'msg'=>'&chi;&nbsp;' . EMEMBER_ALREADY_TAKEN));
        else echo json_encode(array('status_code'=>true,'msg'=>'&radic;&nbsp;'.EMEMBER_STILL_AVAIL));
    }
    exit(0);
}

function wp_emem_check_user_name()
{
    if(is_ajax())
    {
        if (username_exists($_GET['user_name']))
        {
            echo json_encode(array('status_code'=>false,'msg'=>'&chi;&nbsp;'.EMEMBER_ALREADY_TAKEN));
        }
        else
        {
            global $wpdb;
            $user_name = $wpdb->escape(trim($_GET['user_name']));
            $user = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' user_name=\'' .$wpdb->escape($user_name) .'\'');
            if($user) echo json_encode(array('status_code'=>false,'msg'=>'&chi;&nbsp;' .EMEMBER_ALREADY_TAKEN));
            else echo json_encode(array('status_code'=>true,'msg'=>'&radic;&nbsp;'.EMEMBER_STILL_AVAIL));
        }
    }
    exit(0);
}

function access_list_ajax()
{
    if(is_ajax())
    {
        global $wpdb;
        $levelId = $_GET['level_type'];
        $level = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE," id = '" . $wpdb->escape($levelId) . " ' ");
        switch($_GET['level_content'])
        {
           case 'Comments':
              $content = unserialize($level->comment_list);
              $num_comm  = get_comment_count();            
              $content = is_bool($content)? array(): $content;
              echo json_encode(array('comment_list'=>$content,'count'=>$num_comm['approved']));
              break;
           case 'Posts':
              $content = unserialize($level->post_list);
              $bookmark = unserialize($level->disable_bookmark_list);
              #$num_posts = wp_count_posts( 'post' );             
              #$num_posts->publish
              $num_posts = $wpdb->get_var("SELECT count(*) from $wpdb->posts WHERE post_status='publish' AND post_type!='page'");
              $content = is_bool($content)? array(): $content;
              $bookmark = empty($bookmark['posts'])? array(): $bookmark['posts'];
              echo json_encode(array('post_list'=>$content,'disable_bookmark'=>$bookmark,'count'=>$num_posts));

              break;
           case 'Pages':
           	  $bookmark = unserialize($level->disable_bookmark_list);
              $content = unserialize($level->page_list);
              $bookmark = empty($bookmark['pages'])? array(): $bookmark['pages'];
              $content = is_bool($content)? array(): $content;
              $num_pages = wp_count_posts( 'page' );
              echo json_encode(array('page_list'=>$content,'disable_bookmark'=>$bookmark,'count'=>$num_pages->publish));
              break;
           case 'Categories':
              $content = unserialize($level->category_list);
              $content = is_bool($content)? array(): $content;
              $num_cats  = wp_count_terms('category');
              echo json_encode(array('category_list'=>$content,'count'=>$num_cats));
              break;
        }
    }
    exit(0);
}
?>