<?php
/**
 * 1. update capability when logging in to invalid if inactive or expired.
 * 2. update capbility when account is made actvie.
 * 3. update capability when payment is made.
 * 4. format subscriber_inactive, subscriber_expired
 * 
 * ***/
/********************************************
***      THIS IS NOT A FREE PLUGIN        ***
*** DO NOT COPY ANY CODE FROM THIS PLUGIN ***
*********************************************/
require_once ( ABSPATH . WPINC . '/pluggable.php' );
require_once ( ABSPATH . WPINC . '/registration.php' );
$siteurl = get_bloginfo('wpurl');
define('WP_EMEMBER_FOLDER', dirname(plugin_basename(__FILE__)));
//echo '<pre>';
//$c = get_userdata(1);
//var_dump(array_keys($c->wp_capabilities));
//echo '</pre>';
$wp_eMember_url = WP_PLUGIN_URL.'/'.WP_EMEMBER_FOLDER;
/*if ($_SERVER["HTTPS"] == "on")
{
	$wp_eMember_url = str_replace("http","https",$wp_eMember_url);
}*/
define('WP_EMEMBER_URL', $wp_eMember_url);

include_once('emember_config.php');
$emember_config = Emember_Config::getInstance();
$config = $emember_config;
$lang = $emember_config->getValue('eMember_language');
if (!empty($lang))$eMember_language_file = "lang/".$lang.".php";
else $eMember_language_file = "lang/eng.php";

include_once($eMember_language_file);

include_once('eMember_db_access.php');
include_once('eMember_misc_functions.php');
include_once('auth.php');
include_once('emember_ajax.php');
include_once('emember_access_checkers.php');
include_once('emember_custom_feed.php');
include_once('eMember_auto_responder_handler.php');

$emember_auth   = new Auth();
$auth = $emember_auth;
if(isset($_POST['doLogin'])){
    global $wpdb;
    global $emember_config;
    $emember_auth->login($_POST['login_user_name'],$_POST['login_pwd'], isset($_POST['rememberme'])?$_POST['rememberme'] : false);
    if($emember_auth->isLoggedIn()){    	
        $user_id = username_exists( $_POST['login_user_name'] );        
        $after_login_page = $emember_config->getValue('after_login_page');
        $membership_level = $emember_auth->getUserInfo('membership_level');
        //$membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='$membership_level' ");
        $membership_level_resultset = $emember_auth->userInfo->primary_membership_level;
        $_SESSION['membership_level_name'] = $membership_level_resultset->alias;
        
        //Log into the affiliate account if the option is set
        $eMember_auto_affiliate_account_login = $emember_config->getValue('eMember_auto_affiliate_account_login');
        if($eMember_auto_affiliate_account_login && function_exists('wp_aff_platform_install'))
        {
            $_SESSION['user_id']= $_POST['login_user_name'];
    	    if(isset($_POST['rememberme']))
            {
    		    setcookie("user_id", $_SESSION['user_id'], time()+60*60*24*7, "/");
    		}        	
        }
        
        $sign_in_wp = $emember_config->getValue('eMember_signin_wp_user');
        if($sign_in_wp){   
            if($user_id){
                $preserve_role = $emember_auth->getUserInfo('flags');
                if(($preserve_role & 1) != 1){ 
                	$user_info = get_userdata($user_id);
                	$user_cap = array_keys($user_info->wp_capabilities);
                	if(!in_array('administrator',$user_cap))
                		update_wp_user_Role($user_id, $membership_level_resultset->role);
                }
                update_account_status($_POST['login_user_name']);
                wp_signon(array(
                                'user_login'=>$_POST['login_user_name'],
                                'user_password'=>$_POST['login_pwd'],
                                'remember'=>isset($_POST['rememberme'])?$_POST['rememberme']:''
                                ),
                                is_ssl() ? true : false);
            }
        }  
        $enable_after_login_redirect = $emember_config->getValue('eMember_enable_redirection');                      
        if($enable_after_login_redirect){ 
            if(!empty($membership_level_resultset->loginredirect_page)){
                header('Location: ' . $membership_level_resultset->loginredirect_page);exit;
            }
            else if(!empty($after_login_page)){
                header('Location: ' . $after_login_page);exit;
            }
        }        
    }
}

add_shortcode("free_rego_with_email_confirmation","free_rego_with_email_confirmation_handler");
add_shortcode("emember_protected","emember_protected_handler");
add_shortcode("emember_total_memebers","emember_total_members_handler");
add_shortcode('wp_eMember_registration_form_for','wp_eMember_registration_form_handler');
add_shortcode('wp_eMember_compact_login','eMember_compact_login_widget');
add_shortcode('wp_eMember_free_membership_renewal', 'wp_eMember_free_membership_renewal_handler');

add_filter('the_content', 'do_shortcode');
add_filter('the_content', 'filter_eMember_registration_form');
add_filter('the_content', 'filter_eMember_public_user_list');
add_filter('the_content', 'filter_eMember_login_form');
add_filter('the_content', 'filter_eMember_edit_profile_form');
add_filter('the_content', 'filter_eMember_bookmark_list');
add_filter('the_content','secure_content', 3000);
add_filter('wp_head', 'wp_emember_hook_password_reminder');

$lockdown_domain = $emember_config->getValue('eMember_enable_domain_lockdown');
if($lockdown_domain)add_action('wp_head', 'lockdown_widget');
add_action('init', 'export_members_to_csv');
add_action('init', 'load_library');
add_action('init', 'wp_eMember_widget_init');
add_action('init', 'emember_menu');
add_action('comment_text','comment_text_action');
add_action('profile_update','sync_emember_profile', $id);
add_action('wp_logout', 'logout_handler');
add_action('init', 'del_bookmark');
add_action('do_feed_ememberfeed', 'emember_create_custom_feed', 10, 1);
add_action('wp_ajax_emember_upload_ajax', 'wp_emem_upload_file');
add_action('wp_ajax_nopriv_check_name', 'wp_emem_check_user_name');
add_action('wp_ajax_item_list_ajax', 'item_list_ajax');
add_action('wp_ajax_access_list_ajax', 'access_list_ajax');
add_action('wp_ajax_send_mail', 'wp_emem_send_mail');
add_action('wp_ajax_nopriv_send_mail', 'wp_emem_send_mail');
add_action('wp_ajax_check_level_name', 'wp_emem_check_level_name');
add_action('wp_ajax_add_bookmark', 'wp_emem_add_bookmark');
add_action('wp_ajax_wp_user_list_ajax', 'wp_emem_wp_user_list_ajax');
add_action('wp_ajax_emember_user_list_ajax', 'wp_emem_user_list_ajax');
add_action('wp_ajax_emember_user_count_ajax', 'wp_emem_user_count_ajax');
add_action('wp_ajax_nopriv_emember_public_user_list_ajax', 'wp_emem_public_user_list_ajax');
add_action('wp_ajax_nopriv_emember_public_user_profile_ajax', 'wp_emem_public_user_profile_ajax');
add_action('wp_ajax_nopriv_delete_profile_picture', 'wp_emem_delete_image');
add_action('wp_ajax_delete_profile_picture', 'wp_emem_delete_image');
add_action('wp_ajax_get_post_preview', 'wp_emem_get_post_preview');
//////////////////////////
add_action('admin_menu', 'eMember_add_custom_box');

/* Use the save_post action to do something with the data entered */
add_action('save_post', 'eMember_save_postdata');

/* Adds a custom section to the "advanced" Post and Page edit screens */
function eMember_add_custom_box() {
    if( function_exists( 'add_meta_box' )) {
	    add_meta_box( 'eMember_sectionid', __( 'eMember Protection options', 'eMember_textdomain' ), 
	                'eMember_inner_custom_box', 'post', 'advanced' );
	    add_meta_box( 'eMember_sectionid', __( 'eMember Protection options', 'eMember_textdomain' ), 
	                'eMember_inner_custom_box', 'page', 'advanced' );
	} 
	else {
	    add_action('dbx_post_advanced', 'eMember_old_custom_box' );
	    add_action('dbx_page_advanced', 'eMember_old_custom_box' );
	}
}
   
/* Prints the inner fields for the custom post/page section */
function eMember_inner_custom_box() {
    global $post;
    global $emember_auth;
    $id = $post->ID;
	//$protection = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id = 1', ' id DESC ');
	$protection = $emember_auth->protection;
	$all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
    // Use nonce for verification
    $is_protected = false;
    $is_in = array();
    if($post->post_type ==='post'){
    	$p_posts = unserialize( $protection->post_list ); 
    	$p_posts = is_bool($p_posts)? array() : $p_posts;
    	$is_protected = in_array($id, $p_posts)? true: false;
    	
    	foreach($all_levels as $level){
    		$l_posts = unserialize( $level->post_list );
    		$l_posts = is_bool($l_posts)? array() : $l_posts;
    		$is_in[$level->id] = in_array($id, $l_posts)? "checked='checked'":"";
    	}
    }  
    else if($post->post_type === 'page'){
    	$p_pages = unserialize( $protection->page_list );
        $p_pages = is_bool($p_pages)? array() : $p_pages;
    	$is_protected = in_array($id, $p_pages)? true:false;
    	foreach($all_levels as $level){
    		$l_pages = unserialize( $level->page_list );
    		$l_pages = is_bool($l_pages)? array() : $l_pages;
    		$is_in[$level->id] = in_array($id, $l_pages)? "checked='checked'":"";
    	}    	
    }
    echo '<input type="hidden" name="eMember_noncename" id="eMember_noncename" value="' . 
    wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
    // The actual fields for data entry
	echo '<h4>'.  __("Do you want to protect this content?", 'eMember_textdomain' ) . '</h4>' ;
	echo '  <input type="radio" ' . ((!$is_protected)? 'checked': "") . '  name="eMember_protect_post" value="1" /> No, Do not protect this content. <br/>';
	echo '  <input type="radio" ' . (($is_protected)? 'checked': "") . '  name="eMember_protect_post" value="2" /> Yes, Protect this content.<br/>';  
    echo  '<h4>'.__("Select the membership level that can access this content:", 'eMember_textdomain' )  ."</h4>";  
    foreach ($all_levels as $level)
       echo '<input type="checkbox" ' . (isset($is_in[$level->id])? $is_in[$level->id]:""). ' name="eMember_protection_level['.$level->id .']" value="' . $level->id . '" /> ' .$level->alias  . "<br/>";        
}

/* Prints the edit form for pre-WordPress 2.5 post/page */
function eMember_old_custom_box() {

  echo '<div class="dbx-b-ox-wrapper">' . "\n";
  echo '<fieldset id="eMember_fieldsetid" class="dbx-box">' . "\n";
  echo '<div class="dbx-h-andle-wrapper"><h3 class="dbx-handle">' . 
        __( 'eMember Protection options', 'eMember_textdomain' ) . "</h3></div>";     
  echo '<div class="dbx-c-ontent-wrapper"><div class="dbx-content">';
  // output editing form
  eMember_inner_custom_box();
  // end wrapper
  echo "</div></div></fieldset></div>\n";
}

/* When the post is saved, saves our custom data */
function eMember_save_postdata( $post_id ) {
  // verify this came from the our screen and with proper authorization,
  // because save_post can be triggered at other times

  if ( !wp_verify_nonce( $_POST['eMember_noncename'], plugin_basename(__FILE__) )) {
    return $post_id;
  }

  // verify if this is an auto save routine. If it is our form has not been submitted, so we dont want
  // to do anything
  if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
    return $post_id;

  
  // Check permissions
  if ( 'page' == $_POST['post_type'] ) {
    if ( !current_user_can( 'edit_page', $post_id ) )
      return $post_id;
  } else {
    if ( !current_user_can( 'edit_post', $post_id ) )
      return $post_id;
  }

  // OK, we're authenticated: we need to find and save the data
  $enable_protection = array();
  global $emember_auth;
  $enable_protection['protect'] = $_POST['eMember_protect_post'];
  $enable_protection['level']   = $_POST['eMember_protection_level'];
  //$protection = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id = 1', ' id DESC ');
  $protection = $emember_auth->protection;  
	  //$protection = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id = 1', ' id DESC ');
	  if('page' == $_POST['post_type']){
	      $p_pages = unserialize( $protection->page_list );
	      $p_pages = is_bool($p_pages)? array() : $p_pages;
	      if($_POST['eMember_protect_post']==2)$p_pages[] = $post_id;	     
	      else foreach($p_pages as $k=>$v)if($v===$post_id) unset($p_pages[$k]);	
	  	  $p_pages = array_unique($p_pages);
          $p_pages = serialize($p_pages);
          $protection = (array)($protection);
          $protection['page_list']=$p_pages;	  	  	      
	  }
	  else if('post' == $_POST['post_type']){
	  	  $p_posts = unserialize( $protection->post_list );
	  	  $p_posts = is_bool($p_posts)? array() : $p_posts;
	  	  if($_POST['eMember_protect_post']==2)$p_posts[] = $post_id;	     
	      else foreach($p_posts as $k=>$v)if($v===$post_id) unset($p_posts[$k]);	  	  
	  	  $p_posts = array_unique($p_posts);
          $p_posts = serialize($p_posts);
          $protection = (array)($protection);
          $protection['post_list']=$p_posts;	            	 
	  }
      dbAccess::update(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE,' id = 1' , $protection);
      
      $all_levels = dbAccess::findAll(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id != 1 ', ' id DESC ');
      
	  foreach($all_levels as $level){
	      //$level = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id = '.$p_level, ' id DESC ');
    	  if('page' == $_POST['post_type']){
    	      $l_pages = unserialize( $level->page_list );
    	      $l_pages = is_bool($l_pages)? array() : $l_pages;
    	      if(isset($_POST['eMember_protection_level'][$level->id]))
	          	 $l_pages[] = $post_id;
	          else 
	             foreach($l_pages as $k=>$v)if($v===$post_id) unset($l_pages[$k]);
	  	      $l_pages = array_unique($l_pages);
              $l_pages = serialize($l_pages);
              $level = (array)($level);
              $level['page_list']=$l_pages;	  	  	          	      
    	  }
    	  else if('post' == $_POST['post_type']){
    	  	  $l_posts = unserialize( $level->post_list );
    	  	  $l_posts = is_bool($l_posts)? array() : $l_posts;
    	  	  if(isset($_POST['eMember_protection_level'][$level->id]))
	  	          $l_posts[] = $post_id;
	  	      else 
	  	          foreach($l_posts as $k=>$v)if($v===$post_id) unset($l_posts[$k]);
	  	      $l_posts = array_unique($l_posts);
              $l_posts = serialize($l_posts);
              $level = (array)($level);
              $level['post_list']=$l_posts;	  	      	  	      	  	  
    	  }
    	  dbAccess::update(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE,' id = '.$level['id'],  $level);	      
	  }

  // Do something with $mydata 
  // probably using add_post_meta(), update_post_meta(), or 
  // a custom table (see Further Reading section below)
   
   return $enable_protection;
}
////////////////////////////////////////////

function lockdown_widget(){
	global $emember_auth;
	global $emember_config;
	$join_url = $emember_config->getValue('eMember_payments_page');
	
	$url_components = parse_url($join_url);
	$join_path  = (isset($url_components['path'])?$url_components['path']:"");
	$join_query = (isset($url_components['query'])? '?' . $url_components['query']:"");
	$join_uri = $join_path . $join_query;
	
	if(strpos($_SERVER['REQUEST_URI'],$join_uri)!==false) return;
	
	$reg_url = $emember_config->getValue('eMember_registration_page');
	$url_components = parse_url($reg_url);
	$reg_path  = (isset($url_components['path'])?$url_components['path']:"");
	$reg_query = (isset($url_components['query'])? '?' . $url_components['query']:"");
	$reg_uri = $reg_path . $reg_query;

	if(strpos($_SERVER['REQUEST_URI'],$reg_uri)!==false) return;
	
	if(!$emember_auth->isLoggedIn()){
	   include_once('emember_lockdown_popup.php');
       wp_emember_hook_password_reminder();	   
	   exit;
	}
}

function escape_csv_value($value) {
	$value = str_replace('"', '""', $value); // First off escape all " and make them ""
	if(preg_match('/,/', $value) or preg_match("/\n/", $value) or preg_match('/"/', $value)) { // Check if I have any commas or new lines
		return '"'.$value.'"'; // If I have new lines or commas escape them
	} else {
		return $value; // If no new lines or commas just return the value
	}
}

function export_members_to_csv(){
    global $wpdb;
    if($_POST['wp_emember_export']){
        $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
        $ret_member_db = $wpdb->get_results("SELECT * FROM $member_table ORDER BY member_id DESC", OBJECT);
        $csv_output = "User name, First Name, Last Name, Street, City,State,ZIP,Country, Email, Phone,Membership Start,\n";
        
        foreach($ret_member_db as $result){
            $csv_output .= escape_csv_value(stripslashes($result->user_name )). ','.
                           escape_csv_value(stripslashes($result->first_name)). ', '. 
                           escape_csv_value(stripslashes($result->last_name)) .  ','.
                           escape_csv_value(stripslashes($result->address_street)). ', ' . 
                           escape_csv_value(stripslashes($result->address_city)). ', ' . 
                           escape_csv_value(stripslashes($result->address_state)).', ' . 
                           escape_csv_value(stripslashes($result->address_zipcode)) . ', ' .
                           escape_csv_value(stripslashes($result->country)) . ',' .
                           escape_csv_value(stripslashes($result->email)) . ','.
                           escape_csv_value(stripslashes($result->phone)) .','. 
                           escape_csv_value(stripslashes($result->subscription_starts)). ','."\n"; 
        }
        $filename = "member_list_".date("Y-m-d_H-i",time());
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");  
        header("Content-Description: File Transfer");  
        header("Content-Length: " . strlen($csv_output));   
        header("Content-type: text/x-csv");     
        header( "Content-disposition: attachment; filename=".$filename.".csv");
        print $csv_output;
        exit;   
    }
}

add_action('wp_authenticate', 'wp_login_callback', 1, 2 );
function update_account_status($username){
	global $wpdb;
    if($username){
        $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
        $ret_member_db = $wpdb->get_row("SELECT * FROM $member_table WHERE user_name='" . $wpdb->escape($username) . "'", OBJECT);
        if($ret_member_db){
            $wp_user = get_userdatabylogin( $username );        
            if($wp_user){
                $new_capabilities = array();
                $account_states = array('expired','','inactive','pending','unsubscribed');
                $modified = false;
                if($wp_user->wp_capabilities)
                foreach($wp_user->wp_capabilities as $role=>$state){                    
                    if(in_array($ret_member_db->account_state,$account_states)){
                        if(is_bool(strpos($role, '_'))){
                           $new_capabilities[$role . '_' . $ret_member_db->account_state] = $state;
                           $modified = true;
                        }
                    }else if($ret_member_db->account_state === 'active'){
                        $parts =explode('_',$role) ;
                        $new_capabilities[$parts[0]] = $state;
                        $modified = true;
                    }                    
                }
                if($modified)update_usermeta($wp_user->ID,'wp_capabilities', $new_capabilities);                
            }
        }               
    }
}
function wp_login_callback($username,$password){
    global $wpdb;
    global $emember_auth;
    global $emember_config;
    $auto_emember_login = $emember_config->getValue('eMember_signin_emem_user');
    update_account_status($username);
    if($auto_emember_login){    
	    $emember_auth->login($username,$password,true);
	    if($emember_auth->isLoggedIn()){
	        $after_login_page = $emember_config->getValue('after_login_page');
	        $membership_level = $emember_auth->getUserInfo('membership_level');
	        //$membership_level_resultset = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, " id='$membership_level' ");
	        $membership_level_resultset = $emember_auth->userInfo->primary_membership_level;
	        $_SESSION['membership_level_name'] = $membership_level_resultset->alias;    	
	    }
    }
}
function wp_eMember_registration_form_handler($atts)
{
    extract(shortcode_atts(array(
        'level' => 'no level specified',
    ), $atts));	
    return show_registration_form($level);
}
function emember_total_members_handler($attrs, $contents, $codes=''){
    return emember_get_total_members();  
}

function emember_get_total_members(){
    global $wpdb;
    $emember_user_count = $wpdb->get_row("SELECT COUNT(*) as count FROM " . WP_EMEMBER_MEMBERS_TABLE_NAME . ' ORDER BY member_id');
    return $emember_user_count->count;		
}
function del_bookmark(){
    if(isset($_POST['remove_bookmark'])){
        global $emember_auth;
        if($emember_auth->isLoggedIn()){
            $bookmarks = unserialize($emember_auth->getUserInfo('extra_info'));
            if(!empty($bookmarks['bookmarks']) && !empty($_POST['del_bookmark'])){
                $bookmarks['bookmarks'] = array_diff($bookmarks['bookmarks'],$_POST['del_bookmark']);
                $extr['extra_info'] = serialize($bookmarks);
                $emember_auth->userInfo->extra_info = $extr['extra_info'];
                dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $emember_auth->getUserInfo('member_id'), $extr);
            }
        }    
    }    
}
/********************more tag#start***************************************/
$enable_more_tag = $emember_config->getValue('eMember_enable_more_tag');
if($enable_more_tag) add_filter( 'the_content_more_link', 'eMember_my_more_link', 10, 2 );

/********************more tag#end*********************************************/
$enable_bookmark = $emember_config->getValue('eMember_enable_bookmark');
if($enable_bookmark) add_filter('the_content', 'boomark_handler');
function boomark_handler($content){
    global $emember_auth;
    global $post;
    if(is_feed()) return $content;
    if($emember_auth->isLoggedIn()){
        $membership_level = $emember_auth->getUserInfo('membership_level');

        //$plevel = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id=1');
        $plevel = $emember_auth->protection;
        $debookmarked = unserialize($plevel->disable_bookmark_list);
        if(is_page())
            $debookmarked = is_bool($debookmarked['pages'])? array(): (array)$debookmarked['pages'];
        else 
            $debookmarked = is_bool($debookmarked['posts'])? array(): (array)$debookmarked['posts'];
        if(in_array($post->ID, $debookmarked)) return $content;    	

        //$level = dbAccess::find(WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE, ' id=' . $membership_level);
        $level = $emember_auth->userInfo->primary_membership_level;    	
        $debookmarked = unserialize($level->disable_bookmark_list);
        if(is_page())
            $debookmarked = is_bool($debookmarked['pages'])? array(): (array)$debookmarked['pages'];
        else
            $debookmarked = is_bool($debookmarked['posts'])? array(): (array)$debookmarked['posts'];    	
        if(in_array($post->ID, $debookmarked)) return $content; 

        $extr = unserialize($emember_auth->getUserInfo('extra_info'));
        $bookmark = isset($extr['bookmarks'])?$extr['bookmarks'] : array(); 
        $title = EMEMBER_ADD_FAV;
        $link  =  $post->ID;
        if(in_array($post->ID, $bookmark)){
            $a1 = '<div title="Bookmarked"  class="count">
                        <span class="c"><b>&radic;</b></span><br/>
                        <span class="t">'.EMEMBER_FAVORITE.'</span>
                    </div>';
            $a2 = '<div title="Bookmarked"class="emember">'.EMEMBER_ADDED.'</div>';                     
        }
        else{
            $a1 = '<a title="' . $title . '" target="_parent" href="'.$link.'" class="count">
                        <span class="c"><b>+</b></span><br/>
                        <span class="t">'.EMEMBER_BOOKMARK.'</span>
                    </a>';
            $a2 = '<a href="'.$link.'" title="' . $title . '" target="_parent" class="emember">'.EMEMBER_ADD.'</a>';                     
        }   
    }
    else{
        $title = EMEMBER_LOGIN_TO_BOOKMARK;
        $link  = "";
        $a1 = '<div title="' . $title . '"  class="count">
                    <span class="c"><b style="color:red;">x</b></span><br/>
                    <span class="t">'.EMEMBER_BOOKMARK.'</span>
                </div>';
        $a2 = '<div  title="' . $title . '" class="emember">'.EMEMBER_LOGIN.'</div>';                     
    }
    $button = '<div class="emember_bookmark_button" style="float: right; margin-left: 10px;">
                   <div  class="ememberbookmarkbutton">
                   '.$a1.'				
            </div>
        </div>
        ';
    return $button.$content;
}
function wp_emember_hook_password_reminder(){
    echo '<script type="text/javascript">WPURL="' . get_bloginfo('wpurl') . '";</script>' . "\n";    
    include_once('emember_password_sender_box.php');
}

function sync_emember_profile($wp_user_id){
    $wp_user_data = get_userdata($wp_user_id);
    $profile = dbAccess::find(WP_EMEMBER_MEMBERS_TABLE_NAME, ' user_name=\'' . $wp_user_data->user_login . '\'');
    $profile = (array)$profile;
    $profile['user_name'] = $wp_user_data->user_login; 
    $profile['email']     = $wp_user_data->user_email;
    $profile['password']  = $wp_user_data->user_pass;
    $profile['first_name']= $wp_user_data->user_firstname;
    $profile['last_name'] = $wp_user_data->user_lastname;
    dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id = ' . $profile['member_id'], $profile);   
}
function load_library(){    
      wp_enqueue_script('jquery');
      wp_enqueue_style('eMember.style',WP_EMEMBER_URL.'/css/eMember_style.css');
      if(is_admin()){
          wp_enqueue_script('jquery.datepicker',WP_EMEMBER_URL.'/js/jquery-ui-1.7.2.custom.min.js',array('jquery-ui-core'));
          wp_enqueue_script('jquery.dateentry',WP_EMEMBER_URL.'/js/jquery.dateentry.min.js'); 
          wp_enqueue_script('jquery.dynamicField',WP_EMEMBER_URL.'/js/jquery.dynamicField-1.0.js');            
          wp_enqueue_style('jquery.dateentry',WP_EMEMBER_URL.'/css/jquery.dateentry.css');
          if($_GET['members_action']=='add_edit'||$_GET['members_action']=='add_wp_members')
          	 wp_enqueue_style('jquery-ui', WP_EMEMBER_URL.'/css/custom-theme/jquery-ui.css');
      }
      if(get_bloginfo('version')<'3.0'){
      	  wp_enqueue_script('jquery.pagination',WP_EMEMBER_URL.'/js/jquery.pagination-1.2.js');	     
	      wp_enqueue_script('jquery.confirm',WP_EMEMBER_URL.'/js/jquery.confirm-1.2.js');      	
      }
      else {
	      wp_enqueue_script('jquery.pagination',WP_EMEMBER_URL.'/js/jquery.pagination-2.0rc.js');
	      wp_enqueue_script('jquery.confirm',WP_EMEMBER_URL.'/js/jquery.confirm-1.3.js');      	
      }
      wp_enqueue_script('jquery.hint',WP_EMEMBER_URL.'/js/jquery.hint.js');     
      wp_enqueue_script('ajaxupload',WP_EMEMBER_URL.'/js/ajaxupload.js');
      wp_enqueue_script('jquery.tools',WP_EMEMBER_URL.'/js/jquery.tools.min.js');
      wp_enqueue_script('jquery.libs',WP_EMEMBER_URL.'/js/jquery.libs.js');                             
}

/********************feed#start*******************************************/
//add_filter('the_excerpt_rss', 'secure_feed_entry');
//add_filter('the_content_rss', 'secure_feed_entry');
//add_filter('comment_text_rss', 'secure_feed_comment');
//add_filter('the_title_rss', 'secure_feed_title');

function emember_delete_enclosure(){
    return '';
}


add_filter( 'get_enclosed', 'emember_delete_enclosure' );
add_filter( 'rss_enclosure', 'emember_delete_enclosure' );
add_filter( 'atom_enclosure', 'emember_delete_enclosure' );

add_filter('generate_rewrite_rules', 'custom_feed_rewrite');

function custom_feed_rewrite($wp_rewrite) {
    $feed_rules = array(
                        'feed/(.+)' => 'index.php?feed=' . $wp_rewrite->preg_index(1),
                        '(.+).xml' => 'index.php?feed='. $wp_rewrite->preg_index(1)
                        );
    $wp_rewrite->rules = $feed_rules + $wp_rewrite->rules;
}

function secure_feed_title($title){
    return $title ;
}
function secure_feed_entry($content){
    return auth_check_post($content);
}

function secure_feed_comment($content){
   return auth_check_comment($content);
}
/********************feed#end*********************************************/
function wp_eMember_widget_init(){
    $widget_options = array('classname' => 'wp_eMember_widget', 'description' => __( "Display WP eMember Login.") );
    wp_register_sidebar_widget('wp_eMember_widget', __('WP eMember Login'), 'show_wp_eMember_login_widget', $widget_options);
}

/*********************protected tag#start**********************************/
function emember_protected_handler($attrs, $contents, $codes=''){
    global $emember_auth;

    global $emember_config;
    $emember_auth->hasmore = true;
    if($emember_auth->isLoggedIn()) {
      	$expires = $emember_auth->getUserInfo('account_state');
      	if($expires == 'expired') return get_renewal_link();  
        
      	if(isset($attrs['member_id'])){
            $member_id = $emember_auth->getUserInfo('member_id');
            $permitted_member_ids = explode('-', $attrs['member_id']);
            if (in_array($member_id, $permitted_member_ids))
                return $contents; 
            else{               
                return '<b>'.EMEMBER_CONTENT_RESTRICTED.'</b><br/><br/>';            
            }            
        }      	  	
        if(isset($attrs['for'])){
            $level = $emember_auth->getUserInfo('membership_level');
            $permitted_levels = explode('-', $attrs['for']);
            if (in_array($level, $permitted_levels))
                return $contents; 
            else{
                $account_upgrade_url = $emember_config->getValue('eMember_account_upgrade_url');                
                return '<b>'. EMEMBER_HIDDEN_CONTENT_MESSAGE. '<br/>'.EMEMBER_PLEASE.' <a href=" '.$account_upgrade_url .'" target=_blank>'.EMEMBER_RENEW.'</a> '.EMEMBER_YOUR_ACCOUNT.'</b>';            
            }            
        }
        return $contents;        
    }

    $join_url = $emember_config->getValue('eMember_payments_page');
    if(empty($join_url)) 
         return '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:'.$emember_config->getValue('admin_email').'">Admin</a>.';
    else $join_url = ' href ="'.$join_url.'" ';

    $replacement = '<a '. $join_url .' ><b>'.EMEMBER_MEMBERS_ONLY_MESSAGE.'</b></a>';
    return $replacement;
}
/*********************protected tag#end************************************/
function show_wp_eMember_login_widget($args){
    global $emember_config;
    extract($args);
    $widget_title = $emember_config->getValue('wp_eMember_widget_title');
    if (empty($widget_title)) $widget_title = EMEMBER_MEMBER_LOGIN;
    echo $before_widget;
    echo $before_title . $widget_title . $after_title;
    echo eMember_login_widget();
    echo $after_widget;
}

//Add the Admin Menus

define("EMEMBER_MANAGEMENT_PERMISSION", "add_users");

if (is_admin()){
   function wp_eMember_add_admin_menu(){
      add_menu_page(__("WP eMember", 'wp_eMember'), __("WP eMember", 'wp_eMember'), EMEMBER_MANAGEMENT_PERMISSION, __FILE__, "wp_eMember_dashboard");
      add_submenu_page(__FILE__, __("Dashboard WP eMember", 'wp_eMember'), __('Dashboard', 'wp_eMember'), EMEMBER_MANAGEMENT_PERMISSION, __FILE__, "wp_eMember_dashboard");
	  add_submenu_page(__FILE__, __("Settings WP eMember", 'wp_eMember'), __("Settings", 'wp_eMember'), EMEMBER_MANAGEMENT_PERMISSION, 'eMember_settings_menu', "wp_eMember_settings");      
      add_submenu_page(__FILE__, __("Members WP eMember", 'wp_eMember'), __("Members", 'wp_eMember'), EMEMBER_MANAGEMENT_PERMISSION, 'wp_eMember_manage', "wp_eMember_members");      
      add_submenu_page(__FILE__, __("Membership Level WP eMember", 'wp_eMember'), __("Membership Level", 'wp_eMember'), EMEMBER_MANAGEMENT_PERMISSION, 'eMember_membership_level_menu', "wp_eMember_membership_level");      
      add_submenu_page(__FILE__, __("Admin Functions", 'wp_eMember'), __("Admin Functions", 'wp_eMember'), EMEMBER_MANAGEMENT_PERMISSION, 'eMember_admin_functions_menu', "wp_eMember_admin_functions_menu");
   }

   //Include menus
   require_once(dirname(__FILE__).'/eMember_members_menu.php');
   require_once(dirname(__FILE__).'/eMember_dashboard_menu.php');
   require_once(dirname(__FILE__).'/eMember_membership_level_menu.php');
   require_once(dirname(__FILE__).'/eMember_settings_menu.php');
   require_once(dirname(__FILE__).'/eMember_admin_functions_menu.php');   
}
// Insert the options page to the admin menu
if (is_admin()){
   add_action('admin_menu','wp_eMember_add_admin_menu');
}

function emember_menu(){
    global $wpemem_evt;
    $wpemem_evt = trim($_REQUEST['event']);
    switch($wpemem_evt){
       case 'logout':       
          wp_emem_logout();
          break;
       case 'delete_account':
          delete_account();
           break;
       case 'check_name':
           do_action( 'wp_ajax_nopriv_check_name');
           die('0');break;
       case 'access_list_ajax':
          do_action( 'wp_ajax_access_list_ajax');
           die('0');break;
       case 'item_list_ajax':
           do_action( 'wp_ajax_item_list_ajax');
           die('0');break;
       case 'check_level_name':
          do_action( 'wp_ajax_check_level_name');
          die('0');break;
       case 'send_mail':
          do_action( 'wp_ajax_send_mail');
          die('0');break;
       case 'bookmark_ajax':
           do_action('wp_ajax_add_bookmark');
           die('0');break;
       case 'wp_user_list_ajax':
           do_action('wp_ajax_wp_user_list_ajax');
           die('0');break;           
       case 'emember_user_list_ajax':
           do_action('wp_ajax_emember_user_list_ajax');
           die('0');break;           
       case 'emember_user_count_ajax':
           do_action('wp_ajax_emember_user_count_ajax');
           die('0');break;           
       case 'emember_upload_ajax':
           do_action('wp_ajax_emember_upload_ajax');
           die('0');break;           
       case 'emember_public_user_list_ajax':
           do_action('wp_ajax_nopriv_emember_public_user_list_ajax');
           die('0');break;           
       case 'emember_public_user_profile_ajax':
           do_action('wp_ajax_nopriv_emember_public_user_profile_ajax');
           die('0');break;            
    }
}

function comment_text_action($content){
    return auth_check_comment($content);
}

function secure_content($content){
    if(is_category()) {return auth_check_category($content); }
    if(is_page()) {return auth_check_page($content);}    
    return auth_check_post($content);
}
function get_renewal_link(){
    global $emember_config;
    $account_upgrade_url = $emember_config->getValue('eMember_account_upgrade_url');
    if(empty($account_upgrade_url)) return 'Account renewal page is not defined. Please Contact <a href="mailto:'.$emember_config->getValue('admin_email').'">Admin</a>.';  
    return EMEMBER_SUBSCRIPTION_EXPIRED_MESSAGE .' '.EMEMBER_PLEASE. 
           ' <a href=" '.$account_upgrade_url .'" target=_blank>'.EMEMBER_RENEW.
           '</a> ' . EMEMBER_YOUR_ACCOUNT;     
}

function get_login_link(){
    global $emember_config;
    $login_url = get_permalink();
    $join_url = $emember_config->getValue('eMember_payments_page');
    $eMember_enable_fancy_login = $emember_config->getValue('eMember_enable_fancy_login');
    if(empty($join_url)) return '<b>Membership Payment/Join Page</b> is not defined in the settings page.Please Contact <a href="mailto:'.$emember_config->getValue('admin_email').'">Admin</a>.';
    
    if($eMember_enable_fancy_login){
    $url_text = EMEMBER_PLEASE .' <a id="'.microtime(true).'" class="emember_fancy_login_link" href="javascript:void(0);">'. 
                EMEMBER_LOGIN .'</a> ' .EMEMBER_TO_VIEW_CONTENT;
    $url_text .= '('.EMEMBER_NON_MEMBER.' <a href="'.$join_url.'">'.EMEMBER_JOIN.'</a>)';    	
	    ob_start();
	    include_once('fancy_login.php');   
	    $output = ob_get_contents();
	    ob_end_clean();      
	    return $url_text . $output;
    }
    $no_fancy_login = '';   
    if(strpos($login_url, '?')){    
       $no_fancy_login = EMEMBER_PLEASE .' <a   href="'.$login_url.'&event=login">'. 
                    EMEMBER_LOGIN .'</a> ' .EMEMBER_TO_VIEW_CONTENT;
    }
    else{
       $no_fancy_login = EMEMBER_PLEASE .' <a  href="'.$login_url.'?event=login">'. 
                    EMEMBER_LOGIN .'</a> ' .EMEMBER_TO_VIEW_CONTENT;
    }
    
    return $no_fancy_login . '('.EMEMBER_NON_MEMBER.' <a href="'.$join_url.'">'.EMEMBER_JOIN.'</a>)';
}

function filter_eMember_login_form($content){  
    $pattern = '#\[wp_eMember_login_form:end]#';
    preg_match_all ($pattern, $content, $matches);

    foreach ($matches[0] as $match){
        $replacement = print_eMember_login_form();
        $content = str_replace ($match, $replacement, $content);
    }	    

    return $content;
}

function filter_eMember_public_user_list($content){
    include_once('public_user_directory.php');
    $pattern = '#\[wp_eMember_public_user_list:end]#';
    preg_match_all ($pattern, $content, $matches);
    foreach ($matches[0] as $match){
        $replacement = print_eMember_public_user_list();
        $content = str_replace ($match, $replacement, $content);
    }	    
    return $content;    	
}
function print_eMember_login_form(){
    return eMember_login_widget();
}
function delete_account(){
    global $emember_config;
    global $emember_auth;
    if(!$emember_auth->isLoggedIn()) return;
    $f = $emember_config->getValue('eMember_allow_account_removal');
    if($f){
        $f = $emember_config->getValue('eMember_allow_wp_account_removal');
        if($f){			
            $wp_user_id = username_exists($emember_auth->getUserInfo('user_name'));
            $ud = get_userdata($wp_user_id);
            if(isset($ud->wp_capabilities['administrator'])||$ud->wp_user_level == 10){
              if($_GET['confirm']!=2){
                  $u = get_bloginfo('wpurl');
                  $_GET['confirm'] = 2;
                  $u .= '?' . http_build_query($_GET);
                  $warning = "<html><body><div id='message' style=\"color:red;\" ><p>You are about to delete an account that has admin privilege.
                  If you are using WordPress user integration then this will delete the corresponding user
                  account from WordPress and you may not be able to log in as admin with this account.
                  Continue? <a href='". $u. "'>yes</a>/<a href='javascript:void(0);' onclick='top.document.location=\"". get_bloginfo('wpurl') . "\";' >no</a></p></div></body></html>";
                  echo $warning;
                  exit;
              }	
            }
            wp_clear_auth_cookie();		
            if($wp_user_id) wp_delete_user( $wp_user_id, 1 ); //assigns all related to this user to admin.
        }
        $ret = dbAccess::delete(WP_EMEMBER_MEMBERS_TABLE_NAME, 'member_id=' . $emember_auth->getUserInfo('member_id'));
        $ret = dbAccess::delete(WP_EMEMBER_MEMBERS_META_TABLE, 'user_id='.$auth->getUserInfo('member_id'));				
        global $auth;
        $auth->logout();
        header('location:' . get_bloginfo('wpurl'));exit;
    }	
}
function filter_eMember_registration_form($content){  
    $pattern = '#\[wp_eMember_registration_form:end]#';
    preg_match_all ($pattern, $content, $matches);

    foreach ($matches[0] as $match){
        $replacement = print_eMember_registration_form();
        $content = str_replace ($match, $replacement, $content);
    }
    return $content;
}

function print_eMember_registration_form(){
    return show_registration_form();
}

function filter_eMember_edit_profile_form($content){
    global $auth; 

    $pattern = '#\[wp_eMember_profile_edit_form:end]#';
    preg_match_all ($pattern, $content, $matches);
    if((count($matches[0])>0)&&!$auth->isLoggedIn()){
        return EMEMBER_PROFILE_MESSAGE;
    }

    foreach ($matches[0] as $match){
        $replacement = print_eMember_edit_profile_form();
        $content = str_replace ($match, $replacement, $content);
    }

    return $content;
}

function filter_eMember_bookmark_list($content){   
    $pattern = '#\[wp_eMember_bookmark_list:end]#';
    preg_match_all ($pattern, $content, $matches);

    foreach ($matches[0] as $match){
        $replacement = print_eMember_bookmark_list();
        $content = str_replace ($match, $replacement, $content);
    }	    
    return $content;    
}

function print_eMember_edit_profile_form(){
    return show_edit_profile_form();
}

function wp_emem_logout(){
    global $emember_config;
    global $auth;    

/*********for role integration#start*****************/
    global $user_login;
    get_currentuserinfo();
    $emember_login = $auth->getUserInfo('user_name');

    $auth->logout();   
    if($emember_login===$user_login)
    {
        //wp_logout();
    wp_clear_auth_cookie();
    }

/*********for role integration#start*****************/
    $logout_page = $emember_config->getValue('after_logout_page');
    if($logout_page){
        header('Location: ' . $logout_page);exit;
    }
    else{
        echo '<script type="text/javascript">window.location = "'.get_bloginfo("wpurl").'";</script>';
    }   
}

function logout_handler()
{   
    global $auth;
    $auth->logout();
}

function eMember_login_widget()
{
    global $auth;
    global $emember_config;
    $username = $auth->getUserInfo('user_name');

    if($auth->isLoggedIn()){
        $expires = $auth->getUserInfo('account_state');
        if($auth->my_subscription_duration === 0)
            $sub_expires = EMEMBER_NEVER;
        else{
            $sub_start = strtotime($auth->getUserInfo('subscription_starts'));
            $sub_expires = date('F j, Y',strtotime("+" . $auth->my_subscription_duration . " days ", $sub_start));
        }
        $states = array('active'=>EMEMBER_ACTIVE,
                         'inactive'=>EMEMBER_INACTIVE,
                         'expired'=>EMEMBER_EXPIRED,
                         'pending'=>EMEMBER_PENDING,
                         'unsubscribed'=>EMEMBER_UNSUBSCRIBED);
        $eMember_secure_rss = $emember_config->getValue('eMember_secure_rss');
        $feed_url = get_bloginfo('url') . '?feed=ememberfeed&key=' . md5($auth->getUserInfo('member_id'));
        $logout = get_logout_url();
        $output .= '<div class="eMember_logged_widget">';
        $output .= '<ul>' . EMEMBER_LOGGED_IN_AS;
        $output .= '<label class="eMember_highlight">'.$username.'</label>';
        $output .= '<br />' . EMEMBER_LOGGED_IN_LEVEL;
        $output .= '<label class="eMember_highlight">'.$auth->user_membership_level_name.'</label>';
        $output .= '<br />' . EMEMBER_ACCOUNT_STATUS. " ";               
        $output .= '<label class="eMember_highlight">'.$states[$auth->getUserInfo('account_state')].'</label>';
        if($expires != 'expired'){        
            $output .= '<br />' . EMEMBER_ACCOUNT_EXPIRES_ON . " ";        
            $output .= '<label class="eMember_highlight">'.$sub_expires.'</label>';
        }  
        else
        {
            $renew_url = $emember_config->getValue('eMember_account_upgrade_url');
            $output .= '<li><a href="'.$renew_url.'">'.EMEMBER_RENEW.'</a></li>';
        }      
        $output .= '<li><a href="'.$logout.'">'.EMEMBER_LOGOUT.'</a></li>';
        if($eMember_secure_rss)
            $output .= '<li><a href="'.$feed_url.'">'.EMEMBER_MY_FEED.'</a></li>';        
        $edit_profile_page = $emember_config->getValue('eMember_profile_edit_page');
        $support_page = $emember_config->getValue('eMember_support_page');

        if(!empty($edit_profile_page))
            $output .= '<li><a href="'.$edit_profile_page.'">'.EMEMBER_EDIT_PROFILE.'</a></li>';
        if(!empty($support_page))
            $output .= '<li><a href="'.$support_page.'">'.EMEMBER_SUPPORT_PAGE.'</a></li>';
        $output .= '</ul>';
        $custom_login_msg = $emember_config->getValue('eMember_login_widget_message_for_logged_members');
        if(!empty($custom_login_msg))
        {        	
        	$output .= html_entity_decode($custom_login_msg, ENT_COMPAT);;
        }
        $output .= '</div>';
    }
    else  
        $output = show_login_form();

    return $output;
}
function eMember_compact_login_widget()
{
    global $auth;
    global $emember_config;
    $output = "";
    $output .= "<div class='eMember_compact_login'>";
    if($auth->isLoggedIn()){
    	$output .= EMEMBER_HELLO;
    	$name = $auth->getUserInfo('first_name')." ".$auth->getUserInfo('last_name');;
    	$output .= $name;
    	$logout = get_logout_url();
    	$output .= ' | ';
    	$output .= '<a href="'.$logout.'">'.EMEMBER_LOGOUT.'</a>';
    }
    else 
    {
    	$output .= EMEMBER_HELLO;
    	$eMember_enable_fancy_login = $emember_config->getValue('eMember_enable_fancy_login');
        if($eMember_enable_fancy_login)
        {
        	$output .= '<a id="'.microtime(true).'" class="emember_fancy_login_link" href="javascript:void(0);">'.EMEMBER_LOGIN.'</a>';
		    ob_start();
		    include_once('fancy_login.php');   
		    $output_fancy_jquery = ob_get_contents();
		    ob_end_clean();      
		    $output .= $output_fancy_jquery;
	    } 	
    	else
    	{
    		$login_url = $emember_config->getValue('login_page_url');
    		$output .= '<a href="'.$login_url.'">'.EMEMBER_LOGIN .'</a>';
    	}
    	$output .= EMEMBER_NOT_A_MEMBER_TEXT;
    	$join_url = $emember_config->getValue('eMember_payments_page');
    	$output .= '<a href="'.$join_url.'">'.EMEMBER_JOIN .'</a>';    	
    }       
    $output .= "</div>"; 
    return $output;
}
function get_logout_url(){
    $url = get_bloginfo('url');
    if(strpos($url,'?')) $logout = $url."&event=logout";
    else $logout = $url."/?event=logout";
    return $logout;
}
function wp_eMember_free_membership_renewal_handler($atts)
{
	global $auth;
	$user_id = $auth->getUserInfo('member_id');
	if (!empty($user_id))
	{		
		$output = "";
		$output .= '<div class="free_eMember_renewal_form">';
	    if(isset($_POST['eMember_free_renewal']))
	    {
			$member_id = $_POST['eMember_free_renewal'];
			$curr_date = (date ("Y-m-d"));
			dbAccess::update(WP_EMEMBER_MEMBERS_TABLE_NAME,'member_id='.$member_id, array('subscription_starts'=>$curr_date,'account_state'=>'active'));		    	
			$output .= "Membership Renewed!";
	    }
	    else
	    {
			$output .= '<form name="free_eMember_renewal" method="post" action="">';
			$output .= '<input type="hidden" name="eMember_free_renewal" value="'.$user_id.'" />';
			$output .= '<input type="submit" name="eMember_free_renew_submit" value="Renew" />';
			$output .= '</form>';			
	    }
	    $output .= '</div>';
		return $output;
	}
	else
	{
		return "You must be logged in to renew a membership!";
	}
}
function eMember_handle_affiliate_signup($user_name,$pwd,$afirstname,$alastname,$aemail,$referrer)
{
	global $emember_config;
	if (function_exists('wp_aff_platform_install'))
	{
	    $commission_level = get_option('wp_aff_commission_level');//This must use the get_option and not getValue
	    $date = (date ("Y-m-d"));
	    wp_aff_create_affilate($user_name,$pwd,'','',$afirstname,$alastname,'',$aemail,'','','','','','','','',$date,'',$commission_level,$referrer);
    	    wp_aff_send_sign_up_email($user_name,$pwd,$aemail);
	}
}
function eMember_get_aff_referrer()
{
        $referrer = "";
        if (!empty($_SESSION['ap_id']))
        {
            $referrer = $_SESSION['ap_id'];
        }
        else if (isset($_COOKIE['ap_id']))
        {
            $referrer = $_COOKIE['ap_id'];
        }
        return $referrer;
}
function eMember_is_post_protected ($post_id)
{
    global $wpdb;
    $wpdb->prefix . "wp_eMember_membership_tbl";
    $query = "SELECT post_list FROM " . $wpdb->prefix . "wp_eMember_membership_tbl WHERE id = 1;";
    $post_list = unserialize($wpdb->get_var($wpdb->prepare($query)));
    if(!$post_list) return false;
    return in_array($post_id, $post_list);
}
?>