<?php
function emember_pages_settings(){
	global $emember_config;
    if (isset($_POST['info_update'])){
        $msg = '';
        $emember_config->setValue('login_page_url',trim((string)$_POST["login_page_url"]));
        $emember_config->setValue('after_login_page',trim((string)$_POST["after_login_page"]));
        $emember_config->setValue('after_logout_page',trim((string)$_POST["after_logout_page"]));        
        $emember_config->setValue('eMember_registration_page',trim((string)$_POST["eMember_registration_page"]));
        update_option('eMember_registration_page', trim((string)$_POST["eMember_registration_page"])); //For backwards compatibility with eStore
        $emember_config->setValue('eMember_payments_page',trim((string)$_POST["eMember_payments_page"]));
		$emember_config->setValue('eMember_profile_edit_page',trim((string)$_POST["eMember_profile_edit_page"]));   
		$emember_config->setValue('eMember_support_page',trim((string)$_POST["eMember_support_page"]));
		$emember_config->setValue('eMember_reg_title'     ,isset($_POST['eMember_reg_title']     )?"checked='checked'":'');  
		$emember_config->setValue('eMember_reg_firstname' ,isset($_POST['eMember_reg_firstname'] )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_lastname'  ,isset($_POST['eMember_reg_lastname']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_company'   ,isset($_POST['eMember_reg_company']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_email'     ,isset($_POST['eMember_reg_email']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_phone'     ,isset($_POST['eMember_reg_phone']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_street'    ,isset($_POST['eMember_reg_street']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_city'      ,isset($_POST['eMember_reg_city']      )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_state'     ,isset($_POST['eMember_reg_state']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_zipcode'   ,isset($_POST['eMember_reg_zipcode']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_country'   ,isset($_POST['eMember_reg_country']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_gender'    ,isset($_POST['eMember_reg_gender']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_title'    ,isset($_POST['eMember_edit_title']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_firstname',isset($_POST['eMember_edit_firstname'])?"checked='checked'":''); 
		$emember_config->setValue('eMember_edit_lastname' ,isset($_POST['eMember_edit_lastname'] )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_company'  ,isset($_POST['eMember_edit_company']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_email'    ,isset($_POST['eMember_edit_email']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_phone'    ,isset($_POST['eMember_edit_phone']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_street'   ,isset($_POST['eMember_edit_street']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_city'     ,isset($_POST['eMember_edit_city']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_state'    ,isset($_POST['eMember_edit_state']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_zipcode'  ,isset($_POST['eMember_edit_zipcode']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_country'  ,isset($_POST['eMember_edit_country']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_gender'   ,isset($_POST['eMember_edit_gender']   )?"checked='checked'":'');

		$emember_config->setValue('eMember_reg_title_required'     ,isset($_POST['eMember_reg_title_required']     )?"checked='checked'":'');  
		$emember_config->setValue('eMember_reg_firstname_required' ,isset($_POST['eMember_reg_firstname_required'] )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_lastname_required'  ,isset($_POST['eMember_reg_lastname_required']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_company_required'   ,isset($_POST['eMember_reg_company_required']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_email_required'     ,isset($_POST['eMember_reg_email_required']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_phone_required'     ,isset($_POST['eMember_reg_phone_required']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_street_required'    ,isset($_POST['eMember_reg_street_required']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_city_required'      ,isset($_POST['eMember_reg_city_required']      )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_state_required'     ,isset($_POST['eMember_reg_state_required']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_zipcode_required'   ,isset($_POST['eMember_reg_zipcode_required']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_country_required'   ,isset($_POST['eMember_reg_country_required']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_reg_gender_required'    ,isset($_POST['eMember_reg_gender_required']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_title_required'    ,isset($_POST['eMember_edit_title_required']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_firstname_required',isset($_POST['eMember_edit_firstname_required'])?"checked='checked'":''); 
		$emember_config->setValue('eMember_edit_lastname_required' ,isset($_POST['eMember_edit_lastname_required'] )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_company_required'  ,isset($_POST['eMember_edit_company_required']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_email_required'    ,isset($_POST['eMember_edit_email_required']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_phone_required'    ,isset($_POST['eMember_edit_phone_required']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_street_required'   ,isset($_POST['eMember_edit_street_required']   )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_city_required'     ,isset($_POST['eMember_edit_city_required']     )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_state_required'    ,isset($_POST['eMember_edit_state_required']    )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_zipcode_required'  ,isset($_POST['eMember_edit_zipcode_required']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_country_required'  ,isset($_POST['eMember_edit_country_required']  )?"checked='checked'":'');
		$emember_config->setValue('eMember_edit_gender_required'   ,isset($_POST['eMember_edit_gender_required']   )?"checked='checked'":'');
		
		$tmpmsg1 = htmlentities(stripslashes($_POST['eMember_login_widget_message_for_logged_members']) , ENT_COMPAT);
		$emember_config->setValue('eMember_login_widget_message_for_logged_members',$tmpmsg1);		
		
		$emember_config->saveConfig();		
        echo '<div id="message" class="updated fade"><p>';                
        echo ($msg)? '<strong style="color:red;">'.$msg : '<strong>Options Updated!';        
        echo '</strong></p></div>';		
    }
    ?>
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
	    <input type="hidden" name="info_update" id="info_update" value="true" />   
	    <div class="wrap"><h3>WP eMembers - Pages/Forms Settings</h3>
			<div id="poststuff">
				<div id="post-body">    
				    <p>For detailed documentation, information and updates, please visit the    <a href="http://tipsandtricks-hq.com/wordpress-membership">WP eMember HomePage</a></p>     
					<!--  <div class="basic" style="float:left;"  id="list1a">-->
						<!--  <div class="title"><label for="title">General Settings</label></div> -->
                        <div class="postbox">	
                            <h3><label for="title">General Settings</label></h3> <!-- added -->
	                        <div class="inside">
	                    	    <table width="100%" border="0" cellspacing="0" cellpadding="6">
	                    	    	<tr valign="top">
	                    	    		<td width="25%" align="left"><strong>Login Page:</strong></td>
	                    	    		<td align="left">    
	                    	    			<input name="login_page_url" type="text" size="100" value="<?php echo $emember_config->getValue ('login_page_url'); ?>"/><br />
	                    	    			<i>This is the page where the members can go to log into the site. Create a page and put <strong>[wp_eMember_login_form:end]</strong> trigger text in the page that will display a form which will allow members to be able to log in. Enter the URL of this page in this field</i><br /><br />
	                    	    		</td>
	                    		    </tr>	
	                    		    <tr valign="top">
	                    		    	<td width="25%" align="left">
	                    		    		<strong>After Login Page:</strong>    
	                    		    	</td>
	                    		    	<td align="left">
	                    		    		<input name="after_login_page" type="text" size="100" value="<?php echo $emember_config->getValue('after_login_page'); ?>"/><br />
	                    		    		<i>Members will be redirected to this page after a successful login. This option is only used if you have not specified a redirection page in the membership level configuration for a particular membership level</i><br /><br />
	                    		    	</td>
	                    		    </tr>
	                    		    <tr valign="top">
	                    		    	<td width="25%" align="left">
	                    		    		<strong>After Logout Page:</strong>    
	                    		    	</td>
	                    		    	<td align="left">
	                    		    		<input name="after_logout_page" type="text" size="100" value="<?php echo $emember_config->getValue('after_logout_page'); ?>"/><br />
	                    		    		<i>Members will be redirected to this page after logout.</i><br /><br />
	                    		    	</td>
	                    		    </tr>
	                    		    
	                    		    <tr valign="top">
	                    		    	<td width="25%" align="left">
	                    		    		<strong>Registration Page:</strong>    
	                    		    	</td>
	                    		    	<td align="left">
	                    		    		<input name="eMember_registration_page" type="text" size="100" value="<?php echo $emember_config->getValue('eMember_registration_page'); ?>"/><br />
	                    		    		<i>Where members can register for a membership account. Create a page and put <strong>[wp_eMember_registration_form:end]</strong> trigger text in the page that will display a form which will allow members to be able to register. Enter the URL of this page in this field.</i><br /><br />
	                    		    	</td>
	                    		    </tr>
	                    		    <tr valign="top">
	                    		    	<td width="25%" align="left">
	                    		    		<strong>Membership Payment/Join Page:</strong>    
	                    		    	</td>
	                    		    	<td align="left">
	                    		    		<input name="eMember_payments_page" type="text" size="100" value="<?php echo $emember_config->getValue('eMember_payments_page'); ?>"/><br />
	                    		    		<i>The URL of the page where you have a list of all types of membership that you offer (eg. Free, Silver, Gold) and the necessary buttons that the visitors can use to purchase a membership. For the free membership signup (if you want to allow free membership) simply point them to the Registration page.</i><br /><br />
	                    			    </td>
	                    			</tr>
	                    		    <tr valign="top">
	                    		    	<td width="25%" align="left">
	                    		    		<strong>Member Profile Edit Page:</strong>    
	                    		    	</td>
	                    		    	<td align="left">
	                    		    		<input name="eMember_profile_edit_page" type="text" size="100" value="<?php echo $emember_config->getValue('eMember_profile_edit_page'); ?>"/><br />
	                    		    		<i>The URL of the page where members can edit their profile (eg. their email address). To allow the members to be able to change their profile simply create a page and put <strong>[wp_eMember_profile_edit_form:end]</strong> trigger text in the page that will display a form which will allow members to update their profile. Enter the URL of this page in this settings field</i><br /><br />
	                    			    </td>
	                    			</tr>
	                    		    <tr valign="top">
	                    		    	<td width="25%" align="left">
	                    		    		<strong>Support Page:</strong>    
	                    		    	</td>
	                    		    	<td align="left">
	                    		    		<input name="eMember_support_page" type="text" size="100" value="<?php echo $emember_config->getValue('eMember_support_page'); ?>"/><br />
	                    		    		<i>URL of the Support/Member help page if you have any. Leave empty if does not apply.</i><br /><br />
	                    		    	</td>
	                    		    </tr>
	                    		    	    
	                    	    </table>  
	                    	</div>
	                    </div>
					                   	    					
						<!-- <div class="title"><label for="title">Registration Form Fields</label></div> -->
                       <div class="postbox">    
                       <h3><label for="title">Registration Form Fields</label></h3>	<!-- added -->
                   	    <div class="inside">    
                   	    <strong><i>Fields to be shown on the Registation form (Username, Password and Email address are mandatory fields and will always be present on the form).</i></strong><br /><br />
                   		    <table width="100%" border="0" cellspacing="0" cellpadding="6">    
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Title:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_title" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_title');?> value="1"/>
                   		    			<input name="eMember_reg_title_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_title_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Title field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>First name:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_firstname" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_firstname');?> value="1"/>
                   		    			<input name="eMember_reg_firstname_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_firstname_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable first name field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Last name:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_lastname" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_lastname');?> value="1"/>
                   		    			<input name="eMember_reg_lastname_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_lastname_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable last name field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Phone:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_phone" type="checkbox"  <?php $eMember_reg_phone = $emember_config->getValue('eMember_reg_phone');echo ($eMember_reg_phone)?'checked="checked"':''?> value="1"/>
                   		    			<input name="eMember_reg_phone_required" type="checkbox"  <?php $eMember_reg_phone = $emember_config->getValue('eMember_reg_phone_required');echo ($eMember_reg_phone)?'checked="checked"':''?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Phone field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   				
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Company:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_company" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_company');?> value="1"/>
                   		    			<input name="eMember_reg_company_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_company_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Company field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   <!--		    	<tr valign="top">-->
                   <!--		    		<td width="25%" align="left">-->
                   <!--		    			<strong>Email:</strong>    -->
                   <!--		    		</td>-->
                   <!--		    		<td align="left">-->
                   <!--		    			<input name="eMember_reg_email" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_email');?> value="1"/><br />-->
                   <!--		    			<i>Enable/disable Email field on registration page.</i><br /><br />-->
                   <!--				    </td>-->
                   <!--				</tr>        -->
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Address Street:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_street" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_street');?> value="1"/>
                   		    			<input name="eMember_reg_street_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_street_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Address Street field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Address City:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_city" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_city');?> value="1"/>
                   		    			<input name="eMember_reg_city_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_city_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Address City field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Address State:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_state" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_state');?> value="1"/>
                   		    			<input name="eMember_reg_state_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_state_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Address State field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Address Zipcode:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_zipcode" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_zipcode');?> value="1"/>
                   		    			<input name="eMember_reg_zipcode_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_zipcode_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Address Zipcode field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Country:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_country" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_country');?> value="1"/>
                   		    			<input name="eMember_reg_country_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_country_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Country field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        
                   		    	<tr valign="top">
                   		    		<td width="25%" align="left">
                   		    			<strong>Gender:</strong>    
                   		    		</td>
                   		    		<td align="left">
                   		    			<input name="eMember_reg_gender" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_gender');?> value="1"/>
                   		    			<input name="eMember_reg_gender_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_reg_gender_required');?> value="1"/> Required?
                   		    			<br />
                   		    			<i>Enable/disable Gender field on registration page.</i><br /><br />
                   				    </td>
                   				</tr>        				        
                   		    </table>
                   	    </div>
                       </div>						
                       <!-- <div class="title"><label for="title">Edit Profile Form Fields</label></div> -->					
						    <div class="postbox">
						    <h3><label for="title">Edit Profile Form Fields</label></h3> <!-- added -->    	
	    <div class="inside">    
	    <strong><i>Fields to be shown on the Edit profile form (Username, Password and Email address are mandatory fields and will always be present on the form).</i></strong><br /><br />
		    <table width="100%" border="0" cellspacing="0" cellpadding="6">    
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Title:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_title" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_title');?> value="1"/>
		    			<input name="eMember_edit_title_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_title_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Title field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>First name:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_firstname" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_firstname');?> value="1"/>
		    			<input name="eMember_edit_firstname_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_firstname_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable first name field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Last name:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_lastname" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_lastname');?> value="1"/>
		    			<input name="eMember_edit_lastname_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_lastname_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable last name field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Company:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_company" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_company');?> value="1"/>
		    			<input name="eMember_edit_company_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_company_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Company field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Email:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_email" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_email');?> value="1"/>
		    			<input name="eMember_edit_email_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_email_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Email field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Phone:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_phone" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_phone');?> value="1"/>
		    			<input name="eMember_edit_phone_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_phone_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Phone field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Address Street:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_street" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_street');?> value="1"/>
		    			<input name="eMember_edit_street_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_street_required');?> value="1"/>Required?
		    			<br />
		    			<i>Enable/disable Address Street field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Address City:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_city" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_city');?> value="1"/>
		    			<input name="eMember_edit_city_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_city_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Address City field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Address State:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_state" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_state');?> value="1"/>
		    			<input name="eMember_edit_state_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_state_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Address State field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Address Zipcode:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_zipcode" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_zipcode');?> value="1"/>
		    			<input name="eMember_edit_zipcode_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_zipcode_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Address Zipcode field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Country:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_country" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_country');?> value="1"/>
		    			<input name="eMember_edit_country_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_country_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Country field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        
		    	<tr valign="top">
		    		<td width="25%" align="left">
		    			<strong>Gender:</strong>    
		    		</td>
		    		<td align="left">
		    			<input name="eMember_edit_gender" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_gender');?> value="1"/>
		    			<input name="eMember_edit_gender_required" type="checkbox"  <?php echo $emember_config->getValue('eMember_edit_gender_required');?> value="1"/> Required?
		    			<br />
		    			<i>Enable/disable Gender field on Edit Profile page.</i><br /><br />
				    </td>
				</tr>        				        
		    </table>
	    </div>	    
    </div>
    
    <div class="postbox">    
    <h3><label for="title">Login Widget Message</label></h3>
    <div class="inside">   
        <table width="100%" border="0" cellspacing="0" cellpadding="6">
                        
             <tr valign="top">
	             <td width="25%" align="left"><strong>Additional Message for Logged in Members:</strong></td>
	             <td align="left">    
	             <textarea name="eMember_login_widget_message_for_logged_members" cols="70" rows="5"><?php echo $emember_config->getValue ('eMember_login_widget_message_for_logged_members'); ?></textarea><br />             
	             <i>This message will be added to the default login widget content that is displayed to the members who are logged in. You can use HTML code in this field.</i><br /><br />
	             </td>
             </tr>	
                    	    
        </table>                   	   
     </div></div>
                   	   
	 <div class="submit">
	 <input type="submit"  name="info_update" value="<?php _e('Update options'); ?> &raquo;" />
	 </div>    						
	<!-- </div> -->
				</div>
			</div>
		</div>		
    </form> 
	<script type="text/javascript">
//	   ;(function($){
//			$(document).ready(function(){
//				$('#list1a').accordion({autoHeight:false});	
//				$('#list1a a').click(function(e){ e.stopPropagation(); });			
//		    });		   
//	    })(jQuery);
	</script>    
    <?php	
}
?>