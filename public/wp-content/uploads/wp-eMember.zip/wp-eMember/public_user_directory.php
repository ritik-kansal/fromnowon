<?php
function print_eMember_public_user_list()
{	global $emember_config;
	$p  = $emember_config->getValue('eMember_enable_public_profile');
	if(!$p) return 'Public profile Listing is disabled';
	ob_start();
	echo '<br/><br/><br/><div id="Pagination" class="pagination"></div>';	
    echo '<form action="javascript:void(0);" id="emember_user_search"><p >
	<input type="text" value="" name="e" title="Email" id="post-search-email"/>
	<select id="post_search_operator">
	<option value="and"> And </option>
	<option value="or"> Or </option>
	</select>
	<input type="text" value="" name="u" title="User" id="post-search-user"/>
	<input type="submit"  value="Search"/>
	</p></form>'; 	    
	echo '<table id="member_list" class="widefat"><thead><tr>
	<th scope="col">'.__('User Name', 'wp_eMember').'</th>
	<th scope="col">'.__('First Name', 'wp_eMember').'</th>
	<th scope="col">'.__('Last Name', 'wp_eMember').'</th>
	<th scope="col">'.__('Email', 'wp_eMember').'</th>
	</tr></thead>
	<tbody>';
   $member_table = WP_EMEMBER_MEMBERS_TABLE_NAME;
   $membership_table = WP_EMEMBER_MEMBERSHIP_LEVEL_TABLE;
   $table_name = " $member_table LEFT JOIN $membership_table ON ".
                 " ($member_table.membership_level = $membership_table.id)";

   global $wpdb;
   $emember_user_count = $wpdb->get_row("SELECT COUNT(*) as count FROM" . $table_name . ' ORDER BY member_id');

	echo '</tbody></table>';
	echo '<center><div style="display:none;" id="emember_profile_container"><a href=# id="emember_close_ui" style="position:absolute; top:0px; right:0px;"> Close</a>
	      <div id="emember_profile_details"></div>
	</div></center>';
   ?>
   <script type="text/javascript">
   function drawContent(count, params){
       var counter = 0;       
       var itms_per_pg = parseInt(<?php $items_per_page = $emember_config->getValue('eMember_rows_per_page');
       $items_per_page = trim($items_per_page);
       echo (!empty($items_per_page)&& is_numeric($items_per_page))? $items_per_page:30;?>);         
       var $tbody = jQuery('#member_list tbody');              
       jQuery("#Pagination").pagination(count, {
          callback: function(i,container){
             $tbody.html('Loading...........');
            if(params)
            	paramss = { event: "emember_public_user_list_ajax",start:i*itms_per_pg,limit:itms_per_pg,u:params.u, e:params.e,o:params.o};
            else
            	paramss = { event: "emember_public_user_list_ajax",start:i*itms_per_pg,limit:itms_per_pg};
            var maxIndex = Math.min((i+1)*itms_per_pg, count);
            var target_url = '<?php bloginfo('wpurl'); ?>';
            jQuery.get(target_url + "/wp-admin/admin-ajax.php",
                paramss,
                  function(data){
 	                  $tbody.html('');
 	                  if(data.length<1) {$tbody.html('No member found.');return;}    	                  
 	                  for( var k in data){
 		                  if(jQuery.isFunction(data[k])) continue;
                        var cls = (counter%2)? 'class="alternate"' : '';
                        var $tr2    = jQuery('<tr valign="top" '+cls+' />').appendTo($tbody);
                        
                        jQuery('<td />').
                        append(jQuery("<a href=# uid="+data[k]["member_id"]+" />").html(data[k]["user_name"]).click(
                           function(e)
                           {
                               jQuery('#emember_profile_details').html('').css("padding-top",'20px').
                               append(jQuery('<span />').css('font-size', 'x-large').html('Loading...'));
                               jQuery.blockUI({
                                   		message: jQuery('#emember_profile_container'),
                                   		css:{
                              		        left: '20%',
                              		        top:  '20px',
                              				height: '90%',
                              				width: '50%',
                                  		    border: '8px solid #ECECEC' 
                              		    }
                                   });
                               jQuery('#emember_close_ui').click(function(){jQuery.unblockUI()});
                        	   jQuery.get(target_url + "/wp-admin/admin-ajax.php",{
                            	   event: 'emember_public_user_profile_ajax',
                            	   id: jQuery(e.target).attr('uid')
                        	   },
                        	   function(data)
                        	   {
                            	   if(data.status) jQuery('#emember_profile_details').css('color',"").html(data.content);
                            	   else jQuery('#emember_profile_details').css('color', "red").html(data.content);
                                	                                                                 	   
                               },
                               'json'
                               );
                        	   
                           }           
                        )).
                        appendTo($tr2);                        
                        for (l in data[k]){
                               if(l=="member_id") continue;
                               if(l=="user_name") continue;                              
                              jQuery('<td />').
                                 html(data[k][l]).
                                 appendTo($tr2);
                        }
                        
                        counter++;
                     }                     
                  },
                  'json'
              );            
          },
          num_edge_entries: 2,
          num_display_entries: 10,
          items_per_page: itms_per_pg
       });          	   
   }	      
   
      jQuery(document).ready(function(){
    	  jQuery('input[title!=""]').hint();
          var count = <?php echo $emember_user_count->count; ?>; 
          drawContent(count); 
          jQuery('#emember_user_search').submit(function(e){              
	            e.prevenDefault;
	            var user  = jQuery('#post-search-user').val();
	            var email = jQuery('#post-search-email').val(); 
	            var op    = jQuery('#post_search_operator').val();
	            var q     = "u="+ user+ "&e="+email + "&o="+op;
	            if(user !="" ||email !="")
	            {
	            	var target_url = '<?php bloginfo('wpurl'); ?>';
	                jQuery.get(target_url + "/wp-admin/admin-ajax.php",
                        {  event: "emember_user_count_ajax",u:user, e:email,o:op},
                           function(data){  
                              drawContent(data.count, {u:user, e:email,o:op});                      	
                           },
                           'json'
                        );                
	            }
	          	return false;    
          });  	  
      });
   </script>
   <?php	
   $content = ob_get_contents();
   ob_end_clean();
   return $content;
}
?>