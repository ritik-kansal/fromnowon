You can store your downloadable file here or create sub-directories and put your files inside it.

Please note that you don't have to store your downloadable files here for it to work... you can store it anywhere on the web.

This directory is .htaccess password protected so no one can browse to this directory. 

This URL has more info on this topic:
http://www.tipsandtricks-hq.com/forum/topic/download-directory-protection