<?php
if(!isset($_SESSION)) 
{
	session_start();
}

include_once('../../../wp-load.php');
include_once('eStore_handle_subsc_ipn.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('email.php');

$custom_data="";

function handle_payment_data($raw_data,$gateway)
{	    	
	eStore_payment_debug("Handling payment data from: ".$gateway,true);
	if($gateway == "2co")
	{
		$mc_currency = $raw_data['list_currency'];
		$uniqueOrderId = $raw_data['item_id_1'];
		$cart_items = eStore_retrieve_order_details_from_db($uniqueOrderId, $gateway, $mc_currency);				
	    $payment_data = extract_2co_general_payment_data($raw_data,$gateway);	    

	    	    
	    if ($payment_data['txn_type'] == "ORDER_CREATED")
	    {
	    	eStore_payment_debug("Order Received... verifying payment data.",true);	
		    $product_verified = process_payment_data($payment_data,$cart_items);
		    if ($product_verified)
		    {
	            record_sales_data($payment_data,$cart_items);
	    	    award_affiliate_commission($payment_data,$cart_items);  
	    	    eStore_handle_auto_affiliate_account_creation($payment_data);  
	        }       	
	    }
	
	    //Log the payment and cart data to the debug file    
	    foreach ($payment_data as $key=>$value)
	    {
	        $text .= "$key=$value, ";
	    }
		foreach ($cart_items as $key=>$value)
	    {
	        $text .= "$key=$value, ";
	    }	    
	    eStore_payment_debug($text,true,true);
	}
	else if($gateway == "authorize")
	{
		$cart_items = eStore_retrieve_order_details_from_db($raw_data['x_cust_id'], $gateway);
		$payment_data = extract_authorize_general_payment_data($raw_data,$gateway);		
		
		//print_r($cart_items);
		if(!empty($cart_items))
		{
			$product_verified = process_payment_data($payment_data,$cart_items);
			if ($product_verified)
			{
		        record_sales_data($payment_data,$cart_items);
		        award_affiliate_commission($payment_data,$cart_items);  
		        eStore_handle_auto_affiliate_account_creation($payment_data);  
		    }  
		}
		else
		{
			eStore_payment_debug("Cart items empty! Could not retrieve items from the database.",false);
		}    	
	    //Log the payment data to the debug file    	    		
	    foreach ($payment_data as $key=>$value)
	    {
	        $text .= "$key=$value, ";
	    }
		foreach ($cart_items as $key=>$value)
	    {
	        $text .= "$key=$value, ";
	    }	    
	    eStore_payment_debug($text,true,true);
	    
	    //The pending payment data can be deleted at this stage	    	
	}
    //file_put_contents('2co_process.txt', $text);
    
	reset_eStore_cart();
    $return = get_option('cart_return_from_paypal_url');
    $redirection_parameter = 'Location: '.$return;
    header($redirection_parameter);
    exit;    
}

function eStore_retrieve_order_details_from_db($uniqueOrderId, $gateway, $mc_currency='USD')
{		
	eStore_payment_debug("Retrieving order details... Key: ".$uniqueOrderId." Gateway: ".$gateway,true);
	global $wpdb,$custom_data;
	$cart_items = array();
		
	$pending_payment_table_name = WP_ESTORE_PENDING_PAYMENT_TABLE_NAME;
	$wp_eStore_db = $wpdb->get_results("SELECT * FROM $pending_payment_table_name WHERE customer_id = '$uniqueOrderId'", OBJECT);
	if ($wp_eStore_db)
	{		
		foreach ($wp_eStore_db as $wp_eStore_db)
		{
			$item_number = $wp_eStore_db->item_number;
			$item_name = $wp_eStore_db->name;
			$quantity = $wp_eStore_db->quantity;
			$mc_gross = $wp_eStore_db->price*$quantity;
			$mc_shipping = $wp_eStore_db->shipping;
			$custom = $wp_eStore_db->custom;			
			
			$current_item = array(
	          					   'item_number' => $item_number,
								   'item_name' => $item_name,
								   'quantity' => $quantity,
								   'mc_gross' => $mc_gross,
								   'mc_shipping' => $mc_shipping,
								   'mc_currency' => $mc_currency,
								   'custom' => $custom,
								  );
	
			array_push($cart_items, $current_item);	
			$ret_item_details = $item_number."|".$item_name."|".$quantity."|".$mc_gross."|".$mc_shipping."|".$custom;	
			eStore_payment_debug("Retrieved Item Details: ".$ret_item_details,true);
		}
	}	
	$custom_data = $cart_items[0]['custom'];
    return $cart_items;	
}

function extract_authorize_general_payment_data($raw_data,$gateway)
{    	
global $custom_data;	
$customvariables = get_custom_var($custom_data);
$eMember_id = $customvariables['eMember_id'];
$coupon = $customvariables['coupon'];

$gross_total = $raw_data['x_amount'];
$address = $raw_data['x_ship_to_address'].", ".$raw_data['x_ship_to_city'].", ".$raw_data['x_ship_to_state']." ".$raw_data['x_ship_to_zip'].", ".$raw_data['x_ship_to_country'];

$payment_data = array(
'gateway' => $gateway,
'custom' => $custom_data,
'txn_id' => $raw_data['x_trans_id'],
'txn_type' => $raw_data['x_type'],
'transaction_subject' => $raw_data['x_response_reason_text'],
'first_name' => $raw_data['x_first_name'],
'last_name' => $raw_data['x_last_name'],
'payer_email' => $raw_data['x_email'],
'num_cart_items' => $raw_data['item_count'],
'subscr_id' => $raw_data['x_cust_id'],
'address' => $address,
'phone' => $raw_data['x_phone'],
'coupon_used' => $coupon,
'eMember_username' => $eMember_id,
'mc_gross' => $gross_total,
                     );
return $payment_data;
}

function extract_2co_general_payment_data($raw_data,$gateway)
{
global $custom_data;	
$customvariables = get_custom_var($custom_data);
$eMember_id = $customvariables['eMember_id'];
$coupon = $customvariables['coupon'];

$gross_total = $raw_data['invoice_list_amount'];
$address = $raw_data['bill_street_address']." ".$raw_data['bill_street_address2'].", ".$raw_data['bill_city'].", ".$raw_data['bill_state']." ".$raw_data['bill_postal_code'].", ".$raw_data['bill_country'];	
//item_type_# = bill or refund
$payment_data = array(
'gateway' => $gateway,
'custom' => $raw_data['custom'],
'txn_id' => $raw_data['invoice_id'],
'txn_type' => $raw_data['message_type'],
'transaction_subject' => $raw_data['message_description'],
'first_name' => $raw_data['customer_first_name'],
'last_name' => $raw_data['customer_last_name'],
'payer_email' => $raw_data['customer_email'],
'num_cart_items' => $raw_data['item_count'],
'subscr_id' => $raw_data['invoice_id'],
'address' => $address,
'phone' => $raw_data['customer_phone'],
'coupon_used' => $coupon,
'eMember_username' => $eMember_id,
'mc_gross' => $gross_total,
                     );
return $payment_data;
}

function process_payment_data($payment_data,$cart_items)
{
    global $wpdb;
    $products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;

    $script_location = get_option('eStore_download_script');
	$random_key = get_option('eStore_random_code');
	$payment_currency = get_option('cart_payment_currency');

    $customvariables = get_custom_var($payment_data['custom']);

    $product_specific_instructions = "";
    $currency_symbol = get_option('cart_currency_symbol');
    
    $product_id_array = Array();
	$product_name_array = Array();
	$product_price_array = Array();
	$product_qty_array = Array();
	$download_link_array = Array();
    $counter = 0;
	foreach ($cart_items as $current_cart_item)
	{
			$cart_item_data_num = $current_cart_item['item_number'];
			$cart_item_data_name = $current_cart_item['item_name'];
			$cart_item_data_quantity = $current_cart_item['quantity'];
			$cart_item_data_total = $current_cart_item['mc_gross'];
			$cart_item_data_currency = $current_cart_item['mc_currency'];

			eStore_payment_debug('Item Number: '.$cart_item_data_num,true);
			eStore_payment_debug('Item Name: '.$cart_item_data_name,true);
			eStore_payment_debug('Item Quantity: '.$cart_item_data_quantity,true);
			eStore_payment_debug('Item Total: '.$cart_item_data_total,true);
			eStore_payment_debug('Item Currency: '.$cart_item_data_currency,true);
		
		if ($cart_item_data_num != "SHIPPING")
		{
			// Compare the values with the values stored in the database
			$key=$cart_item_data_num;

			$retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$key'", OBJECT);
            if(!$retrieved_product)
            {
                eStore_payment_debug('No Item found for the Item ID: '.$cart_item_data_num,false);
                return false;
            }
			$coupon_code = $customvariables['coupon'];
			if(!empty($coupon_code))
			{
                eStore_payment_debug('Coupon Code Used : '.$coupon_code,true);
                $coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
                $ret_coupon = $wpdb->get_row("SELECT * FROM $coupon_table_name WHERE coupon_code = '$coupon_code'", OBJECT);
                if ($ret_coupon)
                {
                    $discount_amount = $ret_coupon->discount_value;
                    $discount_type = $ret_coupon->discount_type;
                    if ($discount_type == 0)
                    {
                        //apply % discount
                        $discount = ($retrieved_product->price*$discount_amount)/100;
                        $true_product_price = $retrieved_product->price - $discount;
                    }
                    else
                    {
                        // apply value discount
                        $true_product_price = $retrieved_product->price - $$discount_amount;
                    }
                }
            }
            else
            {
                $true_product_price = $retrieved_product->price*$cart_item_data_quantity;
            }
			if ($cart_item_data_total < $true_product_price)
			{
		    	eStore_payment_debug('Wrong Product Price Detected. Actual Product Price : '.$true_product_price,false);
		    	eStore_payment_debug('Paid Product Price : '.$cart_item_data_total,false);
         		return false;
			}
			
			if ($payment_currency != $cart_item_data_currency)
			{
		    	eStore_payment_debug('Invalid Product Currency. Expected currency: '.$payment_currency.', Received Currency: '.$cart_item_data_currency,false);
         		return false;
			}

		    //*** Handle Membership Payment ***	
		    eStore_payment_debug('Checking if membership inegration is being used.',true);	    
		    $member_ref = $retrieved_product->ref_text;
		    if (!empty($member_ref))
		    {		    	  	
			    if (get_option('eStore_enable_wishlist_int'))
			    {
                    eStore_payment_debug('WishList integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
			        wl_handle_subsc_signup($payment_data,$member_ref,$payment_data['txn_id']);
                }
                else
                {
    		         if (function_exists('wp_eMember_install'))
    		         {
    		         	  $eMember_id = $customvariables['eMember_id'];
                          eStore_payment_debug('eMember integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
    		              eMember_handle_subsc_signup($payment_data,$member_ref,$payment_data['txn_id'],$eMember_id);
                     }
                }	    	
		    }
		    //== End of Membership payment handling ==		    			
			
		    $item_name = $retrieved_product->name;
            $download_link = generate_download_link($retrieved_product,$item_name,$payment_data);
		    eStore_payment_debug('Download Link : '.$download_link,true);
		    
			if(!empty($retrieved_product->item_spec_instruction))
            {
            	$product_specific_instructions .= "\n".$retrieved_product->item_spec_instruction;
            }            

			if($retrieved_product->create_license == 1)
		    {
		    	$license_key = eStore_generate_license_key($payment_data);
		    	$product_license_data .= "\n".$cart_item_data_name." License Key: ".$license_key;
		    	eStore_payment_debug('Lice Key :'.$license_key,true);
		    }		    

            array_push($product_name_array, $cart_item_data_name);
            array_push($product_id_array, $cart_item_data_num);
            array_push($product_price_array, $retrieved_product->price);
            array_push($product_qty_array, $cart_item_data_quantity);
            array_push($download_link_array, $download_link);
		}            
        $counter++;
    }

		// How long the download link remain valid (hours)
		$download_url_life = get_option('eStore_download_url_life');
		// Emails
		$notify_email = get_option('eStore_notify_email_address');  // Email which will recive notification of sale (sellers email)
		$download_email = get_option('eStore_download_email_address'); // Email from which the mail wil be sent

		// Success Email Messages (Buyer will receive this email)
		$email_subject = get_option('eStore_buyer_email_subj');
		$email_body = get_option('eStore_buyer_email_body');

		// Notification Email Message (Seller will receive this eamil)
		$notify_subject = get_option('eStore_seller_email_subj');
		$notify_body =  get_option('eStore_seller_email_body');

		// Send the product
        for ($i=0; $i < sizeof($product_name_array); $i++)
        {
            $constructed_products_name .= $product_name_array[$i];
            $constructed_products_name .= ", ";

            $constructed_products_price .= $product_price_array[$i];
            $constructed_products_price .= ", ";

            $constructed_products_id .= $product_id_array[$i];
            $constructed_products_id .= ", ";
            
            $constructed_products_details .= "\n".$product_name_array[$i]." x ".$product_qty_array[$i]." - ".$currency_symbol.$product_price_array[$i]." (".$payment_currency.")";

            $constructed_download_link .= "\n";
            if (is_array($download_link_array[$i]))
            {
            	$package_downloads = $download_link_array[$i];
            	for ($j=0; $j < sizeof($package_downloads); $j++)
            	{
            		$constructed_download_link .= $package_downloads[$j];
            		$constructed_download_link .= "\n";
            	}
            }
            else
            {
            	$constructed_download_link .= $download_link_array[$i];
            }
        }

        $purchase_date = (date ("Y-m-d"));
        //$total_purchase_amt = $payment_data['mc_gross'];
        $txn_id = $payment_data['txn_id'];        
        $buyer_shipping_info = $payment_data['address'];
        
		$tags = array("{first_name}","{last_name}","{payer_email}","{product_name}","{product_link}","{product_price}","{product_id}","{download_life}","{product_specific_instructions}","{product_details}","{shipping_info}","{license_data}","{purchase_date}","{purchase_amt}","{transaction_id}");
		$vals = array($payment_data['first_name'],$payment_data['last_name'],$payment_data['payer_email'],$constructed_products_name,$constructed_download_link,$constructed_products_price,$constructed_products_id,$download_url_life,$product_specific_instructions,$constructed_products_details,$buyer_shipping_info,$product_license_data,$purchase_date,$payment_data['mc_gross'],$txn_id);

		//$subject = str_replace($tags,$vals,$email_subject);
		$subject = $email_subject;
		$body    = str_replace($tags,$vals,$email_body);
		$headers = 'From: '.$download_email . "\r\n";
        $attachment = '';
        
        eStore_payment_debug('Sending product email to : '.$payment_data["payer_email"],true);
        if (get_option('eStore_use_wp_mail'))
        {
            wp_mail($payment_data['payer_email'], $subject, $body, $headers);
            eStore_payment_debug('Product Email successfully sent to '.$payment_data['payer_email'].'.',true);
        }
        else
        {
        	if(@eStore_send_mail($payment_data['payer_email'],$body,$subject,$download_email,$attachment))
        	{
        	   	eStore_payment_debug('Product Email successfully sent to '.$payment_data['payer_email'].'.',true);
        	}
        	else
        	{
                eStore_payment_debug('Error sending product Email to '.$payment_data['payer_email'].'.',false);
        	}
        }

	    // Notify seller
        foreach ($payment_data as $key=>$value)
        {
            $post_string .= "$key=$value, ";
        }
		$n_subject = $notify_subject;
		$n_body    = str_replace($tags,$vals,$notify_body).
	                  "\n\n-------User Email----------\n".
	                  $body.
	                  "\n\n-------Payment Parameters---\n".
	                  $post_string;
        if (get_option('eStore_use_wp_mail'))
        {
            wp_mail($notify_email, $n_subject, $n_body);
            eStore_payment_debug('Notify Email successfully sent to '.$notify_email.'.',true);
        }
        else
        {
    	    if(@eStore_send_mail($notify_email,$n_body,$n_subject,$download_email))
    	    {
         	    eStore_payment_debug('Notify Email successfully sent to '.$notify_email.'.',true);
            }
            else
    	    {
    	        eStore_payment_debug('Error sending notify Email to '.$notify_email.'.',false);
    	    }
        }
        return true;
}

function award_affiliate_commission($payment_data,$cart_items)
{
        eStore_payment_debug('Updating Affiliate Database Table with Sales Data if Using the WP Affiliate Platform Plugin.',true);
        //global $sale_referrer;
        if (function_exists('wp_aff_platform_install'))
        {
        	eStore_payment_debug('WP Affiliate Platform is installed, registering sale...',true);
        	$customvariables = get_custom_var($payment_data['custom']);
        	
        	if ($payment_data['gateway'] == "authorize" || $payment_data['gateway'] == "2co")
        	{
        		$customvariables = get_custom_var($cart_items[0]['custom']);
        		$referrer = $customvariables['ap_id'];
        		//$referrer = $cart_items[0]['custom'];
        	}
        	else
        	{
        		$referrer = $customvariables['ap_id'];
        	}
            
			$sale_amount = $payment_data['mc_gross'];
			if (!empty($referrer))
			{
				global $wpdb;
				$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
				$affiliates_table_name = WP_AFFILIATE_TABLE_NAME;
				$aff_sales_table = WP_AFFILIATE_SALES_TABLE_NAME;
				$wp_aff_affiliates_db = $wpdb->get_row("SELECT * FROM $affiliates_table_name WHERE refid = '$referrer'", OBJECT);
				$commission_level = $wp_aff_affiliates_db->commissionlevel;
		
		        $counter = 1;
		        $cart_item_number = '';
		        foreach ($cart_items as $current_cart_item)
		        {
       			    $cart_item_number = $current_cart_item['item_number'];
       			    $product_price = $current_cart_item['mc_gross'];// - $payment_data['mc_shipping'.$counter];
       			    eStore_payment_debug('Price of the currently processing item : '.$product_price,true);
                    $retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$cart_item_number'", OBJECT);
                    if (!empty($retrieved_product->commission))
                    {
                        $product_comm_amount = ($product_price*$retrieved_product->commission)/100;
                    }
                    else
                    {
                        $product_comm_amount = ($product_price*$commission_level)/100;
                    }
                    $commission_amount = $commission_amount + $product_comm_amount;
                    $counter++;
                }
                $commission_amount = round($commission_amount,2);
                $clientdate = (date ("Y-m-d"));
                $clienttime	= (date ("H:i:s"));
                $buyer_email = $payment_data['payer_email'];
                $txn_id = $payment_data['txn_id'];
                $item_id = $cart_item_number;
                $aff_version = get_option('wp_aff_platform_version');

                if($aff_version>=4.4)
            	{
            		$c_id = '';
            		$updatedb = "INSERT INTO $aff_sales_table (refid,date,time,browser,ipaddress,payment,sale_amount,txn_id,item_id,buyer_email,campaign_id) VALUES ('$referrer','$clientdate','$clienttime','','','$commission_amount','$sale_amount','$txn_id','$item_id','$buyer_email','$c_id')";
            	}
            	else if($aff_version>=1.1)
                {
                	$updatedb = "INSERT INTO $aff_sales_table (refid,date,time,browser,ipaddress,payment,sale_amount,txn_id,item_id,buyer_email) VALUES ('$referrer','$clientdate','$clienttime','','','$commission_amount','$sale_amount','$txn_id','$item_id','$buyer_email')";
                }
                else
                {
					$updatedb = "INSERT INTO $aff_sales_table (refid,date,time,browser,ipaddress,payment,sale_amount) VALUES ('$referrer','$clientdate','$clienttime','','','$commission_amount','$sale_amount')";
                }
				$results = $wpdb->query($updatedb);							
				$message = 'The sale has been registered in the WP Affiliates Platform Database for referrer: '.$referrer.' with amount: '.$commission_amount;
				eStore_payment_debug($message,true);				
			}
		    else
		    {
		    	eStore_payment_debug('No Referrer Found. This is not an affiliate sale',true);
		    }			
        }
		else
		{
			eStore_payment_debug('Not Using the WP Affiliate Platform Plugin.',true);
		}
}
?>