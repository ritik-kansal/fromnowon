<?php
include_once ('lib/gateway/Paypal.php');
include_once ('lib/gateway/TwoCo.php');
include_once ('lib/gateway/Authorize.php');
include_once ('../../../wp-load.php');

$defaultCurrency = get_option('cart_payment_currency');
$defaultSymbol = get_option('cart_currency_symbol');
$defaultEmail = get_option('cart_paypal_email');
$return = get_option('cart_return_from_paypal_url');
$sandbox_enabled = get_option('eStore_cart_enable_sandbox');

if(isset($_COOKIE['eStore_submit_payment'])){
	if($_COOKIE['eStore_submit_payment'] != "true"){
		exit;
	}		
}

if($_SESSION['eStore_cart_sub_total'] <= 0)
{
	if(get_option('eStore_use_manual_gateway_for_zero_dollar_co') == 1){
		$_POST['eStore_gateway'] = 'manual';
	}
}

if(get_option('eStore_eMember_must_be_logged_to_checkout') == 1)
{	
    if (function_exists('wp_eMember_install'))
    {  
	    global $auth;
	    $user_id = $auth->getUserInfo('member_id');
	    if (empty($user_id))//User is not logged in
	    {
	    	$redirection_url = get_option('eStore_eMember_redirection_url_when_not_logged');
	    	if(empty($redirection_url))
	    	{
	    		echo "Error Detected! If you want to use the 'Only Allow Logged In Members to Checkout' feature then you must specify a value in the 'Redirection URL for Anonymous Checkout' field also.";
	    		exit;
	    	}
			header('Location: ' . $redirection_url);
			exit;
	    }
    }
    else
    {
    	echo "Error! You don't have the WP eMember plugin installed! You can only use the 'Only Allow Logged In Members to Checkout' feature with the WP eMember plugin.";
    	exit;
    }	
}

eStore_show_redirection_message();

if(isset($_POST['eStore_gateway']))
{
    switch ($_POST['eStore_gateway']) {
        case 'paypal':        	
            submit_to_paypal();
            break;
        case 'manual':
        	submit_to_manual();
            break;
        case '2co':
            submit_to_2co();
            break;
        case 'authorize':
            submit_to_authorize();
            break;     
		default:
            submit_to_paypal();			
			break;                   
    }
}
else if(isset($_COOKIE['eStore_gateway']))
{
    switch ($_COOKIE['eStore_gateway']) {
        case 'paypal':       	
            submit_to_paypal();
            break;
        case 'manual':
			submit_to_manual();
            break;
        case '2co':
            submit_to_2co();
            break;
        case 'authorize':
            submit_to_authorize();            
            break;
		default:
            submit_to_paypal();			
			break;                             
    }
}
else
{
    submit_to_paypal();	
}

echo '</div></div></div>';
echo "</body>";

function eStore_show_redirection_message()
{
	$bg_img_src = WP_ESTORE_URL.'/images/body-bg.jpg';	
	?>	
	<style type="text/css">
	#container{
	max-width:450px;
	margin-left: auto;
	margin-right: auto;
	}
	#redirection_canvas{
	background:#D6D6D6;
	padding:20px;
	}
	#redirection_body_content {
	margin-top: 30px;
	padding: 20px;
	margin: 5px;
	height:260px;
	color:#504945;
	background:#fff url(<?php echo $bg_img_src; ?>) repeat-x;
	border:1px solid #ccc;
	}
	.redirection_header{
	color:#227ABE;
	text-align:center;
	font:14px  Georgia,century gothic,Arial;
	font-weight:bold;
	}
	</style>
	<?php
	
	$output .= "<head><title>".WP_ESTORE_PROCESSING_ORDER."</title></head>\n";
	$output .= '<div id="container"><div id="redirection_canvas"><div id="redirection_body_content">';
	
	//Check if session is working or if the cart is empty
	if(!isset($_SESSION['eStore_cart']) || empty($_SESSION['eStore_cart']))
	{
		$output .= '<br /><strong>Either your shopping cart is empty or the PHP Session on your server is not working correctly. Please check this <a href="http://www.tipsandtricks-hq.com/forum/topic/php-session-not-working-correctly" target="_blank">article</a></strong><br /><br />';
		$output .= '</div></div></div>';
		$output .= "</body>";
		echo $output;
		exit;
	}
	
	//$output .= "<body onLoad=\"document.forms['gateway_form'].submit();\">\n";
	$output .= "<body>\n";
	$loader_img_src = WP_ESTORE_URL.'/images/ajax-loader.gif';
	$output .= "<div class=\"redirection_header\">".WP_ESTORE_ORDER_BEING_PROCESSED."</div>";
	$output .= '<br /><p style="text-align:center;"><img src="'.$loader_img_src.'" alt="'.WP_ESTORE_PROCESSING_ORDER.'" /></p>';
	$output .= "<p style=\"text-align:center;\"><br/>".WP_ESTORE_NOT_AUTO_REDIRECT."<br/></p>\n<br />";		
	
	echo $output;
	if ($_SERVER['HTTPS'] == 'on') {
		echo '<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>';
	}
	else{
		echo '<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>';
	}
	?>	
	<script type="text/javascript">
	jQuery(document).ready(function($) {
	$(function() {			
		setTimeout("$('#gateway_form').submit()", 800);
	 });
	 });
	</script>
	<?php	
	/*   
	    <script type="text/javascript">
	    document.forms['gateway_form'].submit();
	    </script>
	*/
}

function submit_to_authorize()
{
	global $defaultCurrency,$defaultSymbol,$defaultEmail,$return,$sandbox_enabled;
    $myAuthorize = new Authorize();
    
    $authorize_login_id = get_option('eStore_authorize_login');
    $authorize_tx_key = get_option('eStore_authorize_tx_key');
    $myAuthorize->setUserInfo($authorize_login_id, $authorize_tx_key);

    if (!empty($return))
        $myAuthorize->addField('x_receipt_link_URL', $return);

    if (get_option('eStore_auto_product_delivery') != '')
    {
        $notify = WP_ESTORE_URL.'/eStore_auth_ipn.php';
        $myAuthorize->addField('x_Relay_URL', $notify);
    }

    $count = 1;
    foreach ($_SESSION['eStore_cart'] as $item)
    {
	$rounded_price = round($item['price'], 2);
        $item_name = substr(htmlspecialchars($item['name']), 0, 30);
		$line_item_val = $item['item_number']."<|>".$item_name."<|><|>".$item['quantity']."<|>".$rounded_price."<|>"."N";
        $myAuthorize->addField('x_line_item-'.$count, $line_item_val);
        $count++;
    }
    // Shipping
    $myAuthorize->addField('x_freight', $_SESSION['eStore_cart_postage_cost']);
    // Tax
    if(!empty($_SESSION['eStore_cart_total_tax']))
    {
    	$myAuthorize->addField('x_tax', round($_SESSION['eStore_cart_total_tax'], 2));
    }  
    else
    {  
    	$myAuthorize->addField('x_tax', 0);
    }    
    // Duty
    $myAuthorize->addField('x_duty', 0);    
    // Total
    $total = round(($_SESSION['eStore_cart_sub_total'] + $_SESSION['eStore_cart_postage_cost'] + $_SESSION['eStore_cart_total_tax']),2);
    $myAuthorize->addField('x_Amount', $total);
	// Description
    $myAuthorize->addField('x_Description', 'cart checkout');

    //$val = "item2<|>cricket bag<|>Wilson cricket carry bag, red<|>1<|>39.99<|>N";

    $myAuthorize->addField('x_Invoice_num', rand(1, 100));
    
    //Generate Customer ID
    $custId = uniqid();
    $myAuthorize->addField('x_Cust_ID', $custId);
	
    // Enable test mode if needed
    if($sandbox_enabled)
        $myAuthorize->enableTestMode();

    // Save the order details
    eStore_save_order_details($custId);
    
    // Lets clear the cart
    reset_eStore_cart();

    // Let's start the train!
    $myAuthorize->submitPayment2(WP_ESTORE_CLICK_HERE);    
}

function eStore_save_order_details($custId)
{
	global $wpdb;
	$pending_payment_table_name = $wpdb->prefix . "wp_eStore_pending_payment_tbl";
	
	$custom_field_val = eStore_get_custom_field_value1();
	$referrer = eStore_get_referrer();
		
	foreach ($_SESSION['eStore_cart'] as $item)
	{
		$item_number = $item['item_number'];
        $name = $wpdb->escape(htmlspecialchars($item['name']));		
		$price = $item['price'];
		$quantity = $item['quantity'];
		$shipping = $item['shipping'];
						
		$updatedb = "INSERT INTO $pending_payment_table_name (customer_id, item_number, name, price, quantity, shipping, custom) VALUES ('$custId', '$item_number', '$name','$price','$quantity','$shipping','$custom_field_val')";
		$results = $wpdb->query($updatedb);	
	}
}

function submit_to_2co()
{
    global $defaultCurrency,$defaultSymbol,$defaultEmail,$return,$sandbox_enabled;
    $my2CO = new TwoCo();

    // Specify your 2CheckOut vendor id
    $vendor_id = get_option('eStore_2co_vendor_id');
    $my2CO->addField('sid', $vendor_id);

    if (!empty($defaultCurrency))
        $tco_currency = $defaultCurrency;
    else
        $tco_currency = 'USD';
    $my2CO->addField('tco_currency', $tco_currency);//use list_currency 
    
    // Save the order details
    $uniqueId = uniqid();        
    eStore_save_order_details($uniqueId);
    
    // Specify the order information
    $my2CO->addField('id_type', '1');
    $my2CO->addField('cart_order_id', $uniqueId);

    // =======================
    $count = 1;
    foreach ($_SESSION['eStore_cart'] as $item)
    {
   		$rounded_price = round($item['price'], 2);   		  		
        $my2CO->addField("c_name_$count", htmlspecialchars($item['name']));
        $my2CO->addField("c_description_$count", htmlspecialchars($item['name']));
        $my2CO->addField("c_price_$count", $rounded_price);
        //$my2CO->addField("quantity_$count", $item['quantity']);
        //$my2CO->addField("c_prod_$count", $item['item_number']);
        $my2CO->addField("c_prod_$count", $item['item_number'].','.$item['quantity']);
        if(empty($item['shipping']))
        {
            $my2CO->addField("c_tangible_$count", 'N');
        }
        else
        {
            $my2CO->addField("c_tangible_$count", 'Y');
        }
        $total += $rounded_price * $item['quantity'];
        $count++;
    }
    if ($_SESSION['eStore_cart_postage_cost'] > 0)
    {
   		$rounded_shipping = round($_SESSION['eStore_cart_postage_cost'], 2);
        $my2CO->addField("c_name_$count", "Shipping");
        $my2CO->addField("c_description_$count", "Shipping");
        $my2CO->addField("c_price_$count", $rounded_shipping);
        $my2CO->addField("c_prod_$count", "SHIPPING".','."1");    
    }
    $my2CO->addField('total', round($total+$rounded_shipping+$_SESSION['eStore_cart_total_tax']));
    //$my2CO->addField('sh_cost', $_SESSION['eStore_cart_postage_cost']);

    //========================
    //$my2CO->addField('pay_method', "CC");
    //$my2CO->addField('skip_landing', "1");
    //========================

    // Specify the url where 2CO will send the INS
    if (!empty($return))
    {
        $my2CO->addField('return_url', $return);
    }

    if (get_option('eStore_auto_product_delivery') != '')
    {
        $notify = WP_ESTORE_URL.'/eStore_2co_ipn.php';
        $my2CO->addField('x_Receipt_Link_URL', $notify);
    }

    $custom_field_val = eStore_get_custom_field_value1();
    $my2CO->addField('custom', $custom_field_val);

    // Enable test mode if needed
    if($sandbox_enabled)
    {
        $my2CO->enableTestMode();
    }

    // Lets clear the cart
    reset_eStore_cart();
    
    $my2CO->submitPayment2(WP_ESTORE_CLICK_HERE);     
}

function submit_to_paypal()
{
    global $defaultCurrency,$defaultSymbol,$defaultEmail,$return,$sandbox_enabled;

    if (!empty($defaultCurrency))
        $paypal_currency = $defaultCurrency;
    else
        $paypal_currency = 'USD';
    if (!empty($defaultSymbol))
        $paypal_symbol = $defaultSymbol;
    else
        $paypal_symbol = '$';

    if (!empty($defaultEmail))
        $email = $defaultEmail;

    $myPaypal = new Paypal();
    $myPaypal->gatewayUrl = 'https://www.paypal.com/cgi-bin/webscr';
    
    $myPaypal->addField('charset', "utf-8");
    $myPaypal->addField('business', $email);
    $myPaypal->addField('currency_code', $paypal_currency);

    if (!empty($return))
        $myPaypal->addField('return', $return);
	$cancel_url =  get_option('cart_cancel_from_paypal_url');
	if(!empty($cancel_url))
	{
		$myPaypal->addField('cancel_return', $cancel_url);
	}
    if (get_option('eStore_auto_product_delivery') != '')
    {
        $notify = WP_ESTORE_URL.'/paypal.php';
        $myPaypal->addField('notify_url', $notify);
    }

    // =======================
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$weight = 0;    
    $count = 1;
    foreach ($_SESSION['eStore_cart'] as $item)
    {
   		$rounded_price = round($item['price'], 2);
        $myPaypal->addField("item_name_$count", htmlspecialchars($item['name']));
        $myPaypal->addField("amount_$count", $rounded_price);
        $myPaypal->addField("quantity_$count", $item['quantity']);
        $myPaypal->addField("item_number_$count", $item['item_number']);
        
        $id = $item['item_number'];
        $ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
        if(!empty($ret_product->weight))
        {
        	$weight += ($ret_product->weight * $item['quantity']);
        }
        
        $count++;
    }

    if (!get_option('eStore_paypal_profile_shipping'))
    {
        //Not Using paypal's profile based shipping so include shipping otherwise ignore shipping here as it will be calculated on paypal's site
        $shipping = round($_SESSION['eStore_cart_postage_cost'], 2);
        if(!empty($shipping))
        {
        	$myPaypal->addField('no_shipping', '2');        	
        }        
        //$myPaypal->addField('shipping_1', $shipping);
        $myPaypal->addField('handling_cart', $shipping);

    }
    else
    {
    	//Include the weight for profile based shipping calc
    	$myPaypal->addField('weight_cart', round($weight, 2));
    	$myPaypal->addField('weight_unit', 'lbs');
    }
    if(!empty($_SESSION['eStore_cart_total_tax']))
    {
    	$myPaypal->addField('tax_cart', round($_SESSION['eStore_cart_total_tax'], 2));
    }
    //========================

    if (get_option('eStore_display_tx_result'))
	{
        $myPaypal->addField('rm', '2');
	}

	$myPaypal->addField('cmd', '_cart');
	$myPaypal->addField('upload', '1');

    $custom_field_val = eStore_get_custom_field_value1();
    $myPaypal->addField('custom', $custom_field_val);

    $myPaypal->addField('mrb', '3FWGC6LFTMTUG');
    $page_style_name = get_option('eStore_paypal_co_page_style');
    if(!empty($page_style_name))
    {
    	$myPaypal->addField('page_style', $page_style_name);
    }
    
    $returnButtonText = get_option('eStore_paypal_return_button_text');
    if (!empty($returnButtonText))
    {
        $myPaypal->addField('cbt', $returnButtonText);
    }
    // Enable sandbox mode if needed
    if($sandbox_enabled)
        $myPaypal->enableTestMode();

    // Lets clear the cart
    reset_eStore_cart();
            
    // submit the payment!
    $myPaypal->submitPayment2(WP_ESTORE_CLICK_HERE);    
} 

function submit_to_manual()
{
	$click_text = WP_ESTORE_CLICK_HERE;
		
	$output .= "<div style=\"text-align:center;\">";
	$output .= '<form id="gateway_form" action="'.WP_ESTORE_URL.'/eStore_manual_gateway.php" method="post">';
	$output .= '<input type="hidden" name="eStore_manaul_gateway" id="eStore_manaul_gateway" value="process" />';	
	$output .= "<input type=\"submit\" value=\"$click_text\">";
	$output .= "</form>";
	$output .= "</div>";
	echo $output;	
}

function eStore_get_custom_field_value1()
{
	$output = '';
	$_SESSION['eStore_custom_values']='';
	if (!empty($_SESSION['ap_id']))
	{
        $name = 'ap_id';
        $value = $_SESSION['ap_id'];
        $custom_field_val = append_values_to_custom_field($name,$value);      
	}
	else if (isset($_COOKIE['ap_id']))
	{
        $name = 'ap_id';
        $value = $_COOKIE['ap_id'];
        $custom_field_val = append_values_to_custom_field($name,$value);
	}
	if (!empty($_SESSION['eStore_coupon_code']))
	{
        $name = 'coupon';
        $value = $_SESSION['eStore_coupon_code'];
        $custom_field_val = append_values_to_custom_field($name,$value);
    } 
    if (function_exists('wp_eMember_install'))
    {  
	    global $auth;
	    $user_id = $auth->getUserInfo('member_id');
	    if (!empty($user_id))
	    {
			$name = 'eMember_id';
			$custom_field_val = append_values_to_custom_field($name,$user_id);
	    }
    }
    return $custom_field_val;
}

function eStore_get_referrer()
{
	if (!empty($_SESSION['ap_id']))
	{
        $value = $_SESSION['ap_id'];
	}
	else if (isset($_COOKIE['ap_id']))
	{
        $value = $_COOKIE['ap_id'];
	}	
	return $value;
}
?>