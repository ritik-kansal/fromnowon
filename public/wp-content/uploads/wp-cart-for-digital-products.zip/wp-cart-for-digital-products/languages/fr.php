<?php
/*
WP eStore plugin French Language File
*/
//Product Display
define("ESTORE_AVAILABLE_QTY", "En inventaire");
//define("ESTORE_AVAILABLE_QTY", "Quantité disponible");

//Shopping Cart
define("ESTORE_ITEM_NAME", "Article");
define("ESTORE_QUANTITY", "Quantité");
define("ESTORE_PRICE", "Prix");
define("ESTORE_TOTAL", "Total: ");
define("ESTORE_SUB_TOTAL", "Sous-total");
define("ESTORE_SHIPPING", "Port");
define("ESTORE_REMOVE_ITEM", "Enlever");
//define("ESTORE_REMOVE_ITEM", "Supprimer");
define("ESTORE_EMPTY_CART", "Vider le panier");

define("ESTORE_ENTER_COUPON_CODE", "Code du coupon :");
//define("ESTORE_ENTER_COUPON_CODE", "Code du rabais :");
define("ESTORE_APPLY", "Appliquer");

define("ESTORE_TERMS_AND_CONDITIONS", "Conditions de vente");
define("ESTORE_TERMS_AGREE", " je suis d'accord avec");
define("ESTORE_TERMS_ERROR", "Vous devez accepter les conditions de vente");

define("ESTORE_CONTINUE_SHOPPING", "Continuer à magasiner");

define("ESTORE_PAYMENT_METHOD", "Paiement par ");
define("ESTORE_PAYMENT_METHOD", "Méthode de paiement ");
define("ESTORE_PAYPAL", "PayPal");
define("ESTORE_MANUAL", "Manuel");
//define("ESTORE_MANUAL", "Chèque");
define("ESTORE_TWO_CO", "2Checkout");
define("ESTORE_AUTHORIZE", "Authorize.net");

define("ESTORE_COUPON_NOT_ACTIVE", "Le code n'est pas actif");
define("ESTORE_MAX_COUPON_USE", "Limite de rabais atteinte");
define("ESTORE_TOTAL_DISCOUNT", "Votre rabais a été appliqué avec succès! Rabais total : ");
define("ESTORE_COUPON_INVALID", "Le code n'est pas valable");
define("ESTORE_DISCOUNT_LIMIT", "Le rabais s'applique une seule fois");
define("ESTORE_COUPON_COND_NOT_MET", "Votre panier ne contient pas le minimum requis");
define("ESTORE_DISCOUNT_FREE_SHIPPING", "LIVRAISON GRATUITE");

define("ESTORE_QUANTITY_CHANGE", "Mettre à jour la quantité.");
define("ESTORE_QUANTITY_CHANGE_NOT_ALLOWED", "La quantité ne peut pas être modifié une fois que le rabais a été appliqué; si vous modifiez la quantité, votre panier sera vidé.");
define("ESTORE_QUANTITY_LIMIT_EXCEEDED", "Votre commande dépasse la quantité disponible.");

define("ESTORE_ITEM_ADDED", "Article ajouté au panier");
define("ESTORE_ITEM_DELETED", "Article supprimé du panier");
define("ESTORE_QTY_UPDATED", "Quantité mise à jour");

define("ESTORE_CART_EMPTY", "Votre panier est vide.");
define("ESTORE_VISIT_THE_SHOP", "Visiter la boutique");

define("ESTORE_DOWNLOAD_TEXT", "Télécharger");

define("ESTORE_FILL_IN_SHIPPING_DETAILS", "Veuillez remplir et soumettre le formulaire pour compléter votre commande.");
define("ESTORE_FIRST_NAME", "Prénom");
define("ESTORE_LAST_NAME", "Nom");
define("ESTORE_ADDRESS", "Adresse");
define("ESTORE_CITY", "Ville");
define("ESTORE_STATE", "Province");
define("ESTORE_POSTCODE", "Code postal");
define("ESTORE_COUNTRY", "Pays");
define("ESTORE_PHONE", "Téléphone");
define("ESTORE_EMAIL", "Courriel");
define("ESTORE_ADDITIONAL_COMMENT", "Notes");
define("ESTORE_CONFIRM_ORDER", "Confirmer votre commande");
define("ESTORE_COLLECT_DETAILS", "Détails...");
define("ESTORE_ORDER_COMPLETE", "Votre commande a été soumise!");
define("ESTORE_REQUIRED_FIELDS_MISSING", "Les information suivantes sont obligatoires : ");

define("ESTORE_ENTER_AFFILIATE_ID", "Entrez votre identifiant (ID) d'affiliation : ");
define("ESTORE_AFFILIATE_ID_SET", "Votre ID d'affiliation a été envoyé");
define("ESTORE_AFFILIATE_PLUGIN_INACTIVE", "L'extension Affiliate n'est pas active");

define("ESTORE_PENDING_PAYMENT_EMAIL_SUBJECT", "Paiement en attente reçu");
define("ESTORE_PENDING_PAYMENT_EMAIL_BODY", "Merci pour votre achat. Les produits commandés seront envoyés une fois que votre paiement aura été vérifié.");

define("ESTORE_ITEM_IN_THE_CART", " Articles dans le panier");
define("ESTORE_ITEMS_IN_THE_CART", " Articles dans le panier");
define("ESTORE_VIEW_CART", " Voir le panier");

define("ESTORE_YOU_MUST_BE_LOGGED", "Vous devez être connecté(e) en tant que membre pour voir l'historique des achats");
define("ESTORE_NO_PURCHASE_FOUND", "Aucun achat trouv�");
define("ESTORE_PRODUCT_ID", "Identifiant (ID) du produit");
define("ESTORE_PRODUCT_NAME", "Nom du Produit");
define("ESTORE_TRANSACTION_ID", "Identifiant (ID) de la Transaction");
define("ESTORE_EMAIL_ADDRESS", "Adresse email d�j� utilis�e");
define("ESTORE_DATE", "Date");
define("ESTORE_PRICE_PAID", "Prix payé");

define("WP_ESTORE_NO_COPIES_LEFT", "Désolé! Il ne reste aucune copie.");

define("WP_ESTORE_DETAILS_OF_ORDERED_PRODUCT", "Détails des articles commandés");
define("WP_ESTORE_TOTAL_ITEMS_ORDERED", "Total des articles commandés");
define("WP_ESTORE_CUSTOMER_DETAILS", "Détails clients");
define("WP_ESTORE_NAME", "Name");
define("WP_ESTORE_ADDITIONAL_COMMENT", "Commentaires aditionnels");
define("WP_ESTORE_REFERRER", "Référant");

define("WP_ESTORE_PROCESSING_ORDER", "Commande en cours...");
define("WP_ESTORE_ORDER_BEING_PROCESSED", "Veuillez patienter, votre commande est en cours� Vous allez être redirigé(e) vers la page de paiement dans un instant");
define("WP_ESTORE_NOT_AUTO_REDIRECT", "Si vous n'êtes pas redirigé(e) vers la page de paiement d'ici 5 secondes...");
define("WP_ESTORE_CLICK_HERE", "Cliquez ici");

define("WP_ESTORE_THIS_ITEM_DOES_NOT_HAVE_DOWNLOAD", " - Ce produit n'a pas de contenu téléchargeable");
define("WP_ESTORE_YOU_WILL_SOON_RECEIVE_EMAIL", "Vous allez rapidement recevoir un reçu de votre paiement et une copie de ces informations de téléchargement dans votre email");
define("WP_ESTORE_TOTAL_COST", "Cout Total");

define("WP_ESTORE_ORDER_SUMMARY", "Your Order Summary");
define("WP_ESTORE_DESCRIPTION", "Description");
define("WP_ESTORE_TAX", "Tax");

define("WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_SUBJECT", "Member Account Upgraded");
define("WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_BODY", "Your account has been upgraded successfully");

define("WP_ESTORE_YOUR_PRICE", "Your Price");
define("WP_ESTORE_MINIMUM_PRICE_YOU_CAN_ENTER", "The minimum price you can specify is ");

define("WP_ESTORE_BUY_NOW", "Buy Now");
define("WP_ESTORE_SUBSCRIBE", "Subscribe");

define("WP_ESTORE_NAME_OR_EMAIL_MISSING", "<p style='color: red;'><strong>Name or email address is missing!</strong></p>");
define("WP_ESTORE_EMAIL_SENT", "<p style='color: green;'><strong>Email sent! Please check your inbox for the download link.</strong></p>");
define("WP_ESTORE_REQUIRED_FIELD", "This field is required.");

define("WP_ESTORE_YOUR_ORDER", "You ordered the following items: ");

define("ESTORE_SHIPPING_VARIATION", "Shipping Option");
define("ESTORE_CLICK_UPDATE_BUTTON", "Please click the update button to finalize your change!");

define("ESTORE_FREE_DOWNLOAD_SUBJECT", "Free download link");  
define("ESTORE_DEAR", "Dear");
define("ESTORE_FREE_DOWNLOAD_EMAIL_BODY", "Below is your download link: ");
define("ESTORE_THANK_YOU", "Thank You");

define("ESTORE_OLD_PRICE", "Price");
?>