<?php
/*
WP eStore plugin German Language File
*/
//Product Display
define("ESTORE_AVAILABLE_QTY", "Lieferbare St.");

//Shopping Cart
define("ESTORE_ITEM_NAME", "Artikel");
define("ESTORE_QUANTITY", "Menge");
define("ESTORE_PRICE", "Preis");
define("ESTORE_TOTAL", "Summe: ");
define("ESTORE_SUB_TOTAL", "Artikelsumme");
define("ESTORE_SHIPPING", "Versandkosten");
define("ESTORE_REMOVE_ITEM", "Artikel entfernen");
define("ESTORE_EMPTY_CART", "Einkaufswagen leeren");

define("ESTORE_ENTER_COUPON_CODE", "Gutschein Code:");
define("ESTORE_APPLY", "Absenden");

define("ESTORE_TERMS_AND_CONDITIONS", "Geschäftsbedingungen (AGB) zu");
define("ESTORE_TERMS_AGREE", " Ich stimme den ");
define("ESTORE_TERMS_ERROR", "Sie müssen den Geschäftsbedingungen zustimmen!");

define("ESTORE_CONTINUE_SHOPPING", "Weiter einkaufen");

define("ESTORE_PAYMENT_METHOD", "Zahlart: ");
define("ESTORE_PAYPAL", "PayPal");
define("ESTORE_MANUAL", "&uuml;berweisung");
define("ESTORE_TWO_CO", "2Checkout");
define("ESTORE_AUTHORIZE", "Authorize.net");

define("ESTORE_COUPON_NOT_ACTIVE", "Gutschein-Code ungültig!");
define("ESTORE_MAX_COUPON_USE", "Max. Anzahl an eingelösten Gutscheinen erreicht!");
define("ESTORE_TOTAL_DISCOUNT", "Rabatt erfolgreich abgezogen! Rabatt gesamt: ");
define("ESTORE_COUPON_INVALID", "Gutschein-Code ist ungültig!");
define("ESTORE_DISCOUNT_LIMIT", "Rabatt wird nur einmal gewährt!");
define("ESTORE_COUPON_COND_NOT_MET", "Die Mindestanforderungen für diesen Gutschein sind nicht erfüllt!");
define("ESTORE_DISCOUNT_FREE_SHIPPING", "Kostenlose Lieferung");

define("ESTORE_QUANTITY_CHANGE", "ENTER-Taste drücken um die Menge zu aktualisieren.");
define("ESTORE_QUANTITY_CHANGE_NOT_ALLOWED", "Nach dem der Rabatt abgezogen wurde, kann die Menge nicht mehr verändert werden! Die Änderung löscht den Warenkorb.");
define("ESTORE_QUANTITY_LIMIT_EXCEEDED", "Die eingegebene Menge ist nicht lieferbar!");

define("ESTORE_ITEM_ADDED", "Produkt wurde in den Einkaufswagen gelegt!");
define("ESTORE_ITEM_DELETED", "Produkt wurde aus dem Einkaufswagen entfernt!");
define("ESTORE_QTY_UPDATED", "Menge aktualisiert!");

define("ESTORE_CART_EMPTY", "Einkaufswagen ist leer");
define("ESTORE_VISIT_THE_SHOP", "Besuchen Sie den Shop");

define("ESTORE_DOWNLOAD_TEXT", "Download");

define("ESTORE_FILL_IN_SHIPPING_DETAILS", "Bitte folgende Details ausf&uuml;llen und best&auml;tigen um den Bestellvorgang abzuschlie&szlig;en.");
define("ESTORE_FIRST_NAME", "Vorname");
define("ESTORE_LAST_NAME", "Nachname");
define("ESTORE_ADDRESS", "Addresse");
define("ESTORE_CITY", "Stadt");
define("ESTORE_STATE", "Bundesland");
define("ESTORE_POSTCODE", "PLZ");
define("ESTORE_COUNTRY", "Land");
define("ESTORE_PHONE", "Telefon");
define("ESTORE_EMAIL", "Email");
define("ESTORE_ADDITIONAL_COMMENT", "Kommentar");
define("ESTORE_CONFIRM_ORDER", "Bestellung best&auml;tigen");
define("ESTORE_COLLECT_DETAILS", "Kundendaten eingeben ...");
define("ESTORE_ORDER_COMPLETE", "Bestellung erfolgreich!");
define("ESTORE_REQUIRED_FIELDS_MISSING", "Folgende Felder bitte ausf&uuml;llen:");

define("ESTORE_ENTER_AFFILIATE_ID", "Bitte Partner ID eingeben: ");
define("ESTORE_AFFILIATE_ID_SET", "Partner ID gesetzt");
define("ESTORE_AFFILIATE_PLUGIN_INACTIVE", "Das Partner Plugin ist nicht aktiv.");

define("ESTORE_PENDING_PAYMENT_EMAIL_SUBJECT", "Ausstehende Zahlung empfangen");
define("ESTORE_PENDING_PAYMENT_EMAIL_BODY", "Vielen Dank f&uuml;r Ihre Bestellung. Wir werden sofort nach Zahlungseingang versenden.");

define("ESTORE_ITEM_IN_THE_CART", " Produkt im Warenkorb");
define("ESTORE_ITEMS_IN_THE_CART", " Produkte im Warenkorb");
define("ESTORE_VIEW_CART", " Zeige Warenkorb");

define("ESTORE_YOU_MUST_BE_LOGGED", "Sie müssen eingelogt sein um Ihre Bestellung/en zu sehen.");
define("ESTORE_NO_PURCHASE_FOUND", "Kein K&auml;ufe gefunden");
define("ESTORE_PRODUCT_ID", "Produkt ID");
define("ESTORE_PRODUCT_NAME", "Produktname");
define("ESTORE_TRANSACTION_ID", "Transaktions ID");
define("ESTORE_EMAIL_ADDRESS", "Emailaddresse wird schon verwendet.");
define("ESTORE_DATE", "Datum");
define("ESTORE_PRICE_PAID", "Bezahlt");

define("WP_ESTORE_NO_COPIES_LEFT", "Verzeihung! Kein Exemplar mehr übrig.");

define("WP_ESTORE_DETAILS_OF_ORDERED_PRODUCT", "Artikeldaten");
define("WP_ESTORE_TOTAL_ITEMS_ORDERED", "Gesamtzahl Artikel");
define("WP_ESTORE_CUSTOMER_DETAILS", "Kundendaten");
define("WP_ESTORE_NAME", "Name");
define("WP_ESTORE_ADDITIONAL_COMMENT", "Kommentar");
define("WP_ESTORE_REFERRER", "Verweis durch");

define("WP_ESTORE_PROCESSING_ORDER", "Bestellung wird verarbeitet...");
define("WP_ESTORE_ORDER_BEING_PROCESSED", "Bitte warten, Ihre Bestellung wird verarbeitet... Sie werden gleich zur Zahlungsseite weitergeleitet.");
define("WP_ESTORE_NOT_AUTO_REDIRECT", "Wenn Sie nicht innerhalb von 5 Sekunden weitergeleitet werden...");
define("WP_ESTORE_CLICK_HERE", "klicken Sie hier");

define("WP_ESTORE_THIS_ITEM_DOES_NOT_HAVE_DOWNLOAD", " - Dieser Artikel enthält keinen Download");
define("WP_ESTORE_YOU_WILL_SOON_RECEIVE_EMAIL", "Sie sollten in Kürze eine Bestellbestätigung und eine Kopie der Download-Informationen erhalten.");
define("WP_ESTORE_TOTAL_COST", "Gesamtpreis");

define("WP_ESTORE_ORDER_SUMMARY", "Bestell&uuml;bersicht");
define("WP_ESTORE_DESCRIPTION", "Beschreibung");
define("WP_ESTORE_TAX", "Steuern");

define("WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_SUBJECT", "Kundenkonto erweitert");
define("WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_BODY", "Ihr Kundenkonto wurde erfolgreich erweitert.");

define("WP_ESTORE_YOUR_PRICE", "Ihr Preis");
define("WP_ESTORE_MINIMUM_PRICE_YOU_CAN_ENTER", "Der Mindestpreis ist ");

define("WP_ESTORE_BUY_NOW", "Jetzt kaufen");
define("WP_ESTORE_SUBSCRIBE", "Abonnieren");

define("WP_ESTORE_NAME_OR_EMAIL_MISSING", "<p style='color: red;'><strong>Name oder Email-Addresse fehlt!</strong></p>");
define("WP_ESTORE_EMAIL_SENT", "<p style='color: green;'><strong>Email versendet! Bitte schauen Sie in Ihrem Posteingang nach einem Download-Link.</strong></p>");
define("WP_ESTORE_REQUIRED_FIELD", "Dieses Feld muss ausgefüllt werden.");

define("WP_ESTORE_YOUR_ORDER", "Sie haben folgende Artikel bestellt: ");

define("ESTORE_SHIPPING_VARIATION", "Versandopstion");
define("ESTORE_CLICK_UPDATE_BUTTON", "Please click the update button to finalize your change!");

define("ESTORE_FREE_DOWNLOAD_SUBJECT", "Free download link");  
define("ESTORE_DEAR", "Dear");
define("ESTORE_FREE_DOWNLOAD_EMAIL_BODY", "Below is your download link: ");
define("ESTORE_THANK_YOU", "Thank You");

define("ESTORE_OLD_PRICE", "Price");
?>