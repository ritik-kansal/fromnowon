<?php
/*
|-------------------------------------------|
|Property       |   logic  | value          |
|-------------------------------------------|
|Item Quantity  |     >    | 3              |
|Total Quantity |     =    | 15.00          |
|Subtotal Amount| Contains | "Test Product" |
|Total Amount   |          |                |
|Item Name      |          |                |
|Item ID        |
|Free shipping if total|
|Product Category ID|
|-------------------------------------------|
*/
$total_cond_discount = 0;
// if(!empty($value)) -> eStore_apply_cond_discount()
function eStore_apply_cond_discount($ret_coupon)
{
	global $total_cond_discount;
	$total_cond_discount = 0;
    switch($ret_coupon->property)
    {
        case '1':
            eStore_handle_item_quantity_discount($ret_coupon);
            break;
        case '2':
            eStore_handle_total_quantity_discount($ret_coupon);
            break;
        case '3':
            eStore_handle_total_discount($ret_coupon,"subtotal");
            break;
        case '4':
            eStore_handle_total_discount($ret_coupon,"total");
            break;   
        case '5':
            eStore_handle_item_name_discount($ret_coupon);
            break;   
        case '6':
            eStore_handle_item_id_discount($ret_coupon);
            break; 
        case '7':
            eStore_handle_free_shipping_discount($ret_coupon);
            break;  
        case '8':
            eStore_handle_product_category_id_discount($ret_coupon);
            break;                                                                           
        default:
            break;
    }
    return $total_cond_discount;
}

function eStore_handle_product_category_id_discount($ret_coupon)
{
	global $wpdb;
	$cat_prod_rel_table_name = $wpdb->prefix . "wp_eStore_cat_prod_rel_tbl";	
	$products = $_SESSION['eStore_cart'];
	foreach ($products as $key => $item)
	{
		$apply_coupon = false;
		$item_id = $item['item_number'];
		$wp_eStore_cat_db = $wpdb->get_results("SELECT * FROM $cat_prod_rel_table_name where prod_id=$item_id", OBJECT);
		if ($wp_eStore_cat_db)
		{
			foreach ($wp_eStore_cat_db as $wp_eStore_cat_db)
			{
				if($wp_eStore_cat_db->cat_id == $ret_coupon->value)
				{
					$apply_coupon = true;
				}				
			}
			if($apply_coupon)
			{
				$item['price'] = eStore_calc_new_per_item_price($ret_coupon, $item['price'],$item['quantity']);
				unset($products[$key]);
				array_push($products, $item);				
			}
		}
	}
	sort($products);
	$_SESSION['eStore_cart'] = $products;						
}
function eStore_handle_free_shipping_discount($ret_coupon,$flag="total")
{
	global $total_cond_discount;
	$products = $_SESSION['eStore_cart'];
	$total = $_SESSION['eStore_cart_sub_total'];
	$shipping = $_SESSION['eStore_cart_postage_cost'];
	if ($flag == "total")
	{
		$total = $total + $shipping;
	}

	if ($ret_coupon->logic == "1")
	{
		if ($total > $ret_coupon->value)
		{
			foreach ($products as $key => $item)
			{
				$item['shipping'] = 0;
				unset($products[$key]);
				array_push($products, $item);				
			}
		}
	}
	else if ($ret_coupon->logic == "2")
	{
		if ($total == $ret_coupon->value)
		{
			foreach ($products as $key => $item)
			{
				$item['shipping'] = 0;
				unset($products[$key]);
				array_push($products, $item);				
			}
		}
	}	
	$total_cond_discount = -99;//ESTORE_DISCOUNT_FREE_SHIPPING;
	sort($products);
	$_SESSION['eStore_cart'] = $products;
}


function eStore_handle_item_id_discount($ret_coupon)
{
	$products = $_SESSION['eStore_cart'];
	foreach ($products as $key => $item)
	{
		if ($item['item_number'] == $ret_coupon->value)
		{
			$item['price'] = eStore_calc_new_per_item_price($ret_coupon, $item['price'],$item['quantity']);
			unset($products[$key]);
			array_push($products, $item);
		}
	}
	sort($products);
	$_SESSION['eStore_cart'] = $products;
}

function eStore_handle_item_name_discount($ret_coupon)
{
	$products = $_SESSION['eStore_cart'];
	foreach ($products as $key => $item)
	{
		$pos = strpos($item['name'],$ret_coupon->value);
		if ($pos !== false)
		{
			$item['price'] = eStore_calc_new_per_item_price($ret_coupon, $item['price'],$item['quantity']);
			unset($products[$key]);
			array_push($products, $item);
		}
	}
	sort($products);
	$_SESSION['eStore_cart'] = $products;
}

function eStore_handle_total_discount($ret_coupon,$flag="total")
{
	$products = $_SESSION['eStore_cart'];
	$total = $_SESSION['eStore_cart_sub_total'];
	$shipping = $_SESSION['eStore_cart_postage_cost'];
	if ($flag == "total")
	{
			$total = $total + $shipping;
	}

	if ($ret_coupon->logic == "1")
	{
		if ($total > $ret_coupon->value)
		{
			$products = eStore_apply_discount_on_products($ret_coupon,$products);
		}
	}
	else if ($ret_coupon->logic == "2")
	{
		if ($total == $ret_coupon->value)
		{
			$products = eStore_apply_discount_on_products($ret_coupon,$products);
		}
	}
	sort($products);
	$_SESSION['eStore_cart'] = $products;
}

function eStore_handle_total_quantity_discount($ret_coupon)
{
	$products = $_SESSION['eStore_cart'];
	$total_quantity = 0;
	foreach ($products as $key => $item)
	{
		$total_quantity = $total_quantity + $item['quantity'];
	}
	if ($ret_coupon->logic == "1")
	{
		if ($total_quantity > $ret_coupon->value)
		{
			$products = eStore_apply_discount_on_products($ret_coupon,$products);
		}
	}
	else if ($ret_coupon->logic == "2")
	{
		if ($total_quantity == $ret_coupon->value)
		{
			$products = eStore_apply_discount_on_products($ret_coupon,$products);
		}
	}
	sort($products);
	$_SESSION['eStore_cart'] = $products;
}

function eStore_handle_item_quantity_discount($ret_coupon)
{
	$products = $_SESSION['eStore_cart'];
    if ($ret_coupon->logic == "1") //handle greater than
    {
		foreach ($products as $key => $item)
		{
			if ($item['quantity'] > $ret_coupon->value)
			{
				$item['price'] = eStore_calc_new_per_item_price($ret_coupon, $item['price'],$item['quantity']);
				unset($products[$key]);
				array_push($products, $item);
			}
		}
    }
    else if ($ret_coupon->logic == "2") //handle equal to
    {
		foreach ($products as $key => $item)
		{
			if ($item['quantity'] == $ret_coupon->value)
			{
				$item['price'] = eStore_calc_new_per_item_price($ret_coupon, $item['price'],$item['quantity']);
				unset($products[$key]);
				array_push($products, $item);
			}
		}
    }
	sort($products);
	$_SESSION['eStore_cart'] = $products;
}

function eStore_apply_discount_on_products($ret_coupon,$products)
{
	foreach ($products as $key => $item)
	{
		$item['price'] = eStore_calc_new_per_item_price($ret_coupon, $item['price'],$item['quantity']);
		if($item['price']<0)
		{
			$item['price'] = 0;
		}
		unset($products[$key]);
		array_push($products, $item);
	}

	return $products;
}
function eStore_calc_new_per_item_price($ret_coupon, $amount,$quantity)
{
	if ($ret_coupon->discount_type == 1)// value discount
	{
		global $total_cond_discount;
		$total_discount_amount = $ret_coupon->discount_value;
		$total_items_in_cart = eStore_get_total_cart_item_qty();
		$per_item_discount_amount = $total_discount_amount/$total_items_in_cart;
		$new_per_item_price = $amount - $per_item_discount_amount;
		$total_cond_discount = $total_cond_discount + $per_item_discount_amount*$quantity;
	}
	else
	{
		$new_per_item_price = (eStore_calc_new_item_total($ret_coupon, $amount,$quantity)/$quantity);
	}
	return round($new_per_item_price,2);
}
function eStore_calc_new_item_total($ret_coupon, $amount,$quantity)
{
	$new_total = eStore_calc_value_after_discount($ret_coupon, $amount*$quantity,$quantity);
	return $new_total;
}
function eStore_calc_value_after_discount($ret_coupon, $amount,$quantity)
{
	$discount_val = eStore_calc_discount_amount($ret_coupon, $amount,$quantity);
	return ($amount - $discount_val);
}
function eStore_calc_discount_amount($ret_coupon, $amount,$quantity)
{
	global $total_cond_discount;
	if ($ret_coupon->discount_type == 0) // %discount
	{
		$discount_amount = (($amount * $ret_coupon->discount_value)/100);
	}
	else if ($ret_coupon->discount_type == 1)// value discount
	{
		$discount_amount = $ret_coupon->discount_value*$quantity;
	}
	$total_cond_discount = $total_cond_discount + $discount_amount;
	return $discount_amount;
}
?>