<?php
// This script is used if you want visitors to think the downloads are in a directory other than the eStore plugin directory.
//     1. Copy this file to the directory you want people to think the files are stored at.  For example, if you want visitors
//        to think the files are stored at www.yoursite.com/downloads you would create a "downloads" directory in your site's
//        top level directory and copy this file there.
//     2. Rename this file:  download.php
//     3. If your copy of WordPress is installed in a subdirectory (www.yoursite.com/blog), you must change the value of
//        $wp_home_dir to the name of the subdirectory that contains WordPress.  In this example, the line should look like:
//            $wp_home_dir='blog';   <--- Type everything EXCEPT the "//" characters.
//     4. On the WordPress -> WP eStore -> Settings page, set the "Download Validation Script Location" to the URL of the
//        directory that corresponds with this script.  In this example, if you would set the location to:
//            http://www.yoursite.com/downloads
// -- The Assurer, 2010-09-14.

// If you installed WordPress in a subdirectory, you must put that subdirectory name here...
$wp_home_dir = '';
/********** Please do not change anything below this line **********/

if(!isset($_GET['file']) || empty($_GET['file'])) {	// Required "file=" URL query string is missing!
	echo 'Invalid Request';
	exit;
}	

if(chdir($_SERVER['DOCUMENT_ROOT']) === FALSE) {	// Could not chdir() to the site's root directory!
	echo 'Please tell us "the Custom Download Validation Script could not find the site\'s root directory, because the UID of the cuustom script does not match the root directory\'s UID."  Thank you!';
	exit;
}

// Next, if necessary, we chdir() to the location of where WordPress is installed...
$wp_home_dir = trim($wp_home_dir);			// Just in case, trim leading/trailing whitespace.
$wp_home_dir = trim($wp_home_dir,'/');			// And any leading/trailing slashes.
if(strlen($wp_home_dir) > 0) {				// WordPress is in a subdirectory...
	if(scandir($wp_home_dir) === FALSE) {		// Could not find the WordPress home directory!
		echo 'Please tell us "the Custom Download Validation Script could not find the WordPress home directory, because the script is not properly configured."  Thank you!';
		exit;
	}
	if(chdir($wp_home_dir) ===FALSE) {		// Could not chdir() to WordPress home directory!
		echo 'Please tell us "the Custom Download Validation Script could not find the WordPress home directory, because the UID of the cuustom script does not match the home directory\'s UID."  Thank you!';
		exit;
	}
}

// Now chdir() over to the eStore plugin directory...
$wp_eStore_plugin_dir = 'wp-content/plugins/wp-cart-for-digital-products';
if(scandir($wp_eStore_plugin_dir) === FALSE) {		// Could not find the eStore plugin directory!
	echo 'Please tell us "the Custom Download Validation Script could not find the eStore plugin directory, because it may have been moved, renamed, or deinstalled."  Thank you!';
	exit;
}
if(chdir($wp_eStore_plugin_dir) ===FALSE) {		// Could not chdir() to eStore plugin directory!
	echo 'Please tell us "the Custom Download Validation Script could not find the eStore plugin directory, because the UID of the cuustom script does not match the plugin directory\'s UID."  Thank you!';
	exit;
}

// Almost there!  Transfer control over to the main download validation script...
if(file_exists('download.php') === FALSE) {		// Could not find main download validation script.
	echo 'Please tell us "the Custom Download Validation Script could not find the download.php file in the eStore plugin directory."  Thank you!';
	exit;
}
	require_once('download.php');			// And, go!
	return;
?>
