<?php
require_once('eStore_classes/_loader.php');			// Activate the class loader.
include_once('admin_includes.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('eStore_addon_settings_menu.php');

function wp_estore_settings_menu()
{
	 echo '<div class="wrap">';
	 echo '<div id="poststuff"><div id="post-body">'; 
	 
	 echo eStore_admin_submenu_css();
   ?>
   <h2>WP eStore Settings v <?php echo WP_ESTORE_VERSION; ?></h2>
   <ul class="eStoreSubMenu">
   <li><a href="admin.php?page=wp_eStore_settings">General Settings</a></li>
   <li><a href="admin.php?page=wp_eStore_settings&settings_action=gateway">Payment Gateway Settings</a></li>   
   <li><a href="admin.php?page=wp_eStore_settings&settings_action=aweber">Autoresponder Settings</a></li>
   <li><a href="admin.php?page=wp_eStore_settings&settings_action=addon">Addon Settings</a></li>
   <li><a href="admin.php?page=wp_eStore_settings&settings_action=thrid_party">3rd Party Integration</a></li>
   </ul>
   <?php

   switch ($_GET['settings_action'])
   {
       case 'aweber':
           wp_eStore_autoresponder_settings();
           break;
       case 'gateway':
           wp_eStore_payment_gateway_settings();
           break;
       case 'addon':
           wp_eStore_addon_settings();
           break;
       case 'thrid_party':
           wp_eStore_third_party_settings();
           break;
       default:
           show_wp_digi_cart_settings_page();
           break;
   }
   	 
     echo '</div></div>';
     echo '</div>';
}

function wp_eStore_payment_gateway_settings()
{
    if (isset($_POST['info_update']))
    {
        update_option('eStore_use_multiple_gateways', ($_POST['eStore_use_multiple_gateways']=='1') ? '1':'' );
        update_option('eStore_use_manual_gateway_for_zero_dollar_co', ($_POST['eStore_use_manual_gateway_for_zero_dollar_co']=='1') ? '1':'' );
        
        update_option('eStore_use_paypal_gateway', ($_POST['eStore_use_paypal_gateway']=='1') ? '1':'' );
        update_option('cart_paypal_email', trim($_POST["cart_paypal_email"]));
        update_option('eStore_paypal_profile_shipping', ($_POST['eStore_paypal_profile_shipping']=='1') ? '1':'' );
        update_option('eStore_paypal_return_button_text', (string)$_POST["eStore_paypal_return_button_text"]);
        update_option('eStore_paypal_co_page_style', trim($_POST["eStore_paypal_co_page_style"]));
        update_option('eStore_paypal_pdt_token', trim($_POST["eStore_paypal_pdt_token"]));          
        
        update_option('eStore_use_manual_gateway', ($_POST['eStore_use_manual_gateway']=='1') ? '1':'' );
        update_option('eStore_manual_notify_email', trim($_POST["eStore_manual_notify_email"]));
        update_option('eStore_manual_co_cust_direction', stripslashes((string)$_POST["eStore_manual_co_cust_direction"]));
        update_option('eStore_manual_return_url', trim($_POST["eStore_manual_return_url"]));
        update_option('eStore_manual_co_give_aff_commission', ($_POST['eStore_manual_co_give_aff_commission']=='1') ? '1':'' );
        update_option('eStore_manual_co_auto_update_db', ($_POST['eStore_manual_co_auto_update_db']=='1') ? '1':'' );   
        update_option('eStore_manual_co_do_autoresponder_signup', ($_POST['eStore_manual_co_do_autoresponder_signup']=='1') ? '1':'' );          
        update_option('eStore_manual_co_give_download_links', ($_POST['eStore_manual_co_give_download_links']=='1') ? '1':'' );

        update_option('eStore_use_2co_gateway', ($_POST['eStore_use_2co_gateway']=='1') ? '1':'' );
        update_option('eStore_2co_vendor_id', (string)$_POST["eStore_2co_vendor_id"]);
        update_option('eStore_2co_secret_word', (string)$_POST["eStore_2co_secret_word"]);

        update_option('eStore_use_authorize_gateway', ($_POST['eStore_use_authorize_gateway']=='1') ? '1':'' );
        update_option('eStore_authorize_login', trim($_POST["eStore_authorize_login"]));
        update_option('eStore_authorize_tx_key', trim($_POST["eStore_authorize_tx_key"]));
        
        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Options Updated!';
        echo '</strong></p></div>';
    }
    $defaultEmail = get_option('cart_paypal_email');
    if (empty($defaultEmail)) $defaultEmail = get_bloginfo('admin_email');
    
	?>
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="info_update" id="info_update" value="true" />

	<div class="postbox">
	<h3><label for="title">General Payment Gateway Settings</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Use Multiple Payment Gateways
    </td><td align="left">
    <input name="eStore_use_multiple_gateways" type="checkbox"<?php if(get_option('eStore_use_multiple_gateways')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will give the customer an option to select a payment method (eg. PayPal, 2Checkout, Manual).</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Redirect to Manual Checkout For Zero Amount Purchase
    </td><td align="left">
    <input name="eStore_use_manual_gateway_for_zero_dollar_co" type="checkbox"<?php if(get_option('eStore_use_manual_gateway_for_zero_dollar_co')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Payment gateways like PayPal do not allow customers to checkout if an item has zero amount. If you want to give your customers item(s) for free then you can use this option together with the manual checkout feature. Ideally you should be using a <a href="http://tipsandtricks-hq.com/ecommerce/?p=126" target="_blank">squeeze page type form</a> to give away free items.</i><br /><br />
    </td></tr>    

    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">PayPal Settings</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Use PayPal Payment Gateway
    </td><td align="left">
    <input name="eStore_use_paypal_gateway" type="checkbox"<?php if(get_option('eStore_use_paypal_gateway')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the customers will be able to checkout through PayPal.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Paypal Email Address/Secure Merchant ID
    </td><td align="left">
    <input name="cart_paypal_email" type="text" size="40" value="<?php echo $defaultEmail; ?>"/>
    <br /><i>Your PayPal email address (this is the account where the payments will go to)</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Use PayPal Profile Based Shipping
    </td><td align="left">
    <input name="eStore_paypal_profile_shipping" type="checkbox"<?php if(get_option('eStore_paypal_profile_shipping')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Check this if you want to use <a href="https://cms.paypal.com/us/cgi-bin/?&cmd=_render-content&content_ID=developer/e_howto_html_ProfileAndTools#id08A9EF00IQY" target="_blank">PayPal profile based shipping</a>. Using this will ignore any other shipping options that you have specified in this plugin.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Customize the Return Button Text
    </td><td align="left">
    <input name="eStore_paypal_return_button_text" type="text" size="40" value="<?php echo get_option('eStore_paypal_return_button_text'); ?>"/>
    <br /><i>Use this if you want to customize the return button text that is shown to your customers on the payment confirmation page on PayPal. The button text is "Return To Merchant" by default</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Custom Checkout Page Style Name
    </td><td align="left">
    <input name="eStore_paypal_co_page_style" type="text" size="40" value="<?php echo get_option('eStore_paypal_co_page_style'); ?>"/>
    <br /><i>Specify the page style name here if you want to customize the paypal checkout page with custom page style otherwise leave this field empty.</i><br /><br />
    </td></tr>
    
    <tr valign="top"><td width="25%" align="left">
    PDT Identity Token
    </td><td align="left">
    <input name="eStore_paypal_pdt_token" type="text" size="100" value="<?php echo get_option('eStore_paypal_pdt_token'); ?>"/>
    <br /><i>Specify your identity token in the text field above if you want to <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=499" target="_blank">display the transaction result on the Thank You page</a>. If you need help finding your token then <a href="https://www.paypaltech.com/PDTGen/PDTtokenhelp.htm" target="_blank">click here</a>.</i><br /><br />
    </td></tr>
        
    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">Manual Checkout Settings</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Use Manual Payment Option
    </td><td align="left">
    <input name="eStore_use_manual_gateway" type="checkbox"<?php if(get_option('eStore_use_manual_gateway')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the customers will be able to checkout using a Manual process.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Notification Email Address
    </td><td align="left">
    <input name="eStore_manual_notify_email" type="text" size="40" value="<?php echo get_option('eStore_manual_notify_email'); ?>"/>
    <br /><i>This is where the email containg the products and customer details will be sent to when a customer checks out using the manual checkout method.</i><br /><br />
    </td></tr>

	<tr valign="top"><td width="25%" align="left">
	Directions for the Customer
	</td><td align="left">
	<textarea name="eStore_manual_co_cust_direction" rows="6" cols="50"><?php echo get_option('eStore_manual_co_cust_direction'); ?></textarea>
	<br /><i>You can put direction for payment here. The customer will receive this in the order confirmation email. The followiong tags can be used in this field {first_name}, {last_name}, {payer_email}, {transaction_id}.</i><br /><br />
	</td></tr>

    <tr valign="top"><td width="25%" align="left">
    Return URL
    </td><td align="left">
    <input name="eStore_manual_return_url" type="text" size="40" value="<?php echo get_option('eStore_manual_return_url'); ?>"/>
    <br /><i>This is where the customers will be redirected to after they complete the manual checkout.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Automatically Update Customer & Products Database
    </td><td align="left">
    <input name="eStore_manual_co_auto_update_db" type="checkbox"<?php if(get_option('eStore_manual_co_auto_update_db')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Usually the customers and products database are updated after a confirmed payment. In the event of manual payment the plugin has no way of verifying the payment. Checking this option will update the customers and products database after the manual checkout submission. Alternatively, you can uncheck this option and manually enter the data after you receive the money from the customer.</i><br /><br />
    </td></tr>
    
    <tr valign="top"><td width="25%" align="left">
    Perform Autoresponder Signup
    </td><td align="left">
    <input name="eStore_manual_co_do_autoresponder_signup" type="checkbox"<?php if(get_option('eStore_manual_co_do_autoresponder_signup')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Usually autoresponder signup is performed for a confirmed payment. Check this option if you want to perform autoresponder signup as soon as the customer submits the manual checkout form.</i><br /><br />
    </td></tr>
        
    <tr valign="top"><td width="25%" align="left">
    Automatically Award Affiliate Commission
    </td><td align="left">
    <input name="eStore_manual_co_give_aff_commission" type="checkbox"<?php if(get_option('eStore_manual_co_give_aff_commission')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the affiliate commission will be automatically awarded to the appropriate affiliate after the manual checkout submission.</i><br /><br />
    </td></tr>
    
    <tr valign="top"><td width="25%" align="left">
    Send Product Download Links in the Email
    </td><td align="left">
    <input name="eStore_manual_co_give_download_links" type="checkbox"<?php if(get_option('eStore_manual_co_give_download_links')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Usually the product download links are given to the customer after a confirmed payment. In the event of manual payment the plugin has no way of verifying the payment so it is preferred that you manually give out the links after you receive the payment. Checking this option will force the plugin to send out download links in the manual checkout email that the customer receives after checkout.</i><br /><br />
    </td></tr>    
    
    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">2Checkout Settings</label></h3>
	<div class="inside">

	<strong><i>(Please make sure to setup your 2Checkout accout by following <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=1075" target="_blank">this instruction</a> first)</i></strong>
	<br /><br />
	
    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Use 2Checkout Payment Gateway
    </td><td align="left">
    <input name="eStore_use_2co_gateway" type="checkbox"<?php if(get_option('eStore_use_2co_gateway')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the customers will be able to checkout using <a href="http://www.2checkout.com/?affiliate=1385310" target="_blank">2Checkout</a>.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    2Checkout Vendor ID
    </td><td align="left">
    <input name="eStore_2co_vendor_id" type="text" size="20" value="<?php echo get_option('eStore_2co_vendor_id'); ?>"/>
    <br /><i>Your 2Checkout vendor ID.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    2Checkout Secret Word
    </td><td align="left">
    <input name="eStore_2co_secret_word" type="text" size="20" value="<?php echo get_option('eStore_2co_secret_word'); ?>"/>
    <br /><i>Your 2Checkout Secret Word. <a href="http://www.2checkout.com/community/blog/knowledge-base/suppliers/tech-support/3rd-party-carts/md5-hash-checking/where-do-i-set-up-the-secret-word" target="_blank">How to find the secret word?</a></i><br /><br />
    </td></tr>

    </table>
    </div></div>

<?php if(function_exists('wp_eStore_authorize_net_install')){ ?>
	<div class="postbox">
	<h3><label for="title">Authorize.net Settings</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="left">
    Use Authorize.net Payment Gateway
    </td><td align="left">
    <input name="eStore_use_authorize_gateway" type="checkbox"<?php if(get_option('eStore_use_authorize_gateway')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the customers will be able to checkout using <a href="http://www.authorize.net/" target="_blank">Authorize.net</a>.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Authorize.net Login
    </td><td align="left">
    <input name="eStore_authorize_login" type="text" size="20" value="<?php echo get_option('eStore_authorize_login'); ?>"/>
    <br /><i>API login ID for the payment gateway account.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Authorize.net Transaction Key
    </td><td align="left">
    <input name="eStore_authorize_tx_key" type="text" size="20" value="<?php echo get_option('eStore_authorize_tx_key'); ?>"/>
    <br /><i>Transaction key obtained from the Authorize.net Merchant Interface.</i><br /><br />
    </td></tr>

    </table>
    </div></div>
<?php } ?>
    
    <div class="submit">
        <input type="submit" name="info_update" value="<?php _e('Update'); ?> &raquo;" />
    </div>
    </form>
    <?php
}

function wp_eStore_autoresponder_settings()
{
    //echo "<br />Automatically sign up your customers to your AWeber List<br />";
    if (isset($_POST['info_update']))
    {
        update_option('eStore_enable_aweber_int', ($_POST['eStore_enable_aweber_int']=='1') ? '1':'' );
        update_option('eStore_aweber_list_name', trim($_POST["eStore_aweber_list_name"]));
        
        update_option('eStore_use_mailchimp', ($_POST['eStore_use_mailchimp']=='1') ? '1':'' );
        update_option('eStore_enable_global_chimp_int', ($_POST['eStore_enable_global_chimp_int']=='1') ? '1':'' );
        update_option('eStore_chimp_list_name', trim($_POST["eStore_chimp_list_name"]));
        update_option('eStore_chimp_api_key', trim($_POST["eStore_chimp_api_key"]));
        update_option('eStore_chimp_user_name', trim($_POST["eStore_chimp_user_name"]));
        update_option('eStore_chimp_pass', trim($_POST["eStore_chimp_pass"]));

        update_option('eStore_use_getResponse', ($_POST['eStore_use_getResponse']=='1') ? '1':'' );
        update_option('eStore_enable_global_getResponse_int', ($_POST['eStore_enable_global_getResponse_int']=='1') ? '1':'' );
        update_option('eStore_getResponse_campaign_name', trim($_POST["eStore_getResponse_campaign_name"]));
        update_option('eStore_getResponse_api_key', trim($_POST["eStore_getResponse_api_key"]));
        
        update_option('eStore_enable_infusionsoft_int', ($_POST['eStore_enable_infusionsoft_int']=='1') ? '1':'' );
        update_option('eStore_infusionsoft_group_number', (string)$_POST["eStore_infusionsoft_group_number"]);
        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Autoresponder Options Updated!';
        echo '</strong></p></div>';
    }

	?>
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="info_update" id="info_update" value="true" />

	<div class="postbox">
	<h3><label for="title">AWeber Settings (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=615" target="_blank">AWeber Integration Instructions</a>)</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    <strong>Global AWeber Signup:</strong>
    </td><td align="left">
    <input name="eStore_enable_aweber_int" type="checkbox"<?php if(get_option('eStore_enable_aweber_int')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will automatically sign up the customer of every transaction to your AWeber List specified below. If you want to selectively signup customers on a per product basis then use the Autoresponder settings of that product.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>AWeber List Name:</strong>
    </td><td align="left">
    <input name="eStore_aweber_list_name" type="text" size="30" value="<?php echo get_option('eStore_aweber_list_name'); ?>"/>
    <br /><i>The name of the AWeber list where the customers will be signed up to (eg. listname@aweber.com)</i><br /><br />
    </td></tr>

    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">MailChimp Settings (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=753" target="_blank">MailChimp Integration Instructions</a>)</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    <strong>Use MailChimp AutoResponder:</strong>
    </td><td align="left">
    <input name="eStore_use_mailchimp" type="checkbox"<?php if(get_option('eStore_use_mailchimp')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Check this if you want to use MailChimp Autoresponder service.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>Global MailChimp Integration:</strong>
    </td><td align="left">
    <input name="eStore_enable_global_chimp_int" type="checkbox"<?php if(get_option('eStore_enable_global_chimp_int')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will automatically sign up the customer of every transaction to your MailChimp List specified below. If you want to selectively signup customers on a per product basis then use the Autoresponder settings of that product.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>MailChimp List Name:</strong>
    </td><td align="left">
    <input name="eStore_chimp_list_name" type="text" size="30" value="<?php echo get_option('eStore_chimp_list_name'); ?>"/>
    <br /><i>The name of the MailChimp list where the customers will be signed up to (e.g. Customer List)</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>MailChimp API Key:</strong>
    </td><td align="left">
    <input name="eStore_chimp_api_key" type="text" size="50" value="<?php echo get_option('eStore_chimp_api_key'); ?>"/>
    <br /><i>The API Key of your MailChimp account (can be found under the "Account" tab). If you do not have the API Key then you can use the username and password option below.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    Or
    <br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>MailChimp Username:</strong>
    </td><td align="left">
    <input name="eStore_chimp_user_name" type="text" size="30" value="<?php echo get_option('eStore_chimp_user_name'); ?>"/>
    <br /><i>The username of your MailChimp account</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>MailChimp Password:</strong>
    </td><td align="left">
    <input name="eStore_chimp_pass" type="password" size="30" value="<?php echo get_option('eStore_chimp_pass'); ?>"/>
    <br /><i>The password of your MailChimp account</i><br /><br />
    </td></tr>

    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">GetResponse Settings (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=898" target="_blank">GetResponse Integration Instructions</a>)</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    <strong>Use GetResponse AutoResponder:</strong>
    </td><td align="left">
    <input name="eStore_use_getResponse" type="checkbox"<?php if(get_option('eStore_use_getResponse')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Check this if you want to use GetResponse.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>Global GetResponse Integration:</strong>
    </td><td align="left">
    <input name="eStore_enable_global_getResponse_int" type="checkbox"<?php if(get_option('eStore_enable_global_getResponse_int')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will automatically sign up the customer of every transaction to your GetResponse campaign specified below. If you want to selectively signup customers on a per product basis then use the Autoresponder settings of that product.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>GetResponse Campaign Name:</strong>
    </td><td align="left">
    <input name="eStore_getResponse_campaign_name" type="text" size="30" value="<?php echo get_option('eStore_getResponse_campaign_name'); ?>"/>
    <br /><i>The name of the GetResponse campaign where the customers will be signed up to (e.g. marketing)</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>GetResponse API Key:</strong>
    </td><td align="left">
    <input name="eStore_getResponse_api_key" type="text" size="50" value="<?php echo get_option('eStore_getResponse_api_key'); ?>"/>
    <br /><i>The API Key of your GetResponse account (can be found inside your GetResponse Account).</i><br /><br />
    </td></tr>

    </table>
    </div></div>
    
	<div class="postbox">
	<h3><label for="title">Infusionsoft Settings (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=727" target="_blank">Infusionsoft Integration Instructions</a>)</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    <strong>Global Infusionsoft Signup:</strong>
    </td><td align="left">
    <input name="eStore_enable_infusionsoft_int" type="checkbox"<?php if(get_option('eStore_enable_infusionsoft_int')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>When checked the plugin will automatically sign up the customer of every transaction to your Infusionsoft group specified below.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    <strong>Infusionsoft Group Number:</strong>
    </td><td align="left">
    <input name="eStore_infusionsoft_group_number" type="text" size="30" value="<?php echo get_option('eStore_infusionsoft_group_number'); ?>"/>
    <br /><i>The group number where the customers will be signed up to(eg. 45)</i><br /><br />
    </td></tr>

    </table>
    </div></div>

    <div class="submit">
        <input type="submit" name="info_update" value="<?php _e('Update'); ?> &raquo;" />
    </div>
    </form>
    <?php
}

function wp_eStore_third_party_settings()
{
    if (isset($_POST['info_update']))
    {
        update_option('eStore_enable_wishlist_int', ($_POST['eStore_enable_wishlist_int']=='1') ? '1':'' );
        update_option('eStore_wishlist_post_url', trim($_POST["eStore_wishlist_post_url"]));
        update_option('eStore_wishlist_secret_word', trim($_POST["eStore_wishlist_secret_word"]));
        
        update_option('eStore_ngg_template_product_id', trim($_POST["eStore_ngg_template_product_id"]));   

        update_option('eStore_enable_analytics_tracking', ($_POST['eStore_enable_analytics_tracking']=='1') ? '1':'' );
        
        update_option('eStore_memberwing_ipn_post_url', trim($_POST["eStore_memberwing_ipn_post_url"])); 

        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Options Updated!';
        echo '</strong></p></div>';
    }

	?>
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="info_update" id="info_update" value="true" />

	<div class="postbox">
	<h3><label for="title">WishList Integration Settings (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=448" target="_blank">WishList Integration Instructions</a>)</label></h3>
	<div class="inside">

    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    Enable Wishlist Members Integration
    </td><td align="left">
    <input name="eStore_enable_wishlist_int" type="checkbox"<?php if(get_option('eStore_enable_wishlist_int')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Check this checkbox if you want to integrate with the WishList Members plugin.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    WishList Members POST URL
    </td><td align="left">
    <input name="eStore_wishlist_post_url" type="text" size="100" value="<?php echo get_option('eStore_wishlist_post_url'); ?>"/>
    <br /><i>Get this value from your WishList Members plugin's Integration tab (Select Generic Integration)</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="left">
    WishList Members Secret Word
    </td><td align="left">
    <input name="eStore_wishlist_secret_word" type="text" size="50" value="<?php echo get_option('eStore_wishlist_secret_word'); ?>"/>
    <br /><i>Get this value from your WishList Members plugin's Integration tab (Select Generic Integration)</i><br />
    </td></tr>
    </table>
    </div></div>
    
	<div class="postbox">
	<h3><label for="title">NextGen Gallery Settings (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=805" target="_blank">NextGen Gallery Integration Instructions</a>)</label></h3>
	<div class="inside">
    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    Product ID to be Used as a Template
    </td><td align="left">
    <input name="eStore_ngg_template_product_id" type="text" size="3" value="<?php echo get_option('eStore_ngg_template_product_id'); ?>"/>
    <br /><i>Configure one product with the price, variation, shipping etc options that you prefer then use the ID of that product here. The eStore will use the information from this product when placing "Buy" button under the gallery images.</i><br /><br />
    </td></tr>
    
    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">Google Analytics Tracking (<a href="http://www.tipsandtricks-hq.com/ecommerce/?p=850" target="_blank">Analytics E-Commerce Tracking Overview</a>)</label></h3>
	<div class="inside">
    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    Enable Google Analytics Tracking
    </td><td align="left">
    <input name="eStore_enable_analytics_tracking" type="checkbox"<?php if(get_option('eStore_enable_analytics_tracking')!='') echo ' checked="checked"'; ?> value="1"/>
    <br /><i>Check this checkbox if you want to integrate Google Analytics e-commerce tracking for products sold through WP eStore.</i><br /><br />
    </td></tr>        
    
    </table>
    </div></div>

	<div class="postbox">
	<h3><label for="title">Memberwing Integration Settings</label></h3>
	<div class="inside">
    <table width="100%" border="0" cellspacing="0" cellpadding="6">

    <tr valign="top"><td width="25%" align="left">
    PayPal IPN Post URL
    </td><td align="left">
    <input name="eStore_memberwing_ipn_post_url" type="text" size="100" value="<?php echo get_option('eStore_memberwing_ipn_post_url'); ?>"/>
    <br /><i>If you want to integrate the Memberwing plugin with eStore then get the IPN Post URL from your Memberwing plugin and specify it here.</i><br /><br />
    </td></tr>
    
    </table>
    </div></div>

    <div class="submit">
        <input type="submit" name="info_update" value="<?php _e('Update'); ?> &raquo;" />
    </div>
    </form>
    <?php
}

function show_wp_digi_cart_settings_page ()
{	
	global $eStore_debug_manager;
	if(isset($_POST['reset_logfiles'])) {
	// Reset the debug log files...
		$eStore_debug_manager->reset_logfiles();
        	echo '<div id="message" class="updated fade"><p><strong>Debug log files have been reset!</strong></p></div>';
	}
    if (isset($_POST['info_update']))
    {
        update_option('eStore_cart_language', (string)$_POST["eStore_cart_language"]);
        update_option('cart_payment_currency', (string)$_POST["cart_payment_currency"]);
        update_option('cart_currency_symbol', (string)$_POST["cart_currency_symbol"]);
        //update_option('eStore_paypal_profile_shipping', ($_POST['eStore_paypal_profile_shipping']!='') ? 'checked="checked"':'' );        
        update_option('eStore_products_per_page', (string)$_POST["eStore_products_per_page"]);
        //update_option('cart_paypal_email', (string)$_POST["cart_paypal_email"]);
        update_option('addToCartButtonName', (string)$_POST["addToCartButtonName"]);
        update_option('soldOutImage', (string)$_POST["soldOutImage"]);
        update_option('wp_eStore_widget_title', stripslashes((string)$_POST["wp_eStore_widget_title"]));
        update_option('wp_cart_title', stripslashes((string)$_POST["wp_cart_title"]));
        update_option('wp_cart_empty_text', (string)$_POST["wp_cart_empty_text"]);
        update_option('cart_return_from_paypal_url', (string)$_POST["cart_return_from_paypal_url"]);
        update_option('cart_cancel_from_paypal_url', (string)$_POST["cart_cancel_from_paypal_url"]);
        update_option('eStore_products_page_url', (string)$_POST["eStore_products_page_url"]);
        update_option('eStore_display_continue_shopping', ($_POST['eStore_display_continue_shopping']!='') ? 'checked="checked"':'' );
        update_option('eStore_checkout_page_url', (string)$_POST["eStore_checkout_page_url"]);
        update_option('eStore_auto_checkout_redirection', ($_POST['eStore_auto_checkout_redirection']!='') ? 'checked="checked"':'' );
        update_option('eStore_auto_cart_anchor', ($_POST['eStore_auto_cart_anchor']!='') ? 'checked="checked"':'' );
        update_option('eStore_shopping_cart_image_hide', ($_POST['eStore_shopping_cart_image_hide']!='') ? 'checked="checked"':'' );
        update_option('eStore_show_t_c', ($_POST['eStore_show_t_c']!='') ? 'checked="checked"':'' );
        update_option('eStore_show_t_c_for_buy_now', ($_POST['eStore_show_t_c_for_buy_now']!='') ? 'checked="checked"':'' );
        update_option('eStore_t_c_url', (string)$_POST["eStore_t_c_url"]); 
        update_option('eStore_show_compact_cart', ($_POST['eStore_show_compact_cart']!='') ? 'checked="checked"':'' ); 
        update_option('eStore_enable_fancy_redirection_on_checkout', ($_POST['eStore_enable_fancy_redirection_on_checkout']!='') ? 'checked="checked"':'' );              
        update_option('eStore_enable_lightbox_effect', ($_POST['eStore_enable_lightbox_effect']!='') ? 'checked="checked"':'' );
        update_option('eStore_enable_smart_thumb', ($_POST['eStore_enable_smart_thumb']=='1') ? '1':'' );
                                           
        update_option('eStore_base_shipping', (string)$_POST["eStore_base_shipping"]);
        update_option('eStore_shipping_variation', (string)$_POST["eStore_shipping_variation"]);
        update_option('eStore_always_display_shipping_variation', ($_POST['eStore_always_display_shipping_variation']=='1') ? '1':'' );
        update_option('eStore_enable_tax', ($_POST['eStore_enable_tax']!='') ? 'checked="checked"':'' );
        update_option('eStore_global_tax_rate', (string)$_POST["eStore_global_tax_rate"]);
        
        update_option('eStore_secondary_currency_code', (string)$_POST["eStore_secondary_currency_code"]);
        update_option('eStore_secondary_currency_symbol', (string)$_POST["eStore_secondary_currency_symbol"]);
        update_option('eStore_secondary_currency_conversion_rate', (string)$_POST["eStore_secondary_currency_conversion_rate"]);
        
        update_option('eStore_random_code', (string)$_POST["eStore_random_code"]);
        update_option('eStore_download_url_life', (string)$_POST["eStore_download_url_life"]);
        update_option('eStore_download_url_limit_count', (string)$_POST["eStore_download_url_limit_count"]);
        //update_option('eStore_download_enable_ip_address_lock', ($_POST['eStore_download_enable_ip_address_lock']=='1') ? '1':'' );
        update_option('eStore_download_script', (string)$_POST["eStore_download_script"]);
        
        update_option('eStore_ppv_verification_failed_url', (string)$_POST["eStore_ppv_verification_failed_url"]);       
        
        update_option('eStore_auto_product_delivery', ($_POST['eStore_auto_product_delivery']!='') ? 'checked="checked"':'' );
        update_option('eStore_display_tx_result', ($_POST['eStore_display_tx_result']!='') ? 'checked="checked"':'' );       
        update_option('eStore_strict_email_check', ($_POST['eStore_strict_email_check']!='') ? 'checked="checked"':'' );
        update_option('eStore_auto_customer_removal', ($_POST['eStore_auto_customer_removal']!='') ? 'checked="checked"':'' );

        update_option('eStore_use_wp_mail', ($_POST['eStore_use_wp_mail']!='') ? 'checked="checked"':'' );
        update_option('eStore_send_buyer_email', ($_POST['eStore_send_buyer_email']!='') ? 'checked="checked"':'' );
        update_option('eStore_download_email_address', (string)$_POST["eStore_download_email_address"]);
        update_option('eStore_buyer_email_subj', stripslashes((string)$_POST["eStore_buyer_email_subj"]));
        update_option('eStore_buyer_email_body', stripslashes((string)$_POST["eStore_buyer_email_body"]));
        update_option('eStore_notify_email_address', (string)$_POST["eStore_notify_email_address"]);
        update_option('eStore_seller_email_subj', stripslashes((string)$_POST["eStore_seller_email_subj"]));
        update_option('eStore_seller_email_body', stripslashes((string)$_POST["eStore_seller_email_body"]));
        
	// Update debug manager related settings...
	eStore_dbgmgradm::settings_menu_post($_POST['eStore_cart_enable_debug'], $_POST['eStore_cart_enable_sandbox']);
        
        wp_eStore_clear_cache();
        
        echo '<div id="message" class="updated fade">';
        echo '<p><strong>Options Updated!</strong></p></div>';
    }
    $cart_language = get_option('eStore_cart_language');
    if (empty($cart_language)) $cart_language = 'eng.php';

    $defaultCurrency = get_option('cart_payment_currency');
    if (empty($defaultCurrency)) $defaultCurrency = 'USD';

    $defaultSymbol = get_option('cart_currency_symbol');
    if (empty($defaultSymbol)) $defaultSymbol = '$';

	$eStore_products_per_page = get_option('eStore_products_per_page');
	if (empty($eStore_products_per_page)) $eStore_products_per_page = '20';
	
    //$notify_url =  get_option('eStore_notify_url');
    $return_url =  get_option('cart_return_from_paypal_url');
    $cancel_url =  get_option('cart_cancel_from_paypal_url');
    
    $eStore_products_page_url =  get_option('eStore_products_page_url');
    $eStore_checkout_page_url = get_option('eStore_checkout_page_url');

    $addcart = get_option('addToCartButtonName');
    if (empty($addcart)) $addcart = 'Add to Cart';

    $soldOut = get_option('soldOutImage');
    if (empty($soldOut)) $soldOut = WP_ESTORE_URL.'/images/sold_out.png';

	$title = get_option('wp_cart_title');
	//if (empty($title)) $title = 'Your Shopping Cart';
	$widget_title = get_option('wp_eStore_widget_title');

	$emptyCartText = get_option('wp_cart_empty_text');

//    if (get_option('eStore_paypal_profile_shipping'))
//        $eStore_paypal_profile_shipping = 'checked="checked"';
//    else
//        $eStore_paypal_profile_shipping = '';

    if (get_option('eStore_display_continue_shopping'))
        $eStore_display_continue_shopping = 'checked="checked"';
    else
        $eStore_display_continue_shopping = '';

    if (get_option('eStore_auto_checkout_redirection'))
        $eStore_auto_checkout_redirection = 'checked="checked"';
    else
        $eStore_auto_checkout_redirection = '';
        
    if (get_option('eStore_auto_cart_anchor'))
        $eStore_cart_anchor = 'checked="checked"';
    else
        $eStore_cart_anchor = '';

    if (get_option('eStore_shopping_cart_image_hide'))
        $eStore_cart_image_hide = 'checked="checked"';
    else
        $eStore_cart_image_hide = '';
        
    if (get_option('eStore_show_t_c'))
        $eStore_show_t_c = 'checked="checked"';
    else
        $eStore_show_t_c = '';   
        
    if (get_option('eStore_show_t_c_for_buy_now'))
        $eStore_show_t_c_for_buy_now = 'checked="checked"';
    else
        $eStore_show_t_c_for_buy_now = '';          
        
    $eStore_t_c_url = get_option('eStore_t_c_url');    

    if (get_option('eStore_show_compact_cart'))
        $eStore_show_compact_cart = 'checked="checked"';
    else
        $eStore_show_compact_cart = '';

    if (get_option('eStore_enable_fancy_redirection_on_checkout'))
        $eStore_enable_fancy_redirection_on_checkout = 'checked="checked"';
    else
        $eStore_enable_fancy_redirection_on_checkout = '';
                
    if (get_option('eStore_enable_lightbox_effect'))
        $eStore_enable_lightbox_effect = 'checked="checked"';
    else
        $eStore_enable_lightbox_effect = '';
        
    if (get_option('eStore_enable_smart_thumb'))
        $eStore_enable_smart_thumb = 'checked="checked"';
    else
        $eStore_enable_smart_thumb = '';
        
	$baseShipping = get_option('eStore_base_shipping');
	if (empty($baseShipping)) $baseShipping = '0';
	
	$shippingVar = get_option('eStore_shipping_variation');
	if(get_option('eStore_always_display_shipping_variation')!='') 
		$always_display_shipping_var = ' checked="checked"';

    if (get_option('eStore_enable_tax'))
        $eStore_enable_tax = 'checked="checked"';
    else
        $eStore_enable_tax = '';	
                       
    if (get_option('eStore_auto_product_delivery'))
        $eStore_auto_delivery = 'checked="checked"';
    else
        $eStore_auto_delivery = '';

    $eStore_random_code = get_option('eStore_random_code');
    if (empty($eStore_random_code)) $eStore_random_code = 'AZ#Ui$335UBSD)AminOc32j90';

    $eStore_download_url_limit_count = get_option('eStore_download_url_limit_count');
    //if (empty($eStore_download_url_limit_count)) $eStore_download_url_limit_count = '3';
          
    $eStore_download_url_life = get_option('eStore_download_url_life');
    if (empty($eStore_download_url_life)) $eStore_download_url_life = '24';
    
    $eStore_download_script = get_option('eStore_download_script');
    if (empty($eStore_download_script)) 
    {
    	$eStore_download_script = WP_ESTORE_URL."/";
    	update_option('eStore_download_script', $eStore_download_script);
    }

    if (get_option('eStore_strict_email_check'))
        $eStore_strict_email_check = 'checked="checked"';
    else
        $eStore_strict_email_check = '';

    if (get_option('eStore_auto_customer_removal'))
        $eStore_auto_customer_removal = 'checked="checked"';
    else
        $eStore_auto_customer_removal = '';

    if (get_option('eStore_display_tx_result'))
        $eStore_display_tx_result = 'checked="checked"';
    else
        $eStore_display_tx_result = '';

    if (get_option('eStore_use_wp_mail'))
        $eStore_use_wp_mail = 'checked="checked"';
    else
        $eStore_use_wp_mail = '';

    if (get_option('eStore_send_buyer_email'))
        $eStore_send_buyer_email = 'checked="checked"';
    else
        $eStore_send_buyer_email = '';

    $eStore_download_email_address = get_option('eStore_download_email_address');
    if (empty($eStore_download_email_address))
    {
    	$eStore_download_email_address = get_bloginfo('name')." <sales@your-domain.com>";//'sales@your-domain.com';
    }

    $eStore_buyer_email_subj = get_option('eStore_buyer_email_subj');
    if (empty($eStore_buyer_email_subj)) $eStore_buyer_email_subj = "Thank you for the purchase";

    $eStore_buyer_email_body = get_option('eStore_buyer_email_body');
    if (empty($eStore_buyer_email_body))
    {
		$eStore_buyer_email_body = "Dear {first_name} {last_name}".
			  "\n\nThank you for your purchase!".
			  "\n{product_details}".
			  "\n\nAny items to be shipped will be processed as soon as possible, any items that can be downloaded can be downloaded using the encrypted links below.".
			  "\n{product_link}".
			  "\n\nThanks";
    }

    $eStore_notify_email_address = get_option('eStore_notify_email_address');
    if (empty($eStore_notify_email_address)) $eStore_notify_email_address = get_bloginfo('admin_email');

	$eStore_seller_email_subj = get_option('eStore_seller_email_subj');
    if (empty($eStore_seller_email_subj)) $eStore_seller_email_subj = "Notification of product sale";

    $eStore_seller_email_body = get_option('eStore_seller_email_body');
    if (empty($eStore_seller_email_body))
    {
		$eStore_seller_email_body = "Dear Seller".
				"\n\nThis mail is to notify you of a product sale. Product Name: {product_name} Product ID: {product_id}".
				"\nThe sale was made to {first_name} {last_name} ({payer_email})".
				"\n\nThanks";
    }

	?> 	

 	<p>For information, updates and detailed documentation, please visit the <a href="http://www.tipsandtricks-hq.com/ecommerce/wp-estore-documentation" target="_blank">WP eStore Documentation Site</a> or
    The main plugin page <a href="http://www.tipsandtricks-hq.com/?p=1059" target="_blank">WP eStore</a></p>

	<div class="postbox">
	<h3><label for="title">Quick Usage Guide</label></h3>
	<div class="inside">

	<p>1. First add products to the database through the 'Add/Edit Products' interface. Products can be modified through the 'Manage Products' interface.
    <p>2. To add the 'Add to Cart' button simply add the shortcode <strong>[wp_eStore:product_id:PRODUCT-ID:end]</strong> to a post or page next to the product. Replace PRODUCT-ID with the actual product id. Product IDs for all your products can be found in the 'Manage Products' section</p>
	<p>3. To add the shopping cart to a post or page (eg. checkout page) simply add the shortcode <strong>[wp_eStore_cart_when_not_empty]</strong> to a post or page or use the sidebar widget to add the shopping cart to the sidebar.</p>
	<p><strong>Check out the <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=460" target="_blank">shortcodes and function reference page</a> for a full list of usable shortcodes.</strong></p>
    </div></div>
    
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<!--    <input type="hidden" name="info_update" id="info_update" value="true" />-->

 	<?php
echo '
	<div class="postbox">
	<h3><label for="title">General Shopping Cart Settings</label></h3>
	<div class="inside">';

echo '
<table class="form-table">';

?>
<tr valign="top">
<th scope="row">Shopping Cart Language</th>
<td>
<select name="eStore_cart_language">
<option value="eng.php" <?php if($cart_language=="eng.php")echo 'selected="selected"';?>><?php echo "English" ?></option>
<option value="i18n.php" <?php if($cart_language=="i18n.php")echo 'selected="selected"';?>><?php echo "i18n" ?></option>
<option value="ita.php" <?php if($cart_language=="ita.php")echo 'selected="selected"';?>><?php echo "Italian" ?></option>
<option value="spa.php" <?php if($cart_language=="spa.php")echo 'selected="selected"';?>><?php echo "Spanish" ?></option>
<option value="cat.php" <?php if($cart_language=="cat.php")echo 'selected="selected"';?>><?php echo "Catalan" ?></option>
<option value="ger.php" <?php if($cart_language=="ger.php")echo 'selected="selected"';?>><?php echo "German" ?></option>
<option value="nld.php" <?php if($cart_language=="nld.php")echo 'selected="selected"';?>><?php echo "Dutch" ?></option>
<option value="fr.php" <?php if($cart_language=="fr.php")echo 'selected="selected"';?>><?php echo "French" ?></option>
<option value="heb.php" <?php if($cart_language=="heb.php")echo 'selected="selected"';?>><?php echo "Hebrew" ?></option>
</select>
<?php

// Compute the $wp_home_dir configuration hint.
// -- The Assurer, 2010-09-18.
$wp_home_dir = '';
$current_eStore_script_filepath_parts = explode('/', $_SERVER['PHP_SELF']);
while(($current_eStore_script_filepath_parts[0] <> 'wp-admin') AND (count($current_eStore_script_filepath_parts) > 1)) {
	$wp_home_dir .= '/'.array_shift($current_eStore_script_filepath_parts);
}
$wp_home_dir = trim($wp_home_dir, '/');

echo '
<br />Select a language that you want your shopping cart to be displayed in (Contact me for other language options).</td>
</tr>
<tr valign="top">
<th scope="row">Shopping Cart Widget Title</th>
<td><input type="text" name="wp_eStore_widget_title" value="'.$widget_title.'"  /></td>
</tr>
<tr valign="top">
<th scope="row">Shopping Cart Header</th>
<td><input type="text" name="wp_cart_title" value="'.$title.'"  /><br />Leave empty if you do not want the shopping cart header to appear</td>
</tr>
<tr valign="top">
<th scope="row">Text/Image to show when cart is empty</th>
<td><input type="text" name="wp_cart_empty_text" value="'.$emptyCartText.'" size="70" /><br />To use a cusomized image for the Empty Cart Display instead of plain text, simply enter the URL of the image file.</td>
</tr>
<tr valign="top">
<th scope="row">Currency*</th>
<td><input type="text" name="cart_payment_currency" value="'.$defaultCurrency.'" size="3" /> (e.g. USD, EUR, GBP, AUD)</td>
</tr>
<tr valign="top">
<th scope="row">Currency Symbol*</th>
<td><input type="text" name="cart_currency_symbol" value="'.$defaultSymbol.'" size="3" /> (e.g. $, &#163;, &#8364;)
</td>
</tr>

<tr valign="top">
<th scope="row">Products Per Page Limit</th>
<td><input type="text" name="eStore_products_per_page" value="'.$eStore_products_per_page.'" size="3" /> (eg. 20) This is the number of products that will be displayed per page when displaying the full list of products on a page.</td>
</tr>

<tr valign="top">
<th scope="row">Add to Cart button text or Image</th>
<td><input type="text" name="addToCartButtonName" value="'.$addcart.'" size="100" /><br />To use a cusomized image as the button simply enter the URL of the image file. eg. http://www.your-domain.com/wp-content/plugins/wp-cart-for-digital-products/images/buy_now_button.png</td>
</tr>

<tr valign="top">
<th scope="row">Sold Out Image</th>
<td><input type="text" name="soldOutImage" value="'.$soldOut.'" size="100" /><br />When selling limited copies of a product, this image will be shown instead of the payment button when the product is sold out.</td>
</tr>

<tr valign="top">
<th scope="row">Return URL</th>
<td><input type="text" name="cart_return_from_paypal_url" value="'.$return_url.'" size="100" /><br />This is the URL the customer will be redirected to after a successful payment. Enter the URL of your Thank You page here.</td>
</tr>

<tr valign="top">
<th scope="row">Cancel URL</th>
<td><input type="text" name="cart_cancel_from_paypal_url" value="'.$cancel_url.'" size="100" /><br />A URL to which the payer browser is redirected if payment is cancelled.</td>
</tr>

<tr valign="top">
<th scope="row">Products Page</th>
<td><input type="text" name="eStore_products_page_url" value="'.$eStore_products_page_url.'" size="100" /><br />If used, the shopping cart widget will display a link to this page when cart is empty</td>
</tr>

<tr valign="top">
<th scope="row">Display Continue Shopping Link</th>
<td><input type="checkbox" name="eStore_display_continue_shopping" value="1" '.$eStore_display_continue_shopping.' /><br />If checked the shopping cart will display a continue shopping link. There must be a URL in the "Products Page" field for this to work.</td>
</tr>

<tr valign="top">
<th scope="row">Checkout Page</th>
<td><input type="text" name="eStore_checkout_page_url" value="'.$eStore_checkout_page_url.'" size="100" /></td>
</tr>

<tr valign="top">
<th scope="row">Automatic redirection to checkout page</th>
<td><input type="checkbox" name="eStore_auto_checkout_redirection" value="1" '.$eStore_auto_checkout_redirection.' /><br />If checked the visitor will be redirected to the Checkout page after a product is added to the cart. You must enter a URL in the Checkout Page field for this to work.</td>
</tr>

<tr valign="top">
<th scope="row">Allow Shopping Cart Anchor</th>
<td><input type="checkbox" name="eStore_auto_cart_anchor" value="1" '.$eStore_cart_anchor.' /><br />If checked the visitor will be taken to the Shopping cart anchor point within the page after a product Add, Delete or Quantity Change.</td>
</tr>

<tr valign="top">
<th scope="row">Hide Shopping Cart Image</th>
<td><input type="checkbox" name="eStore_shopping_cart_image_hide" value="1" '.$eStore_cart_image_hide.' /><br />If checked the shopping cart image in the title will not be shown.</td>
</tr>

<tr valign="top">
<th scope="row">Terms & Cond. Page URL</th>
<td><input type="text" name="eStore_t_c_url" value="'.$eStore_t_c_url.'" size="70" /><br />
The URL of your Terms and Conditions page if you have one.
</td>
</tr>

<tr valign="top">
<th scope="row">Show Terms & Conditions Checkbox</th>
<td>
<input type="checkbox" name="eStore_show_t_c" value="1" '.$eStore_show_t_c.' /> For Shopping Cart (Add to Cart Type Buttons)
<br /><input type="checkbox" name="eStore_show_t_c_for_buy_now" value="1" '.$eStore_show_t_c_for_buy_now.' /> For Buy Now and Subscription Type Buttons
<br />If checked the customers will have to agree to the Terms and Conditions before they can checkout.</td>
</tr>
		
<tr valign="top">
<th scope="row">Show Compact Cart in Widget</th>
<td><input type="checkbox" name="eStore_show_compact_cart" value="1" '.$eStore_show_compact_cart.' /> <br />If checked the shopping cart displayed in the sidebar widget will display only the number of items in the cart instead of the full item listing. Useful for sites with narrow sidebar.</td>
</tr>

<tr valign="top">
<th scope="row">Enable Fancy Redirection On Checkout</th>
<td><input type="checkbox" name="eStore_enable_fancy_redirection_on_checkout" value="1" '.$eStore_enable_fancy_redirection_on_checkout.' /> 
<br />This feature requires WordPress 3.0, if this option conflicts with other plugin(s) then simply uncheck this option. If checked the redirection to the payment page will be displayed using a fancy JQuery effect. If unchecked it will redirect using the standard method.</td>
</tr>

<tr valign="top">
<th scope="row">Enable Lightbox effect on Images</th>
<td><input type="checkbox" name="eStore_enable_lightbox_effect" value="1" '.$eStore_enable_lightbox_effect.' /><br />Check this if you want lightbox effect on the product thumbnail images.</td>
</tr>

<tr valign="top">
<th scope="row">Enable Smart Thumbnail Option</th>
<td><input type="checkbox" name="eStore_enable_smart_thumb" value="1" '.$eStore_enable_smart_thumb.' />
<br />If your product thumbnail images look a little bit squashed then check this option and see the magic happen. The thumbnail images must be stored on the same server that this eStore plugin is installed on (not an external server) for this option to work.</td>
</tr>

</table>
</div></div>

	<div class="postbox">
	<h3><label for="title">Shipping & Tax Related Settings</label></h3>
	<div class="inside">
	
<table class="form-table">	
<tr valign="top">
<th scope="row">Base Shipping Cost</th>
<td><input type="text" name="eStore_base_shipping" value="'.$baseShipping.'" size="2" /> 
(eg. 5) Used for non digital Products. This amount is added to the total of the individual products shipping cost. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=50" target="_blank">Read More Here</a></td>
</tr>

<tr valign="top">
<th scope="row">Shipping Variation Option</th>
<td><textarea name="eStore_shipping_variation" cols="83" rows="2">'.$shippingVar.'</textarea>
<br />Can be used to offer shipping variation option to customers. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=1056" target="_blank">Read More Here</a></td>
</tr>

<tr valign="top">
<th scope="row">Always Display Shipping Variation</th>
<td><input type="checkbox" name="eStore_always_display_shipping_variation" value="1" '.$always_display_shipping_var.' />
<br />If you want to display the shipping variation in the cart all the time then check this field. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=1056#when_to_use_always_display_shipping_var" target="_blank">Read More Here</a></td>
</tr>

<tr valign="top">
<th scope="row">Calculate Tax</th>
<td><input type="checkbox" name="eStore_enable_tax" value="1" '.$eStore_enable_tax.' /> Enables tax calculation
<br />Tax Rate <input type="text" name="eStore_global_tax_rate" value="'.get_option('eStore_global_tax_rate').'" size="2" />% 
<br />Enter the tax rate (eg. 10). You can override the tax rate of an individual item by editing the product. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=916" target="_blank">Read More Here</a></td>
</tr>

</table>
</div></div>

	<div class="postbox">
	<h3><label for="title">Secondary Currency Settings (This is for Display Purpose Only)</label></h3>
	<div class="inside">
<i>&nbsp;&nbsp;If you want to display the price of your products in a secondary currency side by side with your primary currency then use this section otherwise leave the fields empty.</i>	

<table class="form-table">	
<tr valign="top">
<th scope="row">Secondary Currency Code </th>
<td><input type="text" name="eStore_secondary_currency_code" value="'.get_option('eStore_secondary_currency_code').'" size="3" /> 
 (e.g. USD, EUR, GBP, AUD)</td>
</tr>

<tr valign="top">
<th scope="row">Secondary Currency Symbol </th>
<td><input type="text" name="eStore_secondary_currency_symbol" value="'.get_option('eStore_secondary_currency_symbol').'" size="3" /> 
 (e.g. $, &#163;, &#8364;)</td>
</tr>

<tr valign="top">
<th scope="row">Conversion Rate</th>
<td><input type="text" name="eStore_secondary_currency_conversion_rate" value="'.get_option('eStore_secondary_currency_conversion_rate').'" size="3" /> 
<br />Conversion rate for the primary to secondary currency. For example if your primary currency is USD and the secondary currency is EUR then a rough conversion rate would be .775</td>
</tr>

</table>
</div></div>

	<div class="postbox">
	<h3><label for="title">Digital Product Delivery Settings</label></h3>
	<div class="inside">		
		
<table class="form-table">
<tr valign="top">
<th scope="row">Random Code</th>
<td><input type="text" name="eStore_random_code" value="'.$eStore_random_code.'" size="70" /><br />This Random code is used as a key to generate the encrypted download link for your downloadable products. Change it to something random.</td>
</tr>

<tr valign="top">
<th scope="row">Duration of Download Link</th>
<td><input type="text" name="eStore_download_url_life" value="'.$eStore_download_url_life.'" size="3" /> Hours<br />This is the duration of time the encrypted links will remain active. After this amount of time the link will expire.</td>
</tr>
	
<tr valign="top">
<th scope="row">Download Limit Count</th>
<td><input type="text" name="eStore_download_url_limit_count" value="'.$eStore_download_url_limit_count.'" size="3" /> Times<br />Number of times an item can be downloaded before the link expires. Leave empty or set a high value (e.g. 999) if you do not want to limit downloads by download count.</td>
</tr>

<tr valign="top">
<th scope="row">Download Validation Script Location</th>
<td><input type="text" name="eStore_download_script" value="'.$eStore_download_script.'" size="100" /><br />You do not need to change this value unless you want to customize this. Can be used to customize the download URL <a href="http://tipsandtricks-hq.com/ecommerce/?p=224" target="_blank">Read More Here</a>.<br>Configuration hint for the custom_download.php file is --> <font style="background-color:#ffff66">$wp_home_dir = \''.$wp_home_dir.'\';</font></td>
</tr>
</table>
</div></div>

	<div class="postbox">
	<h3><label for="title">Pay Per View Content Settings</label></h3>
	<div class="inside">		
		
<table class="form-table">
<tr valign="top">
<th scope="row">Redirection Page for Unauthorized Access</th>
<td><input type="text" name="eStore_ppv_verification_failed_url" value="'.get_option('eStore_ppv_verification_failed_url').'" size="70" />
<br />Visitors will be redirected to this page when trying to access the Pay Per View URL without clicking on a valid link. Only use this settings if you are selling Pay Per View content.</td>
</tr>
</table>
</div></div>

	<div class="postbox">
	<h3><label for="title">Post Payment Processing Settings</label></h3>
	<div class="inside">	
<table class="form-table">
<tr valign="top">
<th scope="row">Use Automatic Post Payment Processing</th>
<td><input type="checkbox" name="eStore_auto_product_delivery" value="1" '.$eStore_auto_delivery.' /><br />If checked the plugin will perform the post payment processing after every purchase. This option must be checked if you want certain functionality eg. automatically send emails after purchase, award affiliate commission automatically if you are using the affiliate platform plugin etc.</td>
</tr>

<tr valign="top">
<th scope="row">Use Strict PayPal Email Address Checking</th>
<td><input type="checkbox" name="eStore_strict_email_check" value="1" '.$eStore_strict_email_check.' /><br />If checked the script will check to make sure that the PayPal email address specified is the same as the account where the payment was deposited (Usage of PayPal Email Alias will fail too).</td>
</tr>

<tr valign="top">
<th scope="row">Use Automatic Customer Record Removal</th>
<td><input type="checkbox" name="eStore_auto_customer_removal" value="1" '.$eStore_auto_customer_removal.' /><br />If checked the plugin will delete a customer record from the customer database when a refund is issued.</td>
</tr>

<tr valign="top">
<th scope="row">Enable Transaction Result Display</th>
<td><input type="checkbox" name="eStore_display_tx_result" value="1" '.$eStore_display_tx_result.' /><br />Check this if you want to display the transaction result containing the product delivery message on a post-payment return page (eg. a Thank You page). This allows the customer to be able to download the Digital goods via an encrypted link from this page instantly. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=499" target="_blank">Learn How To</a></td>
</tr>
</table>
		
</div></div>
		
	<div class="postbox">
	<h3><label for="title">Email Settings</label></h3>
	<div class="inside">					

<table class="form-table">
<tr valign="top">
<th scope="row">Use WordPress Mailing System</th>
<td><input type="checkbox" name="eStore_use_wp_mail" value="1" '.$eStore_use_wp_mail.' /> If checked the plugin will use the WordPress mail function to send emails. Otherwise it will use a simple PHP mail script that comes with this plugin. <a href="http://www.tipsandtricks-hq.com/forum/topic/explanation-on-the-use-wordpress-mailing-system-checkbox-option" target="_blank">Read more on the difference</a></td>
</tr>

<tr valign="top">
<th scope="row">Send Emails to Buyer After Purchase</th>
<td><input type="checkbox" name="eStore_send_buyer_email" value="1" '.$eStore_send_buyer_email.' /> If checked the plugin will send an email to the buyer with the sale details. If digital goods are purchased then the email will contain encrypted download links for the downloadable products.</a></td>
</tr>

<tr valign="top">
<th scope="row">From Email Address*</th>
<td><input type="text" name="eStore_download_email_address" value="'.$eStore_download_email_address.'" size="50" /><br />eg. Your Name &lt;sales@your-domain.com&gt; This is the email address that will be used to send the email to the buyer. This name and email address will appear in the from field of the email.</td>
</tr>

<tr valign="top">
<th scope="row">Buyer Email Subject*</th>
<td><input type="text" name="eStore_buyer_email_subj" value="'.$eStore_buyer_email_subj.'" size="50" /><br />This is the subject of the email that will be sent to the buyer.</td>
</tr>

<tr valign="top">
<th scope="row">Buyer Email Body*</th>
<td><textarea name="eStore_buyer_email_body" rows="6" cols="50">'.$eStore_buyer_email_body.'</textarea><br />This is the body of the email that will be sent to the buyer. Do not change the email tags (text within the braces {}). All the available email tags are listed <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=460#email_tags" target="_blank">here</a></td>
</tr>

<tr valign="top">
<th scope="row">Notification Email Address*</th>
<td><input type="text" name="eStore_notify_email_address" value="'.$eStore_notify_email_address.'" size="50" /><br />This is the email address where the seller will be notified of product sales. This address is used incase you want to get notified to a different email address than your paypal one.</td>
</tr>

<tr valign="top">
<th scope="row">Seller Email Subject*</th>
<td><input type="text" name="eStore_seller_email_subj" value="'.$eStore_seller_email_subj.'" size="50" /><br />This is the subject of the email that will be sent to the seller for record.</td>
</tr>

<tr valign="top">
<th scope="row">Seller Email Body*</th>
<td><textarea name="eStore_seller_email_body" rows="6" cols="50">'.$eStore_seller_email_body.'</textarea><br />This is the body of the email that will be sent to the seller for record. Do not change the text withing the braces {}</td>
</tr>
</table>
</div></div>
		
	<div class="postbox">
	<h3><label for="title">Testing and Debugging Settings</label></h3>
	<div class="inside">'.
	eStore_dbgmgradm::settings_menu_html().
	'</div></div>
    
    <div class="submit">
        <input type="submit" name="info_update" value="Update Options &raquo;" />
    </div>

 </form><p>All fields marked with an asterisk (*) are required.</p> 
 ';

}

function wp_estore_admin_menu()
{
    echo '<div class="wrap">';
    echo '<h2>Admin Functions</h2>';
	echo '<div id="poststuff"><div id="post-body">';
	
	global $wpdb;
	
	echo 'These helpful admin functions allow you to do various manual admin stuff from time to time like generating an encrypted download link for any product, sending email to any customer etc.<br />';
    if ($_POST['generate_download_link'])
    {
    	$eStore_product_id = (string)$_POST["wp_eStore_product_id"];
    	$wp_eStore_variation_name = (string)$_POST["wp_eStore_variation_name"];
    		    
		$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
        $retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$eStore_product_id'", OBJECT);
        
        if (!empty($wp_eStore_variation_name))
        {
        	$item_name = $retrieved_product->name." (".$wp_eStore_variation_name.")";
        }
        else
        {
        	$item_name = $retrieved_product->name;
        }
        
        $eStore_download_link = generate_download_link($retrieved_product,$item_name);
        if (empty($eStore_download_link))
        {
        	$eStore_download_link = "Download link generation failed! Make sure the digital product variation name is correct if this product uses digital product variation.";
        }
        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Download Link Generated!';
        echo '</strong></p></div>';  
    }

    if ($_POST['send_email'])
    {
    	update_option('eStore_from_email',(string)$_POST["wp_eStore_from_email"]);
		update_option('eStore_to_email',(string)$_POST["wp_eStore_to_email"]);
		update_option('eStore_email_subject',(string)$_POST["wp_eStore_email_subject"]);
		update_option('eStore_admin_email_body',(string)$_POST["wp_eStore_email_body"]);

        $attachment = '';
        if (get_option('eStore_use_wp_mail'))
        {
            $from = get_option('eStore_from_email');
            $headers = 'From: '.$from . "\r\n";
            wp_mail(get_option('eStore_to_email'), get_option('eStore_email_subject'), get_option('eStore_admin_email_body'),$headers);
        }
        else
        {
        	if(@eStore_send_mail(get_option('eStore_to_email'),get_option('eStore_admin_email_body'),get_option('eStore_email_subject'),get_option('eStore_from_email'),$attachment))
        	{
        	   	echo '<script type="text/javascript">alert("Email Sent Successfully!")</script>';
        	}
        	else
        	{
        		echo '<script type="text/javascript">alert("Email Sending failed!")</script>';
        	}
        }
    }
	if(isset($_POST['bulk_delete']))
	{
		$interval_val = $_POST['bulk_delete_hours'];
		$interval_unit = 'HOUR';//MINUTE
		$cur_time = current_time('mysql');

		$download_links_table_name = $wpdb->prefix . "wp_eStore_download_links_tbl";
		$cond = " DATE_SUB('$cur_time',INTERVAL '$interval_val' $interval_unit) > creation_time";
        $result = $wpdb->query("DELETE FROM $download_links_table_name WHERE $cond", OBJECT);        

        if($result)	
		{			
			$message .= "The download links have been deleted! The current timestamp value used was: ".$cur_time;
		}
		else
		{
			$message .= "Nothing to delete!";
		}
        echo '<div id="message" class="updated fade"><p><strong>';
        echo $message;
        echo '</strong></p></div>';		
	}
	if(isset($_POST['reset_settings_to_default']))
	{
		wp_eStore_reset_settings_to_default();
		$message = "Settings options have been reset to default!";
        echo '<div id="message" class="updated fade"><p><strong>';
        echo $message;
        echo '</strong></p></div>';					
	}	
	if(isset($_POST['reset_sales_data']))
	{
		wp_eStore_reset_sales_data();
		$message = "Sales data have been reset!";
        echo '<div id="message" class="updated fade"><p><strong>';
        echo $message;
        echo '</strong></p></div>';				
	}
	if(isset($_POST['remove_all_db_tables']))
	{
		wp_eStore_remove_all_db_tables();
		$message = "All Database tables have been removed! Remmber, eStore will not work unless you deactivate and reactivate it again!";
        echo '<div id="message" class="updated fade"><p><strong>';
        echo $message;
        echo '</strong></p></div>';				
	}		
	
    ?>
	<div class="postbox">
	<h3><label for="title">Generate an Encrypted download link for a Product</label></h3>
	<div class="inside">

    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="generate_download_link" id="generate_download_link" value="true" />
    
    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="right">
    <strong>Product ID: </strong>
    </td><td align="left">
    <input name="wp_eStore_product_id" type="text" size="10" value="<?php echo $eStore_product_id; ?>" />
    <br /><i>(i) Enter the product id of the product that you want to generate an encrypted download link for.</i><br /><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="right">
    <strong>Digital Product Variation Name: </strong>
    </td><td align="left">
    <input name="wp_eStore_variation_name" type="text" size="30" value="<?php echo $wp_eStore_variation_name; ?>" />
    <br /><i>(ii) Enter the digital product variation name if you are using it. Leave empty if this product do not use the digital product variation.</i><br /><br />
    </td></tr>
    
    <tr valign="top"><td width="25%" align="right">
    </td><td align="left">
    <input type="submit" name="generate_download_link" value="<?php _e('Generate Link'); ?> &raquo;" />
    <br /><i>(iii) Hit the "Generate Link" button.</i><br /><br />
    </td></tr>
    
    <br />
    <tr valign="top"><td width="25%" align="right">
    <strong>Download Link: </strong>
    </td><td align="left">
    <textarea name="wp_eStore_download_link" rows="6" cols="70"><?php echo $eStore_download_link; ?></textarea>
    <br /><i>The is the encrypted download link.</i><br />
    </td></tr>
    </table>
    </form>
	</div></div>
	
	<div class="postbox">
	<h3><label for="title">Send Email to Customers</label></h3>
	<div class="inside">
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="send_email" id="send_email" value="true" />

    <table width="100%" border="0" cellspacing="0" cellpadding="6">
    <tr valign="top"><td width="25%" align="right">
    <strong>From Email Address: </strong>
    </td><td align="left">
    <input name="wp_eStore_from_email" type="text" size="50" value="<?php echo get_option('eStore_from_email'); ?>" />
    <br /><i>This email address will appear in the from field of the email.</i><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="right">
    <strong>To Email Address: </strong>
    </td><td align="left">
    <input name="wp_eStore_to_email" type="text" size="50" value="<?php echo get_option('eStore_to_email'); ?>" />
    <br /><i>This is the email address where the email will be sent to.</i><br />
    </td></tr>

    <tr valign="top"><td width="25%" align="right">
    <strong>Email Subject: </strong>
    </td><td align="left">
    <input name="wp_eStore_email_subject" type="text" size="50" value="<?php echo get_option('eStore_email_subject'); ?>" />
    <br /><i>This is the email subject.</i><br />
    </td></tr>

    <br />
    <tr valign="top"><td width="25%" align="right">
    <strong>Email Body: </strong>
    </td><td align="left">
    <textarea name="wp_eStore_email_body" rows="10" cols="70"><?php echo get_option('eStore_admin_email_body'); ?></textarea>
    <br /><i>Type your email and hit Send Email.</i><br /><br />
    <input type="submit" name="send_email" value="<?php _e('Send Email'); ?> &raquo;" />
    </td></tr>

	</table>
	</form>
	</div></div>
	
    <div class="postbox">
    <h3><label for="title">Clean The Encrypted Download Links Table</label></h3>
    <div class="inside">
    <br />
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
	 Delete All Links Older Than
    <input name="bulk_delete_hours" type="text" size="3" value=""/> Hours
    <div class="submit">
        <input type="submit" name="bulk_delete" value="Bulk Delete &raquo;" />
    </div>
    </form>
    </div></div>

    <div class="postbox">
    <h3><label for="title">The Almighty Reset Buttons</label></h3>
    <div class="inside">
    
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" onSubmit="return confirm('Are you sure you want to reset all the settings options to default?');" >    
    <div class="submit">
        <input type="submit" name="reset_settings_to_default" value="Reset eStore Settings to Default" />
    </div>    
    </form> 
       
    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" onSubmit="return confirm('Are you sure you want to reset all sales related data? Useful if you are trying to reset all the test transactions before going live.');" >    
    <div class="submit">
        <input type="submit" name="reset_sales_data" value="Reset All Sales Data" />
    </div>    
    </form> 

    <form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" onSubmit="return confirm('Are you sure you want to remove all eStore database tables? Useful if you are trying to do a clean reinstall of the plugin.');" >    
    <div class="submit">
        <input type="submit" name="remove_all_db_tables" value="Remove All eStore Database Tables" />
    </div>    
    </form> 
               
    </div></div>
        	
    <?php
    echo '</div></div>';
    echo '</div>';
}
?>
