<?php
include_once('../../../wp-load.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('eStore_auto_responder_handler.php');

if(isset($_POST['eStore_manaul_gateway']) && $_POST['eStore_manaul_gateway'] == "process")
{
	eStore_manual_gateway_api();
}
else
{
	exit;
}

function eStore_manual_gateway_api()
{
       if (isset($_POST['submit_shipping']))
        {
			$input_verified = false;

			$err_msg = eStore_check_address_details();
                        if (!empty($err_msg))
                        {
                            $msg = '<div id="error">';
                            $msg .= ESTORE_REQUIRED_FIELDS_MISSING;
                            $msg .= $err_msg;
                            $msg .= '</div>';
                            echo $msg;
                        }
			else
			{				  	
					$address = $_POST['address'].", ".$_POST['city'].", ".$_POST['state']." ".$_POST['postcode']." ".$_POST['country'];
					$payment_data = extract_manaul_co_general_payment_data($_POST['firstname'],$_POST['lastname'],$_POST['email'],$address,$_POST['phone']);
										
    	            $cust_direction = get_option('eStore_manual_co_cust_direction');
    	            $curr_symbol = get_option('cart_currency_symbol');
    	            if(!empty($cust_direction))
    	            {
						$tags = array("{first_name}","{last_name}","{payer_email}","{transaction_id}");
						$vals = array($_POST['firstname'],$_POST['lastname'],$_POST['email'],$payment_data['txn_id']);
				    	$cust_direction_mod    = stripslashes(str_replace($tags,$vals,$cust_direction));	
				    	            	
    	            	$body .= "\n-------------------------------\n";
    	            	$body .= $cust_direction_mod;	
    	            	$body .= "\n-------------------------------\n";
    	            }	            
    	            $count = 1;
    	            foreach ($_SESSION['eStore_cart'] as $item)
    	            {
    	           		$rounded_price = round($item['price'], 2);
    	           		$body .= "\n".WP_ESTORE_DETAILS_OF_ORDERED_PRODUCT.": ".$count;
    	                $body .= "\n-------------------------";
    	                $body .= "\n".ESTORE_PRODUCT_ID.": ".$item['item_number'];
    	                $body .= "\n".ESTORE_PRODUCT_NAME.": ".$item['name'];
    	                $body .= "\n".ESTORE_PRICE.": ".$curr_symbol.$rounded_price;
    	                $body .= "\n".ESTORE_QUANTITY.": ".$item['quantity']."\n";
    	                if(get_option('eStore_manual_co_give_download_links')!='')
    	                {
    	                	$body .= generate_download_link_for_product($item['item_number'], $item['name'], $payment_data)."\n";
    	                }
    	                $count++;
    	            }
    	            $body .= "\n-------------------------------\n";
    	            $body .= ESTORE_SUB_TOTAL.": ".$curr_symbol.round($_SESSION['eStore_cart_sub_total'],2);
    	            $body .= "\n".ESTORE_SHIPPING.": ".$curr_symbol.round($_SESSION['eStore_cart_postage_cost'],2);
    	            $body .= "\n".WP_ESTORE_TAX.": ".$curr_symbol.round($_SESSION['eStore_cart_total_tax'],2);
    	            $total = $_SESSION['eStore_cart_sub_total'] + $_SESSION['eStore_cart_postage_cost']+$_SESSION['eStore_cart_total_tax'];
    	            $body .= "\n".ESTORE_TOTAL.": ".$curr_symbol.round($total,2);
					$conversion_rate = get_option('eStore_secondary_currency_conversion_rate');
					if (!empty($conversion_rate))
					{
						$secondary_curr_symbol = get_option('eStore_secondary_currency_symbol');
						$body .= "\n".ESTORE_TOTAL.' ('.get_option('eStore_secondary_currency_code').'): '.$secondary_curr_symbol.number_format($total*$conversion_rate,2);
					}    	            
    	            
    	            $total_items = $count-1;
    	            $body .= "\n".WP_ESTORE_TOTAL_ITEMS_ORDERED.": ".$total_items;
    	            
    	            $body .= "\n\n".WP_ESTORE_CUSTOMER_DETAILS;
    	            $body .= "\n-------------------------";
    	            $body .= "\n".WP_ESTORE_NAME.": ".$_POST['firstname']." ".$_POST['lastname'];
    	            $body .= "\n".ESTORE_EMAIL.": ".$_POST['email'];
    	            $body .= "\n".ESTORE_PHONE.": ".$_POST['phone'];
    	            $body .= "\n".ESTORE_ADDRESS.": ".$_POST['address'];
                        $body .= "\n".ESTORE_CITY.": ".$_POST['city'];
                        $body .= "\n".ESTORE_STATE.": ".$_POST['state'];
                        $body .= "\n".ESTORE_POSTCODE.": ".$_POST['postcode'];
                        $body .= "\n".ESTORE_COUNTRY.": ".$_POST['country'];
    	            $body .= "\n".WP_ESTORE_ADDITIONAL_COMMENT.": ".$_POST['additional_comment'];
    	            //echo $body;
    	            $notify_email = get_option('eStore_manual_notify_email');
    	            $buyer_email = $_POST['email'];

    	            if(empty($notify_email))
    	            {
    	                $notify_email = get_bloginfo('admin_email');
    	            }
    	            // Get referrer
    	            if (!empty($_SESSION['ap_id']))
		    		{
		    			$referrer = $_SESSION['ap_id'];
		    		}
		    		else if (isset($_COOKIE['ap_id']))
		    		{
		    			$referrer = $_COOKIE['ap_id'];
		    		}
		    		$seller_email_body = $body."\n\n".WP_ESTORE_REFERRER.": ".$referrer;
		    		
		    		$from_email_address = get_option('eStore_download_email_address');
		    		$headers = 'From: '.$from_email_address . "\r\n";
    	            // Notify Seller
    	            $n_subject = get_option('eStore_seller_email_subj');//"Product Sale Notification";
    	            wp_mail($notify_email, $n_subject, $seller_email_body);
    	            
    	            // Notify Buyer
    	            $buyer_email_subj = get_option('eStore_buyer_email_subj');
    	            wp_mail($buyer_email,$buyer_email_subj,$body,$headers);
    	            
    	            $return_url = get_option('eStore_manual_return_url');
    	            if(empty($return_url))
    	            {
    	                $return_url = get_bloginfo('wpurl');
    	            }
    	            
    	            $cart_items = extract_manual_item_data(); 
					//Add to the customer database
					if(get_option('eStore_manual_co_auto_update_db')=='1')
					{						
						record_sales_data($payment_data,$cart_items);
					}

					//Perform autoresponder signup
					if(get_option('eStore_manual_co_do_autoresponder_signup') == '1')
					{
						eStore_item_specific_autoresponder_signup($cart_items,$_POST['firstname'],$_POST['lastname'],$_POST['email']);
						eStore_global_autoresponder_signup($_POST['firstname'],$_POST['lastname'],$_POST['email']);
					}
										
    	            //Award Affiliate Commission
					eStore_award_commission_manual_co($payment_data,$cart_items);
					
					//Create affiliate account if needed
					eStore_handle_auto_affiliate_account_creation($payment_data);
					
					//Reset cart and redirect to Thank you page
    	            reset_eStore_cart();   	            
    	            header('Location: ' . $return_url);
    	            exit;
    	            
    	            //echo '<div id="success">';
                    //echo "<br />".ESTORE_ORDER_COMPLETE;
    	            //echo '<br />Please <a href="'.$return_url.'">Click Here</a> to return to the Store.<br />';
    	            //echo "</div>";
    	            //exit;
			}
        }
        include_once ('view/eStore_shipping_details_view.php');
        echo show_shipping_details_form_new("manual");
}

function extract_manual_item_data()
{
	$cart_items = array();
	foreach ($_SESSION['eStore_cart'] as $item)
	{
		$item_number = $item['item_number'];
		$item_name = $item['name'];
		$quantity = $item['quantity'];
		$mc_gross = round($item['price'], 2);
		//$mc_shipping = $item['item_number'];
		$mc_currency = get_option('cart_payment_currency');

		$current_item = array(
          					   'item_number' => $item_number,
							   'item_name' => $item_name,
							   'quantity' => $quantity,
							   'mc_gross' => $mc_gross,
							   'mc_currency' => $mc_currency,
							  );

		array_push($cart_items, $current_item);
    }
    return $cart_items;    
}

function extract_manaul_co_general_payment_data($fname,$lname,$email,$address,$phone)
{
$custom = eStore_get_custom_field_value();	
$unique_id = uniqid();
$num_cart_items = count($_SESSION['eStore_cart']);

$coupon_code_used = '';
if (!empty($_SESSION['eStore_coupon_code']))
{
	$coupon_code_used = $_SESSION['eStore_coupon_code'];
}

$eMember_id = '';
if (function_exists('wp_eMember_install'))
{  
	global $auth;
	$user_id = $auth->getUserInfo('member_id');
	if (!empty($user_id))
	{
		$eMember_id = $user_id;
	}
}

$payment_data = array(
'gateway' => 'manual',
'custom' => $custom,
'txn_id' => $unique_id,
'txn_type' => 'Shopping Cart',
'transaction_subject' => 'Shopping cart manual checkout',
'first_name' => $fname,
'last_name' => $lname,
'payer_email' => $email,
'num_cart_items' => $num_cart_items,
'subscr_id' => $unique_id,
'address' => $address,
'phone' => $phone,
'coupon_used' => $coupon_code_used,
'eMember_username' => $eMember_id,
                     );
return $payment_data;
}

function eStore_award_commission_manual_co($payment_data,$cart_items)
{	
	if (function_exists('wp_aff_platform_install') && get_option('eStore_manual_co_give_aff_commission') == 1)
	{   
		eStore_aff_award_commission($payment_data,$cart_items);
	} 	
}

function eStore_check_address_details()
{
    if (empty($_POST['firstname']))
    {
	$error_msg .= "<br />".ESTORE_FIRST_NAME;
    }
    if (empty($_POST['lastname']))
    {
	$error_msg .= "<br />".ESTORE_LAST_NAME;
    }
    if (empty($_POST['address']))
    {
	$error_msg .= "<br />".ESTORE_ADDRESS;
    }
    if (empty($_POST['city']))
    {
	$error_msg .= "<br />".ESTORE_CITY;
    }
    if (empty($_POST['postcode']))
    {
	$error_msg .= "<br />".ESTORE_POSTCODE;
    }
    if (empty($_POST['email']))
    {
	$error_msg .= "<br />".ESTORE_EMAIL;
    }

    return $error_msg;
}
?>