<?php
include_once('../../../wp-load.php');
require_once('eStore_classes/_loader.php');
include_once('email.php');
include_once('eStore_includes2.php');
include_once('eStore_includes4.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('eStore_auto_responder_handler.php');

if ((isset($_REQUEST['name'])) && (strlen(trim($_REQUEST['name'])) > 0)) {
	$name = stripslashes(strip_tags($_REQUEST['name']));
} else {$name = 'No name entered';}
if ((isset($_REQUEST['email'])) && (strlen(trim($_REQUEST['email'])) > 0)) {
	$email = stripslashes(strip_tags($_REQUEST['email']));
} else {$email = 'No email entered';}
if ((isset($_REQUEST['prod_id'])) && (strlen(trim($_REQUEST['prod_id'])) > 0)) {
	$prod_id = stripslashes(strip_tags($_REQUEST['prod_id']));
} else {$prod_id = 'No product id found';}
if ((isset($_REQUEST['ap_id'])) && (strlen(trim($_REQUEST['ap_id'])) > 0)) {
	$ap_id = stripslashes(strip_tags($_REQUEST['ap_id']));
}
if ((isset($_REQUEST['clientip'])) && (strlen(trim($_REQUEST['clientip'])) > 0)) {
	$clientip = stripslashes(strip_tags($_REQUEST['clientip']));
}

$eStore_debug_manager->squeeze_form("Processing free download request for Ajax powered squeeze form...", ESTORE_LEVEL_SUCCESS);

// These 2 lines of code ensure the Ajax version of the "squeeze form" now passes its data through to the PDF Stamper addon.
// -- The Assurer, 2010-09-12.
$payment_data = free_download_pseudo_payment_data($name, $email);		// Populate the pseudo payment data.
$download = generate_download_link_for_product($prod_id, '', $payment_data);	// Generate the download link.
//$download = generate_download_link_for_product($prod_id);

if (eStore_send_free_download1($name, $email, $download))
{
	$eStore_debug_manager->squeeze_form("Email with the download link sent to: ".$email, ESTORE_LEVEL_SUCCESS);

    global $wpdb;
    $customer_table_name = $wpdb->prefix . "wp_eStore_customer_tbl";
    $products_table_name = $wpdb->prefix . "wp_eStore_tbl";
    $retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$prod_id'", OBJECT);
    
    $download_email = get_option('eStore_download_email_address');

    // Autoresponder Sign up
    list($firstname,$lastname) = explode(' ',$name);   
    $cart_items = array();
	$current_item = array(
	          		'item_number' => $prod_id,
					'item_name' => $retrieved_product->name,
					);
	
	array_push($cart_items, $current_item);	  

	$eStore_debug_manager->squeeze_form("Performing autoresponder signup if specified in the settings...", ESTORE_LEVEL_SUCCESS);
    eStore_item_specific_autoresponder_signup($cart_items,$firstname,$lastname,$email);    
    eStore_global_autoresponder_signup($firstname,$lastname,$email);             
                
    $eStore_debug_manager->squeeze_form("Updating the customers database with the visitor details...", ESTORE_LEVEL_SUCCESS);
    // Update the Customer and products table
	$cart_item_qty = 1;
    if (is_numeric($retrieved_product->available_copies))
    {
        $new_available_copies = ($retrieved_product->available_copies - $cart_item_qty);
    }
    $new_sales_count = ($retrieved_product->sales_count + $cart_item_qty);
    $current_product_id = $retrieved_product->id;
    $updatedb = "UPDATE $products_table_name SET available_copies = '$new_available_copies', sales_count = '$new_sales_count' WHERE id='$current_product_id'";
    $results = $wpdb->query($updatedb);    
     
    $emailaddress = $email;
    $name_pieces = explode(' ', $name);
	$firstname = $name_pieces[0];
    $clientdate = (date ("Y-m-d"));
    $txn_id = "Free Download";
    $sale_price = '0';
	if (!empty($name_pieces[1]))
		$lastname = $name_pieces[1];

    $ret_customer_db = $wpdb->get_results("SELECT email_address FROM $customer_table_name WHERE purchased_product_id = '$prod_id' and email_address='$emailaddress'", OBJECT);
    if (!$ret_customer_db)
	{
		$updatedb = "INSERT INTO $customer_table_name (first_name, last_name, email_address, purchased_product_id,txn_id,date,sale_amount) VALUES ('$firstname', '$lastname','$emailaddress','$prod_id','$txn_id','$clientdate','$sale_price')";
		$results = $wpdb->query($updatedb);
	} 
	
	if(!empty($ap_id))
	{		
		$eStore_debug_manager->squeeze_form("Affiliate Referrer ID Value:".$ap_id, ESTORE_LEVEL_SUCCESS,true);
		if(get_option('eStore_aff_enable_lead_capture_for_sqeeze_form')!='')
		{
			if(function_exists('wp_aff_record_remote_lead')){
				if(empty($clientip)){
					$clientip = "";
				}
				wp_aff_record_remote_lead($ap_id,$email,$prod_id,$clientip);
				$eStore_debug_manager->squeeze_form("Affiliate lead captured", ESTORE_LEVEL_SUCCESS,true);
			}
			else{
				$eStore_debug_manager->squeeze_form("Affiliate platform plugin is not installed or it needs to be updated to use this feature!", ESTORE_LEVEL_FAILURE,true);
			}
		}
	}
	$eStore_debug_manager->squeeze_form("Squeeze form task complete.", ESTORE_LEVEL_SUCCESS,true);  	
}
?>
