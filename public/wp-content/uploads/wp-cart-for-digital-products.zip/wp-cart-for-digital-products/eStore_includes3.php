<?php
$tx_result_msg = '';
$tx_result_error_msg = ''; 
function eStore_display_transaction_result()
{
	global $tx_result_msg,$tx_result_error_msg;    
    if (empty($tx_result_error_msg) && isset($_SESSION['eStore_tx_result']))
    {
    	$output .= '<div STYLE="word-wrap: break-word">';
    	$output .= WP_ESTORE_YOUR_ORDER;
    	$output .= $_SESSION['eStore_tx_result'].'<br />';
    	$output .= '</div>';
    }
    else
    {
    	$output .= '<br />'.$tx_result_error_msg.'<br />';
    }
    //$output .= '<br />'.$tx_result_msg;
    return $output;
}

function eStore_process_PDT_payment_data($keyarray)
{
	setcookie("cart_in_use","true",time()+21600,"/");
	
	global $tx_result_msg,$tx_result_error_msg;
   	if (get_option('eStore_strict_email_check') != '')
   	{
    	$seller_paypal_email = get_option('cart_paypal_email');
    	if ($seller_paypal_email != $keyarray['receiver_email'])
    	{
    		$tx_result_error_msg .= 'Invalid Seller Paypal Email Address Detected: '.$keyarray['receiver_email'];
    		return false;
    	}
    }
   	$payment_status = $keyarray['payment_status'];
    if ($payment_status != "Completed")
    {
        $tx_result_error_msg .= 'The Fund have not been cleared yet. Product will be delivered when the fund clears!';
    	return false;
    }

    $custom = $keyarray['custom'];
    $delimiter = "&";
    $customvariables = array();
    $namevaluecombos = explode($delimiter, $custom);
    foreach ($namevaluecombos as $keyval_unparsed)
    {
        $equalsignposition = strpos($keyval_unparsed, '=');
        if ($equalsignposition === false)
        {
            $customvariables[$keyval_unparsed] = '';
            continue;
        }
        $key = substr($keyval_unparsed, 0, $equalsignposition);
        $value = substr($keyval_unparsed, $equalsignposition + 1);
        $customvariables[$key] = $value;
    }	
    $pictureID = $customvariables['ngg_pid'];
    
    $transaction_type = $keyarray['txn_type'];
    $transaction_id = $keyarray['txn_id'];
    $transaction_subject = $keyarray['transaction_subject'];
    $gross_total = $keyarray['mc_gross'];
		if ($transaction_type == "cart")
		{
			// Cart Items
			$num_cart_items = $keyarray['num_cart_items'];
			$tx_result_msg .= 'Number of Cart Items: '.$num_cart_items;

			$i = 1;
			$cart_items = array();
			while($i < $num_cart_items+1)
			{
				$item_number = $keyarray['item_number' . $i];
				$item_name = $keyarray['item_name' . $i];
				$quantity = $keyarray['quantity' . $i];
				$mc_gross = $keyarray['mc_gross_' . $i];
				$mc_currency = $keyarray['mc_currency'];

				$current_item = array(
									   'item_number' => $item_number,
									   'item_name' => $item_name,
									   'quantity' => $quantity,
									   'mc_gross' => $mc_gross,
									   'mc_currency' => $mc_currency,
									  );

				array_push($cart_items, $current_item);
				$i++;
			}
		}
		else
		{
			$cart_items = array();
			$tx_result_msg .= 'Transaction Type: Buy Now/Subscribe';
			$item_number = $keyarray['item_number'];
			$item_name = $keyarray['item_name'];
			$quantity = $keyarray['quantity'];
			$mc_gross = $keyarray['mc_gross'];
			$mc_currency = $keyarray['mc_currency'];

			$current_item = array(
									   'item_number' => $item_number,
									   'item_name' => $item_name,
									   'quantity' => $quantity,
									   'mc_gross' => $mc_gross,
									   'mc_currency' => $mc_currency,
									  );

			array_push($cart_items, $current_item);
		}
		$script_location = get_option('eStore_download_script');
		$random_key = get_option('eStore_random_code');

		global $wpdb;
		$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
		$customer_table_name = $wpdb->prefix . "wp_eStore_customer_tbl";
		$sales_table_name = $wpdb->prefix . "wp_eStore_sales_tbl";
		$payment_currency = get_option('cart_payment_currency');

	    $product_id_array = Array();
	    $product_name_array = Array();
	    $product_price_array = Array();
	    $product_qty_array = Array();
	    //$attachments_array = Array();
	    $download_link_array = Array();
        $counter = 0;
               
		foreach ($cart_items as $current_cart_item)
		{
			$cart_item_data_num = $current_cart_item['item_number'];
			$cart_item_data_name = trim($current_cart_item['item_name']);
			$cart_item_data_quantity = $current_cart_item['quantity'];
			$cart_item_data_total = $current_cart_item['mc_gross'];
			$cart_item_data_currency = $current_cart_item['mc_currency'];

			$tx_result_msg .= '<br />Item Number: '.$cart_item_data_num;
			$tx_result_msg .= '<br />Item Name: '.$cart_item_data_name;
			$tx_result_msg .= '<br />Item Quantity: '.$cart_item_data_quantity;
			$tx_result_msg .= '<br />Item Total: '.$cart_item_data_total;
			$tx_result_msg .= '<br />Item Currency: '.$cart_item_data_currency;

			// Compare the values with the values stored in the database
			$key=$cart_item_data_num;
			$retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$key'", OBJECT);
			$coupon_code = $customvariables['coupon'];
			if(!empty($coupon_code))
			{
                $tx_result_msg .= 'Coupon Code Used : '.$coupon_code;
                $coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
                $ret_coupon = $wpdb->get_row("SELECT * FROM $coupon_table_name WHERE coupon_code = '$coupon_code'", OBJECT);
                if ($ret_coupon)
                {
                    $discount_amount = $ret_coupon->discount_value;
                    $discount_type = $ret_coupon->discount_type;
                    if ($discount_type == 0)
                    {
                        //apply % discount
                        $discount = ($retrieved_product->price*$discount_amount)/100;
                        $true_product_price = $retrieved_product->price - $discount;
                    }
                    else
                    {
                        // apply value discount
                        $true_product_price = $retrieved_product->price - $discount_amount;
                    }
                }
            }           
            else
            {
                $true_product_price = $retrieved_product->price*$cart_item_data_quantity;
            }
            $true_product_price = round($true_product_price, 2);
			if ($cart_item_data_total < $true_product_price)
			{
		    	$tx_result_error_msg .= 'Wrong Product Price Detected. Actual Product Price : '.$true_product_price;
		    	$tx_result_error_msg .= 'Paid Product Price : '.$cart_item_data_total;
         		return false;
			}
			
			if(!empty($retrieved_product->currency_code))
			    $payment_currency = $retrieved_product->currency_code;			
			if ($payment_currency != $cart_item_data_currency)
			{
		    	$tx_result_error_msg .= 'Invalid Product Currency : '.$cart_item_data_currency;
         		return false;
			}
			
			//Check if nextgen gallery integration is being used
		    $pid_check_value = eStore_is_ngg_pid_present($cart_item_data_name);
		    if($pid_check_value != -1)
		    {
		    	$pictureID = $pid_check_value;
		    }			
			if(!empty($pictureID))
			{
				$download_link = eStore_get_ngg_image_url_html($pictureID,$cart_item_data_name);
				$pictureID = "";
			}
			else
			{
			    $product_id = $retrieved_product->id;
			    if(empty($retrieved_product->product_download_url))
			    {
	                $download_link = "<br /><strong>".$cart_item_data_name."</strong>". WP_ESTORE_THIS_ITEM_DOES_NOT_HAVE_DOWNLOAD;
	            }
	            else
	            {   
	            	$payment_data = array();
	            	$payment_data['customer_name'] = $keyarray['first_name']." ".$keyarray['last_name'];
	            	$payment_data['payer_email'] = $keyarray['payer_email'];
	            	$payment_data['contact_phone'] = $keyarray['contact_phone'];
	            	$payment_data['address'] = $keyarray['address_street'].", ".$keyarray['address_city'].", ".$keyarray['address_state']." ".$keyarray['address_zip'].", ".$keyarray['address_country'];
	            	
	            	if(!empty($retrieved_product->variation3))
	            	{
	            		$download_link = get_download_for_variation_tx_result($cart_item_data_name,$retrieved_product,$script_location,$random_key,$payment_data);
	            	}
	            	else
	            	{         	
		    			$download_url_field = $retrieved_product->product_download_url;
		    			$product_ids = explode(',',$download_url_field);
					    $package_product = true;
	                    $multi_parts = false;
					    foreach($product_ids as $id)
					    {
					        if(!is_numeric($id))
					        {
					            $package_product = false;
					        }
					    }
					    if(sizeof($product_ids)>1 && !$package_product){
	                        $multi_parts = true;
	                    }
					    if($package_product)
					    {
					        $tx_result_msg .= 'The product is a package product.';
					        //$count = 0;
					        foreach($product_ids as $id)
					        {
	                            $id = trim($id);
					        	//$download = $id.'|'.time();
		                        $retrieved_product_for_id = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
		                        //$download_key = rawurlencode(base64_encode(RC4Crypt::encrypt($random_key,$download)));
		                        $download_key =  eStore_check_stamping_flag_and_generate_download_key($retrieved_product_for_id,$retrieved_product_for_id->id,'',$payment_data);
	                            $download_url = $script_location.'download.php?file='.$download_key;
					        	$raw_download = '<a href="'.$download_url.'">'.$download_url.'</a>';
	                            $download_link .= "<br /><strong>".$retrieved_product_for_id->name."</strong> - ".$raw_download.'<br />';
	                            eStore_register_link_in_db('',$download_key,$download_url,'','','',0);
					        	//$count++;
					        }
					    }
					    else if($multi_parts)
					    {
	                        $tx_result_msg .= 'The product has multiple downloadable files.';
					        $count = 1;
					        $download_link .= "<br /><strong>".$cart_item_data_name."</strong> - ";
					        foreach($product_ids as $id)
					        {
	                            $id = trim($id);
	                            if(!empty($id)){
	                                //$download = $product_id.'|'.time().'|'.$id;
	                                //$download_key = rawurlencode(base64_encode(RC4Crypt::encrypt($random_key,$download)));
	                                $download_key =  eStore_check_stamping_flag_and_generate_download_key($retrieved_product,$product_id,$id,$payment_data);
	                                $download_url = $script_location.'download.php?file='.$download_key;
	                                $raw_download = '<a href="'.$download_url.'">'.$download_url.'</a>';
	                                $download_link .= "<br />Part ".$count." : ".$raw_download;
	                                eStore_register_link_in_db('',$download_key,$download_url,'','','',0);
	                                $count++;
	                            }
	                        }
	                    }
					    else
					    {
					        //$download = $product_id.'|'.time();
					        //$download_key = rawurlencode(base64_encode(RC4Crypt::encrypt($random_key,$download)));
					        //echo "Doing stamping. Payment data: ".$payment_data['customer_name'];
					        $download_key =  eStore_check_stamping_flag_and_generate_download_key($retrieved_product,$product_id,'',$payment_data);
					        $download_url = $script_location.'download.php?file='.$download_key;
					        $raw_download = '<a href="'.$download_url.'">'.$download_url.'</a>';
					        $download_link = "<br /><strong>".$cart_item_data_name."</strong> - ".$raw_download;		
					        eStore_register_link_in_db('',$download_key,$download_url,'','','',0);	         
					    } 
	            	} 
	            }
			}
		    $tx_result_msg .= 'Download Link : '.$download_link;

            array_push($product_name_array, $cart_item_data_name);
            array_push($product_id_array, $product_id);
            array_push($product_price_array, $cart_item_data_total);
            array_push($product_qty_array, $cart_item_data_quantity);            
            //array_push($attachments_array, $retrieved_product->product_download_url);
            array_push($download_link_array, $download_link);
            $counter++;
            $download_link = '';
		}
		// How long the download link remain valid (hours)
		$download_url_life = get_option('eStore_download_url_life');
		$email_body = get_option('eStore_buyer_email_body');

		// Send the product
        for ($i=0; $i < sizeof($product_name_array); $i++)
        {
            $constructed_products_name .= $product_name_array[$i];
            $constructed_products_name .= ", ";

            $constructed_products_price .= $product_price_array[$i];
            $constructed_products_price .= ", ";

            $constructed_products_id .= $product_id_array[$i];
            $constructed_products_id .= ", ";

            $constructed_download_link .= "<br />";
            if (is_array($download_link_array[$i]))
            {
            	$package_downloads = $download_link_array[$i];
            	for ($j=0; $j < sizeof($package_downloads); $j++)
            	{
            		$constructed_download_link .= $package_downloads[$j];
            		$constructed_download_link .= "<br />";
            	}
            }
            else
            {
            	$constructed_download_link .= $download_link_array[$i];
            }
        }
        $email_info = "<br /><br />".WP_ESTORE_YOU_WILL_SOON_RECEIVE_EMAIL."(<strong>".$keyarray['payer_email']."</strong>)<br />";
        
        $offer_text = html_entity_decode(get_option('eStore_special_offer_text'), ENT_COMPAT,"UTF-8");
        if(!empty($offer_text))
        {
            $_SESSION['eStore_tx_result'] = $constructed_download_link."<br /><br />".WP_ESTORE_TOTAL_COST.": ".$gross_total."<br />".ESTORE_TRANSACTION_ID.": ".$keyarray['txn_id'].$email_info."<br />".$offer_text;
        }
        else
        {
            $_SESSION['eStore_tx_result'] = $constructed_download_link."<br /><br />".WP_ESTORE_TOTAL_COST.": ".$gross_total."<br />".ESTORE_TRANSACTION_ID.": ".$keyarray['txn_id'].$email_info;
        }

        //Google Analytics e-commerce tracking (only do it if set in settings menu)
        if(get_option('eStore_enable_analytics_tracking'))
        {
	        $mc_shipping = $keyarray['mc_shipping'];
	        $mc_tax = $keyarray['tax'];
	        $city = $keyarray['address_city'];
	        $state = $keyarray['address_state'];
	        $country = $keyarray['address_country'];
	        $eStore_analytics_code = array();
	        $eStore_analytics_code[] = "['_addTrans',"."'".$transaction_id."','".get_bloginfo('name')."','".$gross_total."','".$mc_tax."','".$mc_shipping."','".$city."','".$state."','".$country."']";
	        
			for ($j=0; $j < sizeof($product_name_array); $j++)  
			{
				$eStore_analytics_code[] = "['_addItem',"."'".$transaction_id."','".$product_id_array[$j]."','".$product_name_array[$j]."','','".$product_price_array[$j]."','".$product_qty_array[$j]."']";
			}  
			$eStore_analytics_code[] = "['_trackTrans']";
			$_SESSION['eStore_ga_code'] = $eStore_analytics_code;
			
			add_filter('yoast-ga-push-after-pageview','eStore_add_trans');
        }	
}

function eStore_add_trans($push) 
{
	for ($j=0; $j < sizeof($_SESSION['eStore_ga_code']); $j++) 
	{
		$push[] = $_SESSION['eStore_ga_code'][$j];
	}
	return $push;
}
?>
