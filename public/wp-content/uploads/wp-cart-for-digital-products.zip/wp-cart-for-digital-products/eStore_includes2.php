<?php
include_once('eStore_post_payment_processing_helper.php');

function eStore_generate_download_link1($id)
{
    $download = $id.'|'.time();
	$script_location = get_option('eStore_download_script');
	$random_key = get_option('eStore_random_code');
	$download_key = rawurlencode(base64_encode(RC4Crypt::encrypt($random_key,$download)));
	$eStore_download_link = $script_location.'download.php?file='.$download_key;
	eStore_register_link_in_db('',$download_key,$eStore_download_link,'','','',0);
	return $eStore_download_link;
}

function eStore_send_free_download1($name, $to_email_address, $download)
{
	$attachment = '';
	$from_email_address = get_option('eStore_download_email_address');
	$headers = 'From: '.$from_email_address . "\r\n";
	$email_subj = ESTORE_FREE_DOWNLOAD_SUBJECT;
	$email_body = ESTORE_DEAR.' '.$name.
				  "\n\n".ESTORE_FREE_DOWNLOAD_EMAIL_BODY.
 				  "\n".$download.
				  "\n\n".ESTORE_THANK_YOU;
    if (get_option('eStore_use_wp_mail'))
    {
        wp_mail($to_email_address, $email_subj, $email_body, $headers);
        return true;
    }
    else
    {
	    if(@eStore_send_mail($to_email_address,$email_body,$email_subj,$from_email_address,$attachment))
	    {
	    	return true;
	    }
	    else
	    {
	    	return false;
	    }
    }
}

function free_download_pseudo_payment_data($cust_name, $cust_email)
{
// This function returns pseudo payment_data that can be passed to the PDF Stamper addon.  It is called by both the Ajax
// and non-Ajax versions of the free download "squeeze form."
// -- The Assurer, 2010-09-12.
	$payment_data = array(
		'customer_name' => $cust_name,
		'payer_email' => $cust_email,
		'contact_phone' => 'N/A or Not Provided',
		'address' => $cust_email,
		'payer_business_name' => $cust_name,
	);
	return $payment_data;
}
?>
