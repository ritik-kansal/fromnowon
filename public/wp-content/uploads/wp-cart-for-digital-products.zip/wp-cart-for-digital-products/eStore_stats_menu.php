<?php
include_once('admin_includes.php');

$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
$customer_table_name = $wpdb->prefix . "wp_eStore_customer_tbl";
$coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
$sales_table_name = $wpdb->prefix . "wp_eStore_sales_tbl";

function wp_estore_stats_menu()
{
	echo '<div class="wrap">
	<h2>'.__('WP eStore Stats', 'wp_eStore').'</h2>';

    echo '<div id="poststuff">
	     <div id="post-body">';
               
	global $total_refund;
	global $refund_qty;
    global $wpdb;
    global $products_table_name;
    	
    $curr_date = (date ("Y-m-d"));
    $m = date('m');
    $y = date('Y');
	$start_date = $y.'-'.$m.'-01';
	$end_date = $curr_date;
	$currency = get_option('cart_payment_currency');
	
    if(isset($_POST['show_stats_between_dates']))
    {
    	//Show stats between dataes
    	$start_date = $_POST['stat_start_date'];
    	$end_date = $_POST['stat_end_date'];
    }	
	echo '
	<div class="postbox">
	<h3><label for="title">Choose Date Range (yyyy-mm-dd)</label></h3>
	<div class="inside">';
			
	?>	
	
	<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
	
	Start Date: <input name="stat_start_date" type="text" id="stat_start_date" value="<?php echo $start_date; ?>" size="12" />
	
	End Date: <input name="stat_end_date" type="text" id="stat_end_date" value="<?php echo $end_date; ?>" size="12" />
	
    <div class="submit">
        <input type="submit" name="show_stats_between_dates" value="<?php _e('View Stats'); ?> &raquo;" />
    </div>	
	</form>	
	<?php 
	echo '</div></div>';
	
	echo '
	<div class="postbox">
	<h3><label for="title">Overview</label></h3>
	<div class="inside">';
	
	echo '
	<table width="350">';

		echo '<tr>';
		echo '<td>Total Number of Products : </td>';
		echo '<td><strong>'.eStore_total_num_products().'</strong></td>';
		echo '</tr>';
		
        echo '<tr>';
		echo '<td>Total Number of Coupons : </td>';
		echo '<td><strong>'.eStore_total_num_coupons().'</strong></td>';
		echo '</tr>';

		echo '<tr>';
		echo '<td>Number of Item Sales : </td>';
		echo '<td><strong>'.eStore_num_sales_between_dates($start_date,$end_date).'</strong></td>';
		echo '</tr>';

		echo '<tr>';
		echo '<td>Total Sales Amount : </td>';
		echo '<td><strong>'.eStore_sale_amount_between_dates($start_date,$end_date).'</strong></td>';
		echo '<td>'.$currency.'</td>';
		echo '</tr>';

		echo '<tr>';
		echo '<td>Refund Issued : </td>';
		echo '<td><strong>'.eStore_num_refunds_between_dates($start_date,$end_date).'</strong></td>';
		echo '<td>Transactions</td>';
		echo '</tr>';

		echo '<tr>';
		echo '<td>Total Refund Amount : </td>';
		echo '<td><strong>'.eStore_refund_amount_between_dates($start_date,$end_date).'</strong></td>';
		echo '<td>'.$currency.'</td>';
		echo '</tr>';
				
		echo '<tr>';
		echo '<td>Net Sales Amount : </td>';
		echo '<td><strong>'.eStore_net_amount_between_dates($start_date,$end_date).'</strong></td>';
		echo '<td>'.$currency.'</td>';
		echo '</tr>';
		
	echo '</table>';
	echo '</div></div>';

	echo "<h3>Itemized Sale Stats</h3>";
	$item_stats = eStore_itemised_sale_stat_between_datas($start_date,$end_date);
	
		echo '
			<table class="widefat">
			<thead><tr>
			<th scope="col">'.__('Item ID', 'wp_eStore').'</th>
			<th scope="col">'.__('Item Name', 'wp_eStore').'</th>
			<th scope="col">'.__('Average Sale Price ('.$currency.')', 'wp_eStore').'</th>
			<th scope="col">'.__('Quantity Sold', 'wp_eStore').'</th>
			<th scope="col">'.__('Sale Total ('.$currency.')', 'wp_eStore').'</th>
			</tr></thead>
			<tbody>';
				
		foreach ($item_stats as $item)
		{
			$id = $item['item_id'];
			$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
			$avg_sale_price = round($item['sale_total']/$item['qty_sold'],2);
		    echo '<tr>';
		    echo "<td>". $item['item_id'] ."</td><td>". $ret_product->name ."</td><td>".$avg_sale_price ."</td><td>". $item['qty_sold'] ."</td><td>". $item['sale_total']."</td>";
		    echo '</tr>';
		}
//		echo '<tr>';
//		echo '<td colspan=5><strong>Total Refund Amount: </strong>'.$total_refund. ' '.$currency.'</td>';
//		echo '</tr><tr>';
//		echo '<td colspan=5><strong>Total Number of Refunds: </strong>'.$refund_qty.'</td>';
//		echo '</tr>';
			
		echo '</tbody></table>';

    echo '</div></div>';
	echo '</div>';
}

function eStore_total_num_products()
{
    global $wpdb;
    global $products_table_name;
	$query = $wpdb->get_row("SELECT count(*) as total_record FROM $products_table_name", OBJECT);
	$number_of_products = $query->total_record;
	if (empty($number_of_products))
	{
		$number_of_products = "0";
	}
    return $number_of_products;
}
function eStore_total_num_coupons()
{
    global $wpdb;
    global $coupon_table_name;
	$query = $wpdb->get_row("SELECT count(*) as total_record FROM $coupon_table_name", OBJECT);
	$number_of_coupons = $query->total_record;
	if (empty($number_of_coupons))
	{
		$number_of_coupons = "0";
	}
    return $number_of_coupons;
}
function eStore_num_sales_between_dates($start_date,$end_date)
{
    global $wpdb;
    global $sales_table_name;
	$query = $wpdb->get_row("SELECT count(*) as total_record FROM $sales_table_name WHERE sale_price > 0 AND date BETWEEN '$start_date' AND '$end_date'", OBJECT);
	$number_of_sales = $query->total_record;
	if (empty($number_of_sales))
	{
		$number_of_sales = "0";
	}
    return $number_of_sales;
}
function eStore_sale_amount_between_dates($start_date,$end_date)
{
    global $wpdb;
    global $sales_table_name;
	$row = $wpdb->get_row("select SUM(sale_price) AS total from $sales_table_name where sale_price > 0 AND date BETWEEN '$start_date' AND '$end_date'", OBJECT);
	$total_sales = round($row->total,2);
	if (empty($total_sales))
	{
		$total_sales = "0.00";
	}
	return $total_sales;
}

function eStore_num_refunds_between_dates($start_date,$end_date)
{
    global $wpdb;
    global $sales_table_name;
	$query = $wpdb->get_row("SELECT count(*) as total_record FROM $sales_table_name WHERE sale_price < 0 AND date BETWEEN '$start_date' AND '$end_date'", OBJECT);
	$number_of_sales = $query->total_record;
	if (empty($number_of_sales))
	{
		$number_of_sales = "0";
	}
    return $number_of_sales;
}
function eStore_refund_amount_between_dates($start_date,$end_date)
{
    global $wpdb;
    global $sales_table_name;
	$row = $wpdb->get_row("select SUM(sale_price) AS total from $sales_table_name where sale_price < 0 AND date BETWEEN '$start_date' AND '$end_date'", OBJECT);
	$total_sales = round($row->total,2);
	if (empty($total_sales))
	{
		$total_sales = "0.00";
	}
	return $total_sales;
}
function eStore_net_amount_between_dates($start_date,$end_date)
{
	return (eStore_sale_amount_between_dates($start_date,$end_date) + eStore_refund_amount_between_dates($start_date,$end_date));
}
function eStore_itemised_sale_stat_between_datas($start_date,$end_date)
{
    global $total_refund;
    global $refund_qty;
    global $wpdb;
    global $sales_table_name;
    $query = $wpdb->get_results("SELECT * FROM $sales_table_name WHERE date BETWEEN '$start_date' AND '$end_date'", OBJECT);
    
    $item_stats = array();
    //$item_sale_details = array();
    if ($query)
    {
        foreach ($query as $query)
        {
            $item_id = $query->item_id;
            $sale_price = $query->sale_price;
			if ($sale_price < 0) //This is a refund
			{
				continue;        	
			}
            $value = $item_id;
            $key = "item_id";
            if (!eStoreMyInArray($item_stats, $value, $key))
            {
                // Add the new sale item in the array
	            $item_sale_details = array('item_id' => $item_id, 'sale_price' => $sale_price, 'qty_sold' => 1, 'sale_total' => $sale_price);
	            array_push($item_stats, $item_sale_details);                       	
            }
            else
            {
                //Add the qty_sold and sale amount
                //echo "<br />Existing Item ID: ".$item_id." Need to update stats<br />";
                foreach ($item_stats as $key => $item)
                {
                    if ($item['item_id'] == $item_id)
                    {
                        $item['qty_sold'] = $item['qty_sold'] + 1;
                        $item['sale_total'] = $item['sale_total'] + $sale_price;
       	                unset($item_stats[$key]);
        	            array_push($item_stats, $item);
                    }
                }
            }
        }
    }
    return $item_stats;
}

function eStoreMyInArray($array, $value, $key)
{
    //loop through the array
    foreach ($array as $val) {
      //if $val is an array cal myInArray again with $val as array input
      if(is_array($val)){
        if(eStoreMyInArray($val,$value,$key))
          return true;
      }
      //else check if the given key has $value as value
      else{
        if($array[$key]==$value)
          return true;
      }
    }
    return false;
}

?>