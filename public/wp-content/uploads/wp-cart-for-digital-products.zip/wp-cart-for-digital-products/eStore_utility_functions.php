<?php
function eStore_is_valid_url_if_not_empty($url)
{
	if(empty($url))
	{
		return true;
	}
	else
	{
		return eStore_is_valid_url($url);
	}
}
function eStore_is_valid_url($url)
{
        $url = @parse_url($url);
        if ( ! $url) {
            return false;
        }
        $url = array_map('trim', $url);
        $url['port'] = (!isset($url['port'])) ? 80 : (int)$url['port'];
        $path = (isset($url['path'])) ? $url['path'] : '';
        if ($path == '')
        {
            $path = '/';
        }
        $path .= ( isset ( $url['query'] ) ) ? "?$url[query]" : '';
        if ( isset ( $url['host'] ) AND $url['host'] != gethostbyname ( $url['host'] ) )
        {
            if ( PHP_VERSION >= 5 )
            {
                $headers = get_headers("$url[scheme]://$url[host]:$url[port]$path");
            }
            else
            {
                $fp = fsockopen($url['host'], $url['port'], $errno, $errstr, 30);
                if ( ! $fp )
                {
                    return false;
                }
                fputs($fp, "HEAD $path HTTP/1.1\r\nHost: $url[host]\r\n\r\n");
                $headers = fread ( $fp, 128 );
                fclose ( $fp );
            }
            $headers = ( is_array ( $headers ) ) ? implode ( "\n", $headers ) : $headers;
            return ( bool ) preg_match ( '#^HTTP/.*\s+[(200|301|302)]+\s#i', $headers );
        }
        return false;
}
function wp_eStore_is_date_valid($date)
{
    	$arr=split("-",$date); // splitting the array
		$yy=($arr[0]); // first element of the array is year
		$mm=($arr[1]); // second element is month
		$dd=($arr[2]); // third element is day
		If(!checkdate($mm,$dd,$yy)){
			return false;
		}	
		else{
			return true;
		}
}
?>