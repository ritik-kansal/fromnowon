<?php
function get_thumbnail_image_section_code($ret_product)
{
	if(get_option('eStore_enable_smart_thumb'))
	{
		$thumb_img = get_eStore_smart_thumb($ret_product->thumbnail_url);
	}
	else
	{
		$thumb_img = $ret_product->thumbnail_url;
	}	
			
	if(!empty($ret_product->target_thumb_url))
    {
        $output .= '<div class="eStore-thumbnail"><a href="'.$ret_product->target_thumb_url.'" title="'.$ret_product->name.'"><img class="thumb-image" src="'.$thumb_img.'" alt="'.$ret_product->name.'" /></a></div>';
    }
    else
    {
        $output .= '<div class="eStore-thumbnail">';
        $output .= '<a href="'.$ret_product->thumbnail_url.'" rel="lightbox" title="'.$ret_product->name.'"><img class="thumb-image" src="'.$thumb_img.'" alt="'.$ret_product->name.'" /></a>';
        $output .= '</div>';
        if(!empty($ret_product->additional_images))
        {
        	$product_images = explode(',',$ret_product->additional_images);
        	foreach ($product_images as $image)
        	{
        		$output .= '<a href="'.trim($image).'" rel="lightbox" title="'.$ret_product->name.'"></a>';
        	}
        }                
    }
    return $output;
}
function get_input_button($button_url)
{
    if (!empty($button_url))
    {
        $replacement .= '<input type="image" src="'.$button_url.'" class="eStore_button" alt="Add to Cart" />';
    }
    else
    {
    	if (preg_match("/http/", WP_ESTORE_ADD_CART_BUTTON)) // Use the image as the 'add to cart' button
    	{
    		$replacement .= '<input type="image" src="'.WP_ESTORE_ADD_CART_BUTTON.'" class="eStore_button" alt="Add to Cart" />';
    	}
    	else
    	{
    		$replacement .= '<input type="submit" value="'.WP_ESTORE_ADD_CART_BUTTON.'" />';
    	}
    }
    return $replacement;
}

function get_variation_and_input_code($ret_product,$line_break=true,$button_type=1,$nggImage='')
{		
	$variation_add_string = "+";
	$curr_sign = get_option('cart_currency_symbol');
	if (!empty($ret_product->variation1))
	{
		$pieces = explode('|',$ret_product->variation1);
		$variation1_name = $pieces[0];
		if ($line_break) $var_output .= '<br />';
		if(!empty($variation1_name))
			$var_output .= $variation1_name." : ";
		if($button_type == 1){
			$var_output .= '<select name="variation1" class="eStore_variation" onchange="ReadForm1 (this.form, 1);">';
		}
		else if($button_type == 2){
			$var_output .= '<select name="variation1" class="eStore_variation" onchange="ReadForm1 (this.form, 2);">';
		}
		else if($button_type == 3){
			$var_output .= '<select name="variation1" class="eStore_variation" onchange="ReadForm1 (this.form, 3);">';
		}		
		for ($i=1;$i<sizeof($pieces); $i++)
		{
			$pieces2 = explode(':',$pieces[$i]);
			if (sizeof($pieces2) > 1)				
				$tmp_txt = $pieces2[0].' ['.$variation_add_string.' '.$curr_sign.$pieces2[1].']';
			else	
				$tmp_txt = $pieces2[0];
			$var_output .= '<option value="'.htmlspecialchars($tmp_txt).'">'.$tmp_txt.'</option>';
		}
		$var_output .= '</select>';
		if ($line_break) $var_output .= '<br />';	
		else $var_output .= ' ';		
	}

	if (!empty($ret_product->variation2))
	{
		$pieces = explode('|',$ret_product->variation2);
		$variation2_name = $pieces[0];
		if(!empty($variation2_name))
			$var_output .= $variation2_name." : ";
		
		if($button_type == 1){
			$var_output .= '<select name="variation2" class="eStore_variation" onchange="ReadForm1 (this.form, 1);">';
		}
		else if($button_type == 2){
			$var_output .= '<select name="variation2" class="eStore_variation" onchange="ReadForm1 (this.form, 2);">';
		}
		else if($button_type == 3){
			$var_output .= '<select name="variation2" class="eStore_variation" onchange="ReadForm1 (this.form, 3);">';
		}		
		for ($i=1;$i<sizeof($pieces); $i++)
		{
			$pieces2 = explode(':',$pieces[$i]);
			if (sizeof($pieces2) > 1)
				$tmp_txt = $pieces2[0].' ['.$variation_add_string.' '.$curr_sign.$pieces2[1].']';
			else	
				$tmp_txt = $pieces2[0];
				
			$var_output .= '<option value="'.htmlspecialchars($tmp_txt).'">'.$tmp_txt.'</option>';			
		}
		$var_output .= '</select>';
		if ($line_break) $var_output .= '<br />';
		else $var_output .= ' ';			
	}
	if (!empty($ret_product->variation4))
	{
		$pieces = explode('|',$ret_product->variation4);
		$variation4_name = $pieces[0];
		if(!empty($variation4_name))
			$var_output .= $variation4_name." : ";
		
		if($button_type == 1){
			$var_output .= '<select name="variation4" class="eStore_variation" onchange="ReadForm1 (this.form, 1);">';
		}
		else if($button_type == 2){
			$var_output .= '<select name="variation4" class="eStore_variation" onchange="ReadForm1 (this.form, 2);">';
		}
		else if($button_type == 3){
			$var_output .= '<select name="variation4" class="eStore_variation" onchange="ReadForm1 (this.form, 3);">';
		}		
		for ($i=1;$i<sizeof($pieces); $i++)
		{
			$pieces2 = explode(':',$pieces[$i]);
			if (sizeof($pieces2) > 1)
				$tmp_txt = $pieces2[0].' ['.$variation_add_string.' '.$curr_sign.$pieces2[1].']';
			else	
				$tmp_txt = $pieces2[0];
				
			$var_output .= '<option value="'.htmlspecialchars($tmp_txt).'">'.$tmp_txt.'</option>';			
		}
		$var_output .= '</select>';
		if ($line_break) $var_output .= '<br />';
		else $var_output .= ' ';			
	}
	if (!empty($ret_product->variation3))
	{
		$pieces = explode('|',$ret_product->variation3);
		$variation3_name = $pieces[0];
		if(!empty($variation3_name))
			$var_output .= $variation3_name." : ";
		
		if($button_type == 1){
			$var_output .= '<select name="variation3" class="eStore_variation" onchange="ReadForm1 (this.form, 1);">';
		}
		else if($button_type == 2){
			$var_output .= '<select name="variation3" class="eStore_variation" onchange="ReadForm1 (this.form, 2);">';
		}
		else if($button_type == 3){
			$var_output .= '<select name="variation3" class="eStore_variation" onchange="ReadForm1 (this.form, 3);">';
		}			
		for ($i=1;$i<sizeof($pieces); $i++)
		{
			$pieces2 = explode('::',$pieces[$i]);
			if (sizeof($pieces2) > 1)
			{
				if (is_numeric($pieces2[1]))
					$tmp_txt = $pieces2[0].' ['.$variation_add_string.' '.$curr_sign.$pieces2[1].']';
				else
					$tmp_txt = $pieces2[0];
			}
			else	
				$tmp_txt = $pieces2[0];
				
			$var_output .= '<option value="'.htmlspecialchars($tmp_txt).'">'.$tmp_txt.'</option>';
		}
		$var_output .= '</select>';
		if ($line_break) $var_output .= '<br />';
		else $var_output .= ' ';
	}
	if($ret_product->custom_input == '1')
    {
        if(!empty($ret_product->custom_input_label))
            $var_output .= $ret_product->custom_input_label.': <input type="text" name="custom_input" value="" class="eStore_text_input" />';
        else
            $var_output .= 'Instructions: <input type="text" name="custom_input" value="" class="eStore_text_input" />';
  		if ($line_break) $var_output .= '<br />';
		else $var_output .= ' ';
    }
    if(!empty($nggImage->pid))
    {
    	$var_output .= '<input type="text" name="eStore_ngg_pid" value="[pid:'.$nggImage->pid.']" class="eStore_hidden_textfield" />';
    }
    return $var_output;
}
?>