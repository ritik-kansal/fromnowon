<?php
include_once('eStore_classes.php');
include_once('eStore_includes.php');
include_once('eStore_button_display_helper.php');

function eStore_free_download_form($id)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
	$button_image = $ret_product->button_image_url;
	if(empty($button_image))
	{
		$button_image = WP_ESTORE_URL."/images/download_icon.png";
	}
	
	$form_unique_identifier = "eStore_free_download".$id;
	$output = "";
	$email_sent = false;
	if (isset($_POST[$form_unique_identifier]))
	{
		if (empty($_POST['cust_name']) || empty($_POST['cust_email']))
		{
			$output .= WP_ESTORE_NAME_OR_EMAIL_MISSING;
		}
		else
		{
			$postURL = WP_ESTORE_URL."/ajax_process_download.php";
		    // prepare the data
		    $data = array ();
		    $data['name'] = $_POST['cust_name'];
		    $data['email'] = $_POST['cust_email'];
		    $data['prod_id'] = $_POST['free_download_product_id'];
		    $data['ap_id'] = $_POST['free_download_ap_id'];	
		    $data['clientip'] = $_POST['free_download_clientip'];	
			$retVal = eStore_post_data_using_curl($postURL,$data);		
			if($retVal == "NO CURL")
			{
				$output .= "Could not post the request to the server. CURL library is not installed on this server!";
			}		
			else
			{
				$output .= WP_ESTORE_EMAIL_SENT;
			}
			$email_sent = true;
		}		
	}
	if(!$email_sent)
	{	
		$output .= '<div class="free_download_form_old">';
		$output .= '<form method="post"  action=""  style="display:inline">';
		$output .= 'Name: <br /><input name="cust_name" type="text" class="eStore_text_input" /><br />';
		$output .= 'Email: <br /><input name="cust_email" type="text" class="eStore_text_input" /><br />';
		$output .= '<input type="hidden" name="eStore_free_download" value="1" />';
		$output .= '<input type="hidden" name="'.$form_unique_identifier.'" value="1" />';
		$output .= '<input type="hidden" name="free_download_product_id" value="'.$id.'" />';
		$output .= '<input type="hidden" name="free_download_ap_id" id="free_download_ap_id" value="'.$_COOKIE['ap_id'].'" />';
		$output .= '<input type="hidden" name="free_download_clientip" id="free_download_clientip" value="'.$_SERVER['REMOTE_ADDR'].'" />';
		$output .= '<input type="image" name="submit" class="free_download_submit" alt="'.ESTORE_DOWNLOAD_TEXT.'" src="'.$button_image.'" />';
		$output .= '</form>';
		$output .= '</div>';	
	}
	
	return $output;
}
function eStore_free_download_form_ajax($id)
{
    eStore_load_free_download_ajax();

	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
	$button_image = $ret_product->button_image_url;
	if(empty($button_image))
	{
		$button_image = WP_ESTORE_URL."/images/download_icon.png";
	}
	
	if (is_numeric($ret_product->available_copies))
	{
		if ($ret_product->available_copies < 1)// No more copies left
		{
			$output = WP_ESTORE_NO_COPIES_LEFT;
			return $output;
		}
	}
		
    $output .= '<div class="free_download_form">';
	$output .= '<form name="free_download" method="post" action="">';
    $output .= '
      <label for="name" id="name_label">'.WP_ESTORE_NAME.': </label><br />
      <input type="text" name="name" id="name" value="" class="eStore_text_input" />
      <br /><label class="error" for="name" id="name_error">'.WP_ESTORE_REQUIRED_FIELD.'<br /></label>

      <label for="eStore_ajax_email" id="email_label">'.ESTORE_EMAIL.': </label><br />
      <input type="text" name="eStore_ajax_email" id="eStore_ajax_email" value="" class="eStore_text_input" />
      <br /><label class="error" for="eStore_ajax_email" id="email_error">'.WP_ESTORE_REQUIRED_FIELD.'<br /></label>
      
      <input type="hidden" name="free_download_product_id" id="free_download_product_id" value="'.$id.'" />
      <input type="hidden" name="free_download_ap_id" id="free_download_ap_id" value="'.$_COOKIE['ap_id'].'" />
      <input type="hidden" name="free_download_clientip" id="free_download_clientip" value="'.$_SERVER['REMOTE_ADDR'].'" />

      <input type="image" name="submit" class="button" id="submit_btn" alt ="'.ESTORE_DOWNLOAD_TEXT.'" src="'.$button_image.'" />';
    $output .=  '</form>';
	$output .= '</div>';

	return $output;
}

function get_button_code_for_product($id)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
    $output = get_button_code_for_element($ret_product);
    return $output;
}

function get_button_code_for_element($ret_product,$line_break=true,$nggImage='',$buttonImage='')
{
	if($ret_product)
	{
		if (is_numeric ($ret_product->available_copies))
		{
			if ($ret_product->available_copies < 1)// No more copies left
			{
				$replacement = '<input type="image" src="'.WP_ESTORE_SOLD_OUT_IMAGE.'" class="eStore_sold_out" title="This item has been sold out" alt="SOLD OUT"/>';
				return $replacement;
			}
		}
		if (!empty($ret_product->target_button_url))
		{
	        $replacement = '<form method="post" action="'.$ret_product->target_button_url.'">';
	        $replacement .= get_input_button($ret_product->button_image_url);
	        $replacement .= '</form>';
	        return $replacement;
	    }
		$replacement .= '<object class="eStore_button_object">';
		$replacement .= '<form method="post" class="eStore-button-form" action=""  style="display:inline" onsubmit="return ReadForm1(this, 1);">';
		
	    $var_output = get_variation_and_input_code($ret_product,$line_break,1,$nggImage);
	    if (!empty($var_output))
	    {
	         $replacement .= $var_output;
	    }
	
		//If custom price option is set
		if($ret_product->custom_price_option=='1')
		{
			$currSymbol = get_option('cart_currency_symbol');
			$replacement .= WP_ESTORE_YOUR_PRICE.': '.$currSymbol.'<input type="text" name="custom_price" size="3" value="" />&nbsp;';
			if ($line_break) $replacement .= '<br />';
		}
			    
	    if($ret_product->show_qty=='1')
	    {
			$replacement .= ESTORE_QUANTITY.': <input type="text" name="add_qty" size="1" value="1" />&nbsp;';
			if ($line_break) $replacement .= '<br />';
	    }
	    else
	    {
	    	$replacement .= '<input type="hidden" name="add_qty" value="1" />';
	    }    
		    
	    if(!empty($buttonImage)){
	    	$replacement .= get_input_button($buttonImage);
	    }
	    else{
	    	$replacement .= get_input_button($ret_product->button_image_url);
	    }
	    
		if(!empty($nggImage->alttext))
		{			
			$replacement .= '<input type="hidden" name="product" value="'.$nggImage->alttext.'" /><input type="hidden" name="product_name_tmp1" value="'.$nggImage->alttext.'" />';
		}
		else
		{
	    	$replacement .= '<input type="hidden" name="product" value="'.$ret_product->name.'" /><input type="hidden" name="product_name_tmp1" value="'.$ret_product->name.'" />';
		}	
		if(!empty($nggImage->imageURL)){
			$replacement .= '<input type="hidden" name="thumbnail_url" value="'.$nggImage->imageURL.'" />';
		}
		else{
			$replacement .= '<input type="hidden" name="thumbnail_url" value="'.$ret_product->thumbnail_url.'" />';
		}	
		$replacement .= '<input type="hidden" name="price" value="'.$ret_product->price.'" /><input type="hidden" name="price_tmp1" value="'.$ret_product->price.'" />';
		$replacement .= '<input type="hidden" name="item_number" value="'.$ret_product->id.'" /><input type="hidden" name="shipping" value="'.$ret_product->shipping_cost.'" /><input type="hidden" name="addcart_eStore" value="1" /><input type="hidden" name="cartLink" value="'.digi_cart_current_page_url().'" /></form>';
		$replacement .= '</object>';
		return $replacement;
	}
	else //could not retrieve product from database
	{
		$replacement = "<div style='color:red;'>Looks like you have entered a product ID in the shortcode that doesn't exist. Please check your product ID and the shortcode again!</div>";
		return $replacement;
	}
}

function get_button_code_fancy2_for_element($ret_product,$line_break=true)
{
	if($ret_product)
	{	
		if (is_numeric ($ret_product->available_copies))
		{
			if ($ret_product->available_copies < 1)// No more copies left
			{
				$replacement = '<input type="image" src="'.WP_ESTORE_SOLD_OUT_IMAGE.'" class="eStore_sold_out" title="This item has been sold out" alt="SOLD OUT"/>';
				return $replacement;
			}
		}
		if (!empty($ret_product->target_button_url))
		{
	        $replacement = '<form method="post" action="'.$ret_product->target_button_url.'" style="display:inline">';
	        $replacement .= get_input_button($ret_product->button_image_url);
	        $replacement .= " ";
	        $replacement .= '</form>';
	        return $replacement;
	    }
	
	    $replacement .= '<object class="eStore_button_object">';
		$replacement .= '<form method="post"  action=""  style="display:inline" onsubmit="return ReadForm1(this, 1);">';
	    
	    $replacement .= get_input_button($ret_product->button_image_url);
	    $replacement .= " ";
	
		//If custom price option is set
		if($ret_product->custom_price_option=='1')
		{
			$replacement .= WP_ESTORE_YOUR_PRICE.': <input type="text" name="custom_price" size="3" value="" />&nbsp;';
			if ($line_break) $replacement .= '<br />';
		}    
	    if($ret_product->show_qty=='1')
	    {
			$replacement .= ESTORE_QUANTITY.': <input type="text" name="add_qty" size="1" value="1" />';
			if ($line_break) $replacement .= '<br />';
	    }
	    else
	    {
	    	$replacement .= '<input type="hidden" name="add_qty" value="1" />';
	    }  
	        
	    $var_output = get_variation_and_input_code($ret_product,$line_break);
	    if (!empty($var_output))
	    {
	    	$replacement .= "  ";
	        $replacement .= $var_output;
	    }    
		$replacement .= '<input type="hidden" name="product" value="'.$ret_product->name.'" /><input type="hidden" name="price" value="'.$ret_product->price.'" />';
		$replacement .= '<input type="hidden" name="product_name_tmp1" value="'.$ret_product->name.'" /><input type="hidden" name="price_tmp1" value="'.$ret_product->price.'" />';
		$replacement .= '<input type="hidden" name="item_number" value="'.$ret_product->id.'" /><input type="hidden" name="shipping" value="'.$ret_product->shipping_cost.'" /><input type="hidden" name="addcart_eStore" value="1" /><input type="hidden" name="cartLink" value="'.digi_cart_current_page_url().'" /></form>';
		$replacement .= '</object>';
		return $replacement;
	}
	else //could not retrieve product from database
	{
		$replacement = "<div style='color:red;'>Looks like you have entered a product ID in the shortcode that doesn't exist. Please check your product ID and the shortcode again!</div>";
		return $replacement;
	}	
}

function print_eStore_ngg_add_to_cart($image)
{
	$output = "";
	$product_id = get_option('eStore_ngg_template_product_id');
	if(empty($product_id))
	{
		$output .= "You need to specify a product ID in the 3rd Party Settings of eStore";
	}
	else
	{
		global $wpdb;
		$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
		$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$product_id'", OBJECT);		
		
		$output .= get_button_code_for_element($ret_product,true,$image);
	}
	return $output;
}

function print_eStore_ngg_buy_now($image)
{
	$output = "";
	$product_id = get_option('eStore_ngg_template_product_id');
	if(empty($product_id))
	{
		$output .= "You need to specify a product ID in the 3rd Party Settings of eStore";
	}
	else
	{
		$output .= print_eStore_buy_now_button($product_id,'',$image);
	}
	return $output;
}
function print_eStore_buy_now_button($id,$button='',$nggImage='')
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);

	if (is_numeric ($ret_product->available_copies))
	{
		if ($ret_product->available_copies < 1)// No more copies left
		{
			$replacement = '<input type="image" src="'.WP_ESTORE_SOLD_OUT_IMAGE.'" class="eStore_sold_out" title="This item has been sold out" alt="SOLD OUT"/>';
			return $replacement;
		}
	}
	$paypal_email = get_option('cart_paypal_email');
	
    if(!empty($ret_product->currency_code))
        $paypal_currency = $ret_product->currency_code;
	else
        $paypal_currency = get_option('cart_payment_currency');
	
    $return = get_option('cart_return_from_paypal_url');

	// Find out if the product should be delivered automatically through a notify email
	if (get_option('eStore_auto_product_delivery') == '')
	{
		$notify = '';
	}
	else
	{
		$notify = WP_ESTORE_URL.'/paypal.php';
	}

    if (!empty($notify))
        $urls .= '<input type="hidden" name="notify_url" value="'.$notify.'" />';

	if (!empty($ret_product->return_url))
	{
		$urls .= '<input type="hidden" name="return" value="'.$ret_product->return_url.'" />';
	}
	else
	{
    	if (!empty($return))
    		$urls .= '<input type="hidden" name="return" value="'.$return.'" />';
	}
	$cancel_url =  get_option('cart_cancel_from_paypal_url');
	if(!empty($cancel_url))
	{
		$urls .= '<input type="hidden" name="cancel_return" value="'.$cancel_url.'" />';
	}
		
    if (empty($button))
    {
	$button = $ret_product->button_image_url;
    }
    if (!empty($button))
    {
        $button_type .= '<input type="image" src="'.$button.'" class="eStore_buy_now_button" alt="'.WP_ESTORE_BUY_NOW.'"/>';
    }
    else
    {
   		$button_type .= '<input type="submit" class="eStore_buy_now_button" value="'.WP_ESTORE_BUY_NOW.'" />';
    }
    $sandbox_enabled = get_option('eStore_cart_enable_sandbox');

    /* === Paypal form === */
    if($sandbox_enabled)
    {
    	$output .= '<object class="eStore_button_object">';
        $output .= '<form action="'.PAYPAL_SANDBOX_URL.'" method="post" onsubmit="return ReadForm1(this, 2);">';
    }
    else
    {
    	$output .= '<object class="eStore_button_object">';
        $output .= '<form action="'.PAYPAL_LIVE_URL.'" method="post" onsubmit="return ReadForm1(this, 2);">';
    }
    
    //Variation code
    $output .= get_variation_and_input_code($ret_product,true,2);
    if(!empty($nggImage->alttext))
    {
    	$output .= '<input type="hidden" name="product_name_tmp1" value="'.$nggImage->alttext.'" /><input type="hidden" name="price_tmp1" value="'.$ret_product->price.'" />';
    }
    else
    {
    	$output .= '<input type="hidden" name="product_name_tmp1" value="'.$ret_product->name.'" /><input type="hidden" name="price_tmp1" value="'.$ret_product->price.'" />';
    }
     
    $output .= '<input type="hidden" name="cmd" value="_xclick" />';
 
    if (!empty($ret_product->paypal_email))
    {
    	$output .= "<input type=\"hidden\" name=\"business\" value=\"$ret_product->paypal_email\" />";
    }
    else
    {
    	$output .= "<input type=\"hidden\" name=\"business\" value=\"$paypal_email\" />";
    }        

    if(!empty($nggImage->alttext))
    {
    	$output .= "<input type=\"hidden\" name=\"item_name\" value=\"$nggImage->alttext\" />";
    }
    else
    {
    	$output .= "<input type=\"hidden\" name=\"item_name\" value=\"$ret_product->name\" />";
    }
    $output .= "<input type=\"hidden\" name=\"amount\" value=\"$ret_product->price\" />";
    $output .= "<input type=\"hidden\" name=\"currency_code\" value=\"$paypal_currency\" />";
    $output .= "<input type=\"hidden\" name=\"item_number\" value=\"$id\" />";
    
    if (!get_option('eStore_paypal_profile_shipping'))
    {
	    if (!empty($ret_product->shipping_cost))
	    {
	    	$baseShipping = get_option('eStore_base_shipping');
	    	$postage_cost = round($ret_product->shipping_cost + $baseShipping,2);
	    	$output .= "<input type=\"hidden\" name=\"shipping\" value='".$postage_cost."' />";
	    	$output .= "<input type=\"hidden\" name=\"no_shipping\" value='2' />";
	    }
	    else
	    {
	    	$output .= "<input type=\"hidden\" name=\"no_shipping\" value='1' />";
	    }  
    }
    else if(!empty($ret_product->weight))//include weight for profile based shipping
    {
    	$output .= "<input type=\"hidden\" name=\"weight\" value='".$ret_product->weight."' />";
    	$output .= "<input type=\"hidden\" name=\"weight_unit\" value=\"lbs\" />";
    }   
    if(get_option('eStore_enable_tax'))
    {
    	if(!empty($ret_product->tax))
    	{
    		$tax = round(($ret_product->price * $ret_product->tax)/100,2);
    		$output .= "<input type=\"hidden\" name=\"tax\" value='".$tax."' />";
    	}
    	else
        {
        	$tax_rate = get_option('eStore_global_tax_rate');
    		$tax = round(($ret_product->price * $tax_rate)/100,2);
    		$output .= "<input type=\"hidden\" name=\"tax\" value='".$tax."' />";
    	}    	
    } 
    
    $output .= $urls;
    $output .= '<input type="hidden" name="mrb" value="3FWGC6LFTMTUG" />';
    $returnButtonText = get_option('eStore_paypal_return_button_text');
    $output .= '<input type="hidden" name="cbt" value="'.$returnButtonText.'" />';
    
    $page_style_name = get_option('eStore_paypal_co_page_style');
    $output .= '<input type="hidden" name="page_style" value="'.$page_style_name.'" />';
        
	if (get_option('eStore_display_tx_result'))
	{
	    $output .= '<input type="hidden" name="rm" value="2">';
	}    
    if(empty($ret_product->ref_text))
    {
	    if(!empty($nggImage->pid))
	    {
	        $custom_field_val = eStore_get_custom_field_value();
	        $custom_field_val = append_values_to_custom_field('ngg_pid',$nggImage->pid);
	        $output .= '<input type="hidden" name="custom" value="'.$custom_field_val.'" id="eStore_custom_values" />';
	    }
	    else
	    {     	
        	$output .= aff_add_custom_field();
	    }
    }   
    else
    {
        $custom_field_val = eStore_get_custom_field_value();
        $custom_field_val = append_values_to_custom_field('subsc_ref',$ret_product->ref_text);
        $output .= '<input type="hidden" name="custom" value="'.$custom_field_val.'" id="eStore_custom_values" />';
    }      
    if (get_option('eStore_show_t_c_for_buy_now'))
		$output .= eStore_show_terms_and_cond();  
		
    $output .= $button_type;    
    $output .= '</form>';
    $output .= '</object>';
    /* = end of paypal form = */
    return $output;
}

//*********** Start of deprecated method ************
function print_wp_eStore_buy_now_button($id, $button)
{
	$output .= "<br />This is a deprecated function. Please contact us and we will suggest a better alternative.<br />";
    return $output;
}
//************* end of deprecated method ************

function print_eStore_subscribe_button_form($id)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
	
	if (is_numeric ($ret_product->available_copies))
	{
		if ($ret_product->available_copies < 1)// No more copies left
		{
			$replacement = '<input type="image" src="'.WP_ESTORE_SOLD_OUT_IMAGE.'" class="eStore_sold_out" title="This item has been sold out" alt="SOLD OUT"/>';
			return $replacement;
		}
	}
	if (!empty($ret_product->paypal_email))
		$paypal_email = $ret_product->paypal_email;
	else
		$paypal_email = get_option('cart_paypal_email');
		
    if(!empty($ret_product->currency_code))
        $paypal_currency = $ret_product->currency_code;
	else
        $paypal_currency = get_option('cart_payment_currency');	
	//$paypal_currency = get_option('cart_payment_currency');
	$return = get_option('cart_return_from_paypal_url');

	// Find out if the product should be delivered automatically through a notify email
	if (get_option('eStore_auto_product_delivery') == '')
	{
		$notify = '';
	}
	else
	{
		$notify = WP_ESTORE_URL.'/paypal.php';
	}

    if (!empty($notify))
        $urls .= '<input type="hidden" name="notify_url" value="'.$notify.'" />';

	if (!empty($ret_product->return_url))
	{
		$urls .= '<input type="hidden" name="return" value="'.$ret_product->return_url.'" />';
	}
	else
	{
    	if (!empty($return))
    		$urls .= '<input type="hidden" name="return" value="'.$return.'" />';
	}
	$cancel_url =  get_option('cart_cancel_from_paypal_url');
	if(!empty($cancel_url))
	{
		$urls .= '<input type="hidden" name="cancel_return" value="'.$cancel_url.'" />';
	}
	
	$button = $ret_product->button_image_url;
    if (!empty($button))
    {
        $button_type .= '<input type="image" src="'.$button.'" class="eStore_subscribe_button" alt="'.WP_ESTORE_SUBSCRIBE.'"/>';
    }
    else
    {
   		$button_type .= '<input type="submit" class="eStore_subscribe_button" value="'.WP_ESTORE_SUBSCRIBE.'" />';
    }
    $sandbox_enabled = get_option('eStore_cart_enable_sandbox');
   		
    /* === Paypal form === */
    if($sandbox_enabled)
    {
    	$output .= '<object class="eStore_button_object">';
        $output .= '<form action="'.PAYPAL_SANDBOX_URL.'" method="post" onsubmit="return ReadForm1(this, 3);">';
    }
    else
    {
    	$output .= '<object class="eStore_button_object">';
        $output .= '<form action="'.PAYPAL_LIVE_URL.'" method="post" onsubmit="return ReadForm1(this, 3);">';
    }
    //variation code
    $output .= get_variation_and_input_code($ret_product,true,3);
    $output .= '<input type="hidden" name="product_name_tmp1" value="'.$ret_product->name.'" /><input type="hidden" name="price_tmp1" value="'.$ret_product->a3.'" />';
    
    $output .= '<input type="hidden" name="cmd" value="_xclick-subscriptions" />';
    $output .= "<input type=\"hidden\" name=\"business\" value=\"$paypal_email\" />";
    $output .= "<input type=\"hidden\" name=\"item_name\" value=\"$ret_product->name\" />";
    $output .= "<input type=\"hidden\" name=\"currency_code\" value=\"$paypal_currency\" />";
    $output .= "<input type=\"hidden\" name=\"item_number\" value=\"$id\" />";    
    $output .= '<input type="hidden" name="rm" value="2" /><input type="hidden" name="no_note" value="1" />';
    if(!empty($ret_product->p1))
    {
    	$output .= "<input type=\"hidden\" name=\"a1\" value=\"$ret_product->a1\" /><input type=\"hidden\" name=\"p1\" value=\"$ret_product->p1\" /><input type=\"hidden\" name=\"t1\" value=\"$ret_product->t1\" />";
    }
    if(!empty($ret_product->p3))
    {
    	if(empty($ret_product->a3))
    	{
    		$output .= "<div style='color:red;'>Looks like you did not specify a recurring amount in the subscription details. Please note that you must specify a value for the Recurring Billing Amount to create a working subscription payment button!</div>";
    	}
    	else
    	{    		    	
    		$output .= "<input type=\"hidden\" name=\"a3\" value=\"$ret_product->a3\" /><input type=\"hidden\" name=\"p3\" value=\"$ret_product->p3\" /><input type=\"hidden\" name=\"t3\" value=\"$ret_product->t3\" />";
    	}
    }   
    if($ret_product->sra == '1')
    {
    	$output .= '<input type="hidden" name="sra" value="1" />';
    }

    if($ret_product->srt>0)
    {
    	$output .= "<input type=\"hidden\" name=\"src\" value=\"1\" /><input type=\"hidden\" name=\"srt\" value=\"$ret_product->srt\" />";
    }
    else if($ret_product->srt == '0')
    {
        $output .= "<input type=\"hidden\" name=\"src\" value=\"1\" />";
    }

    $output .= $urls;
    $output .= '<input type="hidden" name="mrb" value="3FWGC6LFTMTUG" />';    
    $returnButtonText = get_option('eStore_paypal_return_button_text');
    $output .= '<input type="hidden" name="cbt" value="'.$returnButtonText.'" />';

    $page_style_name = get_option('eStore_paypal_co_page_style');
    $output .= '<input type="hidden" name="page_style" value="'.$page_style_name.'" />';
        
    if(empty($ret_product->ref_text))
    {
        $output .= aff_add_custom_field();
    }
    else
    {
        $custom_field_val = eStore_get_custom_field_value();
        $subsc_ref_val = 'subsc_ref='.$ret_product->ref_text;
        if (empty($custom_field_val)){
            $custom_field_val = $subsc_ref_val;
        }
        else{
            $custom_field_val = $custom_field_val.'&'.$subsc_ref_val;
        }
        $output .= '<input type="hidden" name="custom" value="'.$custom_field_val.'" id="eStore_custom_values" />';
    }
    if (get_option('eStore_show_t_c_for_buy_now'))
		$output .= eStore_show_terms_and_cond();  
		    
    $output .= $button_type;
    $output .= '</form>';
    $output .= '</object>';
    /* = end of paypal form = */
    return $output;		
}

function show_product_fancy_style($id,$button_type=1)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);

    $output = '<div class="eStore-product">';
    $output .= get_thumbnail_image_section_code($ret_product);
    if(!empty($ret_product->product_url))
    {
    	$output .= '<div class="eStore-product-description"><div class="eStore-product-name"><a href="'.$ret_product->product_url.'">'.$ret_product->name.'</a></div>';
    }
    else
    {
    	$output .= '<div class="eStore-product-description"><div class="eStore-product-name">'.$ret_product->name.'</div>';
    }    
    $output .= html_entity_decode($ret_product->description, ENT_COMPAT,"UTF-8");
    if (!empty($ret_product->available_copies))
        $output .= '<br />'.ESTORE_AVAILABLE_QTY.': '.$ret_product->available_copies;
    
    if(!empty($ret_product->old_price)){
    	$output .= '<div class="eStore_oldprice"><strong>'.ESTORE_OLD_PRICE.': </strong>'.WP_ESTORE_CURRENCY_SYMBOL.$ret_product->old_price.'</div>';
    }
    $output .= '<div class="eStore_price"><strong>'.ESTORE_PRICE.': </strong>'.WP_ESTORE_CURRENCY_SYMBOL.$ret_product->price.'</div>';
    
    $conversion_rate = get_option('eStore_secondary_currency_conversion_rate');
    if (!empty($conversion_rate))
    {
    	$secondary_curr_symbol = get_option('eStore_secondary_currency_symbol');
    	$output .= get_option('eStore_secondary_currency_code').' '.$secondary_curr_symbol.number_format($ret_product->price*$conversion_rate,2).'<br />';
    }
    
    if($button_type==1)
        $output .= get_button_code_for_element($ret_product);
    else if ($button_type==2)
        $output .= print_eStore_buy_now_button($id);
    else if ($button_type==3)
        $output .= print_eStore_subscribe_button_form($id);
    else if ($button_type==4)
        $output .= eStore_show_download_now_button($id);
    $output .= '</div></div>';
    
    return $output;
}
function show_product_fancy_style2($id,$button_type=1)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);

    $output = '<div class="eStore-product-fancy2">';
    $output .= get_thumbnail_image_section_code($ret_product);
    if(!empty($ret_product->product_url))
    {
    	$output .= '<div class="eStore-product-description"><div class="eStore-fancy2-product-name"><a href="'.$ret_product->product_url.'">'.$ret_product->name.'</a></div>';
    }
    else
    {
    	$output .= '<div class="eStore-product-description"><div class="eStore-fancy2-product-name">'.$ret_product->name.'</div>';
    }      
    //$output .= '<div class="eStore-product-description"><div class="eStore-product-name">'.$ret_product->name.'</div>';
    $output .= html_entity_decode($ret_product->description, ENT_COMPAT,"UTF-8");
    if (!empty($ret_product->available_copies))
        $output .= '<br /><strong>'.ESTORE_AVAILABLE_QTY.': </strong>'.$ret_product->available_copies;    
    $output .= '</div></div>';

    $output .= '<div class="eStore-product-fancy2-footer">';
    $output .= '<div class="footer-left"><div class="footer-left-content">';
    if($button_type==1)
        $output .= get_button_code_fancy2_for_element($ret_product,false);
    else if ($button_type==2)
        $output .= print_eStore_buy_now_button($id);
    else if ($button_type==3)
        $output .= print_eStore_subscribe_button_form($id);
    else if ($button_type==4)
        $output .= eStore_show_download_now_button($id);    
    $output .= '</div></div>';
    
    $conversion_rate = get_option('eStore_secondary_currency_conversion_rate');
    if (!empty($conversion_rate))
    {
    	$secondary_curr_symbol = get_option('eStore_secondary_currency_symbol');
    	$secondary_curr_code = get_option('eStore_secondary_currency_code');
    	$output .= '<div class="footer-right"><span>';
    	$output .= ESTORE_PRICE.': '.WP_ESTORE_CURRENCY_SYMBOL.$ret_product->price;
    	$output .= ' ('.$secondary_curr_code.' '.$secondary_curr_symbol.number_format($ret_product->price*$conversion_rate,2).')';
    	$output .= '</span></div>';
    }
    else
    {    
		$output .= '<div class="footer-right"><span>'.ESTORE_PRICE.': '.WP_ESTORE_CURRENCY_SYMBOL.$ret_product->price.'</span></div>';
    }
    $output .= '</div>';
    $output .= '<div class="eStore-clear-float"></div>';

    return $output;
}

function show_download_now_fancy_no_price($id)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);

    $output = '<div class="eStore-product">';
    $output .= get_thumbnail_image_section_code($ret_product);
    if(!empty($ret_product->product_url))
    {
    	$output .= '<div class="eStore-product-description"><a href="'.$ret_product->product_url.'"><strong>'.$ret_product->name.'</strong></a>';
    }
    else
    {
    	$output .= '<div class="eStore-product-description"><strong>'.$ret_product->name.'</strong>';
    }    
    $output .= '<br />'.html_entity_decode($ret_product->description, ENT_COMPAT,"UTF-8");
    //if (!empty($ret_product->available_copies))
    //    $output .= '<br />'.ESTORE_AVAILABLE_QTY.': '.$ret_product->available_copies;
    
    $output .= eStore_show_download_now_button($id);
    $output .= '</div></div>';
    
    return $output;
}

function show_all_categories_stylish()
{
	global $wpdb;
	$cat_table_name = WP_ESTORE_CATEGORY_TABLE_NAME;
	$wp_eStore_cat_db = $wpdb->get_results("SELECT * FROM $cat_table_name ORDER BY cat_id ASC", OBJECT);
	if ($wp_eStore_cat_db)
	{
   		foreach ($wp_eStore_cat_db as $wp_eStore_cat_db)
   		{
            $output .= show_category_fancy_style($wp_eStore_cat_db);
   		}
	}	
	return $output;		
}

function show_category_stylish($id)
{
	global $wpdb;
	$cat_table_name = WP_ESTORE_CATEGORY_TABLE_NAME;
	$wp_eStore_cat_db = $wpdb->get_row("SELECT * FROM $cat_table_name WHERE cat_id = '$id'", OBJECT);
	if ($wp_eStore_cat_db)
	{
            $output = show_category_fancy_style($wp_eStore_cat_db);
        }
        return $output;
}

function show_category_fancy_style($wp_eStore_cat_db)
{
    $output = '<div class="eStore-category-fancy">';
    $output .= '<div class="eStore-category-fancy-thumbnail"><a href="'.$wp_eStore_cat_db->cat_url.'" title="'.$wp_eStore_cat_db->cat_name.'"><img class="thumb-image" src="'.$wp_eStore_cat_db->cat_image.'" alt="'.$wp_eStore_cat_db->cat_name.'" /></a></div>';
    $output .= '<div class="eStore-category-fancy-name">';
    $output .= '<a href="'.$wp_eStore_cat_db->cat_url.'">'.'<strong>'.$wp_eStore_cat_db->cat_name.'</strong></a>';
    $output .= '</div>';
    $output .= '<div class="eStore-category-fancy-description">';	
    //$output .= html_entity_decode($wp_eStore_cat_db->cat_desc, ENT_COMPAT);
    $output .= html_entity_decode($wp_eStore_cat_db->cat_desc, ENT_COMPAT,"UTF-8");
    $output .= '</div></div>';
    
    return $output;	
}
function show_products_from_category($id,$style=1)
{
	$i = 0;
    //set pages to include $limit records per page
	$limit = get_option('eStore_products_per_page');
	if(empty($limit))
		$limit = 25;	
    if (isset($_GET['product_page']))
    {
        $page = $_GET['product_page'];
    }
    else
    {
        $page = 1;
    }
    $start = ($page - 1) * $limit;

	global $wpdb;
	$cat_prod_rel_table_name = $wpdb->prefix . "wp_eStore_cat_prod_rel_tbl";
	//$wp_eStore_db = $wpdb->get_results("SELECT * FROM $cat_prod_rel_table_name where cat_id=$id", OBJECT);
	$wp_eStore_db = $wpdb->get_results("SELECT * FROM $cat_prod_rel_table_name where cat_id=$id ORDER BY prod_id DESC LIMIT $start, $limit", OBJECT);
    $totalrows = $wpdb->get_var("SELECT COUNT(*) FROM $cat_prod_rel_table_name where cat_id=$id;");

	if ($wp_eStore_db)
	{
   		foreach ($wp_eStore_db as $wp_eStore_db)
   		{
            if ($style==1)
            {
                $output .= show_product_fancy_style($wp_eStore_db->prod_id);
            }
            else if ($style==2)
            {
                $output .= show_product_fancy_style2($wp_eStore_db->prod_id);
            }          
   		}
	}
	else
	{
		$output .= "No products in this category yet!";
	}
    //Number of pages setup
    if ($totalrows > $limit)
    {
    	$pages = ceil($totalrows / $limit)+1;
    	$separator='?';
		$url=get_permalink();
		if(strpos($url,'?product_page='))
		{
			$separator='?';
		}
		else if(strpos($url,'?')!==false)
		{
		    $separator='&';
		}    	
    	$output .= '<div class="product_page">';
        for($r = 1;$r<$pages;$r++) 
        {
        	$output .= '<a href="'.$url.$separator.'product_page='.$r.'">'.$r.'</a>&nbsp;';
            //$output .= "<a href='?product_page=".$r."'>".$r."</a>&nbsp;";
            if ($r%15==0)
               $output .= '<br /><br />';
        }
        $output .= '</div>';
    }    
	return $output;	
}
function eStore_print_all_products_stylish($style=1)
{
	$i = 0;
    //set pages to include $limit records per page
	$limit = get_option('eStore_products_per_page');
	if(empty($limit))
		$limit = 25;		
    if (isset($_GET['product_page']))
    {
        $page = $_GET['product_page'];
    }
    else
    {
        $page = 1;
    }
    $start = ($page - 1) * $limit;

	global $wpdb;
	$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
	//$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$wp_eStore_db = $wpdb->get_results("SELECT * FROM $products_table_name ORDER BY id DESC LIMIT $start, $limit", OBJECT);
    //get total rows
    $totalrows = $wpdb->get_var("SELECT COUNT(*) FROM $products_table_name;");

	if ($wp_eStore_db)
	{
   		foreach ($wp_eStore_db as $wp_eStore_db)
   		{
            if ($style==1)
            {
                $output .= show_product_fancy_style($wp_eStore_db->id);
            }
            else if ($style==2)
            {
                $output .= show_product_fancy_style2($wp_eStore_db->id);
            }
   		}
	}
    //Number of pages setup
	$separator='?';
	$url=get_permalink();
	if(strpos($url,'?product_page='))
	{
		$separator='?';
	}
	else if(strpos($url,'?')!==false)
	{
	    $separator='&';
	}    
	$pages = ceil($totalrows / $limit)+1;
	$output .= '<div class="product_page">';
    for($r = 1;$r<$pages;$r++) 
    {
        $output .= '<a href="'.$url.$separator.'product_page='.$r.'">'.$r.'</a>&nbsp;';
        if ($r%15==0)
           $output .= '<br /><br />';
    }
    $output .= '</div>';
	return $output;
}

function wp_estore_products_table()
{
	$i = 0;
	$output .= '
	<table class="widefat">
	<thead><tr>
	<th scope="col">'.__('Products', 'wp_eStore').'</th>
	</tr></thead>
	<tbody>';
    
    //set pages to include $limit records per page
	$limit = get_option('eStore_products_per_page');
    if (isset($_GET['product_page']))
    {
        $page = $_GET['product_page'];
    }
    else
    {
        $page = 1;
    }
    $start = ($page - 1) * $limit;

	global $wpdb;
	$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
	//$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$wp_eStore_db = $wpdb->get_results("SELECT * FROM $products_table_name ORDER BY id DESC LIMIT $start, $limit", OBJECT);
    //get total rows
    $totalrows = $wpdb->get_var("SELECT COUNT(*) FROM $products_table_name;");

	if ($wp_eStore_db)
	{
		foreach ($wp_eStore_db as $wp_eStore_db)
		{
			if($i%2 == 0)
              {
				$output .= "<tr bgcolor='#F4F6FA'>";
				$i++;
			  }
			else
			  {
				$output .= "<tr bgcolor='#E9EDF5'>";
				$i++;
			  }
			$output .= '<td><strong>'.$wp_eStore_db->name.'</strong><br> '.WP_ESTORE_CURRENCY_SYMBOL.$wp_eStore_db->price.'<br>';
			$output .= print_wp_digi_cart_button_for_product($wp_eStore_db->id);
			$output .= '<br></td></tr>';
		}
	}

	$output .= '</tbody>
	</table>';

    //Number of pages setup
	$pages = ceil($totalrows / $limit)+1;
	$output .= '<div class="product_page">';
    for($r = 1;$r<$pages;$r++) 
    {
        $output .= "<a href='?product_page=".$r."'>".$r."</a>&nbsp;";
        if ($r%15==0)
           $output .= '<br /><br />';
    }
    $output .= '</div>';
	return $output;
}

function eStore_show_terms_and_cond()
{
    eStore_load_t_and_c_jquery();
    $terms_url = get_option('eStore_t_c_url');
    $terms = "<a href=\"$terms_url\" target=\"_blank\"><u>".ESTORE_TERMS_AND_CONDITIONS."</u></a>";
    $output = '<input type="checkbox" name="t-and-c" class="t-and-c" value="" /><label for="t-and-c">'.ESTORE_TERMS_AGREE.$terms.'</label><br />';
    $output .= '<label class="t_and_c_error" for="t-and-c" id="t_and_c_error">'.ESTORE_TERMS_ERROR.'<br /></label>';
    return $output;
}

function eStore_get_sale_counter($id)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);

    $output = $ret_product->sales_count;
    return $output;
}

function eStore_get_remaining_copies_counter($id)
{
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);

    $output = $ret_product->available_copies;
    return $output;
}

function eStore_show_download_now_button($id)
{
	$output = '<div class="download_now_button">';
	$output .= '<form method="post"  action=""  style="display:inline">';
	$output .= '<input type="hidden" name="eStore_download_now_button" value="1" />';
	$output .= '<input type="hidden" name="download_now_product_id" value="'.$id.'" />';
	
	global $wpdb;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;		
	$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
	$button = $ret_product->button_image_url;
    if (!empty($button))
    {
        $button_type .= '<input type="image" src="'.$button.'" class="download_now_button_submit" alt="'.ESTORE_DOWNLOAD_TEXT.'"/>';
    }
    else
    {
   		$button_type .= '<input type="submit" name="submit" class="download_now_button_submit" value="'.ESTORE_DOWNLOAD_TEXT.'" />';
    }
    	
	$output .= $button_type;
	$output .= '</form>';
	$output .= '</div>';
	return $output;
}
function eStore_show_members_purchase_history()
{
    if (function_exists('wp_eMember_install'))
    {  
	    global $auth;
	    //$user_name = $auth->getUserInfo('user_name');
	    $user_id = $auth->getUserInfo('member_id');
	    if (!empty($user_id))
	    {
			$output .= eStore_display_members_purchase_history($user_id);		
	    }
	    else
	    {
	    	$output .= ESTORE_YOU_MUST_BE_LOGGED;
	    }
    }
    else
    {
    	$output .= "<br />You need to have the WP eMember plugin installed to be able to use this feature";
    }
	return $output;
}
function eStore_display_members_purchase_history($user_id)
{
	global $wpdb;
	$customer_table_name = WP_ESTORE_CUSTOMER_TABLE_NAME;
	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;	
	$ret_customer_db = $wpdb->get_results("SELECT * FROM $customer_table_name WHERE member_username = '$user_id'", OBJECT);	
	$output .= '
	<table class="widefat">
	<thead><tr>
	<th scope="col">'.ESTORE_PRODUCT_NAME.'</th>	
    <th scope="col">'.ESTORE_DATE.'</th>
    <th scope="col">'.ESTORE_PRICE_PAID.'</th>
	</tr></thead>
	<tbody>';

	if ($ret_customer_db)
	{
		foreach ($ret_customer_db as $ret_customer_db)
		{
			//$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$ret_customer_db->purchased_product_id'", OBJECT);				
			$output .= '<tr>';
			$output .= '<td align="left">'.$ret_customer_db->product_name.'</td>';
			$output .= '<td align="center">'.$ret_customer_db->date.'</td>';
			$output .= '<td align="center">'.$ret_customer_db->sale_amount.'</td>';		
			$output .= '</tr>';
		}
	}
	else
	{
		$output .= '<tr><td colspan="4">'.ESTORE_NO_PURCHASE_FOUND.'</td></tr>';
	}
	$output .= '</tbody></table>';
	return $output;		
}
?>