<?php
function eStore_empty_cart_display()
{
	    $empty_cart_text = get_option('wp_cart_empty_text');
    	if (preg_match("/http/", $empty_cart_text)) // Use the image as the 'Empty Cart Display'
    	{
    	    $output .= '<input type="image" src="'.$empty_cart_text.'" class="eStore_empty_cart" alt="Shopping Cart Empty" title="Shopping Cart Empty" />';
    	    $output .= '<br />'.ESTORE_CART_EMPTY;
    	}
    	else
    	{
    		$output .= $empty_cart_text;
    	}

		$products_page = get_option('eStore_products_page_url');
		if (!empty($products_page))
		{
			$output .= '<br /><a rel="nofollow" href="'.$products_page.'">'.ESTORE_VISIT_THE_SHOP.'</a>';
		}
		return $output;
}
function eStore_get_cart_total()
{
	$total = 0;
	if(empty($_SESSION['eStore_cart']))
	{
		return $total;
	}
	foreach ($_SESSION['eStore_cart'] as $item)
	{
		$total += $item['price'] * $item['quantity'];
	}
	return $total;
}
function eStore_get_total_cart_item_qty()
{
	$total_items = 0;
	if(empty($_SESSION['eStore_cart']))
	{
		return $total_items;
	}
	foreach ($_SESSION['eStore_cart'] as $item)
	{
		$total_items +=  $item['quantity'];
	}
	return $total_items;
}
function eStore_get_checkout_url()
{
	if (get_option('eStore_auto_cart_anchor'))
    {
        $checkout_url = get_option('eStore_checkout_page_url')."#wp_cart_anchor";
    }
    else
    {
        $checkout_url = get_option('eStore_checkout_page_url');
    }
    return $checkout_url;
}
function eStore_get_cart_tax()
{
	$total_tax = 0;
	if(get_option('eStore_enable_tax'))
	{
		$tax = 0;
		global $wpdb;
		$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;			
		foreach ($_SESSION['eStore_cart'] as $item)
		{
			$id = $item['item_number'];
			$ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
			if($ret_product->tax == "0"){
				$tax = 0;
			}
			else if(empty($ret_product->tax)){
				$tax_rate = get_option('eStore_global_tax_rate');
				$tax = ($item['price'] * $item['quantity'] * $tax_rate)/100;
			}
			else{
				$tax = ($item['price'] * $item['quantity'] * $ret_product->tax)/100;
			}		
			$total_tax = $total_tax + $tax;
		}
	}
	$_SESSION['eStore_cart_total_tax'] = $total_tax;
	return $total_tax;	
}
function eStore_show_compact_cart()
{
	if ($_SESSION['eStore_cart'] && is_array($_SESSION['eStore_cart']))
	{
		$num_items = count($_SESSION['eStore_cart']); 
	}
	if ($num_items > 0)
	{
		if ($num_items == 1)
		{
			$output .= $num_items.ESTORE_ITEM_IN_THE_CART;
		}
		else
		{
			$output .= $num_items.ESTORE_ITEMS_IN_THE_CART;
		}
		$output .= "<br /><a href=".eStore_get_checkout_url().">".ESTORE_VIEW_CART."</a><br />";			
	}
	else
	{
		$output = eStore_empty_cart_display();
	}
	return $output;
}

function eStore_shopping_cart_fancy1()
{
	if (!digi_cart_not_empty())
	{
        return eStore_empty_cart_display();
    }
    $decimal = '.';
    $defaultSymbol = get_option('cart_currency_symbol');
    if (!empty($defaultSymbol))
        $currency_symbol = $defaultSymbol;
    else
        $currency_symbol = '$';        

    $output .= '<a name="wp_cart_anchor"></a>';    
    $output .= '<div class="eStore_cart_fancy1">';
    
    $title = get_option('wp_cart_title');
    if(!empty($title))
    {
    	$output .= '<div class="eStore_cart_fancy1_header">';
    	$output .= $title;
    	$output .= '</div>';
    }
	
    $output .= eStore_cart_display_quantity_change_warning_part();

	$output .= '<table style="width: 100%;padding:0px 10px 0px 10px;">';
	$output .= eStore_cart_display_items_part($currency_symbol,$decimal);
	$total_tax = eStore_get_cart_tax();
	$output .= eStore_cart_display_total_part($currency_symbol,$decimal,$_SESSION['eStore_cart_sub_total'],$_SESSION['eStore_cart_postage_cost'],$_SESSION['eStore_cart_total_tax']);
	//$output .= eStore_cart_display_continue_shopping_part(); 
	if (get_option('eStore_display_continue_shopping')) 
	{		
    	$products_page = get_option('eStore_products_page_url');
    	$output .= '<tr><td colspan="4"><a href="'.$products_page.'"><img src="'.WP_ESTORE_IMAGE_URL.'/cart_fancy1_continue_shopping.png" alt="Continue Shopping" /></a></td></tr>';             
	}
	$output .= eStore_cart_display_shipping_variation_part($_SESSION['eStore_cart_postage_cost']);
	$output .= eStore_cart_display_action_message_part();
	$output .= eStore_cart_display_enter_affiliate_id_part();
	$output .= eStore_cart_display_enter_coupon_part();
	$output .= "</table>";  
	
	$output .= '<div class="eStore_cart_fancy1_footer">';
	$output .= eStore_cart_display_checkout_button_form_part();
	$output .= '</div>';
	$output .= "</div>";        	  	             
	return $output;
}

function eStore_shopping_cart_multiple_gateway()
{
	if (!digi_cart_not_empty())
	{
        return eStore_empty_cart_display();
    }
    $decimal = '.';
    $defaultSymbol = get_option('cart_currency_symbol');
    if (!empty($defaultSymbol))
        $currency_symbol = $defaultSymbol;
    else
        $currency_symbol = '$';
	        
	$title = get_option('wp_cart_title');

    $output .= '<a name="wp_cart_anchor"></a>';
    $output .= '<div class="shopping_cart" style="padding: 5px;">';
    if (!get_option('eStore_shopping_cart_image_hide'))
    {
    	$output .= "<img src='".WP_ESTORE_URL."/images/shopping_cart_icon.gif' value='Cart' title='Cart' />";
    }
    if(!empty($title))
    {
    	$output .= '<h2>';
    	$output .= $title;
    	$output .= '</h2>';
    }

    $output .= eStore_cart_display_quantity_change_warning_part();

	$output .= '<table style="width: 100%;">';
	$output .= eStore_cart_display_items_part($currency_symbol,$decimal);
	$total_tax = eStore_get_cart_tax();
	$output .= eStore_cart_display_total_part($currency_symbol,$decimal,$_SESSION['eStore_cart_sub_total'],$_SESSION['eStore_cart_postage_cost'],$_SESSION['eStore_cart_total_tax']);
	$output .= eStore_cart_display_continue_shopping_part();
	$output .= eStore_cart_display_action_message_part();
	$output .= eStore_cart_display_shipping_variation_part($_SESSION['eStore_cart_postage_cost']);
	$output .= eStore_cart_display_enter_affiliate_id_part();
	$output .= eStore_cart_display_enter_coupon_part();            
	$output .= "</table>";  
	
	$output .= eStore_cart_display_checkout_button_form_part();
	$output .= "</div>";     	  	             
	return $output;
}

function eStore_cart_display_quantity_change_warning_part()
{
    if ($_SESSION['discount_applied_once'] != 1)
    {
        $output .= '<br /><span id="pinfo" style="display: none; font-weight: bold; color: red;">'.ESTORE_QUANTITY_CHANGE.'</span>';
    }
    else
    {
        $output .= '<br /><span id="pinfo" style="display: none; font-weight: bold; color: red;">'.ESTORE_QUANTITY_CHANGE_NOT_ALLOWED.'</span>';
    }
    return $output;
}

function eStore_cart_display_items_part($currency_symbol,$decimal)
{
    if(get_option('eStore_use_auto_discount') && $_SESSION['discount_applied_once'] != 1)
	{    
		$total = eStore_get_cart_total();
		$total_items = eStore_get_total_cart_item_qty();
		// Auto discount for normal purchase		
		$amt_threshold = get_option('eStore_amount_threshold_auto_coupon');
		if( !empty($amt_threshold) && $total > $amt_threshold)
		{
			$coupon = get_option('eStore_amount_threshold_auto_coupon_code');
			eStore_apply_discount($coupon);	
		}
		$qty_threshold = get_option('eStore_qty_threshold_auto_coupon');
		if( !empty($qty_threshold) && $total_items > $qty_threshold)
		{				
			$coupon = get_option('eStore_qty_threshold_auto_coupon_code');
			eStore_apply_discount($coupon);		
		}	
	}

	$total_items = 0;
    $total = 0;
    if ($_SESSION['eStore_cart'] && is_array($_SESSION['eStore_cart']))
    {
        $output .= '
        <tr>
        <th style="text-align: left">'.ESTORE_ITEM_NAME.'</th><th style="text-align: left">'.ESTORE_QUANTITY.'</th><th style="text-align: left">'.ESTORE_PRICE.'</th><th></th>
        </tr>';

        foreach ($_SESSION['eStore_cart'] as $item)
        {
            $output .= "
            <tr><td style='overflow: hidden;'><a href='".$item['cartLink']."'>".$item['name']."</a></td>
            <td style='text-align: left'><form method=\"post\"  action=\"\" name='peStore_cquantity' style='display: inline'>
            <input type=\"hidden\" name=\"product\" value=\"".htmlspecialchars($item['name'])."\" />
    
            <input type='hidden' name='eStore_cquantity' value='1' /><input type='text' name='quantity' value='".$item['quantity']."' size='1' onchange='document.peStore_cquantity.submit();' onkeypress='document.getElementById(\"pinfo\").style.display = \"\";' /></form></td>
            <td style='text-align: left'>".print_digi_cart_payment_currency(($item['price'] * $item['quantity']), $currency_symbol, $decimal)."</td>
            <td style='text-align: left'><form method=\"post\"  action=\"\">
            <input type=\"hidden\" name=\"product\" value=\"".htmlspecialchars($item['name'])."\" />
            <input type='hidden' name='eStore_delcart' value='1' />
            <input type='image' src='".WP_ESTORE_URL."/images/Shoppingcart_delete.gif' class='eStore_remove_item_button' value='Remove' title='".ESTORE_REMOVE_ITEM."' /></form></td></tr>    
            ";
            
            $total += $item['price'] * $item['quantity'];
    		$item_total_shipping += $item['shipping'] * $item['quantity'];
            $total_items +=  $item['quantity'];
        }
        $_SESSION['eStore_cart_sub_total'] = $total;
        
        //Check the shipping variation price
        $_SESSION['eStore_selected_shipping_option_cost'] = 0;
        if(isset($_POST['eStore_shipping_variation']))
        {
        	$pieces = explode('|',$_POST['eStore_shipping_variation']);
        	$_SESSION['eStore_selected_shipping_option'] = $pieces[0];
        	if(!empty($pieces[1]))
        		$_SESSION['eStore_selected_shipping_option_cost'] = $pieces[1];  
        	else
        	    $_SESSION['eStore_selected_shipping_option_cost'] = 0;  		
        }        
        // Base shipping can only be used in conjunction with individual item shipping
        if ($item_total_shipping != 0)
        {
        	$baseShipping = get_option('eStore_base_shipping');
        	$postage_cost = $item_total_shipping + $baseShipping;
        	$_SESSION['eStore_cart_postage_cost'] = $postage_cost + $_SESSION['eStore_selected_shipping_option_cost'];
        }
        else
        {
        	$postage_cost = 0;
            $_SESSION['eStore_cart_postage_cost'] = $postage_cost + $_SESSION['eStore_selected_shipping_option_cost'];
        }
		if(get_option('eStore_use_auto_discount'))
		{			
			// Auto shipping discount
			$amt_threshold_free_shipping = get_option('eStore_amount_free_shipping_threshold');
			if( !empty($amt_threshold_free_shipping) && $total > $amt_threshold_free_shipping)
			{
	        	$postage_cost = 0;
	            $_SESSION['eStore_cart_postage_cost'] = $postage_cost;		
	            $_SESSION['eStore_last_action_msg'] = '<p style="color: #30D062;">'.ESTORE_TOTAL_DISCOUNT.ESTORE_DISCOUNT_FREE_SHIPPING;		
			}
			$qty_threshold_free_shipping = get_option('eStore_qty_free_shipping_threshold');
			if( !empty($qty_threshold_free_shipping) && $total_items > $qty_threshold_free_shipping)
			{				
	        	$postage_cost = 0;
	            $_SESSION['eStore_cart_postage_cost'] = $postage_cost;	
	            $_SESSION['eStore_last_action_msg'] = '<p style="color: #30D062;">'.ESTORE_TOTAL_DISCOUNT.ESTORE_DISCOUNT_FREE_SHIPPING;			
			}					
		}
    }	
    return $output;
}
function eStore_cart_display_total_part($currency_symbol,$decimal,$total,$postage_cost,$total_tax=0)
{
	if($postage_cost != 0 || $total_tax != 0)
	{
		$output .= "<tr><td colspan='2' style='font-weight: bold; text-align: right;'>".ESTORE_SUB_TOTAL.": </td><td style='text-align: left'>".print_digi_cart_payment_currency($total, $currency_symbol, $decimal)."</td><td></td></tr>";
	}
	if ($postage_cost != 0)
    {
    	$output .= "<tr><td colspan='2' style='font-weight: bold; text-align: right;'>".ESTORE_SHIPPING.": </td><td style='text-align: left'>".print_digi_cart_payment_currency($postage_cost, $currency_symbol, $decimal)."</td><td></td></tr>";        
    }
    if($total_tax != 0)
    {
    	$output .= "<tr><td colspan='2' style='font-weight: bold; text-align: right;'>".WP_ESTORE_TAX.": </td><td style='text-align: left'>".print_digi_cart_payment_currency($total_tax, $currency_symbol, $decimal)."</td><td></td></tr>";
    }
    $empty_cart_code = '<form  method="post" action="" >';
    $empty_cart_code .= "<input type='image' src='".WP_ESTORE_URL."/images/empty-shopping-cart-icon.png' class='eStore_empty_cart_button' value='Empty' title='".ESTORE_EMPTY_CART."' />";
    $empty_cart_code .= '<input type="hidden" name="reset_eStore_cart" value="1" /></form>';

    $output .= "<tr><td colspan='2' style='font-weight: bold; text-align: right;'>".ESTORE_TOTAL.": </td><td style='text-align: left'>".print_digi_cart_payment_currency(($total+$postage_cost+$total_tax), $currency_symbol, $decimal)."</td>";
    $output .= "<td>".$empty_cart_code."</td></tr>";	
    return $output;
}
function eStore_cart_display_continue_shopping_part()
{
	if (get_option('eStore_display_continue_shopping')) 
    {
    	$products_page = get_option('eStore_products_page_url');
    	$output .= '<tr><td colspan="4">&laquo;<a href="'.$products_page.'"><strong>'.ESTORE_CONTINUE_SHOPPING.'</strong></a></td></tr>';    
    	return $output;            
    }    
}
function eStore_cart_display_action_message_part()
{
	if (!empty($_SESSION['eStore_last_action_msg']))
    {
    	$output .= '<tr><td colspan="4"><strong><i>'.$_SESSION['eStore_last_action_msg'].'</i></strong></td></tr>';   
    	return $output;             
    }	
}
function eStore_cart_display_shipping_variation_part($postage_cost,$button_type=1)
{
	$output = "";
	$always_display_shipping_var = get_option('eStore_always_display_shipping_variation');	
	if ($postage_cost != 0 || $always_display_shipping_var != '')
	{
		$shippping_var_txt = get_option('eStore_shipping_variation');		
		if (!empty($shippping_var_txt))
		{
			eStore_load_shipping_var_change_warning_jquery();
			$variation_add_string = "+";
			$curr_sign = get_option('cart_currency_symbol');	
			$pieces = explode('|',$shippping_var_txt);
			$variation1_name = $pieces[0];
	
			$var_output .= $variation1_name." : ";
			if($button_type == 1){
				$var_output .= '<select name="eStore_shipping_variation" class="shipping_variation">';
			}		
			for ($i=1;$i<sizeof($pieces); $i++)
			{
				$pieces2 = explode(':',$pieces[$i]);
				if (sizeof($pieces2) > 1)
					$tmp_txt = $pieces2[0].' ['.$variation_add_string.' '.$curr_sign.$pieces2[1].']';
				else	
					$tmp_txt = $pieces2[0];
				$var_output .= '<option value="'.htmlspecialchars($pieces2[0]."|".$pieces2[1]).'" '.eStore_is_shipping_option_selected($pieces2[0]).'>'.$tmp_txt.'</option>';
			}
			$var_output .= '</select>';	
		    $output .= '<tr><td colspan="4"><strong>'.ESTORE_SHIPPING_VARIATION.'</strong>
		    		    <form  method="post" action="" >
		    		    '.$var_output.'
		    		    <input type="submit" value="Update" />
		    		    </form>
		    			</td></tr>';
		    $output .= '<tr><td colspan="4"><label class="shipping_var_changed eStore_warning" for="shipping_variation" id="shipping_var_changed">'.ESTORE_CLICK_UPDATE_BUTTON.'<br /></label></td></tr>';
		}
	}	
    return $output;	
}
function eStore_is_shipping_option_selected($option_to_match)
{
	if($_SESSION['eStore_selected_shipping_option'] == $option_to_match)
		return 'selected="selected"';		
}
function eStore_cart_display_enter_affiliate_id_part()
{
	if (get_option('eStore_aff_allow_aff_id') == 1)
    {
    	$output .= '<tr><td colspan="4"><strong>'.ESTORE_ENTER_AFFILIATE_ID.'</strong>
    			    <form  method="post" action="" >
    			    <input type="text" name="estore_aff_id" id="estore_aff_id" value="" size="10" />
    			    <input type="submit" value="'.ESTORE_APPLY.'" />
    			    <input type="hidden" name="eStore_apply_aff_id" value="1" />
    			    </form>
    				</td></tr>';
    	return $output;
    }            

}
function eStore_cart_display_enter_coupon_part()
{
	if (get_option('eStore_use_coupon_system') == 1)
    {
    	$output .= '<tr><td colspan="4"><strong>'.ESTORE_ENTER_COUPON_CODE.'</strong>
    			    <form  method="post" action="" >
    			    <input type="text" name="coupon_code" id="coupon_code" value="" size="10" />
    			    <input type="submit" class="eStore_apply_coupon" value="'.ESTORE_APPLY.'" />
    			    <input type="hidden" name="eStore_apply_discount" value="1" />
    			    </form>
    				</td></tr>';
    	return $output;
	}	
}
function eStore_cart_display_checkout_button_form_part()
{
            //$output .= "<tr><td colspan='4'>";
			if (get_option('eStore_show_t_c'))
				$output .= eStore_show_terms_and_cond();

            $output .= '<form action="'.WP_ESTORE_URL.'/eStore_payment_submission.php" method="post">';
            $checkout_button = WP_ESTORE_URL.'/images/paypal_checkout.png';

            if (get_option('eStore_use_multiple_gateways'))
            {
                eStore_load_checkout_method_jquery();
                $output .= ESTORE_PAYMENT_METHOD;
                $output .= '<select class="eStore_gateway" name="eStore_gateway">';
                if (get_option('eStore_use_paypal_gateway'))
               	{
               		if(isset($_COOKIE['eStore_gateway']) && $_COOKIE['eStore_gateway'] == "paypal"){
               			$output .= '<option value="paypal" selected="selected">'.ESTORE_PAYPAL.'</option>';
               			$checkout_button = WP_ESTORE_URL.'/images/paypal_checkout.png';
               		}
               		else{
                    	$output .= '<option value="paypal">'.ESTORE_PAYPAL.'</option>';
               		}
                }
                if (get_option('eStore_use_manual_gateway'))
                {
                	if(isset($_COOKIE['eStore_gateway']) && $_COOKIE['eStore_gateway'] == "manual"){
               			$output .= '<option value="manual" selected="selected">'.ESTORE_MANUAL.'</option>';
               			$checkout_button = WP_ESTORE_URL.'/images/checkout_manual.png';
               		}
               		else{                	
               	    	$output .= '<option value="manual">'.ESTORE_MANUAL.'</option>';
               		}
               	}
                if (get_option('eStore_use_2co_gateway'))
                {
                    if(isset($_COOKIE['eStore_gateway']) && $_COOKIE['eStore_gateway'] == "2co"){
               			$output .= '<option value="2co" selected="selected">'.ESTORE_TWO_CO.'</option>';
               			$checkout_button = WP_ESTORE_URL.'/images/checkout_2co.png';
               		}
               		else{                	
               	    	$output .= '<option value="2co">'.ESTORE_TWO_CO.'</option>';
               		}                	
               	}
               	if (get_option('eStore_use_authorize_gateway'))
               	{
                    if(isset($_COOKIE['eStore_gateway']) && $_COOKIE['eStore_gateway'] == "authorize"){
               			$output .= '<option value="authorize" selected="selected">'.ESTORE_AUTHORIZE.'</option>';
               			$checkout_button = WP_ESTORE_URL.'/images/checkout_authorize.gif';
               		}
               		else{                	
               	    	$output .= '<option value="authorize">'.ESTORE_AUTHORIZE.'</option>';
               		}                		
               	}               	
                $output .= '</select><br />';
            }
            else
            {
                if (get_option('eStore_use_paypal_gateway'))
                {
                    $output .= '<input type="hidden" name="eStore_gateway" id="eStore_gateway" value="paypal" />';
                    $checkout_button = WP_ESTORE_URL.'/images/paypal_checkout.png';
                }
                else if (get_option('eStore_use_manual_gateway'))
                {
                    $output .= '<input type="hidden" name="eStore_gateway" id="eStore_gateway" value="manual" />';
                    $checkout_button = WP_ESTORE_URL.'/images/checkout_manual.png';
                }
                else if (get_option('eStore_use_2co_gateway'))
                {
                    $output .= '<input type="hidden" name="eStore_gateway" id="eStore_gateway" value="2co" />';
                    $checkout_button = WP_ESTORE_URL.'/images/checkout_2co.png';
                }
                else if (get_option('eStore_use_authorize_gateway'))
               	{
                    $output .= '<input type="hidden" name="eStore_gateway" id="eStore_gateway" value="authorize" />';
                    $checkout_button = WP_ESTORE_URL.'/images/checkout_authorize.gif';               		
               	}   
            }
            $output .= '<input type="hidden" name="eStore_url" id="eStore_url" value="'.WP_ESTORE_URL.'" />';
           	
            if(get_option('eStore_enable_fancy_redirection_on_checkout'))
            {
	            $output .= '<a href="'.WP_ESTORE_URL.'/eStore_payment_submission.php" class="redirect_trigger" rel="#overlay">';	                        
	            $output .= '<input type="image" src="'.$checkout_button.'" name="submit" class="eStore_paypal_checkout_button" alt="Checkout" />';
	           	$output .= '</a>';		     	           	
            }
            else
            { 	 	
            	$output .= '<input type="image" src="'.$checkout_button.'" name="submit" class="eStore_paypal_checkout_button" alt="Checkout" />';
            }
            
            $output .= '</form>';
			//$output .= '</td></tr>';	
			return $output;
}
?>