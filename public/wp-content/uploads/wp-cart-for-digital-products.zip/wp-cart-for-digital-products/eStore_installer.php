<?php
//***** Installer *****/
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

//***Installer variables***/
global $wpdb;
$table_name = $wpdb->prefix . "wp_eStore_tbl";
$customer_table_name = $wpdb->prefix . "wp_eStore_customer_tbl";
$coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
$sales_table_name = $wpdb->prefix . "wp_eStore_sales_tbl";
$cat_prod_rel_table_name = $wpdb->prefix . "wp_eStore_cat_prod_rel_tbl";
$cat_table_name = $wpdb->prefix . "wp_eStore_cat_tbl";
$pending_payment_table_name = $wpdb->prefix . "wp_eStore_pending_payment_tbl";
$download_links_table_name = $wpdb->prefix . "wp_eStore_download_links_tbl";

$wp_eStore_db_version = "6.1";
//***Installer***/
if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name)
{
$sql = "CREATE TABLE " . $table_name . " (
	  id int(12) NOT NULL auto_increment,
	  name text NOT NULL,
	  price varchar(128) NOT NULL,
	  product_download_url text NOT NULL,
	  downloadable text NOT NULL,
	  shipping_cost varchar(128) NOT NULL,
	  available_copies varchar(128) NOT NULL,
	  button_image_url text NOT NULL,
	  return_url text NOT NULL,
	  sales_count int(12) NOT NULL,
	  description text NOT NULL,
	  thumbnail_url text NOT NULL,
	  variation1 text NOT NULL,
	  variation2 text NOT NULL,
	  variation3 text NOT NULL,
	  commission varchar(10) NOT NULL default '',
	  a1 varchar(128) NOT NULL,
	  p1 int(12) NOT NULL,
	  t1 varchar(8) NOT NULL,
	  a3 varchar(128) NOT NULL,
	  p3 int(12) NOT NULL,
	  t3 varchar(8) NOT NULL,
	  sra SMALLINT NOT NULL,
	  srt SMALLINT NOT NULL,
	  ref_text varchar(255) NOT NULL,
	  paypal_email varchar(128) NOT NULL,
	  custom_input SMALLINT NOT NULL,
	  custom_input_label varchar(128) NOT NULL,
	  variation4 text NOT NULL,
	  aweber_list varchar(64) NOT NULL,
	  currency_code varchar(8) NOT NULL,
	  target_thumb_url varchar(255) NOT NULL,
	  target_button_url varchar(255) NOT NULL,
	  weight varchar(6) NOT NULL,
	  product_url varchar(255) NOT NULL,
	  item_spec_instruction text NOT NULL,
	  ppv_content SMALLINT NOT NULL,
	  use_pdf_stamper SMALLINT NOT NULL,
	  create_license SMALLINT NOT NULL,
	  tax varchar(6) NOT NULL,
	  author_id varchar(30) NOT NULL default '',
	  show_qty SMALLINT NOT NULL,
	  tier2_commission varchar(10) NOT NULL default '',
	  custom_price_option SMALLINT NOT NULL,
	  additional_images text NOT NULL,
	  old_price varchar(128) NOT NULL,
	  PRIMARY KEY (id)
	);";
dbDelta($sql);

// Add default options on fresh install
add_option("cart_paypal_email", get_bloginfo('admin_email'));
add_option("eStore_use_paypal_gateway", 1);
add_option("cart_payment_currency", 'USD');
add_option("wp_cart_title", 'Items in Your Cart');
add_option('wp_cart_empty_text', 'Your cart is empty');
add_option('cart_return_from_paypal_url', get_bloginfo('wpurl'));
add_option("eStore_auto_product_delivery", 1);
add_option("eStore_enable_lightbox_effect", 1);
add_option("eStore_use_wp_mail", 1);
add_option("eStore_send_buyer_email", 1);
add_option("eStore_manage_products_limit2", 50);
add_option("eStore_auto_convert_to_relative_url", 0);

add_option("wp_eStore_db_version", $wp_eStore_db_version);
}
// Install the customer DB
if($wpdb->get_var("SHOW TABLES LIKE '$customer_table_name'") != $customer_table_name)
{
$sql = "CREATE TABLE " . $customer_table_name . " (
	  id int(12) NOT NULL auto_increment,
	  first_name text NOT NULL,
	  last_name text NOT NULL,
	  email_address text NOT NULL,
	  purchased_product_id int(12) NOT NULL,
      txn_id varchar(64) NOT NULL default '',
      date date NOT NULL default '0000-00-00',
      sale_amount varchar(10) NOT NULL default '',      
      coupon_code_used varchar(64) NOT NULL default '',
      member_username varchar(32) NOT NULL,
      product_name varchar(255) NOT NULL,
	  address text NOT NULL,	  
	  phone varchar(32) NOT NULL,
	  subscr_id varchar(64) DEFAULT '',
	  PRIMARY KEY  (id)
	);";
dbDelta($sql);

// Add default options
add_option("wp_eStore_db2_version", $wp_eStore_db_version);
}
// Install the Coupons/Discounts DB
if($wpdb->get_var("SHOW TABLES LIKE '$coupon_table_name'") != $coupon_table_name)
{
$sql = "CREATE TABLE " . $coupon_table_name . " (
	  id int(12) NOT NULL auto_increment,
	  coupon_code text NOT NULL,
	  discount_value varchar(128) NOT NULL,
	  discount_type text NOT NULL,
	  active text NOT NULL,
	  redemption_limit varchar(12) NOT NULL,
	  redemption_count varchar(12) NOT NULL,
	  property varchar(8) NOT NULL,
	  logic varchar(8) NOT NULL,
	  value varchar(128) NOT NULL,
	  expiry_date date NOT NULL default '0000-00-00',
	  PRIMARY KEY  (id)
	);";
dbDelta($sql);

// Add default options
add_option("wp_eStore_db3_version", $wp_eStore_db_version);
}

// Install the Sales DB
if($wpdb->get_var("SHOW TABLES LIKE '$sales_table_name'") != $sales_table_name)
{
$sql = "CREATE TABLE " . $sales_table_name . " (
    cust_email varchar(128) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    item_id varchar(10) NOT NULL default '',
    sale_price varchar(10) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_eStore_db4_version", $wp_eStore_db_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$cat_prod_rel_table_name'") != $cat_prod_rel_table_name)
{
$sql = "CREATE TABLE " . $cat_prod_rel_table_name . " (
    cat_id int(12) NOT NULL,
    prod_id int(12) NOT NULL,
    PRIMARY KEY  (cat_id, prod_id)
	);";
dbDelta($sql);
// Add default options
add_option("wp_eStore_db5_version", $wp_eStore_db_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$cat_table_name'") != $cat_table_name)
{
$sql = "CREATE TABLE " . $cat_table_name . " (
    cat_id int(12) NOT NULL auto_increment,
    cat_name varchar(64) NOT NULL default 'Uncategorized',
    cat_desc text NOT NULL,
    cat_parent int(12) NOT NULL,
    cat_image varchar(255) NOT NULL,
    cat_url varchar(255) NOT NULL,
    PRIMARY KEY (cat_id)
	);";
dbDelta($sql);
// Add default options
add_option("wp_eStore_db6_version", $wp_eStore_db_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$pending_payment_table_name'") != $pending_payment_table_name)
{
$sql = "CREATE TABLE " . $pending_payment_table_name . " (
	customer_id varchar(64) NOT NULL,
	item_number int(12) NOT NULL,
	name varchar(255) NOT NULL,
	price varchar(128) NOT NULL,
	quantity int(12) NOT NULL,
	shipping varchar(128) NOT NULL,
	custom varchar(255) NOT NULL
	);";
dbDelta($sql);
// Add default options
add_option("wp_eStore_db7_version", $wp_eStore_db_version);
}
// Install the Download Links DB
if($wpdb->get_var("SHOW TABLES LIKE '$download_links_table_name'") != $download_links_table_name)
{
$sql = "CREATE TABLE " . $download_links_table_name . " (
	  id bigint(20) unsigned NOT NULL auto_increment,
	  creation_time datetime NOT NULL default '0000-00-00 00:00:00',
	  download_key varchar(255) NOT NULL default '',
	  download_item text NOT NULL,
	  download_limit_count int(12) NOT NULL default '3',
      download_limit_time int(12) NOT NULL default '48',
      download_limit_ip varchar(15) NOT NULL default '0.0.0.0',
      access_count int(12) NOT NULL default '0',    
	  PRIMARY KEY (id)
	);";
dbDelta($sql);

// Add default options
add_option("wp_eStore_db8_version", $wp_eStore_db_version);
}

//****************
//*** Upgrader ***
//****************/

$installed_ver = get_option( "wp_eStore_db_version" );
if( $installed_ver != $wp_eStore_db_version )
{
dbDelta($sql);
$sql = "CREATE TABLE " . $table_name . " (
	  id int(12) NOT NULL auto_increment,
	  name text NOT NULL,
	  price varchar(128) NOT NULL,
	  product_download_url text NOT NULL,
	  downloadable text NOT NULL,
	  shipping_cost varchar(128) NOT NULL,
	  available_copies varchar(128) NOT NULL,
	  button_image_url text NOT NULL,
	  return_url text NOT NULL,
	  sales_count int(12) NOT NULL,
	  description text NOT NULL,
	  thumbnail_url text NOT NULL,
	  variation1 text NOT NULL,
	  variation2 text NOT NULL,
	  variation3 text NOT NULL,
	  commission varchar(10) NOT NULL default '',
	  a1 varchar(128) NOT NULL,
	  p1 int(12) NOT NULL,
	  t1 varchar(8) NOT NULL,
	  a3 varchar(128) NOT NULL,
	  p3 int(12) NOT NULL,
	  t3 varchar(8) NOT NULL,
	  sra SMALLINT NOT NULL,
	  srt SMALLINT NOT NULL,
	  ref_text varchar(255) NOT NULL,
	  paypal_email varchar(128) NOT NULL,
	  custom_input SMALLINT NOT NULL,
	  custom_input_label varchar(128) NOT NULL,
	  variation4 text NOT NULL,
	  aweber_list varchar(64) NOT NULL,
	  currency_code varchar(8) NOT NULL,
	  target_thumb_url varchar(255) NOT NULL,
	  target_button_url varchar(255) NOT NULL,
	  weight varchar(6) NOT NULL,
	  product_url varchar(255) NOT NULL,
	  item_spec_instruction text NOT NULL,
	  ppv_content SMALLINT NOT NULL,
	  use_pdf_stamper SMALLINT NOT NULL,
	  create_license SMALLINT NOT NULL,
	  tax varchar(6) NOT NULL,
	  author_id varchar(30) NOT NULL default '',
	  show_qty SMALLINT NOT NULL,
	  tier2_commission varchar(10) NOT NULL default '',
	  custom_price_option SMALLINT NOT NULL,
	  additional_images text NOT NULL,
	  old_price varchar(128) NOT NULL,
	  PRIMARY KEY  (id)
	);";
	dbDelta($sql);
	// Add default options at upgrade time
	add_option("cart_paypal_email", get_bloginfo('admin_email'));
	add_option("eStore_use_paypal_gateway", 1);
	add_option("cart_payment_currency", 'USD');
	add_option("eStore_auto_product_delivery", 1);
	add_option("eStore_manage_products_limit2", 50);

	update_option("wp_eStore_db_version", $wp_eStore_db_version);
}

$installed_ver_db2 = get_option( "wp_eStore_db2_version" );
if( $installed_ver_db2 != $wp_eStore_db_version )
{
dbDelta($sql);
$sql = "CREATE TABLE " . $customer_table_name . " (
	  id int(12) NOT NULL auto_increment,
	  first_name text NOT NULL,
	  last_name text NOT NULL,
	  email_address text NOT NULL,
	  purchased_product_id int(12) NOT NULL,
      txn_id varchar(64) NOT NULL default '',
      date date NOT NULL default '0000-00-00',
      sale_amount varchar(10) NOT NULL default '',      
      coupon_code_used varchar(64) NOT NULL default '',
      member_username varchar(32) NOT NULL,
      product_name varchar(255) NOT NULL,
	  address text NOT NULL,	  
	  phone varchar(32) NOT NULL,
	  subscr_id varchar(64) DEFAULT '',	  
	  PRIMARY KEY  (id)
	);";
	dbDelta($sql);
	// Add default options
	update_option("wp_eStore_db2_version", $wp_eStore_db_version);
}

$installed_ver_db3 = get_option( "wp_eStore_db3_version" );
if( $installed_ver_db3 != $wp_eStore_db_version )
{
dbDelta($sql);
$sql = "CREATE TABLE " . $coupon_table_name . " (
	  id int(12) NOT NULL auto_increment,
	  coupon_code text NOT NULL,
	  discount_value varchar(128) NOT NULL,
	  discount_type text NOT NULL,
	  active text NOT NULL,
	  redemption_limit varchar(12) NOT NULL,
	  redemption_count varchar(12) NOT NULL,
	  property varchar(8) NOT NULL,
	  logic varchar(8) NOT NULL,
	  value varchar(128) NOT NULL,
	  expiry_date date NOT NULL default '0000-00-00',
	  PRIMARY KEY  (id)
	);";
	dbDelta($sql);
	// Add default options
	update_option("wp_eStore_db3_version", $wp_eStore_db_version);
}

$installed_ver_db4 = get_option( "wp_eStore_db4_version" );
if( $installed_ver_db4 != $wp_eStore_db_version )
{
dbDelta($sql);
$sql = "CREATE TABLE " . $sales_table_name . " (
    cust_email varchar(128) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    item_id varchar(10) NOT NULL default '',
    sale_price varchar(10) NOT NULL default ''
	);";
dbDelta($sql);

// Add default options
update_option("wp_eStore_db4_version", $wp_eStore_db_version);
}

$installed_ver_db5 = get_option( "wp_eStore_db5_version" );
if( $installed_ver_db5 != $wp_eStore_db_version )
{
$sql = "CREATE TABLE " . $cat_prod_rel_table_name . " (
    cat_id int(12) NOT NULL,
    prod_id int(12) NOT NULL,
    PRIMARY KEY  (cat_id, prod_id)
	);";
dbDelta($sql);
// Add default options
update_option("wp_eStore_db5_version", $wp_eStore_db_version);
}

$installed_ver_db6 = get_option( "wp_eStore_db6_version" );
if( $installed_ver_db6 != $wp_eStore_db_version )
{
$sql = "CREATE TABLE " . $cat_table_name . " (
    cat_id int(12) NOT NULL auto_increment,
    cat_name varchar(64) NOT NULL,
    cat_desc text NOT NULL,
    cat_parent int(12) NOT NULL,
    cat_image varchar(255) NOT NULL,
    cat_url varchar(255) NOT NULL,
    PRIMARY KEY (cat_id)
	);";
dbDelta($sql);
// Add default options
update_option("wp_eStore_db6_version", $wp_eStore_db_version);
}

$installed_ver_db7 = get_option( "wp_eStore_db7_version" );
if( $installed_ver_db7 != $wp_eStore_db_version )
{
$sql = "CREATE TABLE " . $pending_payment_table_name . " (
	customer_id varchar(64) NOT NULL,
	item_number int(12) NOT NULL,
	name varchar(255) NOT NULL,
	price varchar(128) NOT NULL,
	quantity int(12) NOT NULL,
	shipping varchar(128) NOT NULL,
	custom varchar(255) NOT NULL
	);";
dbDelta($sql);
// Add default options
update_option("wp_eStore_db7_version", $wp_eStore_db_version);
}

$installed_ver_db8 = get_option( "wp_eStore_db8_version" );
if( $installed_ver_db8 != $wp_eStore_db_version )
{
$sql = "CREATE TABLE " . $download_links_table_name . " (
	  id bigint(20) unsigned NOT NULL auto_increment,
	  creation_time datetime NOT NULL default '0000-00-00 00:00:00',
	  download_key varchar(255) NOT NULL default '',
	  download_item text NOT NULL,
	  download_limit_count int(12) NOT NULL default '3',
      download_limit_time int(12) NOT NULL default '48',
      download_limit_ip varchar(15) NOT NULL default '0.0.0.0',
      access_count int(12) NOT NULL default '0',    
	  PRIMARY KEY (id)
	);";
dbDelta($sql);

// Add default options
update_option("wp_eStore_db8_version", $wp_eStore_db_version);
}
//***** End DB Installer *****/

/*** Add Default Options ***/
add_option("eStore_send_buyer_email", 1);
add_option("eStore_download_method", '1');
/*** Add AS3TP support ***/
eStore_as3tp::as3key_activate();
/*** End of add default options ***/ 
?>
