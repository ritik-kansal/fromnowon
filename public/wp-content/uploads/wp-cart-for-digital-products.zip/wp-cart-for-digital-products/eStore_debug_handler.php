<?php

//**** This file needs to be included from a file that has access to "wp-load.php" ****

$debug_enabled = false;
$debug_log_file_name = 'eStore_post_payment_debug.log';
$debug_on = get_option('eStore_cart_enable_debug');
if ($debug_on)
{
	$debug_enabled = true;
}
function eStore_payment_debug($message,$success,$end=false)
{
	global $debug_enabled,$debug_log_file_name;
    if (!$debug_enabled) return;
    // Timestamp
    $text = '['.date('m/d/Y g:i A').'] - '.(($success)?'SUCCESS :':'FAILURE :').$message. "\n";
    if ($end) {
    	$text .= "\n------------------------------------------------------------------\n\n";
    }
    // Write to log
    $fp=fopen($debug_log_file_name,'a');
    fwrite($fp, $text );
    fclose($fp);  // close file
}
?>