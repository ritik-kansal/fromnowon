<?php
include_once('../../../wp-load.php');
include_once('email.php');
// the post URL
$postURL = get_option('eStore_wishlist_post_url');
// the Secret Key
$secretKey = get_option('eStore_wishlist_secret_word');

function wl_handle_subsc_signup($ipn_data,$subsc_ref,$unique_ref)
{
    global $postURL;
    global $secretKey;
	
	// prepare the data
	$data = array ();
	$data['cmd'] = 'CREATE';
	$data['transaction_id'] = $unique_ref;
	$data['lastname'] = $ipn_data['last_name'];
	$data['firstname'] = $ipn_data['first_name'];
	$data['email'] = $ipn_data['payer_email'];
	$data['level'] = $subsc_ref;
	
	// generate the hash
	$delimiteddata = strtoupper (implode ('|', $data));
	$hash = md5 ($data['cmd'] . '__' . $secretKey . '__' . $delimiteddata);
	
	// include the hash to the data to be sent
	$data['hash'] = $hash;
	
	// send data to post URL
	$ch = curl_init ($postURL);
	curl_setopt ($ch, CURLOPT_POST, true);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
	$returnValue = curl_exec ($ch);
	
	// process return value
	list ($cmd, $url) = explode ("\n", $returnValue);
	
	// check if the returned command is the same as what we passed
	if ($cmd == 'CREATE') 
	{
	    $message = $url;
	} 
	else 
	{
	    $message = "Error returned from WishList plugin! Command value:".$cmd;
	}
	debug_log_subsc("Member signup URL :".$message,true);
	
	// Send the membership signup email
	$email_subj = "Complete your membership registration";
	$to_address = $ipn_data['payer_email'];
	$from_address = get_option('eStore_download_email_address');
	$email_body = "Dear ".$ipn_data['first_name'].
				  "\n\nPlease Visit the following URL to complete your registration: ".
				  "\n".$message.
				  "\n\nThank You";
	$headers = 'From: '.$from_address . "\r\n";
	    
	if (get_option('eStore_use_wp_mail'))
    {
        wp_mail($to_address,$email_subj,$email_body,$headers);
        debug_log_subsc("Member signup email successfully sent using wp mail system to:".$to_address,true);
    }
    else
    {
		$attachment='';
		if(@eStore_send_mail($to_address,$email_body,$email_subj,$headers))
		{
		    debug_log_subsc("Member signup email successfully sent to:".$to_address,true);
		}
		else
		{
		    debug_log_subsc("Member signup email sending failed",false);
		}
    }
}  
function wl_handle_subsc_cancel($ipn_data)
{
    global $postURL;
    global $secretKey;
	
	// prepare the data
	$data = array ();
	$data['cmd'] = 'DEACTIVATE';
	$data['transaction_id'] = $ipn_data['subscr_id'];
	
	// generate the hash
	$delimiteddata = strtoupper (implode ('|', $data));
	$hash = md5 ($data['cmd'] . '__' . $secretKey . '__' . $delimiteddata);
	// include the hash to the data to be sent
	$data['hash'] = $hash;
	// send data to post URL
	$ch = curl_init ($postURL);
	curl_setopt ($ch, CURLOPT_POST, true);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
	$returnValue = curl_exec ($ch);
	// process return value
	list ($cmd, $url) = explode ("\n", $returnValue);
	// check if the returned command is the same as what we passed
	if ($cmd == 'DEACTIVATE') 
	{
		$message = "Membership deactivated successfully";
	} else 
	{
		$message = "Membership deactivation failed";
	}
	debug_log_subsc($message,true);	
}

function eMember_handle_subsc_signup($ipn_data,$subsc_ref,$unique_ref,$eMember_id='')
{
    global $wpdb,$config;
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    $membership_level_table = $wpdb->prefix . "wp_eMember_membership_tbl";
    	
	if (!empty($eMember_id))
	{
		// upgrade the member account or assign new membership levels to his/her profile
		debug_log_subsc("Upgrading member account",true);
		$account_state = 'active';
		$membership_level = $subsc_ref;
		$subscription_starts = (date ("Y-m-d"));
		$subscr_id = $unique_ref;
		
		if($config->getValue('eMember_enable_secondary_membership'))
		{
			debug_log_subsc("Using secondary membership level feature... adding additional levels to the existing profile",true);
			$resultset = $wpdb->get_row("SELECT * FROM $members_table_name where member_id='$eMember_id'", OBJECT);
			if($resultset)
			{
				$additional_levels = $resultset->more_membership_levels;
				if(emtpy($additional_levels))
				{
					$additional_levels = $membership_level;
				}
				else
				{
					$additional_levels = $additional_levels.",".$membership_level;
				}
				$updatedb = "UPDATE $members_table_name SET more_membership_levels='$additional_levels' WHERE member_id='$eMember_id'";    	    	
				$results = $wpdb->query($updatedb);				
			}
			else
			{
				debug_log_subsc("Could not find a member account for the given eMember ID",false);
			}
		}
		else
		{
			debug_log_subsc("Not using secondary membership level feature... upgrading the current membership level.",true);
			$updatedb = "UPDATE $members_table_name SET account_state='$account_state',membership_level='$membership_level',subscription_starts='$subscription_starts',subscr_id='$subscr_id' WHERE member_id='$eMember_id'";    	    	
			$results = $wpdb->query($updatedb);
		}		
    	//If using the WP user integration then update the role on WordPress too
    	if($config->getValue('eMember_create_wp_user'))
    	{
//			debug_log_subsc("Updating WordPress user role...",true);
//			$resultset = $wpdb->get_row("SELECT * FROM $members_table_name where member_id='$eMember_id'", OBJECT);
//    		$membership_level = $resultset->membership_level;
//    		$username = $resultset->user_name;
//    		debug_log_subsc("Current users username:".$username." and membership level is:".$membership_level,true);
//	        $membership_level_resultset = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$membership_level'", OBJECT);
//	                                                                         
//			$wp_user_id = $username;
//	        $wp_user_info  = array();
//	        $wp_user_info['user_nicename'] = $username;
//	        $wp_user_info['display_name']  = $username;
//	        $wp_user_info['nickname']      = $username;
//	        $wp_user_info['user_email']    = $resultset->email;
//	        //$wp_user_info['user_pass']     = $_POST['pwd'];                       
//	        $wp_user_info['ID']            = $wp_user_id;
//	        $wp_user_info['role']            = $membership_level_resultset->role;
//	        $wp_user_info['user_registered'] = date('Y-m-d H:i:s');                                        
//	        wp_update_user($wp_user_info);
//	        update_wp_user_Role($wp_user_id, $membership_level_resultset->role);  
//	        debug_log_subsc("Current users role updated.",true);
    	}  	
		
		// Send email to notify the user
    	$email = $ipn_data['payer_email'];
		$subject = WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_SUBJECT;//get_option('eMember_email_subject');
		$body = WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_BODY;//get_option('eMember_email_body');
		$from_address = get_option('senders_email_address');
		$email_body = $body;
	    $headers = 'From: '.$from_address . "\r\n";    	
	}
	else
	{
		// create new member account
		debug_log_subsc("Creating new member account",true);		
		$user_name ='';
		$password = '';
	
		$first_name = $ipn_data['first_name'];
		$last_name = $ipn_data['last_name'];
		$email = $ipn_data['payer_email'];
		$membership_level = $subsc_ref;
		$subscr_id = $unique_ref;
		
	    $address_street = $ipn_data['address_street'];
	    $address_city = $ipn_data['address_city'];
	    $address_state = $ipn_data['address_state'];
	    $address_zipcode = $ipn_data['address_zip'];
	    $country = $ipn_data['address_country'];
	
		$date = (date ("Y-m-d"));
		$account_state = 'active';
		$reg_code = uniqid(); //rand(10, 1000);
		$md5_code = md5($reg_code);
	
	    $updatedb = "INSERT INTO $members_table_name (user_name,first_name,last_name,password,member_since,membership_level,account_state,last_accessed,last_accessed_from_ip,email,address_street,address_city,address_state,address_zipcode,country,gender,referrer,extra_info,reg_code,subscription_starts,txn_id,subscr_id) VALUES ('$user_name','$first_name','$last_name','$password', '$date','$membership_level','$account_state','$date','IP','$email','$address_street','$address_city','$address_state','$address_zipcode','$country','','','','$reg_code','$date','','$subscr_id')";
	    $results = $wpdb->query($updatedb);
	
		$results = $wpdb->get_row("SELECT * FROM $members_table_name where subscr_id='$subscr_id' and reg_code='$reg_code'", OBJECT);
	
		$id = $results->member_id;
		
	    $separator='?';
		$url=get_option('eMember_registration_page');
		if(strpos($url,'?')!==false)
		{
			$separator='&';
		}
		$reg_url = $url.$separator.'member_id='.$id.'&code='.$md5_code;
		debug_log_subsc("Member signup URL :".$reg_url,true);
	
		$subject = get_option('eMember_email_subject');
		$body = get_option('eMember_email_body');
		$from_address = get_option('senders_email_address');
	
	    $tags = array("{first_name}","{last_name}","{reg_link}");
	    $vals = array($first_name,$last_name,$reg_url);
		$email_body    = str_replace($tags,$vals,$body);
	    $headers = 'From: '.$from_address . "\r\n";
	}
    if (get_option('eStore_use_wp_mail'))
    {
        wp_mail($email,$subject,$email_body,$headers);
        debug_log_subsc("Member signup/upgrade completion email successfully sent to:".$email,true);
    }
    else
    {
    	$attachment='';
    	if(@eStore_send_mail($email,$email_body,$subject,$from_address,$attachment))
    	{
    	    debug_log_subsc("Member signup/upgrade completion email successfully sent to:".$email,true);
    	}
    	else
    	{
    	    debug_log_subsc("Member signup/upgrade completion email sending failed",false);
    	}
    }
}

function eMember_handle_subsc_cancel($ipn_data)
{
    $subscr_id = $ipn_data['subscr_id'];    

    global $wpdb;
    $members_table_name = $wpdb->prefix . "wp_eMember_members_tbl";
    $membership_level_table   = $wpdb->prefix . "wp_eMember_membership_tbl";
    
    debug_log_subsc("Retrieving member account from the database...",true);
    $resultset = $wpdb->get_row("SELECT * FROM $members_table_name where subscr_id='$subscr_id'", OBJECT);
    if($resultset)
    {
    	$membership_level = $resultset->membership_level;
    	$level_query = $wpdb->get_row("SELECT * FROM $membership_level_table where id='$membership_level'", OBJECT);
    	if ($level_query->subscription_period == 0)
    	{
    		//subscription duration is set to no expiry or until canceled so deactivate the account now
    		$account_state = 'inactive';
		    $updatedb = "UPDATE $members_table_name SET account_state='$account_state' WHERE subscr_id='$subscr_id'";
		    $results = $wpdb->query($updatedb);    		
		    debug_log_subsc("Subscription cancellation received! Member account deactivated.",true);
    	}
    	else
    	{
    		//Set the account to unsubscribed and it will be set to inactive when the "Subscription duration" is over	
    		$account_state = 'unsubscribed';    
		    $updatedb = "UPDATE $members_table_name SET account_state='$account_state' WHERE subscr_id='$subscr_id'";
		    $results = $wpdb->query($updatedb);    		
		    debug_log_subsc("Subscription cancellation received! Member account set to unsubscribed.",true);
    	}
    }
    else
    {
    	debug_log_subsc("No member found for the given subscriber ID:".$subscr_id,false);
    	return;
    }      
}

function debug_log_subsc($message,$success,$end=false)
{
    // Timestamp
    $text = '['.date('m/d/Y g:i A').'] - '.(($success)?'SUCCESS :':'FAILURE :').$message. "\n";
    if ($end) {
    	$text .= "\n------------------------------------------------------------------\n\n";
    }
    // Write to log
    $fp=fopen("subscription_handle_debug.log",'a');
    fwrite($fp, $text );
    fclose($fp);  // close file
}
?>