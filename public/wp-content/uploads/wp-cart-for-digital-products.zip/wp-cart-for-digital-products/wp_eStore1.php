<?php
if(!isset($_SESSION)) 
{
	@session_start();
}	

define('WP_ESTORE_FOLDER', dirname(plugin_basename(__FILE__)));
$eStore_url = WP_PLUGIN_URL.'/'.WP_ESTORE_FOLDER;
if ($_SERVER["HTTPS"] == "on")
{
	$eStore_url = str_replace("http:","https:",$eStore_url);
}
define('WP_ESTORE_URL', $eStore_url);
define('WP_ESTORE_LIB_URL', WP_ESTORE_URL.'/lib');
define('WP_ESTORE_IMAGE_URL', WP_ESTORE_URL.'/images');
define('WP_ESTORE_SESSION_ID', session_id());

global $wpdb;
define('WP_ESTORE_PRODUCTS_TABLE_NAME', $wpdb->prefix . "wp_eStore_tbl");
define('WP_ESTORE_CUSTOMER_TABLE_NAME', $wpdb->prefix . "wp_eStore_customer_tbl");
define('WP_ESTORE_CATEGORY_TABLE_NAME', $wpdb->prefix . "wp_eStore_cat_tbl");
define('WP_ESTORE_CATEGORY_RELATIONS_TABLE_NAME', $wpdb->prefix . "wp_eStore_cat_prod_rel_tbl");
define('PAYPAL_LIVE_URL', "https://www.paypal.com/cgi-bin/webscr");
define('PAYPAL_SANDBOX_URL', "https://www.sandbox.paypal.com/cgi-bin/webscr");

$addcart_eStore = get_option('addToCartButtonName');
if (!$addcart_eStore || ($addcart_eStore == '') )
    $addcart_eStore = 'Add to Cart';
define('WP_ESTORE_ADD_CART_BUTTON', $addcart_eStore);
define('WP_ESTORE_CURRENCY_SYMBOL', get_option('cart_currency_symbol'));

$soldOutImage = get_option('soldOutImage');
if (empty($soldOutImage)) $soldOutImage = WP_ESTORE_URL.'/images/sold_out.png';
define('WP_ESTORE_SOLD_OUT_IMAGE', $soldOutImage);

//includes
$cart_language = get_option('eStore_cart_language');
if (!empty($cart_language))
	$language_file = "languages/".$cart_language;
else
	$language_file = "languages/eng.php";
include_once($language_file);
include_once('eStore_misc_functions.php');
include_once('eStore_cart.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('eStore_includes2.php');
include_once('eStore_includes3.php');
include_once('email.php');
include_once('eStore_discount_calc.php');

function eStore_sale_counter($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return eStore_get_sale_counter($id);
}

function eStore_remaining_copies_counter($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return eStore_get_remaining_copies_counter($id);
}

function eStore_download_now_button($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return eStore_show_download_now_button($id);
}

function eStore_download_now_button_fancy($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_product_fancy_style($id,$button_type=4);
}

function eStore_download_now_button_fancy_no_price_handler($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_download_now_fancy_no_price($id);
}

function eStore_fancy1($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_product_fancy_style($id);
}

function eStore_fancy2($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_product_fancy_style2($id);
}

function eStore_buy_now_fancy($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_product_fancy_style($id,$button_type=2);
}

function eStore_subscribe_fancy($atts) {
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_product_fancy_style($id,$button_type=3);
}

function wp_estore_display_category_fancy($atts)
{
	extract(shortcode_atts(array(
		'id' => 'no id',
	), $atts));
	return show_category_stylish($id);
}

function wp_eStore_buy_now_custom_button_handler($atts)
{
	extract(shortcode_atts(array(
		'id' => 'no id',
		'button' => 'Buy Now',
	), $atts));
	return print_eStore_buy_now_button($id,$button);
}

function wp_eStore_members_purchase_history_handler($atts)
{	
	return eStore_show_members_purchase_history();
}

function wp_estore_display_categories_fancy()
{
	return show_all_categories_stylish();
}

function wp_digi_cart_show($content)
{
	if (strpos($content, "<!--show-wp-cart-for-digital-products-->") !== FALSE)
    {
    	if (digi_cart_not_empty())
    	{
        	$content = preg_replace('/<p>\s*<!--(.*)-->\s*<\/p>/i', "<!--$1-->", $content);
        	$matchingText = '<!--show-wp-cart-for-digital-products-->';
        	$replacementText = print_wp_digi_cart();
        	$content = str_replace($matchingText, $replacementText, $content);
    	}
    }
    return $content;
}
function filter_wp_digi_cart_always_show($content)
{
	if (strpos($content, "<!--always-show-wp-cart-->") !== FALSE)
    {
        $content = preg_replace('/<p>\s*<!--(.*)-->\s*<\/p>/i', "<!--$1-->", $content);
       	$matchingText = '<!--always-show-wp-cart-->';
        $replacementText = wp_digi_cart_always_show();
   	    $content = str_replace($matchingText, $replacementText, $content);
    }
    return $content;
}
function eStore_shopping_cart()
{	
	if (digi_cart_not_empty())
	{
    	return eStore_shopping_cart_multiple_gateway();
	}
	return;
}

function wp_digi_cart_always_show()
{
    if (digi_cart_not_empty())
   	{
        $output = eStore_shopping_cart_multiple_gateway();
    }
    else
    {
    	$title = get_option('wp_cart_title');
    	if(empty($title))
    	{
            $title = "Your Shopping Cart";
        }
        $output .= '<a name="wp_cart_anchor"></a>';
        $output .= '<div class="shopping_cart" style=" padding: 5px;">';
        if (!get_option('eStore_shopping_cart_image_hide'))
        {
        	$output .= "<input type='image' src='".WP_ESTORE_URL."/images/shopping_cart_icon.gif' value='Shopping Cart' title='Shopping Cart' />";
        }
       	$output .= '<h2>';
       	$output .= $title;
       	$output .= '</h2>';
        $output .= eStore_shopping_cart_multiple_gateway();
        $output .= '</div>';
    }
    return $output;
}
function eStore_shopping_cart_fancy1_when_not_empty()
{
	$output = "";
    if (digi_cart_not_empty())
   	{
        $output = eStore_shopping_cart_fancy1();
    }	
    return $output;
}
function wp_estore_products($content)
{
	if (strpos($content, "<!--show-wp-cart-products-table-->") !== FALSE)
    {
        	$content = preg_replace('/<p>\s*<!--(.*)-->\s*<\/p>/i', "<!--$1-->", $content);
        	$matchingText = '<!--show-wp-cart-products-table-->';
        	$replacementText = wp_estore_products_table();
        	$content = str_replace($matchingText, $replacementText, $content);
    }
    return $content;
}

function eStore_cart_when_not_empty()
{
   	if (digi_cart_not_empty())
   	{
       	$output = print_wp_digi_cart();
    }
    return $output;
}

function filter_eStore_transaction_result($content)
{
        $pattern = '#\[wp_eStore_transaction_result:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
			$replacement = eStore_display_transaction_result();
			$content = str_replace ($match, $replacement, $content);
        }
    	return $content;
}
function eStore_display_all_products_stylish($content)
{
        $pattern = '#\[wp_eStore_all_products_stylish:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
			$replacement = eStore_print_all_products_stylish();
			$content = str_replace ($match, $replacement, $content);
        }
    	return $content;
}
function eStore_display_all_products_stylish2($content)
{
        $pattern = '#\[wp_eStore_all_products_stylish2:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
			$replacement = eStore_print_all_products_stylish('2');
			$content = str_replace ($match, $replacement, $content);
        }
    	return $content;
}

/*** PDT Stuff ***/
if(isset($_GET['tx']) && isset($_GET['amt']) && get_option('eStore_display_tx_result'))
{
	$tx_result_error_msg = "";
	//Reset the cart if it's not empty yet
	reset_eStore_cart();
	
	$req = 'cmd=_notify-synch';
	$tx_token = $_GET['tx'];	
	$auth_token = get_option('eStore_paypal_pdt_token');	
	if(empty($auth_token))
	{
		$tx_result_error_msg .= "<br />The PDT identity token is empty. If you want to display the transaction result on the thank you page then you must specify a PDT identity token in the payment gateway settings!";
		return;
	}
	$req .= "&tx=$tx_token&at=$auth_token";	
	
	// post back to PayPal system to validate
	$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
	$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
	
	$sandbox_enabled = get_option('eStore_cart_enable_sandbox');
	if($sandbox_enabled)
	{
		$host_url = 'www.sandbox.paypal.com';
	}
	else
	{
		$host_url = 'www.paypal.com';
	}
	$fp = fsockopen ($host_url, 80, $errno, $errstr, 30);
	// If possible, securely post back to paypal using HTTPS
	// Your PHP server will need to be SSL enabled
	// $fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);
	
	if (!$fp) 
	{
		$tx_result_error_msg .= "<br />HTTP ERROR... could not establish a connection to PayPal for verification!";
	} 
	else 
	{
		fputs ($fp, $header . $req);
		// read the body data
		$res = '';
		$headerdone = false;
		while (!feof($fp)) 
		{
			$line = fgets ($fp, 1024);
			if (strcmp($line, "\r\n") == 0) 
			{
				// read the header
				$headerdone = true;
			}
			else if ($headerdone)
			{
				// header has been read. now read the contents
				$res .= $line;
			}
		}		
		// parse the data
		$lines = explode("\n", $res);
		$keyarray = array();
		if (strcmp ($lines[0], "SUCCESS") == 0) 
		{
			for ($i=1; $i<count($lines);$i++)
			{
				list($key,$val) = explode("=", $lines[$i]);
				$keyarray[urldecode($key)] = urldecode($val);
			}
		}
		else if (strcmp ($lines[0], "FAIL") == 0) 
		{
			$tx_result_error_msg .= "<br />PDT verification failed! Could not verify the authenticity of the payment with PayPal!";
		}	
	}	
	fclose ($fp);	
	eStore_process_PDT_payment_data($keyarray);
}

function reset_eStore_cart()
{
    if(isset($_SESSION['eStore_cart']))
    {
        $products = $_SESSION['eStore_cart'];
        foreach ($products as $key => $item)
        {
            if (!empty($item['name']))
                unset($products[$key]);
        }
        unset($_SESSION['discount_applied_once']);
        unset($_SESSION['coupon_code']);
        unset($_SESSION['eStore_discount_total']);
        unset($_SESSION['eStore_last_action_msg']);
        $_SESSION['eStore_cart'] = $products;
        unset($_SESSION['eStore_selected_shipping_option_cost']);
    }
}

if ($_POST['reset_eStore_cart'])
{
    reset_eStore_cart();
}

if ($_POST['addcart_eStore'])
{
    setcookie("cart_in_use","true",time()+21600,"/");  
    unset($_SESSION['eStore_last_action_msg']);
    $count = 1;
    $products = $_SESSION['eStore_cart'];

    if (is_array($products))
    {
        foreach ($products as $key => $item)
        {
            if ($item['name'] == stripslashes($_POST['product']))
            {
                $req_qty = $item['quantity']+$_POST['add_qty'];
                $update_quantity = is_quantity_availabe($item['item_number'],$req_qty);

                $count += $item['quantity'];
                if ($update_quantity)
                {
                    $item['quantity'] = $item['quantity'] + $_POST['add_qty'];
                    unset($products[$key]);
                    array_push($products, $item);
                }
            }
        }
    }
    else
    {
        $products = array();
    }

    if ($count == 1)
    {
    	//echo "<br />Request-> Item:".$_POST['item_number']." Qty:".$_POST['add_qty'];
    	$quantity_available = is_quantity_availabe($_POST['item_number'],$_POST['add_qty']);
    	if (!$quantity_available)
    	{
    		//Requested qty not available
			$_POST['add_qty'] = 1; //Add one by default
    	}
    	
        if (!empty($_POST[$_POST['product']])){
            $price = $_POST[$_POST['product']];
        }
        else if (isset($_POST['custom_price'])){
        	global$wpdb;
           	$products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
           	$id = $_POST['item_number'];
        	$retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
        	if($_POST['custom_price'] < $retrieved_product->price){
        		$price = $retrieved_product->price;
        		$currSymbol = get_option('cart_currency_symbol');
        		$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.WP_ESTORE_MINIMUM_PRICE_YOU_CAN_ENTER.$currSymbol.$retrieved_product->price.'</p>';
        	}        	
        	else{
    			$price = $_POST['custom_price'];
        	}
    	}
    	else{
    		$price = $_POST['price'];
    	}
        $product = array('name' => stripslashes($_POST['product']), 'price' => $price, 'quantity' => $_POST['add_qty'], 'shipping' => $_POST['shipping'], 'item_number' => $_POST['item_number'], 'cartLink' => $_POST['cartLink'], 'thumbnail_url' => $_POST['thumbnail_url']);
        array_push($products, $product);
        $_SESSION['eStore_last_item_add_url'] = $_POST['cartLink'];
        //$_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_ITEM_ADDED.'</p>';    	
    }

    sort($products);
    $_SESSION['eStore_cart'] = $products;

    if (get_option('eStore_auto_checkout_redirection'))
    {
    	$checkout_url = eStore_get_checkout_url();
        $redirection_parameter = 'Location: '.$checkout_url;
        header($redirection_parameter);
        exit;
    }
    eStore_redirect_if_using_anchor();
}
else if ($_POST['eStore_cquantity'])
{
	unset($_SESSION['eStore_last_action_msg']);
    if ($_SESSION['discount_applied_once'] == 1)
    {
        reset_eStore_cart();
    }
    else
    {
        $products = $_SESSION['eStore_cart'];
        foreach ($products as $key => $item)
        {
            if (($item['name'] == stripslashes($_POST['product'])) && $_POST['quantity'])
            {
            	$update_quantity = is_quantity_availabe($item['item_number'],$_POST['quantity']);
    			if ($update_quantity)
    			{
    	            $item['quantity'] = $_POST['quantity'];
    	            unset($products[$key]);
    	            array_push($products, $item);
    			}
            }
            else if (($item['name'] == stripslashes($_POST['product'])) && !$_POST['quantity'])
                unset($products[$key]);
        }
        sort($products);
        $_SESSION['eStore_cart'] = $products;
    	
        eStore_redirect_if_using_anchor();
    }    
}
else if ($_POST['eStore_delcart'])
{
	unset($_SESSION['eStore_last_action_msg']);
    if ($_SESSION['discount_applied_once'] == 1)
    {
        reset_eStore_cart();
    }
    	
    $products = $_SESSION['eStore_cart'];
    foreach ($products as $key => $item)
    {    	
        if ($item['name'] == stripslashes($_POST['product']))
            unset($products[$key]);
    }
    $_SESSION['eStore_cart'] = $products;

    eStore_redirect_if_using_anchor();
}
if (isset($_POST['eStore_apply_discount']))
{
	$coupon = $_POST['coupon_code'];
	eStore_apply_discount($coupon);
}

if (isset($_POST['eStore_apply_aff_id']))
{
	if (function_exists('wp_aff_platform_install'))
	{
		record_click_for_eStore_cart($_POST['estore_aff_id']);	
		$_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_AFFILIATE_ID_SET.'</p>';
		
		if (get_option('eStore_aff_link_coupon_aff_id') == 1)
		{
			eStore_apply_discount($_POST['estore_aff_id']);			
		}		
	}
	else
	{
		$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_AFFILIATE_PLUGIN_INACTIVE.'</p>';
	}
}

if (isset($_POST['eStore_download_now_button']))
{
    $product_id = $_POST['download_now_product_id'];
    $download_link = eStore_generate_download_link1($product_id);
    $redirection_parameter = 'Location: '.$download_link;
    header($redirection_parameter);
    exit;
}

function eStore_apply_discount($coupon)
{
    if ($_SESSION['discount_applied_once'] != 1)
    {        
        $_SESSION['eStore_coupon_code'] = $coupon;
        global $wpdb;
        $coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
        $ret_coupon = $wpdb->get_row("SELECT * FROM $coupon_table_name WHERE coupon_code = '$coupon'", OBJECT);
        if ($ret_coupon)
        {
        	$coupon_error = false;
        	if($ret_coupon->active!='Yes')
        	{
        		$coupon_error = true;
        		$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_COUPON_NOT_ACTIVE.'</p>';
        	}
        	else if($ret_coupon->expiry_date != '0000-00-00')
        	{
        		$todaysdate = strtotime(date("Y-m-d"));
        		$expirydate = strtotime($ret_coupon->expiry_date);
        		if($expirydate < $todaysdate)
        		{
        			$coupon_error = true;
        			$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'."Coupon code expired!".'</p>';        			
        		}
        	}
        	else if(!empty($ret_coupon->redemption_count) && $ret_coupon->redemption_count >= $ret_coupon->redemption_limit)
        	{
        		$coupon_error = true;
        		$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_MAX_COUPON_USE.'</p>';
        	}

			if(!$coupon_error)
			{
				if(empty($ret_coupon->value))
				{
		            $discount_amount = $ret_coupon->discount_value;
		            $discount_type = $ret_coupon->discount_type;
		            $discount_total = 0;
		            $products = $_SESSION['eStore_cart'];
		            if ($discount_type == 0)
		            {
		            	foreach ($products as $key => $item)
		            	{
		            		if ($item['price'] > 0)
		            		{
		            			$item_discount = (($item['price']*$discount_amount)/100);	            			
		            			$discount_total = $discount_total + $item_discount*$item['quantity'];
		            			$item['price'] = $item['price'] - $item_discount;
		                        unset($products[$key]);
		                        array_push($products, $item);
		            		}
		            		$_SESSION['discount_applied_once'] = 1;
		            	}
		            }
		            else
		            {
		            	foreach ($products as $key => $item)
		            	{
		            		if (($item['price'] - $discount_amount)> 0)
		            		{
		            			$discount_total = $discount_total + $discount_amount*$item['quantity'];
		            			$item['price'] = ($item['price'] - $discount_amount);
		                        unset($products[$key]);
		                        array_push($products, $item);
		            		}
		            		$_SESSION['discount_applied_once'] = 1;
		            	}
		            }
		            $discount_total = round($discount_total, 2);
		            $discount_total = number_format($discount_total, 2, '.', '');
		            $_SESSION['eStore_discount_total'] = $discount_total;
		            $_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_TOTAL_DISCOUNT.WP_ESTORE_CURRENCY_SYMBOL.$discount_total.'</p>';
		            sort($products);
		            $_SESSION['eStore_cart'] = $products;
				}
				else
				{
					$discount_total = round(eStore_apply_cond_discount($ret_coupon),2);
					if ($discount_total == -99)//ESTORE_DISCOUNT_FREE_SHIPPING
					{
						$_SESSION['discount_applied_once'] = 1;
						$_SESSION['eStore_discount_total'] = __e('Free Shipping','estore');
						$_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_TOTAL_DISCOUNT.ESTORE_DISCOUNT_FREE_SHIPPING.'</p>';						
					}					
					else if($discount_total != 0)
					{
						$discount_total = number_format($discount_total, 2, '.', '');
						$_SESSION['eStore_discount_total'] = $discount_total;
						$_SESSION['discount_applied_once'] = 1;
						$_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_TOTAL_DISCOUNT.WP_ESTORE_CURRENCY_SYMBOL.$discount_total.'</p>';
					}
					else
					{
						$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_COUPON_COND_NOT_MET.'</p>';
					}
				}
			}//end apply discount
        }
        else
        {
        	$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_COUPON_INVALID.'</p>';
        }
    }
    else
    {
    	$_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_DISCOUNT_LIMIT.'</p>';
    }	
}

function eStore_redirect_if_using_anchor()
{	
    if (get_option('eStore_auto_cart_anchor'))
    {
        $anchor_name = digi_cart_current_page_url()."#wp_cart_anchor";
        $redirection_parameter = 'Location: '.$anchor_name;
        header($redirection_parameter);        
    }	    
}
function is_quantity_availabe($id,$requested_quantity)
{
    global $wpdb;
    $products_table_name = WP_ESTORE_PRODUCTS_TABLE_NAME;
    $ret_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$id'", OBJECT);
    if (is_numeric ($ret_product->available_copies))
    {
        if ($ret_product->available_copies >= $requested_quantity)
        {
        	//$_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_QTY_UPDATED.'</p>';
            return true;
        }
        else
        {
            $_SESSION['eStore_last_action_msg'] = '<p style="color: red;">'.ESTORE_QUANTITY_LIMIT_EXCEEDED.' '.ESTORE_AVAILABLE_QTY.': '.$ret_product->available_copies.'</p>';
            return false;
        }
    }
    else
    {
    	//$_SESSION['eStore_last_action_msg'] = '<p style="color: green;">'.ESTORE_QTY_UPDATED.'</p>';
    	return true;
    }
}

function print_wp_digi_cart()
{
    //return eStore_shopping_cart();
    return eStore_shopping_cart_multiple_gateway();
}

function aff_add_custom_field()
{
    $custom_field_val = eStore_get_custom_field_value();
    $output = '<input type="hidden" name="custom" value="'.$custom_field_val.'" id="eStore_custom_values" />';
	return 	$output;
}
function eStore_get_custom_field_value()
{
	$output = '';
	$_SESSION['eStore_custom_values']='';
	if (!empty($_SESSION['ap_id']))
	{
        $name = 'ap_id';
        $value = $_SESSION['ap_id'];
        $custom_field_val = append_values_to_custom_field($name,$value);
	}
	else if (isset($_COOKIE['ap_id']))
	{
        $name = 'ap_id';
        $value = $_COOKIE['ap_id'];
        $custom_field_val = append_values_to_custom_field($name,$value);
	}
	if (!empty($_SESSION['eStore_coupon_code']))
	{
        $name = 'coupon';
        $value = $_SESSION['eStore_coupon_code'];
        $custom_field_val = append_values_to_custom_field($name,$value);
    }
    if (function_exists('wp_eMember_install'))
    {  
	    global $auth;
	    $user_id = $auth->getUserInfo('member_id');
	    if (!empty($user_id))
	    {
			$name = 'eMember_id';
			$custom_field_val = append_values_to_custom_field($name,$user_id);
	    } 
    }  
    return $custom_field_val;
}
function append_values_to_custom_field($name,$value)
{
    $custom_field_val = $_SESSION['eStore_custom_values'];
    $new_val = $name.'='.$value;
    if (empty($custom_field_val))
    {
        $custom_field_val = $new_val;
    }
    else
    {
        $custom_field_val = $custom_field_val.'&'.$new_val;
    }
    $_SESSION['eStore_custom_values'] = $custom_field_val;
    return $custom_field_val;
}

function print_wp_digi_cart_button($content)
{
        $pattern = '#\[wp_eStore:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = get_button_code_for_product($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function print_wp_digi_cart_button_for_product($id)
{
	$replacement = get_button_code_for_product($id);
    return $replacement;
}

function eStore_fancy_product_display($content)
{
        $pattern = '#\[wp_eStore_fancy:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_fancy:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = show_product_fancy_style($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function eStore_fancy_product_display2($content)
{
        $pattern = '#\[wp_eStore_fancy2:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_fancy2:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = show_product_fancy_style2($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function eStore_print_products_from_category($content)
{
        $pattern = '#\[wp_eStore_category_products:category_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_category_products:category_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = show_products_from_category($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}
//*********** Start of deprecated method ************
function filter_wp_eStore_buy_now_button($content)
{
        $addcart_eStore = get_option('addToCartButtonName');
        if (!$addcart_eStore || ($addcart_eStore == '') )
            $addcart_eStore = 'Add to Cart';

        $pattern = '#\[wp_eStore_buy_now:product_id:.+button_text:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

		global $wpdb;
		$products_table_name = $wpdb->prefix . "wp_eStore_tbl";

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_buy_now:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = 'button_text:';
            $m = str_replace ($pattern, '', $m);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
            if (sizeof($pieces) == 2)
            {
          		$key = $pieces[0];
                $button_text = $pieces[1];
				$replacement = print_wp_eStore_buy_now_button($key, $button_text);
                $content = str_replace ($match, $replacement, $content);
            }
        }
        return $content;
}
//************* end of deprecated method ************

function filter_eStore_buy_now_button($content)
{
        $pattern = '#\[wp_eStore_buy_now:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_buy_now:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = print_eStore_buy_now_button($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function filter_eStore_subscribe_button($content)
{
        $pattern = '#\[wp_eStore_subscribe:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_subscribe:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = print_eStore_subscribe_button_form($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function filter_eStore_free_download_form($content)
{
        $pattern = '#\[wp_eStore_free_download:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_free_download:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = eStore_free_download_form($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function filter_eStore_free_download_form_ajax($content)
{
        $pattern = '#\[wp_eStore_free_download_ajax:product_id:.+:end]#';
        preg_match_all ($pattern, $content, $matches);

        foreach ($matches[0] as $match)
        {
            $pattern = '[wp_eStore_free_download_ajax:product_id:';
            $m = str_replace ($pattern, '', $match);

            $pattern = ':end]';
            $m = str_replace ($pattern, '', $m);

            $pieces = explode('|',$m);
    		$key = $pieces[0];

			if (sizeof($pieces) == 1)
			{
				$replacement = eStore_free_download_form_ajax($key);
				$content = str_replace ($match, $replacement, $content);
			}
        }
    	return $content;
}

function digi_cart_not_empty()
{
        $count = 0;
        if (isset($_SESSION['eStore_cart']) && is_array($_SESSION['eStore_cart']))
        {
            foreach ($_SESSION['eStore_cart'] as $item)
                $count++;
            return $count;
        }
        else
            return 0;
}

function print_digi_cart_payment_currency($price, $symbol, $decimal)
{
    return $symbol.number_format($price, 2, $decimal, ',');
}

function digi_cart_current_page_url() 
{
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
	    $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} 
	else 
	{
	    $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}
function get_eStore_smart_thumb($img_url)
{
	$src = WP_ESTORE_LIB_URL.'/timthumb.php?src='.$img_url.'&h=125&w=125&zc=1&q=100';
	return $src;
}

function wp_eStore_clear_cache(){
	if ( function_exists('w3tc_pgcache_flush') ) {
	  w3tc_pgcache_flush();
	} else if ( function_exists('wp_cache_clear_cache') ) {
	  wp_cache_clear_cache();
	}
}

// Display The Options Page
function wp_digi_cart_admin_menu ()
{
     add_options_page('WP Sell Digital Products', 'WP Sell Digital Products', 'manage_options', __FILE__, 'wp_digi_cart_options');
}

function show_wp_digi_cart_widget($args)
{
	extract($args);

	$cart_title = get_option('wp_eStore_widget_title');
	if (empty($cart_title)) $cart_title = 'Shopping Cart';

	echo $before_widget;
	echo $before_title . $cart_title . $after_title;
	if (get_option('eStore_show_compact_cart'))
	{
		echo eStore_show_compact_cart();
	}
	else
	{
		echo print_wp_digi_cart();
	}
    echo $after_widget;
}

function wp_digi_cart_widget_control()
{
    ?>
    <p>
    <? _e("Set the Plugin Settings from the Settings menu"); ?>
    </p>
    <?php
}

function widget_wp_digi_cart_init()
{   
    $widget_options = array('classname' => 'widget_wp_digi_cart', 'description' => __( "Display WP Cart For Digital Products.") );
    wp_register_sidebar_widget('wp_digi_cart_widgets', __('WP Cart for Digital Products'), 'show_wp_digi_cart_widget', $widget_options);
    wp_register_widget_control('wp_digi_cart_widgets', __('WP Cart for Digital Products'), 'wp_digi_cart_widget_control' );
}

 
//if(get_option('eStore_enable_fancy_redirection_on_checkout')){
//add_action('wp_head', wp_eStore_load_current_jquery('1.4.2'));
//}
function wp_eStore_load_current_jquery($version) {
        global $wp_scripts;
        if ( ( version_compare($version, $wp_scripts -> registered[jquery] -> ver) == 1 ) && !is_admin() ) {
                wp_deregister_script('jquery');  
                wp_register_script('jquery',
                        'http://ajax.googleapis.com/ajax/libs/jquery/'.$version.'/jquery.min.js',
                        false, $version);
        }
}

function wp_eStore_load_libraries()
{
    wp_enqueue_script('jquery');
    if(!is_admin())
    {   
	    wp_enqueue_script('jquery.external.lib.js',WP_ESTORE_LIB_URL.'/jquery.external.lib.js'); 
	    wp_enqueue_script('jquery.lightbox',WP_ESTORE_LIB_URL.'/jquery.lightbox-0.5.pack.js'); 
    
		if(get_option('eStore_enable_fancy_redirection_on_checkout')){
			wp_enqueue_script('jquery.tools',WP_ESTORE_LIB_URL.'/jquery.tools.min.js');
		} 
    }    	
}

function wp_eStore_head_content()
{	
	echo '<link type="text/css" rel="stylesheet" href="'.WP_ESTORE_URL.'/wp_eStore_style.css" />'."\n";
	echo '<link type="text/css" rel="stylesheet" href="'.WP_ESTORE_URL.'/wp_eStore_custom_style.css" />'."\n";

	echo '<script type="text/javascript" src="'.WP_ESTORE_URL.'/lib/eStore_read_form.js"></script>';
}

function wp_eStore_add_footer_code()
{
	if(get_option('eStore_enable_fancy_redirection_on_checkout'))
	{
		//Overlayed element
		$output .= '<div class="eStore_apple_overlay">';
		$output .= '<div class="cart_redirection_contentWrap"></div>';
		$output .= '</div>';	
		echo $output;					
		eStore_load_fancy_overlay_jquery2();
	}	
	if (get_option('eStore_enable_lightbox_effect') != '')
	{
		eStore_load_lightbox();
	}		
}

function eStore_tinyMCE_addbutton() 
{
	// check user permission
	if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
	return;	
	// Add only in Rich Editor mode
	if (get_user_option('rich_editing') == 'true') 
	{
		add_filter("mce_external_plugins", "eStore_tinyMCE_load");
		add_filter('mce_buttons', 'eStore_tinyMCE_register_button');
	}
}
function eStore_tinyMCE_load($plugin_array) 
{
	$plug = WP_ESTORE_LIB_URL . '/editor_plugin.js';
	$plugin_array['wpEstore'] = $plug;
	return $plugin_array;
}
function eStore_tinyMCE_register_button($buttons) 
{
   array_push($buttons, "separator", "wpEstoreButton");
   return $buttons;	
}

//Add the Admin Menus
define("ESTORE_MANAGEMENT_PERMISSION", "add_users");
if (is_admin())
{
	function wp_digi_cart_add_admin_menu()
	{
		add_menu_page(__("WP eStore", 'wp_eStore'), __("WP eStore", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, __FILE__, "wp_estore_product_management_menu");
		add_submenu_page(__FILE__, __("Manage WP eStore", 'wp_eStore'), __("Manage Products", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, __FILE__, "wp_estore_product_management_menu");
		add_submenu_page(__FILE__, __("Add/Edit WP eStore", 'wp_eStore'), __("Add/Edit Products", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_addedit', "wp_estore_add_product_menu");
		add_submenu_page(__FILE__, __("WP eStore Categories", 'wp_eStore'), __("Categories", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_categories', "wp_eStore_manage_categories_menu");
		add_submenu_page(__FILE__, __("WP eStore Stats", 'wp_eStore'), __("Stats", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_stats', "wp_estore_stats_menu");
        add_submenu_page(__FILE__, __("WP eStore Settings", 'wp_eStore'), __("Settings", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_settings', "wp_estore_settings_menu");
		add_submenu_page(__FILE__, __("WP eStore Admin", 'wp_eStore'), __("Admin Functions", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_admin', "wp_estore_admin_menu");
		add_submenu_page(__FILE__, __("WP eStore Coupons", 'wp_eStore'), __("Coupons/Discounts", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_discounts', "wp_estore_discounts_menu");
		add_submenu_page(__FILE__, __("eStore Manage Customers", 'wp_eStore'), __("Manage Customers", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_estore_customer_management', "wp_estore_customer_management_menu");
		add_submenu_page(__FILE__, __("Add/Edit Customers", 'wp_eStore'), __("Add/Edit Customers", 'wp_eStore'), ESTORE_MANAGEMENT_PERMISSION, 'wp_eStore_customer_addedit', "wp_estore_add_customer_menu");
	}
	//Include menus
	require_once(dirname(__FILE__).'/wp_digi_cart_admin_menu.php');
	require_once(dirname(__FILE__).'/eStore_product_management.php');
	require_once(dirname(__FILE__).'/eStore_categories_menu.php');
	require_once(dirname(__FILE__).'/eStore_discounts_menu.php');
	require_once(dirname(__FILE__).'/eStore_stats_menu.php');
	require_once(dirname(__FILE__).'/eStore_customers_menu.php');
}

// Insert the options page to the admin menu
if (is_admin())
{
	add_action('admin_menu','wp_digi_cart_add_admin_menu');
}

function wp_eStore_plugin_conflict_check()
{
	$msg = "";
	if(function_exists('bb2_install'))
	{
		$msg .= 'You have the Bad Behavior plugin active! This plugin is known to block PayPal\'s payment notification (IPN). Please see <a href="http://www.tipsandtricks-hq.com/forum/topic/list-of-plugins-that-dont-play-nice-conflicting-plugins" target="_blank">this post</a> for more details.';
	}
	if(!empty($msg))
	{
		echo '<div class="updated fade">'.$msg.'</div>';	
	}
}


//This is to make sure the WordPress do not try to update eStore from wordpress.org as it is a private plugin
function wp_eStore_restrict_auto_update_check( $r, $url ) {
	if ( 0 !== strpos( $url, 'http://api.wordpress.org/plugins/update-check' ) )
		return $r; // Not a plugin update request. Bail immediately.
	$plugins = unserialize( $r['body']['plugins'] );
	unset( $plugins->plugins[ plugin_basename( __FILE__ ) ] );
	unset( $plugins->active[ array_search( plugin_basename( __FILE__ ), $plugins->active ) ] );
	$r['body']['plugins'] = serialize( $plugins );
	return $r;
}
add_filter( 'http_request_args', 'wp_eStore_restrict_auto_update_check', 5, 2 );

add_action('init', 'wp_eStore_load_libraries');
add_action('init', 'eStore_tinyMCE_addbutton');
add_action('init', 'widget_wp_digi_cart_init');

add_filter('the_content', 'print_wp_digi_cart_button',11);
add_filter('the_content', 'eStore_fancy_product_display',11);
add_filter('the_content', 'eStore_fancy_product_display2');
add_filter('the_content', 'eStore_display_all_products_stylish',11);
add_filter('the_content', 'eStore_display_all_products_stylish2',11);
add_filter('the_content', 'eStore_print_products_from_category',11);
//add_filter('the_content', 'filter_wp_eStore_buy_now_button',11);
add_filter('the_content', 'filter_eStore_buy_now_button',11);
add_filter('the_content', 'filter_eStore_free_download_form',11);
add_filter('the_content', 'filter_eStore_free_download_form_ajax',11);
add_filter('the_content', 'filter_eStore_subscribe_button',11);
add_filter('the_content', 'wp_digi_cart_show');
add_filter('the_content', 'filter_wp_digi_cart_always_show');
add_filter('the_content', 'filter_eStore_transaction_result');
add_filter('the_content', 'wp_estore_products');
add_filter('the_content', 'do_shortcode');
if (!is_admin())
{add_filter('widget_text', 'do_shortcode');}

add_shortcode('wp_eStore_cart', 'wp_digi_cart_always_show');
add_shortcode('wp_eStore_cart_fancy1', 'eStore_shopping_cart_fancy1');
add_shortcode('wp_eStore_cart_fancy1_when_not_empty', 'eStore_shopping_cart_fancy1_when_not_empty');
add_shortcode('wp_eStore_cart_when_not_empty', 'eStore_cart_when_not_empty');
add_shortcode('wp_eStore_list_products', 'wp_estore_products_table');
add_shortcode('wp_eStore_list_categories_fancy', 'wp_estore_display_categories_fancy');
add_shortcode('wp_eStore_category_fancy', 'wp_estore_display_category_fancy');
add_shortcode('wp_eStore_fancy1', 'eStore_fancy1');
add_shortcode('wp_eStore_fancy2', 'eStore_fancy2');
add_shortcode('wp_eStore_buy_now_fancy', 'eStore_buy_now_fancy');
add_shortcode('wp_eStore_subscribe_fancy', 'eStore_subscribe_fancy');
add_shortcode('wp_eStore_sale_counter', 'eStore_sale_counter');
add_shortcode('wp_eStore_remaining_copies_counter', 'eStore_remaining_copies_counter');
add_shortcode('wp_eStore_download_now_button', 'eStore_download_now_button');
add_shortcode('wp_eStore_download_now_button_fancy', 'eStore_download_now_button_fancy');
add_shortcode('wp_eStore_download_now_button_fancy_no_price', 'eStore_download_now_button_fancy_no_price_handler');
add_shortcode('wp_eStore_buy_now_custom_button', 'wp_eStore_buy_now_custom_button_handler');
add_shortcode('wp_eStore_members_purchase_history', 'wp_eStore_members_purchase_history_handler');

add_action('admin_notices', 'wp_eStore_plugin_conflict_check');

add_action('wp_head', 'wp_eStore_head_content');
add_action('wp_footer', 'wp_eStore_add_footer_code');
?>
