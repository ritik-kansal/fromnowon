<?php
include_once('admin_includes.php');
include_once('eStore_utility_functions.php');

$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
$cat_prod_rel_table_name = $wpdb->prefix . "wp_eStore_cat_prod_rel_tbl";
$cat_table_name = $wpdb->prefix . "wp_eStore_cat_tbl";

//WP Cart Product Management Menu
function wp_estore_product_management_menu()
{
	echo '<div class="wrap">
	<h2>'.__('Manage Products', 'wp_eStore').'</h2>';
	echo '<div id="poststuff"><div id="post-body">';
	   	
	$eStore_products_per_page = get_option('eStore_products_per_page');
	if (empty($eStore_products_per_page)) 
	{
        echo '<div id="message" class="updated fade"><p>';
        echo 'It appears that you have never saved your settings after installing the plugin! Please visit the settings page of this plugin and save it.';
        echo '</p></div>';  			
	}
	?>
	<br />
	<div class="postbox">
	<h3><label for="title">Product Search</label></h3>
	<div class="inside">
	<br /><strong>Search for a product by entering the full or partial product Name</strong>
	<br /><br />
	<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="info_update" id="info_update" value="true" />
    
    <input name="eStore_product_search" type="text" size="30" value=""/>
    <div class="submit">
        <input type="submit" name="info_update" value="<?php _e('Search'); ?> &raquo;" />
    </div>   
    </form>
    </div></div>
	<?php

	if (isset($_POST['limit_update']))
	{
		update_option('eStore_manage_products_limit2', (string)$_POST["eStore_manage_products_limit2"]);
	}
    $limit = get_option('eStore_manage_products_limit2');
    if(empty($limit))
    {
        update_option('eStore_manage_products_limit2', 50);
        $limit = 50;
    }
    
    if(isset($_POST['Delete']))
    {
        if(wp_eStore_delete_product_data($_POST['prod_id']))
        {
            $message = "Product successfully deleted";
        }
        else
        {
            $message = "An error occurded while trying to delete the entry";
        }
        echo '<div id="message" class="updated fade"><p><strong>';
	    echo $message;
	    echo '</strong></p></div>';
    }
    	       
	if (isset($_POST['info_update']))
	{
		$search_term = (string)$_POST["eStore_product_search"];
		update_option('eStore_product_search', (string)$_POST["eStore_product_search"]);
		eStore_display_searched_products($search_term);
	}
	else
	{
		eStore_display_products($limit);
	}

	?>
	<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
    <input type="hidden" name="limit_update" id="limit_update" value="true" />
    <br />
    <strong>Product Display Limit Per Page : </strong>
    <input name="eStore_manage_products_limit2" type="text" size="10" value="<?php echo get_option('eStore_manage_products_limit2'); ?>"/>

        <input type="submit" name="limit_update" value="<?php _e('Update'); ?> &raquo;" />
 
    </form>
    <?php
    echo '</div></div>';
	echo '</div>';
}
function eStore_display_searched_products($search_term)
{
	echo '
	<table class="widefat">
	<thead><tr>
	<th scope="col">'.__('ID', 'wp_eStore').'</th>
	<th scope="col">'.__('Image', 'wp_eStore').'</th>
	<th scope="col">'.__('Product Name', 'wp_eStore').'</th>
	<th scope="col">'.__('Price', 'wp_eStore').'</th>
	<th scope="col">'.__('Download Link', 'wp_eStore').'</th>
	<th scope="col">'.__('Sales Count', 'wp_eStore').'</th>
	<th scope="col">'.__('Available Copies', 'wp_eStore').'</th>
	<th scope="col"></th>
	</tr></thead>
	<tbody>';

	global $wpdb;
	global $products_table_name;

    $wp_eStore_db = $wpdb->get_results("SELECT * FROM $products_table_name WHERE name like '%".$search_term."%'", OBJECT);
	if ($wp_eStore_db)
	{
		foreach ($wp_eStore_db as $wp_eStore_db)
		{
			echo '<tr>';
			echo '<td>'.$wp_eStore_db->id.'</td>';
			if(!empty($wp_eStore_db->thumbnail_url))
			{
				echo '<td><img src="'.$wp_eStore_db->thumbnail_url.'" width="50" height="50"></td>';
			}
			else
			{
				echo '<td><img src="'.WP_ESTORE_URL.'/images/no-image-specified.gif" width="50" height="50"></td>';
			}	
			echo '<td><strong>'.$wp_eStore_db->name.'</strong></td>';
			echo '<td><strong>'.$wp_eStore_db->price.'</strong></td>';
			echo '<td><strong>'.$wp_eStore_db->product_download_url.'</strong></td>';
			echo '<td><strong>'.$wp_eStore_db->sales_count.'</strong></td>';			
			$available_copies = $wp_eStore_db->available_copies;							
			if(empty($available_copies))
			{
				if($available_copies == ''){
					$available_copies = '&#8734;';					
				}
				else{
					$available_copies = '0';
				}
			}
			echo '<td><strong>'.$available_copies.'</strong></td>';	
			
			echo '<td style="text-align: center;"><a href="admin.php?page=wp_eStore_addedit&editproduct='.$wp_eStore_db->id.'">'.__('Edit', 'wp_eStore').'</a>';
			
			echo "<form method=\"post\" action=\"\" onSubmit=\"return confirm('Are you sure you want to delete this entry?');\">";				
			echo "<input type=\"hidden\" name=\"prod_id\" value=".$wp_eStore_db->id." />";
            echo '<input style="border: none; background-color: transparent; padding: 0; cursor:pointer;" type="submit" name="Delete" value="Delete">';
            echo "</form>";
           	echo "</td>";
           	
			echo '</tr>';
		}
	}
	else
	{
		echo '<tr> <td colspan="8">'.__('No Product found.', 'wp_eStore').'</td> </tr>';
	}

	echo '</tbody>
	</table>';
    
	// Add product button
	echo '<br /><br /><a href="admin.php?page=wp_eStore_addedit" class="button rbutton">'.__('Add New Product', 'wp_eStore').'</a>';
	echo ' <a href="admin.php?page=wp_eStore_admin" class="button rbutton">'.__('Admin Functions', 'wp_eStore').'</a>';
}

function eStore_display_products($limit)
{
	echo '
	<table class="widefat">
	<thead><tr>
	<th scope="col">'.__('ID', 'wp_eStore').'</th>
	<th scope="col">'.__('Image', 'wp_eStore').'</th>
	<th scope="col">'.__('Product Name', 'wp_eStore').'</th>
	<th scope="col">'.__('Price', 'wp_eStore').'</th>
	<th scope="col">'.__('Download Link', 'wp_eStore').'</th>
	<th scope="col">'.__('Sales Count', 'wp_eStore').'</th>
	<th scope="col">'.__('Available Copies', 'wp_eStore').'</th>
	<th scope="col"></th>
	</tr></thead>
	<tbody>';

    if (isset($_GET['product_page']))
    {
        $page = $_GET['product_page'];
    }
    else
    {
        $page = 1;
    }
    $start = ($page - 1) * $limit;

	global $wpdb;
	global $products_table_name;

	$wp_eStore_db = $wpdb->get_results("SELECT * FROM $products_table_name ORDER BY id DESC LIMIT $start, $limit", OBJECT);
    //get total rows
    $totalrows = $wpdb->get_var("SELECT COUNT(*) FROM $products_table_name;");

	$i = 0;
	if ($wp_eStore_db)
	{
		foreach ($wp_eStore_db as $wp_eStore_db)
		{
			if($i%2 == 0)
            {
				echo "<tr style='background-color: #fff;'>";
				$i++;
			}
			else
			{
				echo "<tr style='background-color: #E9EDF5;'>";
				$i++;
			}			
			//echo '<tr>';
			echo '<td>'.$wp_eStore_db->id.'</td>';			
			if(!empty($wp_eStore_db->thumbnail_url))
			{
				echo '<td><img src="'.$wp_eStore_db->thumbnail_url.'" width="50" height="50"></td>';
			}
			else
			{
				echo '<td><img src="'.WP_ESTORE_URL.'/images/no-image-specified.gif" width="50" height="50"></td>';
			}				
			echo '<td><strong>'.$wp_eStore_db->name.'</strong></td>';
			echo '<td><strong>'.$wp_eStore_db->price.'</strong></td>';
			echo '<td><strong>'.$wp_eStore_db->product_download_url.'</strong></td>';
			echo '<td><strong>'.$wp_eStore_db->sales_count.'</strong></td>';
			$available_copies = $wp_eStore_db->available_copies;
			if(empty($available_copies))
			{
				if($available_copies == ''){
					$available_copies = '&#8734;';					
				}
				else{
					$available_copies = '0';
				}
			}
			echo '<td><strong>'.$available_copies.'</strong></td>';			
		
           
			echo '<td style="text-align: center;"><a href="admin.php?page=wp_eStore_addedit&editproduct='.$wp_eStore_db->id.'">'.__('Edit', 'wp_eStore').'</a>';
			
			echo "<form method=\"post\" action=\"\" onSubmit=\"return confirm('Are you sure you want to delete this entry?');\">";				
			echo "<input type=\"hidden\" name=\"prod_id\" value=".$wp_eStore_db->id." />";
            echo '<input style="border: none; background-color: transparent; padding: 0; cursor:pointer;" type="submit" name="Delete" value="Delete">';
            echo "</form>";
           	echo "</td>";
			
			echo '</tr>';
		}
	}
	else
	{
		echo '<tr> <td colspan="8">'.__('No Products found.', 'wp_eStore').'</td> </tr>';
	}

	echo '</tbody>
	</table>';
    
    //Number of pages setup
	$pages = ceil($totalrows / $limit)+1;
    for($r = 1;$r<$pages;$r++) 
    {
        echo "<a href='?page=wp-cart-for-digital-products/wp_eStore1.php&product_page=".$r."' class=\"button rbutton\">".$r."</a>&nbsp;";
        if ($r%15==0)
           echo '<br /><br />';        
    }

	// Add product button
	echo '<br /><br /><a href="admin.php?page=wp_eStore_addedit" class="button rbutton">'.__('Add New Product', 'wp_eStore').'</a>';
	echo ' <a href="admin.php?page=wp_eStore_admin" class="button rbutton">'.__('Admin Functions', 'wp_eStore').'</a>';
}

//WP Cart Add Products Menu
function wp_estore_add_product_menu()
{
	echo '<div class="wrap">';
	echo "<h2>Add/Edit Products</h2>";
	echo '<div id="poststuff"><div id="post-body">';

	$eStore_products_per_page = get_option('eStore_products_per_page');
	if (empty($eStore_products_per_page)) 
	{
        echo '<div id="message" class="updated fade"><p>';
        echo 'It appears that you have never saved your settings after installing the plugin! Please visit the settings page of this plugin and save it.';
        echo '</p></div>';  			
	}
	
	global $wpdb;
	global $products_table_name;
	global $cat_prod_rel_table_name;
	global $cat_table_name;

	//If product is being edited, grab current product info
	if ($_GET['editproduct']!='')
	{
		$theid = $_GET['editproduct'];
		$editingproduct = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$theid'", OBJECT);
	}

	if ($_POST['Submit'])
	{
            if(empty($_POST['productname']))
            {
                echo '<div id="message" class="updated fade"><p>'.__('Product name cannot be empty!', 'wp_eStore').'</p></div>';
            }
            else
            {
		$post_editedproduct = $wpdb->escape($_POST['editedproduct']);
		$post_productid = $wpdb->escape($_POST['productid']);
		
		//$tmp_name = htmlentities(stripslashes($_POST['productname']) , ENT_COMPAT);
		$tmp_name = strip_tags(stripslashes($_POST['productname']));
        $post_productname = $wpdb->escape($tmp_name);

		$post_productprice = $wpdb->escape($_POST['productprice']);
		$curr_symbol = get_option('cart_currency_symbol');
		$post_productprice = str_replace($curr_symbol,"",$post_productprice);
		
		$post_producturl = $wpdb->escape($_POST['producturl']);
		$post_product_downloadable = $wpdb->escape($_POST['productdownloadable']);
		$post_product_shipping = $wpdb->escape($_POST['shippingcost']);
		$post_product_available_copies = $wpdb->escape($_POST['availablecopies']);
		$post_product_button_image_url = $wpdb->escape($_POST['buttonimageurl']);
		$post_product_return_url = $wpdb->escape($_POST['returnurl']);
		$paypal_email = $wpdb->escape($_POST['paypal_email']);
		$post_product_sales_count = $wpdb->escape($_POST['salescount']);	
		//$post_product_description = $wpdb->escape($_POST['productdesc']);
		$tmpdescription = htmlentities(stripslashes($_POST['productdesc']) , ENT_COMPAT, "UTF-8");

		$post_product_description = $wpdb->escape($tmpdescription);
		$post_product_thumbnail = $wpdb->escape($_POST['productthumb']);

        $post_product_variation1 = $wpdb->escape(stripslashes($_POST['variation1']));
        $post_product_variation2 = $wpdb->escape(stripslashes($_POST['variation2']));
        $post_product_variation3 = $wpdb->escape(stripslashes($_POST['variation3']));
		$variation4 = $wpdb->escape(stripslashes($_POST['variation4']));

		$post_product_commission = $wpdb->escape($_POST['productcommission']);
		
		if ($post_product_downloadable=='on'){
			$post_product_downloadable = 'yes';
		}
		else{
			$post_product_downloadable = 'no';
		}
		// Subscription related fields
		$a1 = $wpdb->escape($_POST['a1']);
		$p1 = $wpdb->escape($_POST['p1']);
		$t1 = $wpdb->escape($_POST['t1']);
		$a3 = $wpdb->escape($_POST['a3']);
		$p3 = $wpdb->escape($_POST['p3']);
		$t3 = $wpdb->escape($_POST['t3']);
		$sra = $wpdb->escape($_POST['sra']);
		$srt = $wpdb->escape($_POST['srt']);
		$ref_text = $wpdb->escape($_POST['ref_text']);
		if ($sra=='on'){
            $sra='1';
        }
        else{
            $sra='0';
        }
		$custom_input = $wpdb->escape($_POST['custom_input']);
		if ($custom_input=='on'){
            $custom_input='1';
        }
        else{
            $custom_input='0';
        }
        $custom_input_label = $wpdb->escape($_POST['custom_input_label']);
        $aweber_list = $wpdb->escape($_POST['aweber_list']);
        $currency_code = $wpdb->escape($_POST['currency_code']);
        $target_thumb_url = $wpdb->escape($_POST['target_thumb_url']);
        $target_button_url = $wpdb->escape($_POST['target_button_url']);
        $weight = $wpdb->escape($_POST['itemweight']);
        $product_url = $wpdb->escape($_POST['product_url']);
		$tmp_item_spec_instruction = stripslashes($_POST['item_spec_instruction']);
        $post_item_spec_instruction = $wpdb->escape($tmp_item_spec_instruction);      
        
        $ppv_content = $wpdb->escape($_POST['ppv_content']);
		if ($ppv_content=='on'){
            $ppv_content='1';
        }
        else{
            $ppv_content='0';
        }              
        $use_pdf_stamper = $wpdb->escape($_POST['use_pdf_stamper']);
		if ($use_pdf_stamper=='on'){
            $use_pdf_stamper='1';
        }
        else{
            $use_pdf_stamper='0';
        }   
           
        $create_license = $wpdb->escape($_POST['create_license']);
		if ($create_license=='on'){
            $create_license='1';
        }
        else{
            $create_license='0';
        }      
        $post_tax = $wpdb->escape($_POST['tax']);    
        $post_author_id = $wpdb->escape($_POST['author_id']);   
        $show_qty = $wpdb->escape($_POST['show_qty']);
		if ($show_qty=='on'){
            $show_qty='1';
        }
        else{
            $show_qty='0';
        }    
        $tier2_commission = $wpdb->escape($_POST['tier2_commission']);   
        $custom_price_option = $wpdb->escape($_POST['custom_price_option']);
		if ($custom_price_option=='on'){
            $custom_price_option='1';
        }
        else{
            $custom_price_option='0';
        }
        $post_additional_images = $wpdb->escape($_POST['additional_images']);    
        $post_oldprice = $wpdb->escape($_POST['old_price']);
                             
		//---------------
        if ($post_product_sales_count=='') $post_product_sales_count=0;        
        if ($p1=='') $p1=0;        
        if ($p3=='' || $p3<1) $p3=1;        
        if ($srt=='') $srt=0;
        		
        //Validate the form inputs
        $form_fields_validated = true;
        $validation_error_message = "";
        if(!eStore_is_valid_url_if_not_empty($post_product_thumbnail))
        {
        	$validation_error_message .= "<br /><strong>The URL specified in the \"Thumbnail Image URL\" field does not seem to be a valid URL! Please check this value again:</strong>";
        	$validation_error_message .= "<br />".$post_product_thumbnail."<br />";
        	$form_fields_validated = false;
        }
        if(!eStore_is_valid_url_if_not_empty($target_thumb_url))
        {
        	$validation_error_message .= "<br /><strong>The URL specified in the \"Thumbnail Image Link\" field does not seem to be a valid URL! Please check this value again:</strong>";
        	$validation_error_message .= "<br />".$target_thumb_url."<br />";
        	$form_fields_validated = false;
        }  
        if(!eStore_is_valid_url_if_not_empty($product_url))
        {
        	$validation_error_message .= "<br /><strong>The URL specified in the \"Product Page URL\" field does not seem to be a valid URL! Please check this value again:</strong>";
        	$validation_error_message .= "<br />".$product_url."<br />";
        	$form_fields_validated = false;
        } 
        if(!eStore_is_valid_url_if_not_empty($post_product_button_image_url))
        {
        	$validation_error_message .= "<br /><strong>The URL specified in the \"Button Image URL\" field does not seem to be a valid URL! Please check this value again:</strong>";
        	$validation_error_message .= "<br />".$post_product_button_image_url."<br />";
        	$form_fields_validated = false;
        }    
        if(!eStore_is_valid_url_if_not_empty($target_button_url))
        {
        	$validation_error_message .= "<br /><strong>The URL specified in the \"Button Link\" field does not seem to be a valid URL! Please check this value again:</strong>";
        	$validation_error_message .= "<br />".$target_button_url."<br />";
        	$form_fields_validated = false;
        }                            
        if(!$form_fields_validated)
        {
			//Get the updated product again
			$_GET['editproduct'] = $post_editedproduct;
			$editingproduct = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$post_editedproduct'", OBJECT);      
			        	
        	echo '<div id="message" class="error fade"><p>';
        	echo $validation_error_message;
        	echo '</p></div>';  	
        }  
         
        //Insert/Update the database          		
		if ($post_editedproduct=='')
		{
			$updatedb = "INSERT INTO $products_table_name (name, price, product_download_url, downloadable, shipping_cost, available_copies, button_image_url, return_url, sales_count,description,thumbnail_url,variation1,variation2,variation3,commission,a1,p1,t1,a3,p3,t3,sra,srt,ref_text,paypal_email,custom_input,custom_input_label,variation4,aweber_list,currency_code,target_thumb_url,target_button_url,weight,product_url,item_spec_instruction,ppv_content,use_pdf_stamper,create_license,tax,author_id,show_qty,tier2_commission,custom_price_option,additional_images,old_price) VALUES ('$post_productname', '$post_productprice','$post_producturl','$post_product_downloadable','$post_product_shipping','$post_product_available_copies','$post_product_button_image_url','$post_product_return_url','$post_product_sales_count','$post_product_description','$post_product_thumbnail','$post_product_variation1','$post_product_variation2','$post_product_variation3','$post_product_commission','$a1','$p1','$t1','$a3','$p3','$t3','$sra','$srt','$ref_text','$paypal_email','$custom_input','$custom_input_label','$variation4','$aweber_list','$currency_code','$target_thumb_url','$target_button_url','$weight','$product_url','$post_item_spec_instruction','$ppv_content','$use_pdf_stamper','$create_license','$post_tax','$post_author_id','$show_qty','$tier2_commission','$custom_price_option','$post_additional_images','$post_oldprice')";
			$results = $wpdb->query($updatedb);
	
			$wp_eStore_product_ret = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = LAST_INSERT_ID()", OBJECT);
			$cur_product_id = $wp_eStore_product_ret->id;		
			
			//Add the new category relationship
			$categories = $_POST['category'];
			if(!empty($categories))
			{
				while (list ($key,$val) = @each ($categories)) { 
					$updatedb = "INSERT INTO $cat_prod_rel_table_name (cat_id, prod_id) VALUES ('$val', '$cur_product_id')";
					$results = $wpdb->query($updatedb);	
				}	
			}	
			//Get the handle to the inserted product
			$_GET['editproduct'] = $wp_eStore_product_ret->id;
			$editingproduct = $wp_eStore_product_ret;
			echo '<div id="message" class="updated fade"><p>Product &quot;'.$post_productname.'&quot; created.</p></div>';
		}
		else
		{
			$updatedb = "UPDATE $products_table_name SET name = '$post_productname', price = '$post_productprice', product_download_url = '$post_producturl', downloadable = '$post_product_downloadable', shipping_cost = '$post_product_shipping', available_copies = '$post_product_available_copies', button_image_url='$post_product_button_image_url', return_url = '$post_product_return_url', sales_count = '$post_product_sales_count', description = '$post_product_description', thumbnail_url = '$post_product_thumbnail', variation1='$post_product_variation1', variation2='$post_product_variation2',variation3='$post_product_variation3',commission='$post_product_commission',a1='$a1',p1='$p1',t1='$t1',a3='$a3',p3='$p3',t3='$t3',sra='$sra',srt='$srt',ref_text='$ref_text',paypal_email='$paypal_email',custom_input='$custom_input',custom_input_label='$custom_input_label',variation4='$variation4',aweber_list='$aweber_list',currency_code='$currency_code',target_thumb_url='$target_thumb_url',target_button_url='$target_button_url',weight='$weight',product_url='$product_url',item_spec_instruction='$post_item_spec_instruction',ppv_content='$ppv_content',use_pdf_stamper='$use_pdf_stamper',create_license='$create_license',tax='$post_tax',author_id='$post_author_id',show_qty='$show_qty',tier2_commission='$tier2_commission',custom_price_option='$custom_price_option',additional_images='$post_additional_images',old_price='$post_oldprice' WHERE id='$post_editedproduct'";
			$results = $wpdb->query($updatedb);

			//Delete the existing category relationship
			$updatedb = "DELETE FROM $cat_prod_rel_table_name WHERE prod_id='$post_editedproduct'";
			$results = $wpdb->query($updatedb);	
			
			//Add the new relationship
			$categories = $_POST['category'];
			if(!empty($categories))
			{
				while (list ($key,$val) = @each ($categories)) { 
					$updatedb = "INSERT INTO $cat_prod_rel_table_name (cat_id, prod_id) VALUES ('$val', '$post_editedproduct')";
					$results = $wpdb->query($updatedb);	
				}	
			}		

			//Get the handle to the updated product
			$_GET['editproduct'] = $post_editedproduct;
			$editingproduct = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$post_editedproduct'", OBJECT);
			echo '<div id="message" class="updated fade"><p>'.__('Product', 'wp_eStore').' &quot;'.$post_productname.'&quot; '.__('updated.', 'wp_eStore').'</p></div>';
		}
            }
	}
	// Copy Product Details
	if ($_POST['copy_product'])
	{
            $post_orig_product_id = $wpdb->escape($_POST['orig_product_id']);
	    $editingproduct = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$post_orig_product_id'", OBJECT);
	    echo '<div id="message" class="updated fade"><p>'.__('Details from Product ID', 'wp_eStore').' &quot;'.$post_orig_product_id.'&quot; '.__('has been copied. Make your changes and save the new product.', 'wp_eStore').'</p></div>';
	}
	// Delete Product
	if ($_POST['deleteproduct'])
	{
		$post_editedproduct = $wpdb->escape($_POST['editedproduct']);
		echo '<div id="message" class="updated fade"><p>'.__('Do you really want to delete this Product? This action cannot be undone.', 'wp_eStore').' <a href="admin.php?page=wp_eStore_addedit&deleteproduct='.$post_editedproduct.'">'.__('Yes', 'wp_eStore').'</a> &nbsp; <a href="admin.php?page=wp_eStore_addedit&editproduct='.$post_editedproduct.'">'.__('No!', 'wp_eStore').'</a></p></div>';
	}
	if ($_GET['deleteproduct']!='')
	{
		$theproduct=$_GET['deleteproduct'];
		$updatedb = "DELETE FROM $products_table_name WHERE id='$theproduct'";
		$results = $wpdb->query($updatedb);

		$updatedb = "DELETE FROM $cat_prod_rel_table_name WHERE prod_id='$theproduct'";
		$results = $wpdb->query($updatedb);		
		
		echo '<div id="message" class="updated fade"><p>'.__('Product deleted.', 'wp_eStore').'</p></div>';
	}
    eStore_admin_css();
    echo wp_eStore_load_jquery();
    echo eStore_admin_js_scripts();
?>

You can add a new product or edit an existing product from this interface. When creating a new product you can choose to copy the details from an existing product too (see the option below). This option is helpful when creating multiple products with similar details.
<br /><br />

	<div class="postbox">
	<h3><label for="title">Product Details (Not sure how to add a product? <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=593" target="_blank">Watch the video tutorial</a>)</label></h3>
	<div class="inside">
<form method="post" action="admin.php?page=wp_eStore_addedit">
<table class="form-table">

<?php if ($_GET['editproduct']!='') 
{ 
	echo '<input name="editedproduct" type="hidden" value="'.$_GET['editproduct'].'" />'; 
	echo '<tr valign="top"><th scope="row">Porduct ID </th>';
	echo '<td><strong>'.$_GET['editproduct'].'</strong> (This value is for internal use and cannot be changed)</td>';
	echo '</tr>';
} 
?>

<tr valign="top">
<th scope="row"><?php _e('Product Name', 'wp_eStore'); ?></th>
<td><input name="productname" type="text" id="productname" value="<?php echo $editingproduct->name; ?>" size="40" /><br/><?php _e('Name of the Product', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Product Price', 'wp_eStore'); ?></th>
<td><input name="productprice" type="text" id="productprice" value="<?php echo $editingproduct->price; ?>" size="20" /><br/><?php _e('Enter Price to two decimal places. Examples: 10.00 or 6.70 or 1999.95 etc (<strong><i>Do not put currency symbol in the price</i></strong>). See the Subscription payment section below if you are configuring a subscribe button', 'wp_eStore'); ?></td>
</tr>
</table>

<div class="section_head">
<i><strong>Optional Product Details</strong></i> (If any of the following options is not needed for your product you can leave the field empty)
</div>

<div class="msg_head">Additional Product Details (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Product Description', 'wp_eStore'); ?></th>
<td><textarea name="productdesc" cols="83" rows="3"><?php echo $editingproduct->description; ?></textarea>
<br/><?php _e('This description is used when displaying products using the fancy display option.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Thumbnail Image URL', 'wp_eStore'); ?></th>
<td><input name="productthumb" type="text" id="productthumb" value="<?php if ($editingproduct->thumbnail_url!='') { echo $editingproduct->thumbnail_url; } else { echo ''; } ?>" size="100" /><br/><?php _e('This thumbnail image is used when displaying products using the fancy display option.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Old Price', 'wp_eStore'); ?></th>
<td><input name="old_price" type="text" id="old_price" value="<?php echo $editingproduct->old_price; ?>" size="10" />
<br/><?php _e('The original price (for display purpose only). This price will be slashed out in some of the fancy displays (not available in all the fancy display options)', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Additional Product Images', 'wp_eStore'); ?></th>
<td><textarea name="additional_images" cols="83" rows="2"><?php echo $editingproduct->additional_images; ?></textarea>
<br/><?php _e('Enter the image URLs separated by comma. When you display your product using a fancy display with lightbox option, your customers will be able to view these images in the lightbox by clicking the next or previous buttons.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Thumbnail Image Link', 'wp_eStore'); ?></th>
<td><input name="target_thumb_url" type="text" id="target_thumb_url" value="<?php if ($editingproduct->target_thumb_url!='') { echo $editingproduct->target_thumb_url; } else { echo ''; } ?>" size="100" /><br/><?php _e('If you want to link the thumbnail image to a URL then specify the target URL here otherwise leave empty.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Product Page URL', 'wp_eStore'); ?></th>
<td><input name="product_url" type="text" id="product_url" value="<?php if ($editingproduct->product_url!='') { echo $editingproduct->product_url; } else { echo ''; } ?>" size="100" /><br/><?php _e('If you have a specific page for detailed description of this product then specify the URL here otherwise leave empty. The product name will be linked to this page when using the fancy display option.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Product Category', 'wp_eStore'); ?></th>
<td>
<?php
	$wp_eStore_cat_db = $wpdb->get_results("SELECT * FROM $cat_table_name ORDER BY cat_id DESC", OBJECT);
	if ($wp_eStore_cat_db)
	{
		$existing_categories = array();
		if($_GET['editproduct']!='')
		{
            $theid = $_GET['editproduct'];
		    $editingproduct_cat_db = $wpdb->get_results("SELECT * FROM $cat_prod_rel_table_name WHERE prod_id = '$theid'", OBJECT);
		    if ($editingproduct_cat_db)
		    {
		    	
		    	foreach ($editingproduct_cat_db as $existing_product_cat)
		    	{
		    		array_push($existing_categories,$existing_product_cat->cat_id);
		    	}
		    }   
		}		
		foreach ($wp_eStore_cat_db as $cat_item)
		{
			$checked = "";
			if(in_array($cat_item->cat_id,$existing_categories)){
				$checked = "checked='checked'";
			}			
			echo "<input type='checkbox' name='category[]' value='".$cat_item->cat_id."' ".$checked."/> ".$cat_item->cat_name."<br />";						
		}
	}
	else
	{
		echo 'No Categories Found! <a href="admin.php?page=wp_eStore_categories"><strong>Add a Category</strong></a>';
	}
?>
</td>
</tr>
	
<tr valign="top">
<th scope="row"><?php _e('Button Image URL', 'wp_eStore'); ?></th>
<td><input name="buttonimageurl" type="text" id="buttonimageurl" value="<?php if ($editingproduct->button_image_url!='') { echo $editingproduct->button_image_url; } else { echo ''; } ?>" size="100" /><br/><?php _e('This is useful when you want to use a custom button image than the one specified in the Settings menu for this product.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Button Link', 'wp_eStore'); ?></th>
<td><input name="target_button_url" type="text" id="target_button_url" value="<?php if ($editingproduct->target_button_url!='') { echo $editingproduct->target_button_url; } else { echo ''; } ?>" size="100" /><br/><?php _e('Only use this if you want the Add to Cart button for this product to go to the specified URL (eg. a landing page) instead of adding the product to the shopping cart. Useful when you are selling/promoting product of others.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Display Quantity Field', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="show_qty" <?php if ($editingproduct->show_qty=='1'){echo 'checked="checked"';} ?> />
<br /><?php _e('When checked, it will display a text box next to the Add to Cart button so the customers can enter a quantity amount for the item.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Allow Customers to Specify a Price', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="custom_price_option" <?php if ($editingproduct->custom_price_option=='1'){echo 'checked="checked"';} ?> />
<br />When checked, it will display a text box next to the Add to Cart button so the customers can specify a price amount for this item. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=994" target="_blank">Read More Here</a></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Collect Customer Input', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="custom_input" <?php if ($editingproduct->custom_input=='1'){echo 'checked="checked"';} ?> />
&nbsp;&nbsp;Field Label: <input name="custom_input_label" type="text" id="custom_input_label" value="<?php echo $editingproduct->custom_input_label; ?>" size="40" />
<br /><?php _e('When checked, it will display a text box next to the Add to Cart button where the customer can enter special instruction for that product (eg. a Name if selling Engraving).', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Product Specific Commission', 'wp_eStore'); ?></th>
<td>Primary Commission: <input name="productcommission" type="text" id="productcommission" value="<?php if ($editingproduct->commission!='') { echo $editingproduct->commission; } else { echo ''; } ?>" size="3" />
&nbsp;&nbsp;2nd Tier Commission: <input name="tier2_commission" type="text" id="tier2_commission" value="<?php if ($editingproduct->tier2_commission!='') { echo $editingproduct->tier2_commission; } else { echo ''; } ?>" size="3" /> (optional)
<br/><?php _e('Use this option when you want to offer a special affiliate commision rate for this product when using with the <a href="http://www.tipsandtricks-hq.com/?p=1474" target="_blank">WP Affiliate Platform</a> plugin. Only specify the amount (do not include the % or $ sign as it is already specified in the settings menu of the affiliate plugin).', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Reference Text', 'wp_eStore'); ?></th>
<td><input name="ref_text" type="text" id="ref_text" value="<?php echo $editingproduct->ref_text; ?>" size="20" />
<br/><?php _e('Reference Text field can be useful when integrating with a membership plugin. If you are configuring a payment button for the WP eMember plugin then this is where you specify the membership level ID. <a href="http://www.tipsandtricks-hq.com/wordpress-membership/?p=60" target="_blank">Read More Here</a>', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">Digital Content Details (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Digital Product URL', 'wp_eStore'); ?></th>
<td><input name="producturl" type="text" id="producturl" value="<?php if ($editingproduct->product_download_url!='') { echo $editingproduct->product_download_url; } else { echo ''; } ?>" size="100" />
<br/>The URL of the digital product that you are selling. eg. http://www.your-domain.com/downloads/ebook/superman.zip 
<li style="margin-left:15px;margin-top:10px;color:#666666;"><i>If you have not uploaded the file to your server yet then you can do so using the <a href="media-new.php" target="_blank">WordPress's Media Uploader</a>. Simply copy the "File URL" after you upload the file and paste it here.</i></li> 
<li style="margin-left:15px;color:#666666;"><i>Enter the product IDs separated by comma (eg. 3,8,18) if making a bundled product. Enter the file URLs separated by comma if the product has multiple files.</i></li> 
<li style="margin-left:15px;color:#666666;"><i>Please note that you do not have to upload the downloadable file in the downloads directory of this plugin. The file can be kept on any accessible location on the web. <a href="http://www.tipsandtricks-hq.com/forum/topic/download-directory-protection" target="_blank">Read More Here</a>. The buyer will receive an encrypted link which will let them download this product.</i></li>
</td></tr>

<tr valign="top">
<th scope="row"><?php _e('Downloadable', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="productdownloadable" <?php if ($editingproduct->downloadable!='no'){echo 'checked="checked"';} ?> /> 
<?php _e('If checked the digital content will be offered as an anonymous download (the customer won\'t know where it is coming from). If Unchecked the buyer will be redirected to the above URL when they click on the encrypted link (useful for video on demand system)', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Pay Per View Content', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="ppv_content" <?php if ($editingproduct->ppv_content=='1'){echo 'checked="checked"';} ?> />
<br /><?php _e('If you are offering Pay Per View content then check this box and uncheck the "Downloadable" checkbox above. For pay per view content, the true URL of the page where the content is embedded (e.g. a steaming video) does not get revealed.', 'wp_eStore'); ?></td>
</tr>

</table>
</div>

<div class="msg_head">Variations (Click to Expand)</div>
<div class="msg_body">
&nbsp;&nbsp;<strong>Please make sure you have specified a base price for the product in the "Product Price" field above</strong>
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Product Variation 1', 'wp_eStore'); ?></th>
<td><textarea name="variation1" cols="83" rows="3"><?php echo $editingproduct->variation1; ?></textarea><br/><?php _e('Useful if you want to use variation with your product eg. Small, Medium, Large. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=345" target="_blank">Learn How To</a>', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Product Variation 2', 'wp_eStore'); ?></th>
<td><textarea name="variation2" cols="83" rows="3"><?php echo $editingproduct->variation2; ?></textarea><br/><?php _e('Useful when adding additional variation with your product eg. Red, Green. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=345" target="_blank">Learn How To</a>', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Product Variation 3', 'wp_eStore'); ?></th>
<td><textarea name="variation4" cols="83" rows="3"><?php echo $editingproduct->variation4; ?></textarea><br/><?php _e('Useful when adding additional variation with your product eg. Short, Full. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=345" target="_blank">Learn How To</a>', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Digital Product Variation', 'wp_eStore'); ?></th>
<td><textarea name="variation3" cols="83" rows="3"><?php echo $editingproduct->variation3; ?></textarea><br/><?php _e('Can be used for digital delivery of different files depending on the selection (eg. Personal use, Business use). <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=345" target="_blank">Learn How To</a>', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">Shipping & Tax (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Item Shipping Cost', 'wp_eStore'); ?></th>
<td><input name="shippingcost" type="text" id="shippingcost" value="<?php echo $editingproduct->shipping_cost; ?>" size="3" /><br/><?php _e('Enter the Shipping Cost for this item (eg. 5.00). Leave blank if shipping cost does not apply.', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Item Weight', 'wp_eStore'); ?></th>
<td><input name="itemweight" type="text" id="itemweight" value="<?php echo $editingproduct->weight; ?>" size="3" /><br/><?php _e('Enter the Weight of the item in lbs. This is only used if you are using <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=50" target="_blank">PayPal profile based shipping</a.', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Item Specific Tax', 'wp_eStore'); ?></th>
<td><input name="tax" type="text" id="tax" value="<?php echo $editingproduct->tax; ?>" size="3" />%<br/><?php _e('If you want to charge a different tax for this item than the one specified in the settings menu then enter the tax rate for this item here.', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">Inventory Control (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Available Copies', 'wp_eStore'); ?></th>
<td><input name="availablecopies" type="text" id="availablecopies" value="<?php echo $editingproduct->available_copies; ?>" size="10" /><br/><?php _e('Enter the numer of available copies (eg. 50). Leave blank if unlimited. This is useful when you only want to sell 50 copies for example', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Sales Count', 'wp_eStore'); ?></th>
<td><input name="salescount" type="text" id="salescount" value="<?php echo $editingproduct->sales_count; ?>" size="10" /><br/><?php _e('This is the total sales count. This number gets incremented by the quantity sold when you make a sale', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">AddOn Settings (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"></th><td><strong><i>Use the following section only if you are using the <a href="http://www.tipsandtricks-hq.com/wp-pdf-stamper" target="_blank">WP PDF Stamper Plugin</a></i></strong></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Stamp the PDF File', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="use_pdf_stamper" <?php if ($editingproduct->use_pdf_stamper=='1'){echo 'checked="checked"';} ?> />
<?php _e('If this product is an eBook and you want to stamp this PDF file with customer details upon purchase then check this option.', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"></th><td><strong><i>Use the following section only if you are using the <a href="http://www.tipsandtricks-hq.com/?p=1474" target="_blank">WP Affiliate Platform Plugin</a></i></strong></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Author ID for Revenue Sharing', 'wp_eStore'); ?></th>
<td><input name="author_id" type="text" id="author_id" value="<?php echo $editingproduct->author_id; ?>" size="10" /><br />
If you want to share revenue with the author of this product then enter the affiliate ID of this author in this field. <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=930" target="_blnak">Read More Here</a></td>
</tr>

<?php if (function_exists('wp_lic_manager_install')){ ?>
<tr valign="top">
<th scope="row"></th><td><strong><i>Use the following section only if you are using the <a href="http://www.tipsandtricks-hq.com" target="_blank">WP License Manager Plugin</a></i></strong></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Create License', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="create_license" <?php if ($editingproduct->create_license=='1'){echo 'checked="checked"';} ?> />
<?php _e('If this product is a piece of software that has been integrated with the WP License Manage plugin then checking this box will create a license for the customer who purchase this product.', 'wp_eStore'); ?></td>
</tr>
<?php } ?>
</table>
</div>

<div class="msg_head">Autoresponder Settings (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('List Name', 'wp_eStore'); ?></th>
<td><input name="aweber_list" type="text" id="aweber_list" value="<?php echo $editingproduct->aweber_list; ?>" size="40" /><br/>
<?php _e('The name of the list where the customers of this product will be signed up to (example: "listname@aweber.com" if you are using AWeber or "sample_marketing" if you are using GetResponse or "My Customers" if you are using MailChimp). You can find the list/campaign name inside your autoresponder account. Use this if you want the customer of this product to be signed up to a specific list.', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">Product Specific Instructions for Buyer (Click to Expand)</div>
<div class="msg_body">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Instructions for Buyer', 'wp_eStore'); ?></th>
<td><textarea name="item_spec_instruction" cols="83" rows="3"><?php echo $editingproduct->item_spec_instruction; ?></textarea>
<br/><?php _e('This option is useful when you need to give your customer some specific instruction that applies only to this product (e.g. a secret password for the PDF file). This instruction will be added to the buyer\'s email body when this product is purchased. Use the {product_specific_instructions} tag in the "Buyers Email Body" field in the settings menu to dynamically place this information in the email body.', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">Buy Now or Subscription Type Button Specific Settings (Click to Expand)</div>
<div class="msg_body">
<strong>The options in this section are only used for "Buy Now" or "Subscription" type buttons</strong>
<br /><br />This can be useful when you want to use a different setting than the one specified in the Settings menu for this product. For example you might be using USD for your store but you may want to create a subscription button in Euro for one product. 
<br /><br />
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Return URL', 'wp_eStore'); ?></th>
<td><input name="returnurl" type="text" id="returnurl" value="<?php if ($editingproduct->return_url!='') { echo $editingproduct->return_url; } else { echo ''; } ?>" size="50" />
<br/><?php _e('Can be used to redirect customers to a different URL for this item after a successful payment', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('PayPal Email', 'wp_eStore'); ?></th>
<td><input name="paypal_email" type="text" id="paypal_email" value="<?php if ($editingproduct->paypal_email!='') { echo $editingproduct->paypal_email; } else { echo ''; } ?>" size="50" /><br/><?php _e('This is useful when you want to allow other blog authors to sell their products on your blog and the product owner gets the money directly into his/her PayPal account', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Currency Code', 'wp_eStore'); ?></th>
<td><input name="currency_code" type="text" id="currency_code" value="<?php if ($editingproduct->currency_code!='') { echo $editingproduct->currency_code; } else { echo ''; } ?>" size="6" /><br/><?php _e('This is useful when you want to sell a specific product in a different currency than the one specified in the settings menu. (e.g. EUR, GBP, AUD, USD) ', 'wp_eStore'); ?></td>
</tr>
</table>
</div>

<div class="msg_head">Subscription/Recurring Payment Specific Settings (Click to Expand)</div>
<div class="msg_body">
	<div class="postbox">
	<h3><label for="title">Trial Period (Leave Empty if you are not offfering a Trial Period)</label></h3>
	<div class="inside">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Trial Billing Amount', 'wp_eStore'); ?></th>
<td><input name="a1" type="text" id="a1" value="<?php echo $editingproduct->a1; ?>" size="10" /><br/><?php _e('Amount to be charged for the Trail period. Enter 0 if you want to offer a free trial period', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Trial Billing Period', 'wp_eStore'); ?></th>
<td><input name="p1" type="text" id="p1" value="<?php echo $editingproduct->p1; ?>" size="5" />
		<select name='t1'>
		<option value='D' <?php if($editingproduct->t1=='D')echo 'selected="selected"';?>>Day</option>
		<option value='M' <?php if($editingproduct->t1=='M')echo 'selected="selected"';?>>Month</option>
		<option value='Y' <?php if($editingproduct->t1=='Y')echo 'selected="selected"';?>>Year</option>
		</select>
<br/><?php _e('Lenght of the Trial Period', 'wp_eStore'); ?></td>
</tr>
</table>
</div></div>

	<div class="postbox">
	<h3><label for="title">Recurring Billing</label></h3>
	<div class="inside">
<table class="form-table">
<tr valign="top">
<th scope="row"><?php _e('Recurring Billing Amount', 'wp_eStore'); ?></th>
<td><input name="a3" type="text" id="a3" value="<?php echo $editingproduct->a3; ?>" size="10" /><br/><?php _e('Amount to be charged on every billing cycle. If used with a trial period then this amount will be charged after the trial period is over', 'wp_eStore'); ?></td>
</tr>

<tr valign="top">
<th scope="row"><?php _e('Recurring Billing Cycle', 'wp_eStore'); ?></th>
<td><input name="p3" type="text" id="p3" value="<?php echo $editingproduct->p3; ?>" size="5" />
		<select name='t3'>
		<option value='D' <?php if($editingproduct->t3=='D')echo 'selected="selected"';?>>Day</option>
		<option value='M' <?php if($editingproduct->t3=='M')echo 'selected="selected"';?>>Month</option>
		<option value='Y' <?php if($editingproduct->t3=='Y')echo 'selected="selected"';?>>Year</option>
		</select>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Recurring Billing Count', 'wp_eStore'); ?></th>
<td><input name="srt" type="text" id="srt" value="<?php echo $editingproduct->srt; ?>" size="5" /><br/><?php _e('This is the number of payments which will occur at the regular rate. Leave this field empty if you want the payment to continue to recur at the regular rate until the subscription is canceled. Enter -1 if you want to configure a once off payment.', 'wp_eStore'); ?></td>
</tr>
<tr valign="top">
<th scope="row"><?php _e('Reattempt on failure', 'wp_eStore'); ?></th>
<td><input type="checkbox" name="sra" <?php if ($editingproduct->sra=='1'){echo 'checked="checked"';} ?> /> <?php _e('When checked, the payment will be reattempted two more times if the payment fails. After the third failure, the subscription will be cancelled.', 'wp_eStore'); ?></td>
</tr>
</table>
</div></div>
</div>

<p class="submit"><input type="submit" name="Submit" value="<?php _e('Save Product', 'wp_eStore'); ?>" /> &nbsp; <?php if ($_GET['editproduct']!='') { ?><input type="submit" name="deleteproduct" value="<?php _e('Delete Product', 'wp_eStore'); ?>" /><?php } ?></p>

</form>
</div></div>

<div class="postbox">
<h3><label for="title">Copy Product Details from an Existing Product</label></h3>
<div class="inside">

To copy the details from an existing product simply enter the ID of the product whose details you wish to copy and hit the "Copy Product Details" button
<br /><br />
<form method="post" action="admin.php?page=wp_eStore_addedit">
Product ID:
<input name="orig_product_id" type="text" id="orig_product_id" value="" size="5" />
<input type="submit" name="copy_product" value="<?php _e('Copy Product Details', 'wp_eStore'); ?>" />
</form>
</div>
</div>

</div></div>

<?php

	echo 'Want to bulk upload product details from CSV file? <a href="http://www.tipsandtricks-hq.com/ecommerce/?p=775" target="_blank">Click Here to Learn More</a><br /><br />';
	echo '<a href="admin.php?page=wp-cart-for-digital-products/wp_eStore1.php" class="button rbutton">'.__('Manage Products', 'wp_eStore').'</a><br /><br />';

	echo '</div>';
}

function wp_eStore_delete_product_data($product_id)
{
    global $wpdb;
	global $products_table_name;
	global $cat_prod_rel_table_name;
	
	$updatedb = "DELETE FROM $products_table_name WHERE id='$product_id'";
	$results = $wpdb->query($updatedb);

	$updatedb = "DELETE FROM $cat_prod_rel_table_name WHERE prod_id='$product_id'";
	$resultsTwo = $wpdb->query($updatedb);		
		
    if($results>0)
    {
        return true;
    }
    else
    {
        return false;
    }	
}
?>