<?php
/*
Plugin Name: WP eStore
Version: v4.9.5
Plugin URI: http://www.tipsandtricks-hq.com/?p=1059
Author: Ruhul Amin
Author URI: http://www.tipsandtricks-hq.com/
Description: Simple Shopping Cart Plugin to sell digital (ebook, mp3, photos) and non digital products from your wordpress blog through PayPal. The digital goods are automatically delivered to the buyer after purchase using encrypted and time limited download links.
*/
define('WP_ESTORE_VERSION', "4.9.5");
include_once('wp_eStore1.php');
//Installer
function wp_eStore_install ()
{
	require_once(dirname(__FILE__).'/eStore_installer.php');
}
register_activation_hook(__FILE__,'wp_eStore_install');

function wp_eStore_add_settings_link($links, $file) 
{
	if ($file == plugin_basename(__FILE__)){
		$settings_link = '<a href="admin.php?page=wp_eStore_settings">Settings</a>';
		array_unshift($links, $settings_link);
	}
	return $links;
}
add_filter('plugin_action_links', 'wp_eStore_add_settings_link', 10, 2 );
?>