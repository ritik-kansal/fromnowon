<?php
include_once('../../../wp-load.php');
include_once('wp_cart_for_digital_products.php');
include_once('email.php');
include_once('eStore_classes.php');
include_once('eStore_handle_subsc_ipn.php');
include_once('eStore_post_payment_processing_helper.php');
include_once('eStore_includes4.php');
include_once('eStore_auto_responder_handler.php');

$debug_log = "ipn_handle_debug.log"; // Debug log file name
$time = time();
$email_config['protocol'] = 'mail'; // Simple PHP Mail
$error_msg='';

class paypal_ipn_handler {

   var $last_error;                 // holds the last error encountered
   var $ipn_log;                    // bool: log IPN results to text file?
   var $ipn_log_file;               // filename of the IPN log
   var $ipn_response;               // holds the IPN response from paypal
   var $ipn_data = array();         // array contains the POST values for IPN
   var $fields = array();           // array holds the fields to submit to paypal

   	function paypal_ipn_handler()
   	{
        $this->paypal_url = 'https://www.paypal.com/cgi-bin/webscr';
      	$this->last_error = '';
      	$this->ipn_log_file = 'ipn_handle_debug.log';
      	$this->ipn_response = '';
    }

   	function validate_and_dispatch_product()
	{
		// Check Product Name , Price , Currency , Receivers email ,
		global $products,$error_msg;		
        $clientdate = (date ("Y-m-d"));
		$clienttime	= (date ("H:i:s"));
		$product_specific_instructions = "";
		$currency_symbol = get_option('cart_currency_symbol');
		
   		// Read the IPN and validate
   		if (get_option('eStore_strict_email_check') != '')
   		{
    		$seller_paypal_email = get_option('cart_paypal_email');
    		if ($seller_paypal_email != $this->ipn_data['receiver_email'])
    		{
                $error_msg .= 'Invalid Seller Paypal Email Address : '.$this->ipn_data['receiver_email'];
    			$this->debug_log($error_msg,false);
    			return false;
    		}
    		else
    		{
                $this->debug_log('Seller Paypal Email Address is Valid: '.$this->ipn_data['receiver_email'],true);
            }
    	}
    	
    	$payment_status = $this->ipn_data['payment_status'];
    	if (!empty($payment_status))
    	{
    		if ($payment_status == "Denied")
    		{
    			$this->debug_log("You denied the transaction. Most likely a cancellation of an eCheque. Nothing to do here.",false);
    			return false;
    		}
	        if ($payment_status != "Completed" && $payment_status != "Processed" && $payment_status != "Refunded" && $payment_status != "Reversed")
	        {
                $error_msg .= 'Funds have not been cleared yet. Product(s) will be delivered when the funds clear!';
	  			$this->debug_log($error_msg,false);

	  			$to_address = $this->ipn_data['payer_email'];
                $subject = ESTORE_PENDING_PAYMENT_EMAIL_SUBJECT;
                $body = ESTORE_PENDING_PAYMENT_EMAIL_BODY;
                $from_address = get_option('eStore_download_email_address');
                eStore_send_notification_email($to_address, $subject, $body, $from_address);
	    		return false;
	        }
    	}    	
		
		$transaction_type = $this->ipn_data['txn_type'];
		if($transaction_type == "new_case")
		{
			$this->debug_log('This is a dispute case',true);
			return true;
		}
		
		$transaction_id = $this->ipn_data['txn_id'];
		$transaction_subject = $this->ipn_data['transaction_subject'];
				
        $custom = $this->ipn_data['custom'];
        $delimiter = "&";
        $customvariables = array();

        $namevaluecombos = explode($delimiter, $custom);
        foreach ($namevaluecombos as $keyval_unparsed)
        {
            $equalsignposition = strpos($keyval_unparsed, '=');
            if ($equalsignposition === false)
            {
                $customvariables[$keyval_unparsed] = '';
                continue;
            }
            $key = substr($keyval_unparsed, 0, $equalsignposition);
            $value = substr($keyval_unparsed, $equalsignposition + 1);
            $customvariables[$key] = $value;
        }
        $eMember_id = $customvariables['eMember_id'];
        $pictureID = $customvariables['ngg_pid'];
		
		//Check for refund payment
		$gross_total = $this->ipn_data['mc_gross'];
		if ($gross_total < 0)
		{
			// This is a refund or reversal so handle the refund
			eStore_handle_refund($this->ipn_data);
			$this->debug_log('This is a refund/reversal. Refund amount: '.$gross_total,true);
			return true;
		}
		        
		if ($transaction_type == "cart")
		{
			$this->debug_log('Transaction Type: Shopping Cart',true);
			// Cart Items
			$num_cart_items = $this->ipn_data['num_cart_items'];
			$this->debug_log('Number of Cart Items: '.$num_cart_items,true);

			$i = 1;
			$cart_items = array();
			while($i < $num_cart_items+1)
			{
				$item_number = $this->ipn_data['item_number' . $i];
				$item_name = $this->ipn_data['item_name' . $i];
				$quantity = $this->ipn_data['quantity' . $i];
				$mc_gross = $this->ipn_data['mc_gross_' . $i];
				$mc_shipping = $this->ipn_data['mc_shipping' . $i];
				$mc_currency = $this->ipn_data['mc_currency'];

				$current_item = array(
									   'item_number' => $item_number,
									   'item_name' => $item_name,
									   'quantity' => $quantity,
									   'mc_gross' => $mc_gross,
									   'mc_shipping' => $mc_shipping,
									   'mc_currency' => $mc_currency,
									  );

				array_push($cart_items, $current_item);
				$i++;
			}
		}
		else if (($transaction_type == "subscr_signup"))
		{
                    $this->debug_log('Subscription signup IPN received... nothing to do here(handled by the subscription IPN handler). Check the "subscription_handle_debug.log" file more details.',true);
			// Code to handle the signup IPN for subscription
			$subsc_ref = $customvariables['subsc_ref'];
			
			if (get_option('eStore_enable_wishlist_int'))
			{
        			if (!empty($subsc_ref))
        			{
                                    $this->debug_log('WishList integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
        			    wl_handle_subsc_signup($this->ipn_data,$subsc_ref,$this->ipn_data['subscr_id']);
        			}
                        }
                        else
                        {
    			    if (!empty($subsc_ref))
    			    {
                                if (function_exists('wp_eMember_install'))
                                {
                                    $this->debug_log('eMember integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);                                    
                                    eMember_handle_subsc_signup($this->ipn_data,$subsc_ref,$this->ipn_data['subscr_id'],$eMember_id);
                                }
                                //Handle customized subscription signup
                            }
                        }
			return true;
		}
		else if (($transaction_type == "subscr_cancel") || ($transaction_type == "subscr_eot") || ($transaction_type == "subscr_failed"))
		{
			if (get_option('eStore_enable_wishlist_int'))
			{
			    wl_handle_subsc_cancel($this->ipn_data);
                        }
                        else
                        {
                            // Code to handle the IPN for subscription cancellation
                            if (function_exists('wp_eMember_install'))
                            {
                                eMember_handle_subsc_cancel($this->ipn_data);
                            }
                        }
			$this->debug_log('Subscription cancellation IPN received... nothing to do here(handled by the subscription IPN handler)',true);
			return true;
		}
		else
		{
			$cart_items = array();
			$this->debug_log('Transaction Type: Buy Now/Subscribe',true);
			$item_number = $this->ipn_data['item_number'];
			$item_name = $this->ipn_data['item_name'];
			$quantity = $this->ipn_data['quantity'];
			if(empty($quantity)){
				$quantity = 1;
			}
			$mc_gross = $this->ipn_data['mc_gross'];
			$mc_shipping = $this->ipn_data['mc_shipping'];
			$mc_currency = $this->ipn_data['mc_currency'];

			$current_item = array(
									   'item_number' => $item_number,
									   'item_name' => $item_name,
									   'quantity' => $quantity,
									   'mc_gross' => $mc_gross,
									   'mc_shipping' => $mc_shipping,
									   'mc_currency' => $mc_currency,
									  );

			array_push($cart_items, $current_item);
		}
		
        // URL of directory where script is stored ( include trailing slash )
		$script_location = get_option('eStore_download_script');
		$random_key = get_option('eStore_random_code');

		global $time;
		global $wpdb;
		$products_table_name = $wpdb->prefix . "wp_eStore_tbl";
		$customer_table_name = $wpdb->prefix . "wp_eStore_customer_tbl";
		$sales_table_name = $wpdb->prefix . "wp_eStore_sales_tbl";
		$payment_currency = get_option('cart_payment_currency');

	    $product_id_array = Array();
	    $product_name_array = Array();
	    $product_price_array = Array();
	    $product_qty_array = Array();
	    $download_link_array = Array();
	    //$attachments_array = Array();
	    
        $counter = 0;
		foreach ($cart_items as $current_cart_item)
		{
			$cart_item_data_num = $current_cart_item['item_number'];
			$cart_item_data_name = trim($current_cart_item['item_name']);
			$cart_item_data_quantity = $current_cart_item['quantity'];
			$cart_item_data_total = $current_cart_item['mc_gross'];
			$cart_item_shipping = $current_cart_item['mc_shipping'];
			$cart_item_data_currency = $current_cart_item['mc_currency'];
			if(empty($cart_item_data_quantity))
			{
				$cart_item_data_quantity = 1;
			}
			$this->debug_log('Item Number: '.$cart_item_data_num,true);
			$this->debug_log('Item Name: '.$cart_item_data_name,true);
			$this->debug_log('Item Quantity: '.$cart_item_data_quantity,true);
			$this->debug_log('Item Price: '.$cart_item_data_total,true);
			$this->debug_log('Item Shipping: '.$cart_item_shipping,true);
			$this->debug_log('Item Currency: '.$cart_item_data_currency,true);

			// Compare the values with the values stored in the database
			$key=$cart_item_data_num;
			$retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$key'", OBJECT);
			if(!$retrieved_product)
			{
                $error_msg .= 'Request received for product ID: '.$cart_item_data_num.'. Could not find this Product ID in the product database (please check the manage products menu and verify that you have specified the correct product ID).';
		    	$this->debug_log($error_msg,false);
         		return false;				
			}
			$coupon_code = $customvariables['coupon'];
			if(!empty($coupon_code))
			{
                $this->debug_log('Coupon Code Used : '.$coupon_code,true);
                $coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
                $ret_coupon = $wpdb->get_row("SELECT * FROM $coupon_table_name WHERE coupon_code = '$coupon_code'", OBJECT);
                if ($ret_coupon)
                {
                    $discount_amount = $ret_coupon->discount_value;
                    $discount_type = $ret_coupon->discount_type;
                    if ($discount_type == 0)
                    {
                        //apply % discount
                        $discount = ($retrieved_product->price*$discount_amount)/100;
                        $true_product_price = $retrieved_product->price - $discount;
                    }
                    else
                    {
                        // apply value discount
                        $true_product_price = $retrieved_product->price - $discount_amount;
                    }
                }
            }
            else
            {
            	if(is_numeric($retrieved_product->price))
                	$true_product_price = $retrieved_product->price*$cart_item_data_quantity;
                else
                 	$true_product_price = 0;//most likely a subscription button
            }
            $true_product_price = round($true_product_price, 2);
			if ($cart_item_data_total < $true_product_price)
			{
                $error_msg .= 'Wrong Product Price Detected! Actual Product Price : '.$true_product_price.' Amount Paid: '.$cart_item_data_total;
		    	$this->debug_log($error_msg,false);
         		return false;
			}
			
			if(!empty($retrieved_product->currency_code))
			    $payment_currency = $retrieved_product->currency_code;
			if ($payment_currency != $cart_item_data_currency)
			{
                $error_msg .= 'Invalid Product Currency Used: '.$cart_item_data_currency;
		    	$this->debug_log($error_msg,false);
         		return false;
			}

		    //*** Handle Membership Payment ***
		    $member_ref = $retrieved_product->ref_text;
		    if (!empty($member_ref))
		    {
		    	if ($transaction_type == "web_accept")
		    	{
			    if (get_option('eStore_enable_wishlist_int'))
			    {
                                $this->debug_log('WishList integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
			        wl_handle_subsc_signup($this->ipn_data,$member_ref,$this->ipn_data['txn_id']);
                            }
                            else
                            {
    		                if (function_exists('wp_eMember_install'))
    		                {
                                    $this->debug_log('eMember integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
    		                    eMember_handle_subsc_signup($this->ipn_data,$member_ref,$this->ipn_data['txn_id'],$eMember_id);
                                }
                            }
		    	}
		    	else if($transaction_type == "cart")
		    	{
			    if (get_option('eStore_enable_wishlist_int'))
			    {
                                $this->debug_log('WishList integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
			        wl_handle_subsc_signup($this->ipn_data,$member_ref,$this->ipn_data['txn_id']);
                            }
                            else
                            {
    		                if (function_exists('wp_eMember_install'))
    		                {
                                    $this->debug_log('eMember integration is being used... creating member account... see the "subscription_handle_debug.log" file for details',true);
    		                    eMember_handle_subsc_signup($this->ipn_data,$member_ref,$this->ipn_data['txn_id'],$eMember_id);
                                }
                            }
		    	} 		    	
		    }
		    //== End of Membership payment handling ==

		    $product_id = $retrieved_product->id;
		    
		    //Check if nextgen gallery integration is being used
		    $pid_check_value = eStore_is_ngg_pid_present($cart_item_data_name);
		    if($pid_check_value != -1)
		    {
		    	$pictureID = $pid_check_value;
		    }
		    //Generate link from Nextgen gallery if PID is present.
		    if(!empty($pictureID))
		    {
		    	$download_link = eStore_get_ngg_image_url($pictureID,$cart_item_data_name);
		    	$pictureID = "";
		    }
		    else
		    {
            	$download_link = generate_download_link($retrieved_product,$cart_item_data_name,$this->ipn_data);
		    }
		    $this->debug_log('Download Link : '.$download_link,true);
    
		    if(!empty($retrieved_product->item_spec_instruction))
            {
            	$product_specific_instructions .= "\n".$retrieved_product->item_spec_instruction;
            }            

            //Product license key generation if using the license manager
            if (function_exists('wp_lic_manager_install'))
            {
	            $product_license_data .= eStore_check_and_generate_license_key($retrieved_product,$this->ipn_data);
	            $this->debug_log('License Data...'.$product_license_data,true);
            }
		    
            array_push($product_name_array, $cart_item_data_name);
            array_push($product_id_array, $product_id);
            array_push($product_price_array, $cart_item_data_total);
            array_push($product_qty_array, $cart_item_data_quantity);            
            array_push($download_link_array, $download_link);
            //array_push($attachments_array, $retrieved_product->product_download_url);            
           
            $counter++;
            $download_link = '';
		}

		// How long the download link remain valid (hours)
		$download_url_life = get_option('eStore_download_url_life');

		// Emails
		$notify_email = get_option('eStore_notify_email_address');  // Email which will recive notification of sale (sellers email)

		$download_email = get_option('eStore_download_email_address'); // Email from which the mail wil be sent

		// Success Email Messages (Buyer will receive this email)
		$email_subject = get_option('eStore_buyer_email_subj');
		$email_body = get_option('eStore_buyer_email_body');

		// Notification Email Message (Seller will receive this eamil)
		$notify_subject = get_option('eStore_seller_email_subj');
		$notify_body =  get_option('eStore_seller_email_body');

		// Send the product
        for ($i=0; $i < sizeof($product_name_array); $i++)
        {
            $constructed_products_name .= $product_name_array[$i];
            $constructed_products_name .= ", ";

            $constructed_products_price .= $product_price_array[$i];
            $constructed_products_price .= ", ";

            $constructed_products_id .= $product_id_array[$i];
            $constructed_products_id .= ", ";

            $constructed_products_details .= "\n".$product_name_array[$i]." x ".$product_qty_array[$i]." - ".$currency_symbol.$product_price_array[$i]." (".$payment_currency.")";
            
            $constructed_download_link .= "\n";
            if (is_array($download_link_array[$i]))
            {
            	$package_downloads = $download_link_array[$i];
            	for ($j=0; $j < sizeof($package_downloads); $j++)
            	{
            		$constructed_download_link .= $package_downloads[$j];
            		$constructed_download_link .= "\n";
            	}
            }
            else
            {
            	$constructed_download_link .= $download_link_array[$i];
            }
        }

        $purchase_date = (date ("Y-m-d"));
        $total_purchase_amt = $this->ipn_data['mc_gross'];
        $txn_id = $this->ipn_data['txn_id'];
        
        //receipt counter for incremental receipt number	    
//		$last_records_id = get_option('eStore_custom_receipt_counter');
//		if (empty($last_records_id))
//		{
//			$last_records_id = 0;
//		}
//		$receipt_count = $last_records_id + 1;
//		$txn_id = $receipt_count;
//		update_option('eStore_custom_receipt_counter', $receipt_count);   
        
        $buyer_shipping_info = "\n".$this->ipn_data['address_name'];
        $buyer_shipping_info .= "\n".$this->ipn_data['address_street'];
        $buyer_shipping_info .= "\n".$this->ipn_data['address_city'];
        $buyer_shipping_info .= "\n".$this->ipn_data['address_state']." ".$this->ipn_data['address_zip'];
        $buyer_shipping_info .= "\n".$this->ipn_data['address_country'];      
        $buyer_shipping_info .= "\n".$this->ipn_data['contact_phone'];
        
		$tags = array("{first_name}","{last_name}","{payer_email}","{product_name}","{product_link}","{product_price}","{product_id}","{download_life}","{product_specific_instructions}","{product_details}","{shipping_info}","{license_data}","{purchase_date}","{purchase_amt}","{transaction_id}");
		$vals = array($this->ipn_data['first_name'],$this->ipn_data['last_name'],$this->ipn_data['payer_email'],$constructed_products_name,$constructed_download_link,$constructed_products_price,$constructed_products_id,$download_url_life,$product_specific_instructions,$constructed_products_details,$buyer_shipping_info,$product_license_data,$purchase_date,$total_purchase_amt,$txn_id);

		//$subject = str_replace($tags,$vals,$email_subject);
		$subject = $email_subject;
		$body    = stripslashes(str_replace($tags,$vals,$email_body));		
		$headers = 'From: '.$download_email . "\r\n";
        $attachment = '';

        // Determine if it's a recurring payment
        $recurring_payment = is_paypal_recurring_payment($this->ipn_data);

        if (!$recurring_payment) //Don't send emails for recurring payments
        {
        	if (get_option('eStore_send_buyer_email'))
        	{
	            if (get_option('eStore_use_wp_mail'))
	            {
	                wp_mail($this->ipn_data['payer_email'], $subject, $body, $headers);
	                $this->debug_log('Product Email successfully sent to '.$this->ipn_data['payer_email'].'.',true);
	            }
	            else
	            {
	            	if(@eStore_send_mail($this->ipn_data['payer_email'],$body,$subject,$download_email,$attachment))
	            	{
	            	   	$this->debug_log('Product Email successfully sent to '.$this->ipn_data['payer_email'].'.',true);
	            	}
	            	else
	            	{
	                    $this->debug_log('Error sending product Email to '.$this->ipn_data['payer_email'].'.',false);
	            	}
	            }
        	}
        }
	    // Notify seller
		//$n_subject = str_replace($tags,$vals,$notify_subject);
		$n_subject = $notify_subject;
		$n_body    = str_replace($tags,$vals,$notify_body).
	                  "\n\n------- User Email ----------\n".
	                  $body.
	                  "\n\n------- Paypal Parameters (Only admin will receive this) -----\n".
	                  $this->post_string;
        $n_body = stripslashes($n_body);
        if (!$recurring_payment) //Don't send emails for recurring payments
        {
            if (get_option('eStore_use_wp_mail'))
            {
                wp_mail($notify_email, $n_subject, $n_body);
                $this->debug_log('Notify Email successfully sent to '.$notify_email.'.',true);
            }
            else
            {
        	    if(@eStore_send_mail($notify_email,$n_body,$n_subject,$download_email))
        	    {
             	    $this->debug_log('Notify Email successfully sent to '.$notify_email.'.',true);
                }
                else
        	    {
        	        $this->debug_log('Error sending notify Email to '.$notify_email.'.',false);
        	    }
            }
        }
        // Do Post operations
        if (!$recurring_payment)
        {
            $this->debug_log('Updating Products, Customers, Coupons, Sales Database Tables with Sales Data.',true);
    			
            $firstname = $this->ipn_data['first_name'];
    		$lastname = $this->ipn_data['last_name'];
    		$emailaddress = $this->ipn_data['payer_email'];            
            $address = $wpdb->escape(stripslashes($buyer_shipping_info));
            $phone = $this->ipn_data['contact_phone'];
            $subscr_id = $this->ipn_data['subscr_id'];
                            
            $counter = 0;
    		foreach ($cart_items as $current_cart_item)
    		{
    			$cart_item_data_num = $current_cart_item['item_number'];
    			$cart_item_data_name = $current_cart_item['item_name'];    			
    			$key=$cart_item_data_num;
    			$retrieved_product = $wpdb->get_row("SELECT * FROM $products_table_name WHERE id = '$key'", OBJECT);
                $current_product_id = $cart_item_data_num;
                $cart_item_qty = $current_cart_item['quantity'];
                $sale_price = $current_cart_item['mc_gross'];
    
    			if(empty($cart_item_qty))
    			{
    				$cart_item_qty = 1;
    			}
                if (is_numeric($retrieved_product->available_copies))
                {
                    $new_available_copies = ($retrieved_product->available_copies - $cart_item_qty);
                }
                $new_sales_count = ($retrieved_product->sales_count + $cart_item_qty);
    
                $updatedb = "UPDATE $products_table_name SET available_copies = '$new_available_copies', sales_count = '$new_sales_count' WHERE id='$current_product_id'";
    			$results = $wpdb->query($updatedb);
    			
    			// Update the Customer table
			    $product_name = $wpdb->escape(stripslashes($cart_item_data_name));           			    
                $updatedb = "INSERT INTO $customer_table_name (first_name, last_name, email_address, purchased_product_id,txn_id,date,sale_amount,coupon_code_used,member_username,product_name,address,phone,subscr_id) VALUES ('$firstname', '$lastname','$emailaddress','$current_product_id','$transaction_id','$clientdate','$sale_price','$coupon_code','$eMember_id','$product_name','$address','$phone','$subscr_id')";
    			$results = $wpdb->query($updatedb);
    
    			$updatedb2 = "INSERT INTO $sales_table_name (cust_email, date, time, item_id, sale_price) VALUES ('$emailaddress','$clientdate','$clienttime','$current_product_id','$sale_price')";
    			$results = $wpdb->query($updatedb2);    			
            }
            if(!empty($coupon_code))
            {
            	$coupon_table_name = $wpdb->prefix . "wp_eStore_coupon_tbl";
                $ret_coupon = $wpdb->get_row("SELECT * FROM $coupon_table_name WHERE coupon_code = '$coupon_code'", OBJECT);
                if ($ret_coupon)
                {
                	$redemption_count = $ret_coupon->redemption_count + 1;
    	            $updatedb = "UPDATE $coupon_table_name SET redemption_count = '$redemption_count' WHERE coupon_code='$coupon_code'";
    				$results = $wpdb->query($updatedb);            	
                }        	
            }
            $this->debug_log('Products, Customers, Coupons, Sales Database Tables Updated.',true);

            //Autoresponder signups
            eStore_item_specific_autoresponder_signup($cart_items,$firstname,$lastname,$emailaddress);
			eStore_global_autoresponder_signup($firstname,$lastname,$emailaddress);
        }

        $this->debug_log('Updating Affiliate Database Table with Sales Data if Using the WP Affiliate Platform Plugin.',true);
        if (function_exists('wp_aff_platform_install') || function_exists('wp_aff_award_commission'))
        {
        	//$this->debug_log('WP Affiliate Platform is installed, checking referral details...',true);      	        	
        	$award_commission = true;
        	if(get_option('eStore_aff_one_time_commission'))
        	{
        		if($recurring_payment)
        		{
        			$award_commission = false;
        			$this->debug_log('One time commission option is being used, This is a recurring payment and will not generate affiliate commission.',true);
        		}
        	}        	
        	if($award_commission)
        	{        		
	        	$referrer = $customvariables['ap_id'];
				if (!empty($referrer))
				{
					$this->debug_log('Affiliate Commission may need to be tracked. See the "eStore_post_payment_debug.log" file for more details on commission calculation',true);
					eStore_aff_award_commission($this->ipn_data,$cart_items);
				}
			    else
			    {
			    	$this->debug_log('No Referrer Found. This is not an affiliate sale',true);
			    }
        	}	
        	
        	//Handle auto affiliate account creation if this feature is used
        	eStore_handle_auto_affiliate_account_creation($this->ipn_data);		
        }
		else
		{
			$this->debug_log('Not Using the WP Affiliate Platform Plugin.',true);
		}  

		//Revenue sharing
		$share_revenue = get_option('eStore_aff_enable_revenue_sharing');
		if(!empty($share_revenue))
		{
			eStore_award_author_commission($this->ipn_data,$cart_items);
		}
		
		//POST IPN Data to corresponding scripts if specified in the settings
		$ipn_external_post_url = get_option('eStore_memberwing_ipn_post_url');
		if(!empty($ipn_external_post_url))
		{
			$this->debug_log('Posting IPN data to :'.$ipn_external_post_url,true);
			$retVal = eStore_post_data_using_curl($ipn_external_post_url, $this->ipn_data);
			if($retVal == "NO CURL")
			{
				$this->debug_log('Could not post IPN. CURL library is not installed on this server!',false);
			}
			else
			{
				$this->debug_log('IPN values posted. Return value: '.$retVal,false);
			}
		}
		        
	    return true;
   	}

    function validate_ipn()
    {
      // parse the paypal URL
      $url_parsed=parse_url($this->paypal_url);

      // generate the post string from the _POST vars aswell as load the _POST vars into an arry
      $post_string = '';
      foreach ($_POST as $field=>$value) {
         $this->ipn_data["$field"] = $value;
         $post_string .= $field.'='.urlencode(stripslashes($value)).'&';
      }

      $this->post_string = $post_string;
      $this->debug_log('Post string : '. $this->post_string,true);

      $post_string.="cmd=_notify-validate"; // append ipn command

      // open the connection to paypal
      $fp = fsockopen($url_parsed['host'],"80",$err_num,$err_str,30);
      if(!$fp)
      {
         // could not open the connection.  If loggin is on, the error message
         // will be in the log.
         $this->debug_log('Connection to '.$url_parsed['host']." failed.fsockopen error no. $errnum: $errstr",false);
         return false;

      }
      else
      {
         // Post the data back to paypal
         fputs($fp, "POST $url_parsed[path] HTTP/1.1\r\n");
         fputs($fp, "Host: $url_parsed[host]\r\n");
         fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
         fputs($fp, "Content-length: ".strlen($post_string)."\r\n");
         fputs($fp, "Connection: close\r\n\r\n");
         fputs($fp, $post_string . "\r\n\r\n");

         // loop through the response from the server and append to variable
         while(!feof($fp)) {
            $this->ipn_response .= fgets($fp, 1024);
         }

         fclose($fp); // close connection

         $this->debug_log('Connection to '.$url_parsed['host'].' successfuly completed.',true);
      }

      if (eregi("VERIFIED",$this->ipn_response))
      {
         // Valid IPN transaction.
         $this->debug_log('IPN successfully verified.',true);
         return true;

      }
      else
      {
         // Invalid IPN transaction.  Check the log for details.
         $this->debug_log('IPN validation failed.',false);
         return false;
      }
   }

   function log_ipn_results($success)
   {
      if (!$this->ipn_log) return;  // is logging turned off?

      // Timestamp
      $text = '['.date('m/d/Y g:i A').'] - ';

      // Success or failure being logged?
      if ($success) $text .= "SUCCESS!\n";
      else $text .= 'FAIL: '.$this->last_error."\n";

      // Log the POST variables
      $text .= "IPN POST Vars from Paypal:\n";
      foreach ($this->ipn_data as $key=>$value) {
         $text .= "$key=$value, ";
      }

      // Log the response from the paypal server
      $text .= "\nIPN Response from Paypal Server:\n ".$this->ipn_response;

      // Write to log
      $fp=fopen($this->ipn_log_file,'a');
      fwrite($fp, $text . "\n\n");

      fclose($fp);  // close file
   }

   function debug_log($message,$success,$end=false)
   {

   	  if (!$this->ipn_log) return;  // is logging turned off?

      // Timestamp
      $text = '['.date('m/d/Y g:i A').'] - '.(($success)?'SUCCESS :':'FAILURE :').$message. "\n";

      if ($end) {
      	$text .= "\n------------------------------------------------------------------\n\n";
      }

      // Write to log
      $fp=fopen($this->ipn_log_file,'a');
      fwrite($fp, $text );
      fclose($fp);  // close file
   }
}

// Start of IPN handling (script execution)

$ipn_handler_instance = new paypal_ipn_handler();

$debug_enabled = get_option('eStore_cart_enable_debug');

if ($debug_enabled)
{
	echo 'Debug is enabled. Check the '.$debug_log.' file for debug output.';
	$ipn_handler_instance->ipn_log = true;
	$ipn_handler_instance->ipn_log_file = $debug_log;
	
	if(empty($_POST))
	{
		$ipn_handler_instance->debug_log('This debug line was generated because you entered the URL of the ipn handling script in the browser.',true,true);
		exit;
	}
}

$sandbox = get_option('eStore_cart_enable_sandbox');

if ($sandbox) // Enable sandbox testing
{
	$ipn_handler_instance->paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
}

$ipn_handler_instance->debug_log('Paypal Class Initiated by '.$_SERVER['REMOTE_ADDR'],true);

// Validate the IPN
if ($ipn_handler_instance->validate_ipn())
{
	$ipn_handler_instance->debug_log('Creating product Information to send.',true);

      if(!$ipn_handler_instance->validate_and_dispatch_product())
      {
          $ipn_handler_instance->debug_log('IPN product validation failed.',false);

          $to_address = get_option('eStore_notify_email_address');
          $subject = "WP eStore - Payment Verification Failed!";
          $body = "Please fully read this email as it will explain everything you need to know to address any issue that maybe occuring (if there are any)!".
          		  "\n\nThe post payment verification for a payment failed. This could happen for one of the following reasons:".
                  "\n\n 1. The fund for the payment have not cleared in PayPal yet (no need to do anything as the digital product will be delivered once the fund clears).".
                  "\n 2. Someone maybe trying to scam a purchase! (no worries... WP eStore got your back :)".
          		  "\n 3. You have made a mistake somewhere (please see the failure reason section below to find out more details about this).".
          		  "\n\n===== Failure reason =====".
          		  "\n".
                  "\nHere are some more details for the exact cause of this transaction failure...\n".$error_msg.
          		  "\n\n===== How to solve the 'Funds have not cleared' or 'Pending payment received' notification =====".
          		  "\n".
          		  "\nIf you have received a pending payment meaning the funds have not cleared for this payment and you don't know the reason then this link should help".
          		  "\nhttp://www.tipsandtricks-hq.com/forum/topic/reasons-for-a-pending-paypal-payment".
          		  "\n\n===== PayPal parameters for this transaction =====".
          		  "\n\n".
          		  $ipn_handler_instance->post_string;

          $from_address = get_option('eStore_download_email_address');
          eStore_send_notification_email($to_address, $subject, $body, $from_address);
      }
}
$ipn_handler_instance->debug_log('Paypal class finished.',true,true);

?>
