<?php
function eStore_send_aweber_mail($list_name,$from_address,$cust_name,$cust_email)
{
    $subject = "Aweber Automatic Sign up email";
    $body    = "\n\nThis is an automatic email that is sent to AWeber for member signup purpose\n".
               "\nEmail: ".$cust_email.
               "\nName: ".$cust_name;

	$headers = 'From: '.$from_address . "\r\n";
    wp_mail($list_name, $subject, $body, $headers);
}

function eStore_send_notification_email($to_address, $subject, $body, $from_address, $attachment='')
{
    if (get_option('eStore_use_wp_mail'))
    {
        $headers = 'From: '.$from_address . "\r\n";
        wp_mail($to_address, $subject, $body, $headers);
        return true;
    }
    else
    {
       	if(@eStore_send_mail($to_address,$body,$subject,$from_address,$attachment))
       	{
            return true;
       	}
       	else
       	{
            return false;
       	}
    }
}
?>
