<?php
/*
WP eStore plugin Srpski Language File
*/
//Product Display
define("ESTORE_AVAILABLE_QTY", "Dostupna količina");

//Shopping Cart
define("ESTORE_ITEM_NAME", "Artikal");
define("ESTORE_QUANTITY", "Količina");
define("ESTORE_PRICE", "Cena");
define("ESTORE_TOTAL", "Zbir");
define("ESTORE_SUB_TOTAL", "Međuzbir");
define("ESTORE_SHIPPING", "Isporuka");
define("ESTORE_REMOVE_ITEM", "Uklonite artikal");
define("ESTORE_EMPTY_CART", "Prazna korpa");

define("ESTORE_ENTER_COUPON_CODE", "Unesite šifru za popust:");
define("ESTORE_APPLY", "Pošaljite");

define("ESTORE_TERMS_AND_CONDITIONS", "Uslovi kupovine");
define("ESTORE_TERMS_AGREE", " Prihvatam ");
define("ESTORE_TERMS_ERROR", "Morate da prihvatite uslove kupovine");

define("ESTORE_CONTINUE_SHOPPING", "Nastavak kupovine");

define("ESTORE_PAYMENT_METHOD", "Metod plaćanja: ");
define("ESTORE_PAYPAL", "PayPal");
define("ESTORE_MANUAL", "Faktura");
define("ESTORE_TWO_CO", "2Checkout");
define("ESTORE_AUTHORIZE", "Authorize.net");

define("ESTORE_COUPON_NOT_ACTIVE", "Šifra je nevažeća");
define("ESTORE_MAX_COUPON_USE", "Maksimalan popust je već obračunat");
define("ESTORE_TOTAL_DISCOUNT", "Obračunat je ukupan popust od: ");
define("ESTORE_COUPON_INVALID", "Šifra je nevažeća");
define("ESTORE_DISCOUNT_LIMIT", "Popust je već obračunat");
define("ESTORE_COUPON_COND_NOT_MET", "U korpi nema minimum stavki za ovaj popust");
define("ESTORE_DISCOUNT_FREE_SHIPPING", "Besplatna isporuka");

define("ESTORE_QUANTITY_CHANGE", "Pritisnite Enter da potvrdite novu količinu");
define("ESTORE_QUANTITY_CHANGE_NOT_ALLOWED", "Promena količine će uticati na obračunavanje popusta");
define("ESTORE_QUANTITY_LIMIT_EXCEEDED", "Unesena količina nije dostupna");

define("ESTORE_ITEM_ADDED", "Artikal je dodat u korpu");
define("ESTORE_ITEM_DELETED", "Artikal je izbačen iz korpe");
define("ESTORE_QTY_UPDATED", "Količina je ažurirana");

define("ESTORE_CART_EMPTY", "Korpa je prazna");
define("ESTORE_VISIT_THE_SHOP", "Posetite prodavnicu");

define("ESTORE_DOWNLOAD_TEXT", "Skidanje");

define("ESTORE_FILL_IN_SHIPPING_DETAILS", "Molimo vas da popunite sledeće podatke i kliknete na Potvrđujem narudžbinu");
define("ESTORE_FIRST_NAME", "Ime");
define("ESTORE_LAST_NAME", "Prezime");
define("ESTORE_ADDRESS", "Adresa");
define("ESTORE_CITY", "Grad");
define("ESTORE_STATE", "Mesto");
define("ESTORE_POSTCODE", "Poštanski broj");
define("ESTORE_COUNTRY", "Država");
define("ESTORE_PHONE", "Telefon");
define("ESTORE_EMAIL", "E-pošta");
define("ESTORE_ADDITIONAL_COMMENT", "Dodatna uputstva za isporuku");
define("ESTORE_CONFIRM_ORDER", "Potvrđujem narudžbinu");
define("ESTORE_COLLECT_DETAILS", "Obrada podataka...");
define("ESTORE_ORDER_COMPLETE", "Narudžbina je poslata");
define("ESTORE_REQUIRED_FIELDS_MISSING", "Sledeći obavezni podaci nedostaju:");

define("ESTORE_ENTER_AFFILIATE_ID", "Šifra prodajnog mesta: ");
define("ESTORE_AFFILIATE_ID_SET", "Šifra je potvrđena");
define("ESTORE_AFFILIATE_PLUGIN_INACTIVE", "Dodatak nije aktivan");

define("ESTORE_PENDING_PAYMENT_EMAIL_SUBJECT", "Čeka se plaćanje");
define("ESTORE_PENDING_PAYMENT_EMAIL_BODY", "Hvala na kupovini. Isporuka će biti obavljena kada primimo plaćanje.");

define("ESTORE_ITEM_IN_THE_CART", " Artikli u korpi");
define("ESTORE_ITEMS_IN_THE_CART", " Artikli u korpi");
define("ESTORE_VIEW_CART", " Pogledajte korpu");

define("ESTORE_YOU_MUST_BE_LOGGED", "Morate biti prijavljeni");
define("ESTORE_NO_PURCHASE_FOUND", "Nema prethodnih kupovina");
define("ESTORE_PRODUCT_ID", "Šifra artikla");
define("ESTORE_PRODUCT_NAME", "Naziv artikla");
define("ESTORE_TRANSACTION_ID", "Broj narudžbine");
define("ESTORE_EMAIL_ADDRESS", "Adresa e-pošte");
define("ESTORE_DATE", "Datum kupovine");
define("ESTORE_PRICE_PAID", "Cena");

define("WP_ESTORE_NO_COPIES_LEFT", "Rasprodato");

define("WP_ESTORE_DETAILS_OF_ORDERED_PRODUCT", "Detalji o naručenom proizvodu");
define("WP_ESTORE_TOTAL_ITEMS_ORDERED", "Ukupna količina");
define("WP_ESTORE_CUSTOMER_DETAILS", "Podaci o kupcu");
define("WP_ESTORE_NAME", "Ime");
define("WP_ESTORE_ADDITIONAL_COMMENT", "Dodatni komentar");
define("WP_ESTORE_REFERRER", "Preporučilac");

define("WP_ESTORE_PROCESSING_ORDER", "Narudžbina se obrađuje...");
define("WP_ESTORE_ORDER_BEING_PROCESSED", "Molimo sačekajte... Uskoro ćete biti prebačeni na stranu za plaćanje");
define("WP_ESTORE_NOT_AUTO_REDIRECT", "Ako ne budete prebačeni na stranu za plaćanje za 5 sekundi...");
define("WP_ESTORE_CLICK_HERE", "Kliknite ovde");

define("WP_ESTORE_THIS_ITEM_DOES_NOT_HAVE_DOWNLOAD", " - Ovaj proizvod se ne može isporučiti elektronski");
define("WP_ESTORE_YOU_WILL_SOON_RECEIVE_EMAIL", "Uskoro ćete dobiti e-poštu sa računom i uputstvima ");
define("WP_ESTORE_TOTAL_COST", "Ukupna suma narudžbine");

define("WP_ESTORE_ORDER_SUMMARY", "Pregled vaše narudžbine");
define("WP_ESTORE_DESCRIPTION", "Opis");
define("WP_ESTORE_TAX", "PDV");

define("WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_SUBJECT", "Promenjena kategorija članstva");
define("WP_ESTORE_EMEMBER_ACCOUNT_UPGRADE_BODY", "Uspešno je promenjena kategorija vašeg članstva");

define("WP_ESTORE_YOUR_PRICE", "Vaša cena");
define("WP_ESTORE_MINIMUM_PRICE_YOU_CAN_ENTER", "Minimalna vrednost je ");

define("WP_ESTORE_BUY_NOW", "Kupi");
define("WP_ESTORE_SUBSCRIBE", "Pretplati se");

define("WP_ESTORE_NAME_OR_EMAIL_MISSING", "<p style='color: red;'><strong>Nedostaju ime ili adresa e-pošte.</strong></p>");
define("WP_ESTORE_EMAIL_SENT", "<p style='color: green;'><strong>E-pošta je poslata.</strong></p>");
define("WP_ESTORE_REQUIRED_FIELD", "Ovo polje je obavezno.");

define("WP_ESTORE_YOUR_ORDER", "Naručili ste sledeće artikle: ");

define("ESTORE_SHIPPING_VARIATION", "Izbor metoda isporuke");  
define("ESTORE_CLICK_UPDATE_BUTTON", "Potvrdite pritiskom na dugme za ažuriranje.");  

define("ESTORE_FREE_DOWNLOAD_SUBJECT", "Veza za skidanje");  
define("ESTORE_DEAR", "Poštovani");
define("ESTORE_FREE_DOWNLOAD_EMAIL_BODY", "Ovo je veza za skidanje elektronskog sadržaja: ");
define("ESTORE_THANK_YOU", "Hvala");

define("ESTORE_OLD_PRICE", "Cena");
define("ESTORE_GENERATE_DOWNLOAD", "Napravite vezu za skidanje");
define("ESTORE_UPDATE", "Ažurirajte");

define("ESTORE_FIRST", "Ime");
define("ESTORE_LAST", "Prezime");

define("ESTORE_ITEM_ALREADY_EXISTS", "Artikal je već u korpi");
define("ESTORE_ITEM_LIMIT_EXCEEDED", "Premašena maksimalno dozvoljena količina artikla!");
define("ESTORE_CART_QTY_LIMIT_EXCEEDED", "Premašena maksimalno dozvoljena količina artikala u korpi! Maksimum je ");

define("ESTORE_CART_DOES_NOT_MEET_MIN_REQUIREMENT", "Niste kupili minimum neophodan za obradu narudžbine ");
define("ESTORE_CART_MINIMUM_CHECKOUT_AMOUNT_REQUIRED", "<br />Minimalna suma za naručivanje je: ");
define("ESTORE_CART_MAXIMUM_CHECKOUT_AMOUNT_REQUIRED", "<br />Maksimalna suma za naručivanje je: ");

define("ESTORE_ITEM_SOLD_OUT", "Ovaj artikal je rasprodat");
define("ESTORE_SOLD_OUT", "RASPRODATO");

define("ESTORE_PART", "Deo");

define("ESTORE_PROCESSING_REQUEST", "Vaš zahtev se obrađuje...");
define("ESTORE_WRONG_SHOPPING_CART_ID", "Neispravana šifra korpe");
define("ESTORE_SHOPPING_CART_SAVED", "Korpa je sačuvana ");
define("ESTORE_SHOPPING_CART_ID", "Šifra korpe");
define("ESTORE_SAVE", "Sačuvajte");
define("ESTORE_RETRIEVE", "Pozovite");
define("ESTORE_SUCCESS", "Uspeh");

define("ESTORE_ENTER_A_NUMBER_FOR_QTY", "Upišite količinu");
define("ESTORE_CART", "Korpa");

define("ESTORE_AUTORESPONDER_CONFIRM_SUBSCRIPTION", "<p style='color: green;'>E-pošta vam je poslata. Morate potvrditi prijem.</p>");

define("WP_ESTORE_CLICK_HERE_TO_DOWNLOAD", "Kliknite ovde da skinete elektronski sadržaj");
define("WP_ESTORE_SERIAL_KEY_IS_YET_TO_BE_CREATED", "Ova narudžbina čeka na obradu. Čim se obrada završi dobićete e-poštu.");
define("WP_ESTORE_REGO_URL_IS_YET_TO_BE_CREATED", "Registracija čeka na obradu. Čim se obrada završi dobićete e-poštu.");
define("WP_ESTORE_CLICK_HERE_TO_COMPLETE_REGO", "Kliknite ovde da završite sa registracijom");

define("WP_ESTORE_SELECT_SHIPPING_OPTION_TO_CALC_SHIPPING", "Izaberite metod isporuke");

define("ESTORE_CART_IS_EMPTY", "Korpa je prazna");
define("WP_ESTORE_DONATE", "Dajte dobrovoljni prilog");
define("WP_ESTORE_IMAGE_VERIFICATION_FAILED", "Neuspešna provera. Pokušajte ponovo");
define("WP_ESTORE_EMAIL_INVALID", "Neispravna adresa e-pošte");
define("WP_ESTORE_GO_TO_PAGE", "Idite na stranu: ");

define("WP_ESTORE_PRODUCT_SEARCH", "Pretraga proizvoda");
define("WP_ESTORE_ENTER_SEARCH_KEYWORD", "Unesite ključnu reč");
define("WP_ESTORE_SEARCH_NO_PRODUCTS_FOUND", "Nema traženih proizvoda");

define("WP_ESTORE_LINK_SENDER_EMAIL_SENT", "Veza za skidanje vam je poslata na: ");

define("WP_ESTORE_STORE_PICKUP_LABEL", "Želim da lično podignem robu");
define("WP_ESTORE_STORE_PICKUP_SELECTED", "Nema troškova isporuke pošto ste izabrali da podignete robu lično");

define('ESTORE_DLVS_HI1', 'Program za bezbednu isporuku elektronskog sadržaja je naišao na problem i ne može vam isporučiti narudžbinu.');
define('ESTORE_DLVS_CP1', 'Molimo vas da kontaktirate administratora.');
define('ESTORE_DLVS_TA1', 'Molimo vas da administratoru kažete da je problem u sledećem:');
define('ESTORE_DLVS_TU1', 'Problem je u sledećem:');
define('ESTORE_DLVS_IR1', 'A valid download request (query string) wasn&rsquo;t specified, as part of the link used.&nbsp;&nbsp;Please check the correctness of the download link used, and try again.&nbsp;&nbsp;Sometimes links sent by email get mangled by the email client, or you did not correctly copy the complete link.');
define('ESTORE_DLVS_LCT', 'The download link (see browser address bar) has been used too many times.&nbsp;If you think this reason is in error, please contact the site administrator.');
define('ESTORE_DLVS_LDB', 'The download link (see browser address bar) couldn&rsquo;t be found in the wp_eStore database.');
define('ESTORE_DLVS_LEX', 'The download link (see browser address bar) has expired (it&rsquo;s too old).&nbsp;&nbsp;If you think this reason is in error, please contact the site administrator.');
define('ESTORE_DLVS_PID', 'The product ID contained in the download link (see browser address bar) doesn&rsquo;t seem to be in the wp_eStore database.  You might have a download link for a product that is no longer stocked.&nbsp;&nbsp;If you think this reason is in error, please contact the site administrator.');
define('ESTORE_DLVS_APM', 'The digital product associated with the download link (see browser address bar) contains a malformed Authenticated Page Redirect (APR) URI.');
define('ESTORE_DLVS_APC', 'There is a compatability mismatch between the download script and the APRTP class library.&nbsp;&nbsp;The administrator might&rsquo;ve performed an incomplete upgrade of the wp_eStore plugin.');
define('ESTORE_DLVS_S3M', 'The digital product associated with the download link (see browser address bar) contains a malformed Amazon S3 URI.&nbsp;&nbsp;The administrator should specifically ensure that bucket names are in compliance with Amazon&rsquo;s bucket naming restrictions.i&nbsp;&nbsp;The most common mistake would be if the administrator used any upper case letters or space characters in the bucket name.');
define('ESTORE_DLVS_S3C', 'There is a compatability mismatch between the download script and the AS3TP class library.&nbsp;&nbsp;The administrator might&rsquo;ve performed an incomplete upgrade of the wp_eStore plugin.');
define('ESTORE_DLVS_FNF', 'The download script couldn&rsquo;t locate the file associated with the digital product.  If the administrator thinks this reason is in error, maybe a different URL conversion option might fix the problem.');
define('ESTORE_DLVS_OPN', 'The file (on the server) containing your download couldn&rsquo;t be opened.');
define('ESTORE_DLVS_FQN', 'The cURL library can only process fully qualified URL.&nbsp;&nbsp;Ensure that the URL conversion option is set for "Do Not Convert," and that fully qualified URL are used in the product database.');
define('ESTORE_DLVS_CNI', 'The cURL library isn&rsquo;t installed on this server.');
define('ESTORE_DLVS_CSI', 'A cURL session couldn&rsquo;t be initialized.');
define('ESTORE_DLVS_CPT', 'Unable to set cURL transfer options.');

?>