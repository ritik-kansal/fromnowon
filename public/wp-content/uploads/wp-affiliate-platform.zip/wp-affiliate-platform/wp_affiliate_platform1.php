<?php
/********************************************
***       THIS IS NOT A FREE PLUGIN       ***
*** DO NOT COPY ANY CODE FROM THIS PLUGIN ***
*********************************************/
if(!isset($_SESSION)) 
{
	session_start();
}

$siteurl = get_bloginfo('wpurl');
define('WP_AFF_PLATFORM_FOLDER', dirname(plugin_basename(__FILE__)));

$wp_aff_platform_url = WP_PLUGIN_URL.'/'.WP_AFF_PLATFORM_FOLDER;
if ($_SERVER["HTTPS"] == "on")
{
	$wp_aff_platform_url = str_replace("http:","https:",$wp_aff_platform_url);
}
define('WP_AFF_PLATFORM_URL', $wp_aff_platform_url);
define('WP_AFF_DATE_CSS_URL', WP_AFF_PLATFORM_URL.'/lib/date/dhtmlxcalendar.css');
define('WP_AFF_COM_JS_URL', WP_AFF_PLATFORM_URL.'/lib/date/dhtmlxcommon.js');
define('WP_AFF_CAL_JS_URL', WP_AFF_PLATFORM_URL.'/lib/date/dhtmlxcalendar.js');
define('WP_AFF_DATE_IMG_URL', WP_AFF_PLATFORM_URL.'/lib/date/codebase/imgs/');

define('WP_AFF_CLICKS_TBL_NAME', $wpdb->prefix . "affiliates_clickthroughs_tbl");
define('WP_AFF_AFFILIATES_TBL_NAME', $wpdb->prefix . "affiliates_tbl");
define('WP_AFF_SALES_TBL_NAME', $wpdb->prefix . "affiliates_sales_tbl");
define('WP_AFF_PAYOUTS_TBL_NAME', $wpdb->prefix . "affiliates_payouts_tbl");
define('WP_AFF_BANNERS_TBL_NAME', $wpdb->prefix . "affiliates_banners_tbl");
define('WP_AFF_LEAD_CAPTURE_TBL_NAME', $wpdb->prefix . "affiliates_leads_tbl");

$aff_language = get_option('wp_aff_language');
if (!empty($aff_language))
	$language_file = "affiliates/lang/".$aff_language;
else
	$language_file = "affiliates/lang/eng.php";
include_once($language_file);

include_once('wp_aff_includes.php');
include_once('wp_affiliate_login_widget.php');
include_once('affiliate_platform_affiliate_view.php');

/*** clickbank commission award ***/
if(isset($_REQUEST['cname']) && isset($_REQUEST['cprice']))
{	
	$aff_id = wp_affiliate_get_referrer();
	if(!empty($aff_id))
	{
		$sale_amt = $_REQUEST['cprice'];
		$txn_id = $_REQUEST['cbreceipt'];
		$item_id = $_REQUEST['item'];
		$buyer_email = $_REQUEST['cemail'];		
		wp_aff_award_commission($aff_id,$sale_amt,$txn_id,$item_id,$buyer_email);		
	}
}

/*** PDT Stuff for PayPal transaction commission awarding ***/
if(isset($_GET['tx']) && isset($_GET['amt']))
{
	$auth_token = get_option('wp_aff_pdt_identity_token');	
	if (get_option('wp_aff_enable_3rd_party') != '' && !empty($auth_token))
	{
		//Process PDT to award commission
		$_SESSION['aff_tx_result_error_msg'] = "";
		$req = 'cmd=_notify-synch';
		$tx_token = $_GET['tx'];	
		$req .= "&tx=$tx_token&at=$auth_token";	
		
		// post back to PayPal system to validate
		$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
		
		$sandbox_enabled = get_option('wp_aff_sandbox_mode');
		if($sandbox_enabled != '')
		{
			$host_url = 'www.sandbox.paypal.com';
		}
		else
		{
			$host_url = 'www.paypal.com';
		}	
		$fp = fsockopen ($host_url, 80, $errno, $errstr, 30);
		// If possible, securely post back to paypal using HTTPS
		// Your PHP server will need to be SSL enabled
		// $fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);
		
		if (!$fp) 
		{
			echo "<br />Error! HTTP ERROR... could not establish a connection to PayPal for verification!";
			return;
		} 
		else 
		{
			fputs ($fp, $header . $req);
			// read the body data
			$res = '';
			$headerdone = false;
			while (!feof($fp)) 
			{
				$line = fgets ($fp, 1024);
				if (strcmp($line, "\r\n") == 0) 
				{
					// read the header
					$headerdone = true;
				}
				else if ($headerdone)
				{
					// header has been read. now read the contents
					$res .= $line;
				}
			}		
			// parse the data
			$lines = explode("\n", $res);
			$keyarray = array();
			if (strcmp ($lines[0], "SUCCESS") == 0) 
			{
				for ($i=1; $i<count($lines);$i++)
				{
					list($key,$val) = explode("=", $lines[$i]);
					$keyarray[urldecode($key)] = urldecode($val);
				}
			}
			else if (strcmp ($lines[0], "FAIL") == 0) 
			{
				echo "<br />Error! PDT verification failed! Could not verify the authenticity of the payment with PayPal!";
				return;
			}	
		}		
		fclose ($fp);	
		global $wpdb;
		$aff_sales_table = WP_AFF_SALES_TBL_NAME;
		$txn_id = $keyarray['txn_id'];
		$resultset = $wpdb->get_results("SELECT * FROM $aff_sales_table WHERE txn_id = '$txn_id'", OBJECT);
		if($resultset){
			//Commission for this transaction has already been awarded so no need to do anything.
		}
		else{
			wp_aff_process_PDT_payment_data($keyarray);
		}
	}
}

/* Affiliate View Option 2 POST Data processing */
if (isset($_POST['wpAffDoLogin']))
{
    if ($_POST['userid']!='' && $_POST['password']!='')
    {			    	
        // protection against script injection
        $userid = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['userid']);
        $password = $_POST['password'];

        global $wpdb;
        $affiliates_table_name = WP_AFF_AFFILIATES_TBL_NAME;
        $result = $wpdb->get_results("SELECT refid FROM $affiliates_table_name where refid='$userid' and pass='$password'", OBJECT);

        if ($result)
        {
    	    // this sets variables in the session
    		$_SESSION['user_id']= $userid;

    		//set a cookie witout expiry until 60 days
    	    if(isset($_POST['remember']))
            {
    		    setcookie("user_id", $_SESSION['user_id'], time()+60*60*24*60, "/");
    		}
    		
    		$target_url= wp_aff_view_get_url_with_separator("members_only");
    		header("Location: ".$target_url);
    		exit;
        }
    	else
    	{
    		$msg = urlencode("Invalid Login. Please try again with correct user name and password. ");
    		$target_url = wp_aff_view_get_url_with_separator("login&msg=".$msg);
    		header("Location: ".$target_url);
    		exit;
    	}
    }
}
if(isset($_GET['wp_affiliate_view']) && $_GET['wp_affiliate_view']=='logout')
{
	/*** Delete the cookies and unset the session data ***/
	unset($_SESSION['user_id']);	
	setcookie("user_id", '', time()-60*60*24*60, "/");
}
/* End of Affiliate View Option 2 POST Data processing */
	
function wp_aff_award_custom_commission_handler($atts) 
{
	$sale_amount = "0"; //Commission will be calcualted based off this amount
	$txn_id = "A unique transaction id"; //can be anything
	$item_id = "Id of this item for identification"; //can be anything
	$buyer_email = "email address of the buyer";
	
	    
	if (!empty($_SESSION['ap_id']))
	{
	    $referrer = $_SESSION['ap_id'];
	}
	else if (isset($_COOKIE['ap_id']))
	{
	    $referrer = $_COOKIE['ap_id'];
	}
	
	if (!empty($referrer))
	{
	    wp_aff_award_commission($referrer,$sale_amount,$txn_id,$item_id,$buyer_email);
	}
	else
	{
	    //Not an affiliate conversion
	}	
	return "";
}

function wp_aff_login_handler($atts)
{
	return aff_login_widget();
}

if(isset($_POST['mc_gross']))
{
	if(get_option('wp_aff_enable_3rd_party'))
	{
		verify_payment_data();
	}
}
function filter_wp_aff_tx_result($content)
{
    $pattern = '#\[wp_aff_transaction_result:end]#';
    preg_match_all ($pattern, $content, $matches);
    foreach ($matches[0] as $match)
    {
		$replacement = wp_aff_display_transaction_result();
		$content = str_replace ($match, $replacement, $content);
    }
    return $content;	
}

function aff_get_cookie_life_time()
{
    $cookie_expiry = get_option('wp_aff_cookie_life');
    if(!empty($cookie_expiry))
    {
        $cookie_life_time = time() + $cookie_expiry*86400;
    }
    else
    {
        $cookie_life_time =  time() + 30*86400;
    }	
    return $cookie_life_time;
}
/*Common stripping to avoid any type of hack*/
if(isset($_GET['ap_id']))
{
	$referrer_id=trim(strip_tags($_GET['ap_id']));
	if(strlen($referrer_id) > 0 )
	{
		$campaign_id = $_GET['c_id'];
		record_click($referrer_id,$campaign_id);
	}
	//wp_aff_redirect_to_non_affiliate_url();
}

function record_click($referrer_id,$campaign_id='')
{
	global $wpdb;
	$cookie_life_time = aff_get_cookie_life_time();

	$domain_url = $_SERVER['SERVER_NAME'];
	$cookie_domain = str_replace("www","",$domain_url);    
    setcookie('ap_id',$referrer_id,$cookie_life_time,"/",$cookie_domain);
    if(!empty($campaign_id)){
    	setcookie('c_id',$campaign_id,$cookie_life_time,"/",$cookie_domain);
    }

    $_SESSION['ap_id'] = $referrer_id;
    if(!empty($campaign_id)){
    	$_SESSION['c_id'] = $campaign_id;
    }

    $clientdate = (date ("Y-m-d"));
    $clienttime = (date ("H:i:s"));
    $clientbrowser = $_SERVER['HTTP_USER_AGENT'];
    $clientip = $_SERVER['REMOTE_ADDR'];
    $clienturl = $_SERVER['HTTP_REFERER'];
    $current_page = wp_aff_current_page_url();
    
    // Ignore bots and wordpress trackbacks
    if(strpos($clientbrowser,"WordPress")!== false || strpos($clientbrowser,"bot")!== false || strpos($current_page,"?secret=")!== false)
    {
    	return;
    }
    
    $e_refid = $wpdb->escape($referrer_id);
    $e_date = $wpdb->escape($clientdate);
    $e_time = $wpdb->escape($clienttime);
    $e_browser = $wpdb->escape($clientbrowser);
    $e_ip = $wpdb->escape($clientip);
    $e_url = $wpdb->escape($clienturl);  

	$affiliates_clickthroughs_table_name = WP_AFF_CLICKS_TBL_NAME;
	if($e_url != $current_page)
	{
		if(empty($e_url))
		{	 
			$e_url = $current_page;//"Data unavailable - May be the URL was entered directly in the browser";
		}   	 
		if(wp_aff_true_click())
		{   	
			$updatedb = "INSERT INTO $affiliates_clickthroughs_table_name (refid,date,time,browser,ipaddress,referralurl,buy,campaign_id) VALUES ('$e_refid', '$e_date', '$e_time', '$e_browser', '$e_ip', '$e_url', '','$campaign_id')";
			$results = $wpdb->query($updatedb);
		}
	}
}

function wp_aff_true_click($clientip='')
{
	global $wpdb;
	$affiliates_clickthroughs_table_name = WP_AFF_CLICKS_TBL_NAME;
	
	$cooldown_time_in_unix = mktime(date("H"), date("i"), date("s")-5);
	$cooldown_time = date("H:i:s",$cooldown_time_in_unix);
	$cur_time = date("H:i:s");
	if(empty($clientip))
	{
		$clientip = $_SERVER['REMOTE_ADDR'];
	}	
    $find = $wpdb->get_results("SELECT * FROM $affiliates_clickthroughs_table_name WHERE time between '$cooldown_time' and '$cur_time' and ipaddress='$clientip'", OBJECT);
    if($find)
    {
    	return false;
    }
    //Set the following value to true if you want to track one click per IP address
    $track_unique_clicks = false;
    if($track_unique_clicks)
    {
        $find = $wpdb->get_results("SELECT * FROM $affiliates_clickthroughs_table_name WHERE ipaddress = '$clientip'", OBJECT);
	    if($find)
	    {
	    	return false;
	    }    	
    }
    return true;	
}

function wp_aff_true_sale($clientip='')
{
	global $wpdb;
	$affiliates_sales_table_name = WP_AFF_SALES_TBL_NAME;
	
	$cooldown_time_in_unix = mktime(date("H"), date("i"), date("s")-10);
	$cooldown_time = date("H:i:s",$cooldown_time_in_unix);
	$cur_time = date("H:i:s");
	if(empty($clientip))
	{
		$clientip = $_SERVER['REMOTE_ADDR'];
	}	
    $find = $wpdb->get_results("SELECT * FROM $affiliates_sales_table_name WHERE time between '$cooldown_time' and '$cur_time' and ipaddress='$clientip'", OBJECT);
    if($find)
    {
    	return false;
    }
    return true;	
}
function wp_aff_record_remote_click($referrer_id,$clientbrowser,$clientip,$clienturl,$campaign_id='')
{
	global $wpdb;
	$affiliates_clickthroughs_table_name = WP_AFF_CLICKS_TBL_NAME;
	
    $clientdate = (date ("Y-m-d"));
    $clienttime = (date ("H:i:s"));
    
    // Ignore bots and wordpress trackbacks
    if(strpos($clientbrowser,"WordPress")!== false || strpos($clientbrowser,"bot")!== false)
    {
    	return;
    }
    
    $e_refid = $wpdb->escape($referrer_id);
    $e_date = $wpdb->escape($clientdate);
    $e_time = $wpdb->escape($clienttime);
    $e_browser = $wpdb->escape($clientbrowser);
    $e_ip = $wpdb->escape($clientip);
    $e_url = $wpdb->escape($clienturl);
 
	if(wp_aff_true_click())
	{   	
		$updatedb = "INSERT INTO $affiliates_clickthroughs_table_name (refid,date,time,browser,ipaddress,referralurl,buy,campaign_id) VALUES ('$e_refid', '$e_date', '$e_time', '$e_browser', '$e_ip', '$e_url', '','$campaign_id')";
		$results = $wpdb->query($updatedb);
	}
}

function record_click_for_eStore_cart($referrer_id)
{
	global $wpdb;
    $cookie_life_time = aff_get_cookie_life_time();
    
	$domain_url = $_SERVER['SERVER_NAME'];
	$cookie_domain = str_replace("www","",$domain_url);    
    setcookie('ap_id',$referrer_id,$cookie_life_time,"/",$cookie_domain);

    $_SESSION['ap_id'] = $referrer_id;

    $campaign_id = '';
    $clientdate = (date ("Y-m-d"));
    $clienttime = (date ("H:i:s"));
    $clientbrowser = $_SERVER['HTTP_USER_AGENT'];
    $clientip = $_SERVER['REMOTE_ADDR'];
    $clienturl = $_SERVER['HTTP_REFERER'];
    
    $e_refid = $wpdb->escape($referrer_id);
    $e_date = $wpdb->escape($clientdate);
    $e_time = $wpdb->escape($clienttime);
    $e_browser = $wpdb->escape($clientbrowser);
    $e_ip = $wpdb->escape($clientip);
    $e_url = $wpdb->escape($clienturl);
    $current_page = wp_aff_current_page_url();

	$affiliates_clickthroughs_table_name = WP_AFF_CLICKS_TBL_NAME;
 	$updatedb = "INSERT INTO $affiliates_clickthroughs_table_name (refid,date,time,browser,ipaddress,referralurl,buy,campaign_id) VALUES ('$e_refid', '$e_date', '$e_time', '$e_browser', '$e_ip', '$e_url', '','$campaign_id')";
	$results = $wpdb->query($updatedb);
}

function wp_aff_record_remote_lead($referrer_id,$buyer_email,$reference,$clientip,$clientbrowser='')
{
	global $wpdb;
	$affiliates_leads_table_name = WP_AFF_LEAD_CAPTURE_TBL_NAME;	
    $clientdate = (date ("Y-m-d"));
    $clienttime = (date ("H:i:s"));
    
    // Ignore bots and wordpress trackbacks
    if(strpos($clientbrowser,"WordPress")!== false || strpos($clientbrowser,"bot")!== false)
    {
    	return;
    }    
    $referrer = $wpdb->escape($referrer_id);
    $buyer_email = $wpdb->escape($buyer_email);
    $reference = $wpdb->escape($reference);    
    $clientdate = $wpdb->escape($clientdate);
    $clienttime = $wpdb->escape($clienttime);
    $ipaddress = $wpdb->escape($clientip);
 
	$updatedb = "INSERT INTO $affiliates_leads_table_name (buyer_email,refid,reference,date,time,ipaddress) VALUES ('$buyer_email','$referrer','$reference','$clientdate','$clienttime','$ipaddress')";
	$results = $wpdb->query($updatedb);		
}

function wp_aff_check_if_account_exists($email)
{
    global $wpdb;
    $affiliates_table_name = WP_AFF_AFFILIATES_TBL_NAME;	
    $resultset = $wpdb->get_row("SELECT * FROM $affiliates_table_name WHERE email = '$email'", OBJECT);
    if($resultset){
    	return true;
    }
    else{
    	return false;
    }
}

function wp_aff_create_affilate($user_name,$pwd,$acompany,$atitle,$afirstname,$alastname,$awebsite,$aemail,$apayable,$astreet,$atown,$astate,$apostcode,$acountry,$aphone,$afax,$date,$paypal_email,$commission_level,$referrer)
{
    global $wpdb;
    $affiliates_table_name = WP_AFF_AFFILIATES_TBL_NAME;
    $updatedb = "INSERT INTO $affiliates_table_name (refid,pass,company,title,firstname,lastname,website,email,payableto,street,town,state,postcode,country,phone,fax,date,paypalemail,commissionlevel,referrer) VALUES ('".$user_name."', '".$pwd."', '".$acompany."', '".$atitle."', '".$afirstname."', '".$alastname."', '".$awebsite."', '".$aemail."', '".$apayable."', '".$astreet."', '".$atown."', '".$astate."', '".$apostcode."', '".$acountry."', '".$aphone."', '".$afax."', '$date','".$paypal_email."','".$commission_level."','".$referrer."')";
    $results = $wpdb->query($updatedb);
}

function wp_aff_send_sign_up_email($user_name,$pwd,$affiliate_email)
{
        $affiliate_login_url = get_option('wp_aff_login_url');

        $email_subj = get_option('wp_aff_signup_email_subject');            
        $body_sign_up = get_option('wp_aff_signup_email_body');    
        $from_email_address = get_option('wp_aff_senders_email_address');
        $headers = 'From: '.$from_email_address . "\r\n";                   
        
        $tags1 = array("{user_name}","{email}","{password}","{login_url}");            
        $vals1 = array($user_name,$affiliate_email,$pwd,$affiliate_login_url);                    
        $aemailbody = str_replace($tags1,$vals1,$body_sign_up);        

        if (get_option('wp_aff_admin_notification'))
        {
             $admin_email_subj = "New affiliate sign up notification";
             wp_mail($from_email_address, $admin_email_subj, $aemailbody);
        }
        wp_mail($affiliate_email, $email_subj, $aemailbody, $headers);
}

function wp_aff_send_commission_notification($affiliate_email)
{
	if (get_option('wp_aff_notify_affiliate_for_commission'))
	{
        $from_email_address = get_option('wp_aff_senders_email_address');
        $headers = 'From: '.$from_email_address . "\r\n";     	
        $notify_body = AFF_COMMISSION_RECEIVED_NOTIFICATION_BODY;	             
        mail($affiliate_email, AFF_COMMISSION_RECEIVED_NOTIFICATION_SUBJECT, $notify_body,$headers);
    }	
}
function wp_aff_redirect_to_non_affiliate_url()
{
	$curr_page = wp_aff_current_page_url();
	$ap_id_pos = strpos($curr_page,"?ap_id");
	if(empty($ap_id_pos))
	{
		$ap_id_pos = strpos($curr_page,"&ap_id");
	}
	$target_url = substr($curr_page,0,$ap_id_pos);
	header('Location: ' . $target_url);
	exit;	
}

function wp_affiliate_referrer_handler($atts)
{
	$referrer = wp_affiliate_get_referrer();
	if(empty($referrer))
	{
		$referrer = "None";
	}
	return $referrer;
}

function wp_aff_current_page_url() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

function wp_aff_login_widget_init()
{
    $widget_options = array('classname' => 'wp_affiliate_widget', 'description' => __( "Display WP Affiliate Login Widget") );
    wp_register_sidebar_widget('wp_affiliate_widget', __('WP Affiliate Login'), 'show_wp_aff_login_widget', $widget_options);
}

function show_wp_aff_login_widget($args)
{
    extract($args);
    //$widget_title = get_option('wp_aff_login_widget_title');
    $widget_title = AFF_WIDGET_TITLE;
    if (empty($widget_title)) $widget_title = "Affiliate Login";
    echo $before_widget;
    echo $before_title . $widget_title . $after_title;
    echo aff_login_widget();
    echo $after_widget;
}

function wp_aff_front_css()
{
    echo '<link type="text/css" rel="stylesheet" href="'.WP_AFF_PLATFORM_URL.'/affiliate_platform_style.css" />'."\n";
}

//Add the Admin Menus
define("AFFILIATE_MANAGEMENT_PERMISSION", "add_users");
if (is_admin())
{
	function wp_aff_platform_add_admin_menu()
	{
		add_menu_page(__("Affiliate Platform", 'wp_affiliate'), __("WP Affiliate", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, __FILE__, "wp_aff_show_stats");
		add_submenu_page(__FILE__, __("WP Affiliate Settings", 'wp_affiliate'), __("Settings", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'wp_aff_platform_settings', "show_aff_platform_settings_page");		
		add_submenu_page(__FILE__, __("WP Affiliates", 'wp_affiliate'), __("Manage Affiliates", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'affiliates', "aff_top_affiliates_menu");
		add_submenu_page(__FILE__, __("WP Affiliates Edit", 'wp_affiliate'), __("Add/Edit Affiliates", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'affiliates_addedit', "edit_affiliates_menu");		
		add_submenu_page(__FILE__, __("WP Affiliate Banners", 'wp_affiliate'), __("Manage Ads", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'manage_banners', "manage_banners_menu");
		add_submenu_page(__FILE__, __("WP Aff Banner Edit", 'wp_affiliate'), __("Add/Edit Ads", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'edit_banners', "wp_aff_edit_ads_menu");
		add_submenu_page(__FILE__, __("WP Affiliate Leads", 'wp_affiliate'), __("Manage Leads", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'manage_leads', "aff_top_leads_menu");
		add_submenu_page(__FILE__, __("WP Affiliate Clicks", 'wp_affiliate'), __("Click Throughs", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'clickthroughs', "clickthroughs_menu");
		add_submenu_page(__FILE__, __("WP Affiliate Sales", 'wp_affiliate'), __("Sales/Comm Data", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'aff_sales', "aff_top_sales_menu");
		add_submenu_page(__FILE__, __("WP Payouts", 'wp_affiliate'), __("Manage Payouts", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'manage_payouts', "manage_payouts_menu");
		add_submenu_page(__FILE__, __("WP Payouts History", 'wp_affiliate'), __("Payouts History", 'wp_affiliate'), AFFILIATE_MANAGEMENT_PERMISSION, 'payouts_history', "payouts_history_menu");
	}
	//Include menus
	require_once(dirname(__FILE__).'/aff_stats_menu.php');
	require_once(dirname(__FILE__).'/wp_affiliate_platform_menu.php');
	require_once(dirname(__FILE__).'/affiliates_menu.php');
	require_once(dirname(__FILE__).'/leads_menu.php');
	require_once(dirname(__FILE__).'/clickthroughs_menu.php');
	require_once(dirname(__FILE__).'/banners_menu.php');
	require_once(dirname(__FILE__).'/payouts_menu.php');
	require_once(dirname(__FILE__).'/payouts_history_menu.php');
	require_once(dirname(__FILE__).'/sales_menu.php');
}

// Insert the options page to the admin menu
if (is_admin())
{
	add_action('admin_menu','wp_aff_platform_add_admin_menu');
}

function wp_aff_load_libraries()
{
    wp_enqueue_script('jquery'); 	
}

add_action('init', 'wp_aff_login_widget_init');
add_action('init', 'wp_aff_load_libraries');
add_action('wp_head', 'wp_aff_front_css');

add_filter('the_content', 'filter_wp_aff_tx_result');

add_shortcode('wp_aff_award_custom_commission', 'wp_aff_award_custom_commission_handler');
add_shortcode('wp_aff_login', 'wp_aff_login_handler');
add_shortcode('wp_affiliate_view', 'wp_affiliate_view_handler');
add_shortcode('wp_affiliate_referrer', 'wp_affiliate_referrer_handler');

if (!is_admin())
{add_filter('widget_text', 'do_shortcode');}
?>
