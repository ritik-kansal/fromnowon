<?php
//***** Installer *****/
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

//***Installer variables***/
$wp_affiliates_version = "3.4";
global $wpdb;
$affiliates_table_name = $wpdb->prefix . "affiliates_tbl";
$affiliates_clickthroughs_table_name = $wpdb->prefix . "affiliates_clickthroughs_tbl";
$affiliates_sales_table_name = $wpdb->prefix . "affiliates_sales_tbl";
$affiliates_payouts_table_name = $wpdb->prefix . "affiliates_payouts_tbl";
$affiliates_banners_table_name = $wpdb->prefix . "affiliates_banners_tbl";
$affiliates_leads_table_name = $wpdb->prefix . "affiliates_leads_tbl";
//***Installer***/
if($wpdb->get_var("SHOW TABLES LIKE '$affiliates_table_name'") != $affiliates_table_name)
{
$sql = "CREATE TABLE " . $affiliates_table_name . " (
    refid varchar(128) NOT NULL default '',
    pass varchar(128) NOT NULL default '',
    company varchar(100) NOT NULL default '',
    title varchar(5) NOT NULL default '',
    firstname varchar(40) NOT NULL default '',
    lastname varchar(40) NOT NULL default '',
    website varchar(100) NOT NULL default '',
    email varchar(100) NOT NULL default '',
    payableto varchar(100) NOT NULL default '',
    street varchar(100) NOT NULL default '',
    town varchar(100) NOT NULL default '',
    state varchar(100) NOT NULL default '',
    postcode varchar(20) NOT NULL default '',
    country varchar(100) NOT NULL default '',
    phone varchar(30) NOT NULL default '',
    fax varchar(30) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    paypalemail varchar(100) NOT NULL default '',
    commissionlevel varchar(10) NOT NULL default '',
    referrer varchar(30) NOT NULL default '',
    tax_id varchar(128) NOT NULL default '',
    PRIMARY KEY  (refid)
	);";
dbDelta($sql);

// Add default options
add_option("wp_aff_cookie_life", 21);
add_option("wp_aff_commission_level", 25);
add_option("wp_aff_site_title", "WP Affiliate Platform");

add_option("wp_affiliates_version", $wp_affiliates_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$affiliates_clickthroughs_table_name'") != $affiliates_clickthroughs_table_name)
{
$sql = "CREATE TABLE " . $affiliates_clickthroughs_table_name . " (
    refid varchar(128) default 'none',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    browser varchar(200) default 'No information',
    ipaddress varchar(50) default 'No information',
    referralurl varchar(200) default 'none detected (maybe a direct link)',
    buy varchar(10) default 'NO',
    campaign_id varchar(64) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_clickthrough_version", $wp_affiliates_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$affiliates_sales_table_name'") != $affiliates_sales_table_name)
{
$sql = "CREATE TABLE " . $affiliates_sales_table_name . " (
    refid varchar(128) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    browser varchar(200) NOT NULL default '',
    ipaddress varchar(20) NOT NULL default '',
    payment varchar(10) NOT NULL default '',
    sale_amount varchar(10) NOT NULL default '',
    txn_id varchar(64) NOT NULL default '',
    item_id varchar(128) NOT NULL default '',
    buyer_email varchar(128) NOT NULL default '',
    campaign_id varchar(64) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_sales_version", $wp_affiliates_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$affiliates_leads_table_name'") != $affiliates_leads_table_name)
{
$sql = "CREATE TABLE " . $affiliates_leads_table_name . " (
    lead_id int(12) NOT NULL auto_increment,
    buyer_email varchar(128) NOT NULL default '',
	refid varchar(128) NOT NULL default '',
	reference varchar(20) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    ipaddress varchar(20) NOT NULL default '',
    PRIMARY KEY (lead_id)   
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_leads_version", $wp_affiliates_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$affiliates_payouts_table_name'") != $affiliates_payouts_table_name)
{
$sql = "CREATE TABLE " . $affiliates_payouts_table_name . " (
    refid varchar(128) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    payout_payment varchar(10) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_payouts_version", $wp_affiliates_version);
}

if($wpdb->get_var("SHOW TABLES LIKE '$affiliates_banners_table_name'") != $affiliates_banners_table_name)
{
$sql = "CREATE TABLE " . $affiliates_banners_table_name . " (
    number int(12) NOT NULL auto_increment,
    name varchar(50) NOT NULL default '',
    ref_url varchar(255) NOT NULL default '',
    link_text varchar(100) NOT NULL default '',
    image varchar(255) NOT NULL default '',
    description text NOT NULL,
    creative_type varchar(4) NOT NULL default '0',
    PRIMARY KEY  (number)
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_banners_version", $wp_affiliates_version);
}

//***Upgrader***/
$installed_ver = get_option( "wp_affiliates_version" );
if( $installed_ver != $wp_affiliates_version )
{
$sql = "CREATE TABLE " . $affiliates_table_name . " (
    refid varchar(128) NOT NULL default '',
    pass varchar(128) NOT NULL default '',
    company varchar(100) NOT NULL default '',
    title varchar(5) NOT NULL default '',
    firstname varchar(40) NOT NULL default '',
    lastname varchar(40) NOT NULL default '',
    website varchar(100) NOT NULL default '',
    email varchar(100) NOT NULL default '',
    payableto varchar(100) NOT NULL default '',
    street varchar(100) NOT NULL default '',
    town varchar(100) NOT NULL default '',
    state varchar(100) NOT NULL default '',
    postcode varchar(20) NOT NULL default '',
    country varchar(100) NOT NULL default '',
    phone varchar(30) NOT NULL default '',
    fax varchar(30) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    paypalemail varchar(100) NOT NULL default '',
    commissionlevel varchar(10) NOT NULL default '',
    referrer varchar(30) NOT NULL default '',
    tax_id varchar(128) NOT NULL default '',
    PRIMARY KEY  (refid)
	);";
dbDelta($sql);

// Add default options
add_option("wp_aff_cookie_life", 21);
add_option("wp_aff_commission_level", 25);
add_option("wp_aff_contact_email", get_bloginfo('admin_email'));

add_option("wp_affiliates_version", $wp_affiliates_version);
}

$installed_ver = get_option( "wp_affiliates_clickthrough_version" );
if( $installed_ver != $wp_affiliates_version )
{
$sql = "CREATE TABLE " . $affiliates_clickthroughs_table_name . " (
    refid varchar(128) default 'none',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    browser varchar(200) default 'No information',
    ipaddress varchar(50) default 'No information',
    referralurl varchar(200) default 'none detected (maybe a direct link)',
    buy varchar(10) default 'NO',
    campaign_id varchar(64) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_clickthrough_version", $wp_affiliates_version);
}

$installed_ver = get_option( "wp_affiliates_sales_version" );
if( $installed_ver != $wp_affiliates_version )
{
$sql = "CREATE TABLE " . $affiliates_sales_table_name . " (
    refid varchar(128) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    browser varchar(200) NOT NULL default '',
    ipaddress varchar(20) NOT NULL default '',
    payment varchar(10) NOT NULL default '',
    sale_amount varchar(10) NOT NULL default '',
    txn_id varchar(64) NOT NULL default '',
    item_id varchar(128) NOT NULL default '',
    buyer_email varchar(128) NOT NULL default '',
    campaign_id varchar(64) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_sales_version", $wp_affiliates_version);
}

$installed_ver = get_option( "wp_affiliates_leads_version" );
if( $installed_ver != $affiliates_leads_table_name )
{
$sql = "CREATE TABLE " . $affiliates_leads_table_name . " (
    lead_id int(12) NOT NULL auto_increment,
    buyer_email varchar(128) NOT NULL default '',
	refid varchar(128) NOT NULL default '',
	reference varchar(20) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    ipaddress varchar(20) NOT NULL default '',
    PRIMARY KEY (lead_id)   
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_leads_version", $wp_affiliates_version);
}

$installed_ver = get_option( "wp_affiliates_payouts_version" );
if( $installed_ver != $wp_affiliates_version )
{
$sql = "CREATE TABLE " . $affiliates_payouts_table_name . " (
    refid varchar(128) NOT NULL default '',
    date date NOT NULL default '0000-00-00',
    time time NOT NULL default '00:00:00',
    payout_payment varchar(10) NOT NULL default ''
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_payouts_version", $wp_affiliates_version);
}

$installed_ver = get_option( "wp_affiliates_banners_version" );
if( $installed_ver != $wp_affiliates_version )
{
$sql = "CREATE TABLE " . $affiliates_banners_table_name . " (
    number int(12) NOT NULL auto_increment,
    name varchar(50) NOT NULL default '',
    ref_url varchar(255) NOT NULL default '',
    link_text varchar(100) NOT NULL default '',
    image varchar(255) NOT NULL default '',
    description text NOT NULL,
    creative_type varchar(4) NOT NULL default '0',
    PRIMARY KEY  (number)
	);";
dbDelta($sql);
// Add default options
add_option("wp_affiliates_banners_version", $wp_affiliates_version);
}

/********************************************/
/*** Setting default values at activation ***/
/********************************************/
$wp_aff_senders_address = get_bloginfo('name')." <".get_option('admin_email').">";
$wp_aff_signup_email_subject = "Affiliate Login Details";
$wp_aff_signup_email_body = "Thank you for registering with us. Here are your login details...\n".        
        "\nUser ID: {user_name}".
        "\nEmail: {email} \n".
        "\nPasswd: {password} \n".
        "\nYou can Log into the system at the following URL:\n{login_url}\n".           
        "\nPlease log into your account to get banners and view your real-time statistics.\n".        
        "\nThank You".
        "\nAdministrator".
        "\n______________________________________________________".
        "\nTHIS IS AN AUTOMATED RESPONSE. ".
        "\n***DO NOT RESPOND TO THIS EMAIL****";
add_option('wp_aff_senders_email_address', stripslashes($wp_aff_senders_address));
add_option('wp_aff_signup_email_subject', stripslashes($wp_aff_signup_email_subject));
add_option('wp_aff_signup_email_body', stripslashes($wp_aff_signup_email_body));

//***** End Installer *****/
$wpurl = get_option('wpurl');
add_option('wp_aff_default_affiliate_landing_url',$wpurl)
?>