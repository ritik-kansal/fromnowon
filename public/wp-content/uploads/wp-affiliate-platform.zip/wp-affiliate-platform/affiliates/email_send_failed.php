<?php 
//include_once "./lang/$language";
include "header.php"; ?>

  <h2 class="title">Thank You For Joining!</h2>
  <p class="error">There was an error sending the email with the account information, Please Contact the Webmaster.</p>
  <p>
  You can log in <a href=index.php>here.</a>
  </p>
        
<?php include "footer.php"; ?>