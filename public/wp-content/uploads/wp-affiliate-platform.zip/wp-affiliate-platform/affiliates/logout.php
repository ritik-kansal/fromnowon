<?php session_start();
unset($_SESSION['user_id']);
/* Delete the cookies*******************/
setcookie("user_id", '', time()-60*60*24*60, "/");
header("Location: login.php"); ?>