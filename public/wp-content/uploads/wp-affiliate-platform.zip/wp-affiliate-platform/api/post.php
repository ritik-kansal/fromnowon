<?php
include_once('../../../../wp-load.php');
include_once('../wp_aff_includes.php');

$debug_enabled = false;
$debug_log_file_name = 'aff_commission_post_debug.log';

$allow_remote_post = get_option('wp_aff_enable_remote_post');
if(!$allow_remote_post)
{
	echo "Remote POST is disabled";
	wp_aff_api_debug('Remote POST is disabled in the settings.',false);
	exit;
}

wp_aff_api_debug('Start Processing...',true);

if($_GET["data"])
{
	$data = $_GET["data"];
	list($secret,$ap_id,$sale_amt,$txn_id,$item_id,$buyer_email) = explode('|',$data);
	wp_aff_api_debug('GET joined data: '.$secret."|".$ap_id."|".$sale_amt."|".$txn_id."|".$item_id."|".$buyer_email,true);
}
else if($_GET["secret"])
{
	$secret = $_GET["secret"];
	$ap_id = $_GET["ap_id"];
	$sale_amt = $_GET["sale_amt"];
	$txn_id = $_GET["txn_id"];
	$item_id = $_GET["item_id"];
	$buyer_email = $_GET["buyer_email"];
	wp_aff_api_debug('GET individual data: '.$secret."|".$ap_id."|".$sale_amt."|".$txn_id."|".$item_id."|".$buyer_email,true);
}
else if(isset($_POST['secret']))
{
	$secret = $_POST['secret'];
	$ap_id = $_POST['ap_id'];
	$sale_amt = $_POST['sale_amt'];
	$txn_id = $_POST['txn_id'];
	$item_id = $_POST['item_id'];
	$buyer_email = $_POST['buyer_email'];
	wp_aff_api_debug('POST data: '.$secret."|".$ap_id."|".$sale_amt."|".$txn_id."|".$item_id."|".$buyer_email,true);	
}
else
{
	wp_aff_api_debug('Request does not have any GET or POST data.. cannot process request',true);	
	exit;
}


wp_aff_api_debug('Validating Request Data',true);
$true_secret = get_option('wp_aff_secret_word_for_post');
$valid = true;
if(empty($secret))
{
	wp_aff_api_debug('Secret word is missing... cannot process request',true);
	$valid = false;
	exit;
}
else if($secret != $true_secret)
{
	wp_aff_api_debug('Secret word do not match... cannot process request',true);
	$valid = false;
	exit;	
}
if(empty($ap_id))
{
	wp_aff_api_debug('Referrer ID is missing... cannot process request',true);
	$valid = false;
	exit;
}
if(empty($sale_amt))
{
	wp_aff_api_debug('Sale amount is missing... cannot process request',true);
	$valid = false;
	exit;
}

if($valid)
{
	if(wp_aff_true_sale())
	{
		wp_aff_award_commission($ap_id,$sale_amt,$txn_id,$item_id,$buyer_email);
		wp_aff_api_debug('Commission awarded',true);
	}	
}

function wp_aff_api_debug($message,$success,$end=false)
{
	global $debug_enabled,$debug_log_file_name;
    if (!$debug_enabled) return;
    // Timestamp
    $text = '['.date('m/d/Y g:i A').'] - '.(($success)?'SUCCESS :':'FAILURE :').$message. "\n";
    if ($end) {
    	$text .= "\n------------------------------------------------------------------\n\n";
    }
    // Write to log
    $fp=fopen($debug_log_file_name,'a');
    fwrite($fp, $text );
    fclose($fp);  // close file
}

?>