<?php

$affiliates_clickthroughs_table_name = $wpdb->prefix . "affiliates_clickthroughs_tbl";

function clickthroughs_menu()
{
	echo '<div class="wrap"><h2>WP Affiliate Platform - Clickthrough Data</h2>';
	
	if(!aff_detect_ie())
	{
    	aff_handle_date_form();    	
	}
	else
	{
		aff_handle_date_form_in_ie();
	}	
	
    if (isset($_POST['info_update']))
    {
    	$start_date = (string)$_POST["start_date"];
    	$end_date = (string)$_POST["end_date"];
        echo '<div id="message" class="updated fade"><p><strong>';
        echo 'Displaying Clicks History Between '.$start_date.' And '. $end_date;
        echo '</strong></p></div>';
		        	
		$curr_date = (date ("Y-m-d"));
		
		global $affiliates_clickthroughs_table_name;
		global $wpdb;
		
		echo '
		<table class="widefat">
		<thead><tr>
		<th scope="col">'.__('Affiliate ID', 'wp_affiliate').'</th>
		<th scope="col">'.__('Date', 'wp_affiliate').'</th>
		<th scope="col">'.__('Time', 'wp_affiliate').'</th>
		<th scope="col">'.__('IP Address', 'wp_affiliate').'</th>';
		if(get_option('wp_aff_enable_clicks_custom_field') != '')
		{
			echo '<th scope="col">'.__('Custom Value', 'wp_affiliate').'</th>';
		}
		echo '<th scope="col">'.__('Referral URL', 'wp_affiliate').'</th>
		<th scope="col"></th>
		</tr></thead>
		<tbody>';
			
		$wp_aff_clicks = $wpdb->get_results("SELECT * FROM $affiliates_clickthroughs_table_name WHERE date BETWEEN '$start_date' AND '$end_date'", OBJECT);
		if ($wp_aff_clicks)
		{
			foreach ($wp_aff_clicks as $wp_aff_clicks)
			{
				echo '<tr>';
				echo '<td><strong>'.$wp_aff_clicks->refid.'</strong></td>';
				echo '<td><strong>'.$wp_aff_clicks->date.'</strong></td>';
				echo '<td><strong>'.$wp_aff_clicks->time.'</strong></td>';
				echo '<td><strong>'.$wp_aff_clicks->ipaddress.'</strong></td>';
				if(get_option('wp_aff_enable_clicks_custom_field') != '')
				{
					echo '<td><strong>'.$wp_aff_clicks->campaign_id.'</strong></td>';
				}
				echo '<td><strong>'.$wp_aff_clicks->referralurl.'</strong></td>';
				echo '</tr>';					
			}	
		}
		else
		{
			echo '<tr> <td colspan="6">'.__('No Click Data Found.', 'wp_affiliate').'</td> </tr>';
		}		
		echo '</tbody></table>';
	}
	else
	{
		show_last_clickthroughs();
	}
	
	echo '</div>';
}

function show_last_clickthroughs()
{
    echo '<div id="message" class="updated fade"><p><strong>';
    echo 'Displaying 20 Recent Clicks Data';
    echo '</strong></p></div>';	
    
	echo '
	<table class="widefat">
	<thead><tr>
	<th scope="col">'.__('Affiliate ID', 'wp_affiliate').'</th>
	<th scope="col">'.__('Date', 'wp_affiliate').'</th>
	<th scope="col">'.__('Time', 'wp_affiliate').'</th>
	<th scope="col">'.__('IP Address', 'wp_affiliate').'</th>';
	if(get_option('wp_aff_enable_clicks_custom_field') != '')
	{
		echo '<th scope="col">'.__('Custom Value', 'wp_affiliate').'</th>';
	}
	echo '<th scope="col">'.__('Referral URL', 'wp_affiliate').'</th>
	<th scope="col"></th>
	</tr></thead>
	<tbody>';

	global $wpdb;
	global $affiliates_clickthroughs_table_name;
	$wp_aff_clicks_db = $wpdb->get_results("SELECT * FROM $affiliates_clickthroughs_table_name ORDER BY date DESC LIMIT 20", OBJECT);

	if ($wp_aff_clicks_db)
	{
		foreach ($wp_aff_clicks_db as $wp_aff_clicks_db)
		{
			echo '<tr>';
			echo '<td>'.$wp_aff_clicks_db->refid.'</td>';
			echo '<td><strong>'.$wp_aff_clicks_db->date.'</strong></td>';
			echo '<td><strong>'.$wp_aff_clicks_db->time.'</strong></td>';
			echo '<td><strong>'.$wp_aff_clicks_db->ipaddress.'</strong></td>';
			if(get_option('wp_aff_enable_clicks_custom_field') != '')
			{
				echo '<td><strong>'.$wp_aff_clicks_db->campaign_id.'</strong></td>';
			}			
			echo '<td><strong>'.$wp_aff_clicks_db->referralurl.'</strong></td>';
			echo '</tr>';
		}
	}
	else
	{
		echo '<tr> <td colspan="8">'.__('No Click Data Found.', 'wp_affiliate').'</td> </tr>';
	}

	echo '</tbody>
	</table>';	
}
?>
