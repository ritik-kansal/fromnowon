<?php
/*
Plugin Name: WP Affiliate Platform
Version: v4.4.4
Plugin URI: http://tipsandtricks-hq.com/wordpress-affiliate/
Author: Ruhul Amin
Author URI: http://www.tipsandtricks-hq.com/
Description: Simple Affiliate Platform for your wordpress blog. Allows your visitors to get an affiliate link for your products and promote it from their blog/site and in return they receive a commission when a sale is made through their link.
*/
define('WP_AFFILIATE_PLATFORM_VERSION', "4.4.4");
include_once('wp_affiliate_platform1.php');
//Installer
function wp_aff_platform_install ()
{
	require_once(dirname(__FILE__).'/affiliate_platform_installer.php');
}
register_activation_hook(__FILE__,'wp_aff_platform_install');
//register_activation_hook( basename(__FILE__), 'wp_aff_platform_install' );

function wp_aff_add_settings_link($links, $file) 
{
	if ($file == plugin_basename(__FILE__)){
		$settings_link = '<a href="admin.php?page=wp_aff_platform_settings">Settings</a>';
		array_unshift($links, $settings_link);
	}
	return $links;
}
add_filter('plugin_action_links', 'wp_aff_add_settings_link', 10, 2 );
?>