<?php
$aff_tx_msg = '';
$aff_error_msg = ''; 

/*** Start of deprecated code (need to be deleted) ***/
function wp_aff_display_transaction_result()
{
	global $aff_tx_msg,$aff_error_msg;   
	$output .= '<h4>The commission award result</h4>'; 
    if (empty($aff_error_msg))
    {
    	$output .= '<div STYLE="word-wrap: break-word">';    	
    	$output .= $aff_tx_msg.'<br />';
    	$output .= '</div>';
    }
    else
    {
    	$output .= '<br />'.$aff_error_msg.'<br />';
    }    
    return $output;	
}

function verify_payment_data()
{
	global $aff_tx_msg,$aff_error_msg;
    $req = 'cmd=_notify-validate';
    
    foreach ($_POST as $key => $value) {
    $value = urlencode(stripslashes($value));
    $req .= "&$key=$value";
    }
    
    $sandbox_enabled = get_option('wp_aff_sandbox_mode');
    $header = "POST /cgi-bin/webscr HTTP/1.0\r\n";     
    if($sandbox_enabled)
    {
   		$header .= "Host: www.sandbox.paypal.com:443\r\n";
    }
    else
    {
    	$header .= "Host: www.paypal.com:443\r\n";
    }
    $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
    $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";

   	if($sandbox_enabled)
   	{
   		$url_parsed=parse_url('https://www.sandbox.paypal.com/cgi-bin/webscr');   		
   	}
    else
    {
    	$url_parsed=parse_url('https://www.paypal.com/cgi-bin/webscr');
    }    
    $fp = fsockopen ($url_parsed['host'], "80", $errno, $errstr, 30);    
    if (!$fp) {
    	$aff_error_msg .= '<br />HTTP ERROR... could not establish a connection to PayPal for verification';
    } 
    else 
    {
    	fputs ($fp, $header . $req);
	    while (!feof($fp)) 
	    {
	    	$res = fgets ($fp, 1024);
		    if (strcmp ($res, "VERIFIED") == 0) {
			    // check the payment_status is Completed
			    // check that txn_id has not been previously processed
			    // check that receiver_email is your Primary PayPal email
			    // check that payment_amount/payment_currency are correct
			    // award commission payment
			    $aff_tx_msg .= "Payment verified... awarding commission if this was a referred sale.";
			    wp_aff_prepare_data();		    
		    }
		    else if (strcmp ($res, "INVALID") == 0) {
		    	$aff_error_msg .= '<br />Could not verify the authenticity of the payment with PayPal';		    
		    }
	    }
    	fclose ($fp);
    }
}
/******************************/
/*** End of deprecated code ***/
/******************************/

function wp_aff_process_PDT_payment_data($keyarray)
{
    $gross_total = $keyarray['mc_gross'];	
    $sale_amount = $keyarray['mc_gross'] - $keyarray['mc_shipping'] - $keyarray['mc_handling'];	    
    $txn_id = $keyarray['txn_id'];
    $item_id = $keyarray['item_number'];
    $buyer_email = $keyarray['payer_email'];
	$referrer = wp_affiliate_get_referrer();  
	wp_aff_award_commission($referrer,$sale_amount,$txn_id,$item_id,$buyer_email);
}
function wp_affiliate_get_referrer()
{
	if (!empty($_SESSION['ap_id']))
	{
	    $referrer = $_SESSION['ap_id'];
	}
	else if (isset($_COOKIE['ap_id']))
	{
	    $referrer = $_COOKIE['ap_id'];
	}	
	return $referrer;
}
function wp_aff_prepare_data()
{
	global $aff_tx_msg,$aff_error_msg;
    $gross_total = $_POST['mc_gross'];	
    $sale_amount = $_POST['mc_gross'] - $_POST['mc_shipping'] - $_POST['mc_handling'];	    
    $txn_id = $_POST['txn_id'];
    $item_id = '';
    $buyer_email = $_POST['payer_email'];
	$referrer = wp_affiliate_get_referrer();  
	wp_aff_award_commission($referrer,$sale_amount,$txn_id,$item_id,$buyer_email);
}
function wp_aff_award_commission($referrer,$sale_amount,$txn_id,$item_id,$buyer_email,$clientip='')
{
	global $aff_tx_msg,$aff_error_msg;
	$commission_award_result = "";
	$aff_tx_msg .= "<br />Referrer: ".$referrer. ", Sale Amount: ".$sale_amount.", Transaction ID: ".$txn_id;
    $clientdate = (date ("Y-m-d"));
	$clienttime	= (date ("H:i:s"));
	if(empty($clientip))
	{
		$clientip = $_SERVER['REMOTE_ADDR'];
	}	
        if(empty($txn_id))
        {
            $txn_id = uniqid();
        }
	if (!empty($referrer))
	{
		global $wpdb;
		$affiliates_table_name = $wpdb->prefix . "affiliates_tbl";
		$aff_sales_table = $wpdb->prefix . "affiliates_sales_tbl";
		$wp_aff_affiliates_db = $wpdb->get_row("SELECT * FROM $affiliates_table_name WHERE refid = '$referrer'", OBJECT);
		$commission_level = $wp_aff_affiliates_db->commissionlevel;
		if (get_option('wp_aff_use_fixed_commission'))
		{
            $commission_amount = $commission_level;
        }
        else
        {
		    $commission_amount = ($commission_level * $sale_amount)/100;
        }
		
        //$aff_version = get_option('wp_aff_platform_version')        
        $c_id='';
       	$updatedb = "INSERT INTO $aff_sales_table (refid,date,time,browser,ipaddress,payment,sale_amount,txn_id,item_id,buyer_email,campaign_id) VALUES ('$referrer','$clientdate','$clienttime','','$clientip','$commission_amount','$sale_amount','$txn_id','$item_id','$buyer_email','$c_id')";		
       	$results = $wpdb->query($updatedb);	
		if(!$results)
		{
			$aff_tx_msg .= "<br />The database update query failed for table: ".$aff_sales_table;
		}		
		else
		{		
			$aff_tx_msg .= '<br />The sale has been registered in the WP Affiliates Platform Database for referrer: '.$referrer.' with amount: '.$commission_amount;
		}
		wp_aff_send_commission_notification($wp_aff_affiliates_db->email);
		
		// 2nd tier commission
		$commission_award_result = wp_aff_award_second_tier_commission($wp_aff_affiliates_db,$sale_amount,$txn_id,$item_id,$buyer_email);
	}
	return $commission_award_result;		
}

function wp_aff_award_second_tier_commission($wp_aff_affiliates_db,$sale_amount,$txn_id,$item_id,$buyer_email)
{
	global $aff_tx_msg;
    $clientdate = (date ("Y-m-d"));
	$clienttime	= (date ("H:i:s"));	
		
		if (get_option('wp_aff_use_2tier') && !empty($wp_aff_affiliates_db->referrer))
		{
			$aff_tx_msg .= '<br />Using tier model';
			$award_tier_commission = true;	
			$duration = get_option('wp_aff_2nd_tier_duration');		
			if(!empty($duration))
			{
				$join_date = $wp_aff_affiliates_db->date;
				$days_since_joined = round((strtotime(date("Y-m-d")) - strtotime($join_date) ) / (60 * 60 * 24));
				
				if ($days_since_joined > $duration)
				{
					$aff_tx_msg .= '<br />Tier commission award duration expried';
					$award_tier_commission = false;
				}
			}				
			if ($award_tier_commission)
			{
				$second_tier_commission_level = get_option('wp_aff_2nd_tier_commission_level');
				if (get_option('wp_aff_use_fixed_commission'))
				{
                                    $commission_amount = $second_tier_commission_level;
                                }
                                else
                                {
				    $commission_amount = round(($second_tier_commission_level * $sale_amount)/100,2);
                                }
				global $wpdb;
				$aff_sales_table = $wpdb->prefix . "affiliates_sales_tbl";				
				$updatedb = "INSERT INTO $aff_sales_table (refid,date,time,browser,ipaddress,payment,sale_amount,txn_id,item_id,buyer_email) VALUES ('$wp_aff_affiliates_db->referrer','$clientdate','$clienttime','','','$commission_amount','$sale_amount','$txn_id','$item_id','$buyer_email')";
				$results = $wpdb->query($updatedb);	
				$aff_tx_msg .= '<br />Tier commission awarded to: '.$wp_aff_affiliates_db->referrer.'. Commission amount: '.$commission_amount;	
			}			
		}	
		return $aff_tx_msg;
}

function wp_aff_handle_refund($unique_txn_id)
{
    $allow_refund = get_option('wp_aff_commission_reversal');
    if ($allow_refund)
    {
        global $wpdb;
        $sales_table = $wpdb->prefix . "affiliates_sales_tbl";
        $wp_aff_sales = $wpdb->get_results("SELECT * FROM $sales_table WHERE txn_id = '$unique_txn_id'", OBJECT);
        
        if ($wp_aff_sales)
        {
        	foreach ($wp_aff_sales as $wp_aff_sales)
        	{
				$referrer = $wp_aff_sales->refid;
				$clientdate = (date ("Y-m-d"));
	        	$clienttime	= (date ("H:i:s"));
				$commission_amount = "-".$wp_aff_sales->payment;
				$sale_amount = "-".$wp_aff_sales->sale_amount;
				$txn_id = $unique_txn_id;
		        $item_id = $wp_aff_sales->item_id;
		    	$buyer_email = $wp_aff_sales->buyer_email;
	
		      	$updatedb = "INSERT INTO $sales_table (refid,date,time,browser,ipaddress,payment,sale_amount,txn_id,item_id,buyer_email) VALUES ('$referrer','$clientdate','$clienttime','','','$commission_amount','$sale_amount','$txn_id','$item_id','$buyer_email')";
				$results = $wpdb->query($updatedb);
        	}
        }
    }
}
?>
