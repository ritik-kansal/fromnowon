<?php
define('WP_AFFILIATE_DO_NOT_OVERRIDE_AFFILIATE_COOKIE', '0');//Set it to 1 to enable this
define('WP_AFFILIATE_AUTO_REDIRECT_TO_NOT_AFFILIATE_URL', '0');//Set it to 1 to enable this
define('WP_AFFILIATE_NO_COMMISSION_FOR_SELF_PURCHASE', '0');//Set it to 1 to enable this
define('WP_AFFILIATE_ENABLE_CLICKBANK_INTEGRATION', '0');//Set it to 1 to enable this
define('WP_AFFILIATE_ENABLE_UTF_8_ENCODING', '0');//Set it to 1 to enable this
//define('WP_AFFILIATE_AUTO_LOGIN_WP_USERS', '0');//This opiton now exists in the "Settings -> WP User Settings" section
define('WP_AFFILIATE_ENABLE_NOFOLLOW_IN_AFFILIATE_ADS', '0');//Set it to 1 to enable this
define('WP_AFFILIATE_SHOW_EPC_DATA_TO_AFFILIATES', '0');//Set it to 1 to enable this
